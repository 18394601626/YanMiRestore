# 语言专项指南与本轮验证边界｜rc.23

30项是指南集合，不是全运行时认证。下表来自本轮14阶段工作树执行，最终ZIP复验另见外部核验记录。

| 语言 | 本轮状态 | 已执行核心契约 | 范围 |
|---|---|---:|---|
| go | CONTROLLED_PASS | 11 | 11 known multi-module checks, plus resource replay; not 11 independent code generation tasks |
| java | CONTROLLED_PASS | 10 | 10 JDK-only paired scenarios; not Spring |
| rust | BLOCKED | 0 | supplied rc14 standard-library fixture only |
| c | CONTROLLED_PASS | 12 | 12 C core tests, plus extra tests in separate configurations |
| cpp | CONTROLLED_PASS | 10 | 10 C++ core tests plus C/C++ linkage and extra tests |
| python | CONTROLLED_PASS | 6 | rc17 fixed fixture; six contracts; one local toolchain |
| javascript | CONTROLLED_PASS | 6 | rc17 fixed fixture; six contracts; one local toolchain |
| typescript | CONTROLLED_PASS | 6 | rc17 fixed fixture; six contracts; one local toolchain |
| php | CONTROLLED_PASS | 6 | rc17 fixed fixture; six contracts; one local toolchain |
| ruby | CONTROLLED_PASS | 6 | rc17 fixed fixture; six contracts; one local toolchain |
| kotlin | CONTROLLED_PASS | 6 | rc17 fixed fixture; six contracts; one local toolchain |
| swift | CONTROLLED_PASS | 6 | rc17 fixed fixture; six contracts; one local toolchain |
| perl | CONTROLLED_PASS | 6 | rc17 fixed fixture; six contracts; one local toolchain |
| bash | CONTROLLED_PASS | 6 | rc17 fixed fixture; six contracts; one local toolchain |
| fortran | CONTROLLED_PASS | 6 | rc17 fixed fixture; six contracts; one local toolchain |
| csharp | BLOCKED | 0 | supplied rc18 source; no framework test |
| dart | BLOCKED | 0 | supplied rc18 source; no framework test |
| objective-c | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |
| scala | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |
| groovy | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |
| fsharp | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |
| vbnet | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |
| r | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |
| julia | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |
| matlab | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |
| lua | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |
| powershell | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |
| sql | CONTROLLED_PASS | 12 | SQLite file database only, 12 core tests plus separately listed regression groups |
| elixir | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |
| erlang | GUIDE_ONLY | 0 | 仅指南；没有当前可执行夹具 |

JDK不等于Spring、SQLite不等于其他数据库、Swift/Linux不等于Apple平台。各语言数量是不同来源口径且可能重复，不合并为编码任务数。独立模型、IDE加载、全书语义审稿均未执行。
