"""Adversarial tests of the UNMODIFIED rc.8 Python evaluator.

These are evaluator unit/injection tests, NOT Spring/DB runs, agent outputs,
true A/B trials, or proof of business-code failure. Synthetic XML and runtime
metadata are deliberately controlled test inputs. New assertions are proposed
acceptance requirements. Failures are preserved; the release is not patched.
"""
from __future__ import annotations
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parents[1]
ROOT = Path(os.environ.get('RC8_RELEASE_ROOT', str(BASE/'source/clean-code-skill-pack-v1.1.0-rc.8'))).resolve()
SOURCE = ROOT/'evals/rc8/run_integration.py'
spec = importlib.util.spec_from_file_location('unchanged_rc8_runner', SOURCE)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
CONTRACT = json.loads((SOURCE.parent/'contract.json').read_text())
CLASS = CONTRACT['class']
METHODS = CONTRACT['tests']
EXPECTED = {(CLASS, n) for n in METHODS}
FAILURES = set(CONTRACT['expected_baseline_failures'])
OBS = []


def xml_report(fixture='fixed', failure_reason='expected', flaky=None):
    root = ET.Element('testsuite', name=CLASS, tests=str(len(METHODS)),
                      failures=str(len(FAILURES) if fixture == 'baseline' else 0), errors='0', skipped='0')
    for name in METHODS:
        case = ET.SubElement(root, 'testcase', classname=CLASS, name=name, time='0.001')
        if fixture == 'baseline' and name in FAILURES:
            message = ('UNRELATED: fixture precondition was wrong; target behavior never observed'
                       if failure_reason == 'unrelated' else 'EXPECTED_CONTROL_ASSERTION: '+name)
            ET.SubElement(case, 'failure', type='org.opentest4j.AssertionFailedError', message=message).text = message
        if flaky and name == 'runtimeIdentity':
            ET.SubElement(case, flaky, type='java.lang.AssertionError', message='failed first attempt, passed retry').text='first failure'
    return ET.tostring(root, encoding='utf-8', xml_declaration=True)


def parsed(raw, code=0):
    with tempfile.TemporaryDirectory(prefix='xml-probe-', dir=BASE/'probes') as tmp:
        p = Path(tmp)/'TEST-contract.xml';p.write_bytes(raw)
        return runner.evaluate_reports(Path(tmp), code, EXPECTED)


def pipeline(runtime_kind='valid', failure_reason='expected'):
    """Call the real orchestrator; mock only environment/process boundary.
    The fixture test subprocess NEVER runs. This is not integration evidence.
    """
    def pretend_execute(command, cwd, log, timeout):
        cwd=Path(cwd); fixture='baseline' if cwd.name.endswith('-baseline') else 'fixed'
        target=cwd/'target';reports=target/'surefire-reports';reports.mkdir(parents=True)
        (reports/'TEST-contract.xml').write_bytes(xml_report(fixture, failure_reason))
        Path(log).write_text('SYNTHETIC ORCHESTRATION UNIT TEST; NO JAVA OR DATABASE EXECUTED.\n')
        meta={'springBoot':'3.5.6','databaseProduct':'PostgreSQL','databaseVersion':'16.4',
              'imageTag':'postgres:16.4','fixtureMode':fixture}
        if runtime_kind=='wrong-engine':meta['databaseProduct']='H2'
        if runtime_kind=='wrong-mode':meta['fixtureMode']='fixed' if fixture=='baseline' else 'baseline'
        if runtime_kind=='malformed':(target/'rc8-runtime.json').write_text('{bad-json')
        elif runtime_kind!='missing':(target/'rc8-runtime.json').write_text(json.dumps(meta))
        return {'status':'FINISHED','exit_code':1 if fixture=='baseline' else 0,
                'command':command,'synthetic_process_stub':True}
    with tempfile.TemporaryDirectory(prefix='pipeline-probe-', dir=BASE/'probes') as tmp:
        out=Path(tmp)/'fresh-output'
        with patch.object(runner,'prerequisites',return_value={'status':'READY_FOR_ATTEMPT','issues':[], 'synthetic_environment':True}), \
             patch.object(runner,'execute',side_effect=pretend_execute), \
             contextlib.redirect_stdout(io.StringIO()):
            try:
                code=runner.run(out,['postgres'],True)
            except Exception as exc:
                return {'kind':'SYNTHETIC_ORCHESTRATION_UNIT_TEST','uncaught_exception':type(exc).__name__,
                        'reason':str(exc),'summary_written':(out/'summary.json').exists()}
        s=json.loads((out/'summary.json').read_text())
        return {'kind':'SYNTHETIC_ORCHESTRATION_UNIT_TEST','orchestrator_exit':code,
                'status':s['status'],'items':[{'fixture':x['fixture'],'status':x['status'],
                    'comparison_confirmed':x['comparison_confirmed'],'runtime':x.get('runtime')}
                    for x in s['integration_results']]}


class FrozenRunnerProbes(unittest.TestCase):
    def remember(self, expected, observed, rationale):
        OBS.append({'id':self._testMethodName,'input_kind':'evaluator_unit_input_not_framework_execution',
                    'expected_requirement':expected,'observed':observed,'rationale':rationale})

    def test_01_plain_reports_positive_control(self):
        r=parsed(xml_report());self.remember('PASS',r,'All 13 required testcase records exist.')
        self.assertEqual(r['status'],'PASS')

    def test_02_skipped_target_rejected_control(self):
        root=ET.fromstring(xml_report());root.set('skipped','1');ET.SubElement(root.find('testcase'),'skipped')
        r=parsed(ET.tostring(root));self.remember('SKIP',r,'A skipped target is not a verified target.')
        self.assertEqual(r['status'],'SKIP')

    def test_03_missing_target_rejected_control(self):
        root=ET.fromstring(xml_report());root.remove(root.find('testcase'));root.set('tests','12')
        r=parsed(ET.tostring(root));self.remember('INCOMPLETE',r,'Missing mandatory method.')
        self.assertEqual(r['status'],'INCOMPLETE')

    def test_04_inconsistent_counts_rejected_control(self):
        root=ET.fromstring(xml_report());root.set('tests','999')
        r=parsed(ET.tostring(root));self.remember('INVALID_EVIDENCE',r,'Aggregate count must match records.')
        self.assertEqual(r['status'],'INVALID_EVIDENCE')

    def test_05_utf8_doctype_rejected_control(self):
        body=xml_report().decode().split('?>',1)[1]
        raw=('<?xml version="1.0" encoding="UTF-8"?><!DOCTYPE testsuite [<!ENTITY label "small-test-only">]>'+body).encode()
        r=parsed(raw);self.remember('INVALID_EVIDENCE',r,'Preserve existing no-DTD policy.')
        self.assertEqual(r['status'],'INVALID_EVIDENCE')

    def test_06_utf16_doctype_must_also_be_rejected(self):
        body=xml_report().decode().split('?>',1)[1]
        raw=('<?xml version="1.0" encoding="UTF-16"?><!DOCTYPE testsuite [<!ENTITY label "small-test-only">]>'+body.replace('time="0.001"','time="0.001" label="&label;"',1)).encode('utf-16')
        r=parsed(raw);self.remember('INVALID_EVIDENCE',r,'Encoding must not bypass the declared no-DTD policy; benign tiny entity only.')
        self.assertEqual(r['status'],'INVALID_EVIDENCE')

    def test_07_flaky_failure_cannot_disappear(self):
        r=parsed(xml_report(flaky='flakyFailure'));self.remember('Reported retry history or non-unqualified-PASS',r,'Surefire flakyFailure means first attempt failed, later retry passed.')
        self.assertTrue(r['status']!='PASS' or r.get('flaky') or r.get('retries') or r.get('warnings'),r)

    def test_08_flaky_error_cannot_disappear(self):
        r=parsed(xml_report(flaky='flakyError'));self.remember('Reported retry history or non-unqualified-PASS',r,'Do not collapse error-then-pass into first-attempt success.')
        self.assertTrue(r['status']!='PASS' or r.get('flaky') or r.get('retries') or r.get('warnings'),r)

    def test_09_valid_pipeline_positive_control(self):
        r=pipeline();self.remember('EXPECTED_OBSERVATIONS_REPRODUCED',r,'Control of the evaluator only; Java process replaced with synthetic outputs.')
        self.assertEqual(r.get('status'),'EXPECTED_OBSERVATIONS_REPRODUCED')

    def test_10_same_names_wrong_failures_not_confirmed(self):
        r=pipeline(failure_reason='unrelated');self.remember('Do not confirm the intended negative control',r,'Method names match, but all failures explicitly describe unrelated preconditions.')
        self.assertNotEqual(r.get('status'),'EXPECTED_OBSERVATIONS_REPRODUCED')

    def test_11_missing_runtime_identity_not_confirmed(self):
        r=pipeline(runtime_kind='missing');self.remember('Missing provenance must be disclosed, not fully confirmed',r,'Reports say runtimeIdentity passed but its mandatory identity artifact is absent.')
        self.assertNotEqual(r.get('status'),'EXPECTED_OBSERVATIONS_REPRODUCED')

    def test_12_contradictory_database_not_confirmed(self):
        r=pipeline(runtime_kind='wrong-engine');self.remember('Reject contradictory runtime evidence',r,'Requested PostgreSQL but supplied identity says H2; this is not a real H2 run.')
        self.assertNotEqual(r.get('status'),'EXPECTED_OBSERVATIONS_REPRODUCED')

    def test_13_swapped_fixture_identity_not_confirmed(self):
        r=pipeline(runtime_kind='wrong-mode');self.remember('Reject swapped candidate identities',r,'baseline result labeled fixed and vice versa.')
        self.assertNotEqual(r.get('status'),'EXPECTED_OBSERVATIONS_REPRODUCED')

    def test_14_malformed_identity_preserves_summary(self):
        r=pipeline(runtime_kind='malformed');self.remember('Structured evidence error and summary retained',r,'A corrupt JSON attachment should not erase the whole run summary.')
        self.assertNotIn('uncaught_exception',r)
        self.assertNotEqual(r.get('status'),'EXPECTED_OBSERVATIONS_REPRODUCED')

    def test_15_real_nonzero_process_control(self):
        with tempfile.TemporaryDirectory(prefix='process-',dir=BASE/'probes') as tmp:
            r=runner.execute([sys.executable,'-c','raise SystemExit(3)'],tmp,Path(tmp)/'output.log',5)
        self.remember('FINISHED exit 3',r,'Real child process; not a Java integration test.')
        self.assertEqual((r['status'],r['exit_code']),('FINISHED',3))

    def test_16_real_timeout_process_control(self):
        with tempfile.TemporaryDirectory(prefix='process-',dir=BASE/'probes') as tmp:
            r=runner.execute([sys.executable,'-c','import time; time.sleep(5)'],tmp,Path(tmp)/'output.log',0.15)
        self.remember('TIMEOUT',r,'Real sleeping child terminated by runner.')
        self.assertEqual(r['status'],'TIMEOUT')


if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(FrozenRunnerProbes))
    path=BASE/'evidence/probe-observations.json'
    data={'classification':'tests_of_existing_evaluator_not_framework_or_agent_AB',
          'release_runner_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
          'test_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),
          'records':OBS}
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
