#include <stdio.h>
#include <string.h>
int main(int argc,char **argv) {
    if(argc!=2) return 2;
    if(strcmp(argv[1],"matching")==0) {
        puts("CONTRACT_FAIL T1:42: expected reason");
        puts("CASE_FAIL T1");
        return 1;
    }
    if(strcmp(argv[1],"borrowed")==0) {
        puts("note: this suite also checks expected reason");
        puts("CONTRACT_FAIL T1:42: unrelated precondition");
        puts("CASE_FAIL T1");
        return 1;
    }
    if(strcmp(argv[1],"false-success")==0) {
        puts("CONTRACT_FAIL T1:42: actual failed assertion");
        puts("CASE_OK T1");
        return 0;
    }
    return 2;
}
