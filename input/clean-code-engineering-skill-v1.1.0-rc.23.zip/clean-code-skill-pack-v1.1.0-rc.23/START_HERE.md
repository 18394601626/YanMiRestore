# 从这里开始｜rc.23

## 安装

将轻量包中的整个 `clean-code-engineering` 文件夹放入项目既有技能目录，保留references、book与assets。先备份并比较自定义修改，不同时启用同名两个版本。安装不会修改业务项目、安装编译器或自动运行检查。

工具修复位于完整包的evals，不在轻量技能目录。根入口如下：

```bash
python -S verify.py --plan
python -S verify.py --profile tools --output ../clean-code-tools
python -S verify.py --profile full --output ../clean-code-full
```

输出目录必须不存在、位于包外。开始和结束核对SHA256SUMS.txt。建议Linux使用没有注入全局启动钩子的系统Python；旧进程测试有固定启动握手预算，不通过不能跳过或改阈值冒充通过。

`full`是`--plan`列出的14阶段，不是每个历史入口、全部框架或30语言全部运行。`GUIDE_ONLY`表示只有指南；工具缺失为`BLOCKED`；`NOT_RUN`表示本次没有执行；核心子范围通过但计划中的补充阶段不完整，语言条目标`INCOMPLETE`而不是完整通过。

退出0：请求范围通过；1：失败/无效或不完整证据；2：部分阻塞；130：中断。收到非法JSON结构时保留无效阶段与原报告，继续独立阶段；派生矩阵出错会保留最终失败汇总和inventory_error，不把RUNNING残留写成成功。存储本身不可写、强杀、远程进程清理、真实性和用户授权不由此证明。

原书198卡、274目录、54项待细化保持；没有独立模型对照或IDE实际加载证明。最终运行结果与精确环境请读VALIDATION，而不是复用历史支持状态。
