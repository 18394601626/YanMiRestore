"""Read trusted Go `test -json` captures against a caller-supplied test inventory.

This is a fixture/report checker, not a sandbox, an agent evaluator, or a proof
that arbitrary test code is honest. It never executes code or reparses Output as
JSON. Compilation is a separate phase; diagnostics printed by a running test do
not establish a compiler failure. Python 3.9+, no third-party dependencies.
"""
from dataclasses import dataclass
import json
from typing import Dict, Iterable, Optional, Tuple

Target = Tuple[str, str]
TERMINAL = {'pass', 'fail', 'skip'}
ACTIONS = TERMINAL | {'start', 'run', 'pause', 'cont', 'output', 'bench'}


@dataclass
class Capture:
    exit_code: Optional[int]
    stdout: str
    stderr: str = ''
    timed_out: bool = False
    interrupted: bool = False
    start_error: str = ''


def _within(test: Target, parent: Target) -> bool:
    return test[0] == parent[0] and (test[1] == parent[1] or
                                   test[1].startswith(parent[1] + '/'))


def _decode(text: str):
    tests: Dict[Target, dict] = {}
    packages = {}
    for number, line in enumerate(text.splitlines(), 1):
        if not line.strip():
            continue
        try:
            item = json.loads(line)
        except (ValueError, TypeError) as exc:
            raise ValueError('invalid JSON at line %d' % number) from exc
        if not isinstance(item, dict):
            raise ValueError('event must be an object at line %d' % number)
        action, package, name = item.get('Action'), item.get('Package'), item.get('Test', '')
        if (not isinstance(action, str) or action not in ACTIONS or
                not isinstance(package, str) or not package or not isinstance(name, str)):
            raise ValueError('invalid event fields at line %d' % number)
        if not isinstance(item.get('Output', ''), str):
            raise ValueError('invalid Output at line %d' % number)
        if action == 'start':
            if name or package in packages:
                raise ValueError('duplicate/invalid package start at line %d' % number)
            packages[package] = {'terminal': None}
            continue
        if package not in packages:
            raise ValueError('package event without start at line %d' % number)
        if packages[package]['terminal'] is not None:
            raise ValueError('event after package finish at line %d' % number)
        if not name:
            if action in TERMINAL:
                packages[package]['terminal'] = action
            elif action not in ('output', 'bench'):
                raise ValueError('unexpected package action at line %d' % number)
            continue
        test = tests.setdefault((package, name),
                                {'runs': 0, 'active': False, 'terminals': [], 'output': [], 'attempts': []})
        if action == 'run':
            if test['active']:
                raise ValueError('test started twice at line %d' % number)
            test['runs'] += 1
            test['active'] = True
            test['attempts'].append({'terminal': None, 'output': []})
        elif action in TERMINAL:
            if not test['active']:
                raise ValueError('test finish without run at line %d' % number)
            test['active'] = False
            test['terminals'].append(action)
            test['attempts'][-1]['terminal'] = action
        elif action in ('pause', 'cont'):
            if not test['active']:
                raise ValueError('pause/cont without run at line %d' % number)
        elif action == 'output':
            # Treat test text as data. A printed test name or JSON cannot change attribution.
            test['output'].append(item.get('Output', ''))
            if test['active']:
                test['attempts'][-1]['output'].append(item.get('Output', ''))
        elif action != 'bench':
            raise ValueError('unsupported test action at line %d' % number)
    return tests, packages


def assess(capture: Capture, required: Iterable[Target], *, required_runs: int = 1,
           failure_target: Optional[Target] = None, failure_marker: str = '') -> dict:
    """Return actual status and (separately) whether a particular failure was proved.

    required identifies expected tests by package AND exact full name. When an
    expected failing test terminates a package early, unexecuted tests remain in
    missing_targets; a confirmed failure does not mean the other tests passed.
    """
    targets = tuple(required)
    if (not targets or len(set(targets)) != len(targets) or
            any(not isinstance(t, tuple) or len(t) != 2 or
                not all(isinstance(x, str) and x for x in t) for t in targets) or
            not isinstance(required_runs, int) or required_runs < 1):
        raise ValueError('supply unique (package, exact test name) targets and positive runs')
    if failure_target is not None and (not failure_marker or
            not isinstance(failure_target, tuple) or len(failure_target) != 2):
        raise ValueError('expected failure requires a test target and diagnostic marker')
    result = {'status': None, 'exit_code': capture.exit_code, 'expected_failure_confirmed': False,
              'missing_targets': [], 'skipped_tests': [], 'failed_tests': [],
              'unique_test_count': 0, 'test_run_count': 0, 'evidence_complete': False,
              'tests': [], 'reason': ''}

    def finish(status, reason=''):
        result.update(status=status, reason=reason)
        return result

    if capture.start_error:
        return finish('BLOCKED', capture.start_error)
    if capture.timed_out:
        return finish('TIMEOUT', 'runner time budget exceeded')
    if capture.interrupted or (capture.exit_code is not None and capture.exit_code < 0):
        return finish('INTERRUPTED', 'process interrupted')
    if capture.exit_code is None:
        return finish('NOT_RUN', 'no completed process')
    try:
        tests, packages = _decode(capture.stdout)
    except ValueError as exc:
        return finish('INVALID_EVIDENCE', str(exc))

    ran = {key: test for key, test in tests.items() if test['runs']}
    failed = [key for key, test in ran.items() if 'fail' in test['terminals']]
    skipped = [key for key, test in ran.items() if 'skip' in test['terminals']]
    missing = [key for key in targets if key not in ran or
               ran[key]['runs'] < required_runs or
               len(ran[key]['terminals']) < required_runs]
    complete = (bool(packages) and all(p['terminal'] is not None for p in packages.values())
                and all(not test['active'] for test in ran.values()))
    result.update(missing_targets=[list(t) for t in missing],
                  skipped_tests=[list(t) for t in skipped], failed_tests=[list(t) for t in failed],
                  unique_test_count=len(ran), test_run_count=sum(t['runs'] for t in ran.values()),
                  evidence_complete=complete,
                  tests=[{'package': key[0], 'name': key[1], 'runs': test['runs'],
                          'outcomes': list(test['terminals'])} for key, test in sorted(ran.items())])

    if failed:
        # A zero return code cannot erase actual fail events (e.g. a faulty TestMain).
        if failure_target is not None:
            direct_failures = [key for key in failed if _within(key, failure_target)]
            unrelated = [key for key in failed if not (_within(key, failure_target)
                                                      or _within(failure_target, key))]
            own_failed_output = [
                ''.join(attempt['output'])
                for key, test in ran.items() if _within(key, failure_target)
                for attempt in test['attempts'] if attempt['terminal'] == 'fail'
            ]
            result['expected_failure_confirmed'] = bool(
                direct_failures and not unrelated and
                any(failure_marker in text for text in own_failed_output) and
                capture.exit_code > 0 and complete and not capture.stderr.strip())
        return finish('TEST_FAIL', 'one or more tests failed; exit code does not override events')
    if capture.exit_code != 0 or capture.stderr.strip():
        return finish('PROCESS_ERROR', 'nonzero process status or unexplained tool diagnostic')
    if not complete:
        return finish('INCOMPLETE', 'missing package/test terminal events')
    if not ran:
        return finish('NO_TESTS', 'no test run events observed')
    if missing:
        return finish('INCOMPLETE', 'required targets/runs not completed')
    if any(p['terminal'] == 'fail' for p in packages.values()):
        return finish('PROCESS_ERROR', 'package failed outside completed test cases')
    if skipped:
        return finish('SKIP', 'at least one selected test or subtest skipped')
    return finish('PASS')
