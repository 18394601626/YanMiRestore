"""Follow-up tests: diagnostic must belong to a failing execution, not just a name."""
import unittest
from test_evidence import complete, event, run_events, T
from evidence import assess

class FailureAttributionChecks(unittest.TestCase):
    def test_passed_repeat_cannot_supply_failed_repeat_diagnostic(self):
        capture = complete(*run_events(output='BROKEN'),
                           *run_events(outcome='fail', output='DIFFERENT'),
                           code=1, final='fail')
        result = assess(capture, [T], required_runs=2,
                        failure_target=T, failure_marker='BROKEN')
        self.assertEqual(result['status'], 'TEST_FAIL')
        self.assertFalse(result['expected_failure_confirmed'])

    def test_passed_sibling_cannot_supply_failed_child_diagnostic(self):
        capture = complete(event('run', T[1]),
                           *run_events(T[1]+'/healthy', output='BROKEN'),
                           *run_events(T[1]+'/bad', 'fail', 'DIFFERENT'),
                           event('fail', T[1]), code=1, final='fail')
        result = assess(capture, [T], failure_target=T, failure_marker='BROKEN')
        self.assertEqual(result['status'], 'TEST_FAIL')
        self.assertFalse(result['expected_failure_confirmed'])

    def test_failing_repeat_own_diagnostic_is_accepted(self):
        capture = complete(*run_events(output='healthy'),
                           *run_events(outcome='fail', output='BROKEN'),
                           code=1, final='fail')
        result = assess(capture, [T], required_runs=2,
                        failure_target=T, failure_marker='BROKEN')
        self.assertTrue(result['expected_failure_confirmed'])

if __name__ == '__main__': unittest.main(verbosity=2)
