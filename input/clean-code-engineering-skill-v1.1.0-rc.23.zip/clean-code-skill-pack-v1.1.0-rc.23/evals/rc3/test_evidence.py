"""Frozen behavioral contracts for the result reader, not agent-effect tests."""
import json
import unittest
from evidence import Capture, assess

P = 'example.com/evidencefixture'
T = (P, 'TestRequired')

def event(action, name='', output='', package=P):
    value = {'Action': action, 'Package': package}
    if name:
        value['Test'] = name
    if output:
        value['Output'] = output
    return value

def stream(*items):
    return '\n'.join(json.dumps(x) for x in items) + '\n'

def run_events(name='TestRequired', outcome='pass', output=''):
    return [event('run', name), event('output', name, output), event(outcome, name)]

def complete(*items, code=0, final='pass'):
    return Capture(code, stream(event('start'), *items, event(final)))

class EvidenceChecks(unittest.TestCase):
    def check(self, capture, expected, **kwargs):
        result = assess(capture, [T], **kwargs)
        self.assertEqual(result['status'], expected, result)
        return result

    def test_01_real_target_pass(self):
        self.check(complete(*run_events()), 'PASS')

    def test_02_zero_selected_tests(self):
        self.check(complete(), 'NO_TESTS')

    def test_03_package_without_test_files(self):
        self.check(complete(final='skip'), 'NO_TESTS')

    def test_04_all_skipped(self):
        self.check(complete(*run_events(outcome='skip')), 'SKIP')

    def test_05_mixed_skipped(self):
        self.check(complete(*run_events(), *run_events('TestOptional', 'skip')), 'SKIP')

    def test_06_failure_beats_zero_exit(self):
        result=self.check(complete(*run_events(outcome='fail', output='BROKEN')), 'TEST_FAIL',
                          failure_target=T, failure_marker='BROKEN')
        self.assertFalse(result['expected_failure_confirmed'])

    def test_07_missing_target_with_other_pass(self):
        result=self.check(complete(*run_events('TestOther')), 'INCOMPLETE')
        self.assertEqual(result['missing_targets'], [list(T)])

    def test_08_test_names_are_exact(self):
        self.check(complete(*run_events('TestRequiredExtra')), 'INCOMPLETE')

    def test_09_target_package_is_exact(self):
        lines=stream(event('start', package='other'), event('run','TestRequired',package='other'),
                     event('pass','TestRequired',package='other'),event('pass',package='other'))
        self.check(Capture(0,lines), 'INCOMPLETE')

    def test_10_missing_terminal_event(self):
        self.check(complete(event('run','TestRequired')), 'INCOMPLETE')

    def test_11_missing_package_finish(self):
        self.check(Capture(0,stream(event('start'),*run_events())), 'INCOMPLETE')

    def test_12_truncated_json(self):
        self.check(Capture(0,complete(*run_events()).stdout+'{"Action":'), 'INVALID_EVIDENCE')

    def test_13_terminal_without_run(self):
        self.check(complete(event('pass','TestRequired')), 'INVALID_EVIDENCE')

    def test_14_non_json_stdout(self):
        self.check(Capture(0,'PASS\n'), 'INVALID_EVIDENCE')

    def test_15_output_text_is_not_a_build_event(self):
        self.check(complete(*run_events(output='[build failed] --- FAIL: TestOther')), 'PASS')

    def test_16_nested_json_output_is_not_an_event(self):
        fake=json.dumps(event('fail','TestOther'))
        self.check(complete(*run_events(output=fake)), 'PASS')

    def test_17_expected_failure_needs_own_diagnostic(self):
        capture=complete(*run_events(outcome='skip'),*run_events('TestOther','fail','TestRequired BROKEN'),code=1,final='fail')
        result=self.check(capture,'TEST_FAIL',failure_target=T,failure_marker='BROKEN')
        self.assertFalse(result['expected_failure_confirmed'])

    def test_18_expected_failure_confirmed(self):
        capture=complete(*run_events(outcome='fail',output='BROKEN'),code=1,final='fail')
        result=self.check(capture,'TEST_FAIL',failure_target=T,failure_marker='BROKEN')
        self.assertTrue(result['expected_failure_confirmed'])

    def test_19_unrelated_failure_blocks_negative_match(self):
        capture=complete(*run_events(outcome='fail',output='BROKEN'),*run_events('TestOther','fail','other'),code=1,final='fail')
        result=self.check(capture,'TEST_FAIL',failure_target=T,failure_marker='BROKEN')
        self.assertFalse(result['expected_failure_confirmed'])

    def test_20_environment_error_is_not_contract_failure(self):
        result=self.check(Capture(1,'',stderr='toolchain unavailable'),'PROCESS_ERROR',failure_target=T,failure_marker='unavailable')
        self.assertFalse(result['expected_failure_confirmed'])

    def test_21_spawn_error(self):
        self.check(Capture(None,'',start_error='executable unavailable'),'BLOCKED')

    def test_22_timeout_with_partial_pass(self):
        capture=complete(*run_events())
        capture.timed_out=True
        self.check(capture,'TIMEOUT')

    def test_23_interrupted_with_partial_pass(self):
        capture=complete(*run_events()); capture.interrupted=True
        self.check(capture,'INTERRUPTED')

    def test_24_required_inventory_mandatory(self):
        with self.assertRaises(ValueError): assess(complete(*run_events()),[])

    def test_25_unknown_event_type(self):
        self.check(complete(event('future-event','TestRequired')), 'INVALID_EVIDENCE')

    def test_26_repeat_counts_not_independent_samples(self):
        result=self.check(complete(*run_events(),*run_events()),'PASS',required_runs=2)
        self.assertEqual(result['unique_test_count'],1)
        self.assertEqual(result['test_run_count'],2)

    def test_27_repeat_failure_cannot_be_hidden_by_last_pass(self):
        self.check(complete(*run_events(outcome='fail'),*run_events(),code=1,final='fail'),'TEST_FAIL')

    def test_28_subtest_skip_blocks_whole_suite_pass(self):
        capture=complete(event('run','TestRequired'),*run_events('TestRequired/boundary','skip'),event('pass','TestRequired'))
        self.check(capture,'SKIP')

    def test_29_interleaved_parallel_tests(self):
        capture=complete(event('run','TestRequired'),event('pause','TestRequired'),*run_events('TestOther'),event('cont','TestRequired'),event('pass','TestRequired'))
        self.check(capture,'PASS')

    def test_30_expected_subtest_failure(self):
        target=(P,'TestRequired/nil')
        capture=complete(event('run','TestRequired'),*run_events('TestRequired/nil','fail','BROKEN'),event('fail','TestRequired'),code=1,final='fail')
        result=self.check(capture,'TEST_FAIL',failure_target=target,failure_marker='BROKEN')
        self.assertTrue(result['expected_failure_confirmed'])

    def test_31_unexplained_stderr_not_green(self):
        capture=complete(*run_events());capture.stderr='unexpected diagnostic'
        self.check(capture,'PROCESS_ERROR')

    def test_32_sanitized_fixture_probe_timeout(self):
        # A compiler/startup timeout is never evidence that a contract was caught.
        self.check(Capture(None,'',timed_out=True),'TIMEOUT')

    def test_33_repetition_below_promised_count(self):
        self.check(complete(*run_events()),'INCOMPLETE',required_runs=2)

if __name__=='__main__': unittest.main(verbosity=2)
