"""Replay frozen Go fixtures with execution-aware verdicts; never a model A/B run.

Only packaged fixtures execute, in temporary directories. The unchanged rc2
matrix is reused with an explicitly replaced execution callback, not edited.
Python 3.9+, local Go. All module/toolchain downloads disabled. Linux-tested.
"""
import argparse
from dataclasses import asdict
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import tempfile
import time

from evidence import Capture, assess

HERE = Path(__file__).resolve().parent
PACKAGE = HERE.parents[1]
RC2 = PACKAGE / 'evals/rc2'


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def frozen_inputs():
    return {str(p.relative_to(PACKAGE)): sha(p)
            for folder in (HERE/'fixtures', RC2/'fixtures', RC2/'probes')
            for p in sorted(folder.rglob('*')) if p.is_file()}


def execute(command, cwd, env, output, label, timeout=60):
    """Save every outcome, including failure to start and runner timeout."""
    start=time.monotonic()
    try:
        process=subprocess.Popen(command, cwd=cwd, env=env, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, text=True, encoding='utf-8',
                                 errors='replace', start_new_session=(os.name!='nt'))
    except OSError as exc:
        capture=Capture(None, '', start_error='%s: %s' % (type(exc).__name__, exc))
    else:
        timed_out=False
        try:
            stdout,stderr=process.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True
            if os.name=='nt':
                process.kill()
            else:
                try:
                    os.killpg(process.pid,signal.SIGKILL)
                except ProcessLookupError:
                    pass
            stdout,stderr=process.communicate()
        capture=Capture(process.returncode,stdout,stderr,timed_out=timed_out,
                        interrupted=(process.returncode < 0 and not timed_out))
    record={'command':list(map(str,command)), 'cwd':str(cwd),
            'seconds':round(time.monotonic()-start,4), 'exit_code':capture.exit_code,
            'timed_out':capture.timed_out, 'interrupted':capture.interrupted,
            'start_error':capture.start_error}
    (output/(label+'.stdout')).write_text(capture.stdout,encoding='utf-8')
    (output/(label+'.stderr')).write_text(capture.stderr,encoding='utf-8')
    record['stdout_sha256']=sha(output/(label+'.stdout'))
    record['stderr_sha256']=sha(output/(label+'.stderr'))
    write_json(output/(label+'.command.json'),record)
    return capture


def command_status(capture):
    if capture.start_error: return 'BLOCKED'
    if capture.timed_out: return 'TIMEOUT'
    if capture.interrupted: return 'INTERRUPTED'
    if capture.exit_code is None: return 'NOT_RUN'
    return 'PASS' if capture.exit_code==0 else 'PROCESS_ERROR'


def compile_check(go,cwd,env,out,label):
    # Compile tests as well as source, without executing TestMain or test bodies.
    capture=execute([go,'test','-c','-o',str(cwd/'probe.test'),'./...'],cwd,env,out,label+'-compile')
    status=command_status(capture)
    if status=='PROCESS_ERROR' and re.search(r'\.go:\d+:\d+:',capture.stderr):
        status='COMPILE_FAIL'
    return capture,status


FAILURE_DETAILS={
    'H02-regressed-behavior':('TestNilConstructorContract','invalid memory address'),
    'M03-typed-nil':('TestSuccessIsNilError','success has a non-nil error'),
    'M04-error-chain':('TestErrorChain','missing error chain lost'),
    'M05-error-type':('TestConcreteErrorType','validation error type lost'),
    'M06-hidden-cause':('TestHiddenErrorStaysHidden','hidden error exposed'),
    'M07-null-to-empty':('TestWireContract/nil','wire='),
    'M08-field-renamed':('TestWireContract','wire='),
}


def inventory(cwd,command):
    """Extract top-level names only from these small frozen fixtures, not arbitrary Go."""
    tests=sorted(cwd.glob('*/*_test.go'))
    if not tests: raise ValueError('historical fixture has no test files')
    package='example.com/skill-effect-lab/'+tests[0].parent.name
    names={name for path in tests for name in re.findall(r'^func (Test\w+)\(t \*testing\.T\)',path.read_text(),re.M)}
    if '-run=^TestDirectConsumer$' in command:
        names={'TestDirectConsumer'}
    return [(package,name) for name in sorted(names)]


def historical_matrix(parent,env,out,go):
    spec=importlib.util.spec_from_file_location('frozen_rc2_matrix',RC2/'run_regressions.py')
    legacy=importlib.util.module_from_spec(spec); spec.loader.exec_module(legacy)

    def audited(command,cwd,env,output,label,expected='PASS',marker=''):
        if command[1] in ('vet','build'):
            capture=execute(command,cwd,env,output,label)
            observed=command_status(capture)
            detail={'status':observed,'scope':'command_only_not_test_execution'}
            matched=observed==expected
        else:
            build,status=compile_check(go,cwd,env,output,label)
            if status!='PASS':
                observed=status
                matched=(expected=='COMPILE_FAIL' and observed=='COMPILE_FAIL' and
                         bool(marker) and marker in build.stderr)
                detail={'status':status,'scope':'compile_only',
                        'expected_compile_failure_confirmed':matched}
            elif expected=='COMPILE_FAIL':
                observed='PASS'
                matched=False
                detail={'status':'PASS','scope':'compile_only','expected_compile_failure_confirmed':False}
            else:
                required=inventory(cwd,command)
                json_command=[command[0],command[1],'-json',*command[2:]]
                capture=execute(json_command,cwd,env,output,label)
                kwargs={}
                if expected=='TEST_FAIL':
                    test_name,diagnostic=FAILURE_DETAILS[label]
                    kwargs={'failure_target':(required[0][0],test_name),'failure_marker':diagnostic}
                detail=assess(capture,required,**kwargs)
                observed=detail['status']
                matched=(observed==expected and
                         (expected!='TEST_FAIL' or detail['expected_failure_confirmed']))
        result={'id':label,'observed':observed,'expected':expected,
                'matches_expected_observation':matched,'detail':detail}
        write_json(output/(label+'.assessment.json'),result)
        print(label,observed,'matched='+str(matched),flush=True)
        return result

    # Reuse fixture definitions and expected outcomes verbatim. Only the local
    # imported module's callback changes. No frozen source/test file is modified.
    legacy.run_command=audited
    return legacy.historical(parent,env,out,go)+legacy.mutations(parent,env,out,go)


def challenges(parent,env,out,go):
    rows=[]
    cases=json.loads((HERE/'fixtures/cases.json').read_text())
    for case in cases:
        cwd=parent/case['id']; shutil.copytree(HERE/'fixtures'/case['id'],cwd)
        build,build_status=compile_check(go,cwd,env,out,case['id'])
        if build_status!='PASS':
            detail={'status':build_status,'expected_failure_confirmed':False}
        else:
            capture=execute([go,'test','-json','-count=1',*case['args'],'./...'],cwd,env,out,case['id'])
            kwargs={}
            if case['marker']:
                kwargs={'failure_target':tuple(case['target']),'failure_marker':case['marker']}
            detail=assess(capture,[tuple(case['target'])],**kwargs)
        # Three negative controls intentionally do not establish the required failure.
        confirmed_want=case['id'] in ('C08-output-build-marker','C10-real-failure')
        matched=(detail['status']==case['expected'] and
                 detail.get('expected_failure_confirmed',False)==confirmed_want)
        row={'id':case['id'],'observed':detail['status'],'expected':case['expected'],
             'matches_expected_observation':matched,'detail':detail}
        rows.append(row);write_json(out/(case['id']+'.assessment.json'),row)
        print(case['id'],detail['status'],'matched='+str(matched),flush=True)
    return rows


def attribution_challenges(parent,env,out,go):
    rows=[]
    cases=json.loads((HERE/'fixtures/attribution-cases.json').read_text())
    for case in cases:
        cwd=parent/case['id']; shutil.copytree(HERE/'fixtures'/case['id'],cwd)
        build,status=compile_check(go,cwd,env,out,case['id'])
        if status!='PASS':
            detail={'status':status,'expected_failure_confirmed':False}
        else:
            capture=execute([go,'test','-json','-count='+str(case['count']),'./...'],cwd,env,out,case['id'])
            target=tuple(case['target'])
            detail=assess(capture,[target],required_runs=case['count'],
                          failure_target=target,failure_marker=case['marker'])
        matched=(detail['status']==case['expected_status'] and
                 detail.get('expected_failure_confirmed',False)==case['expected_failure_confirmed'])
        row={'id':case['id'],'observed':detail['status'],'expected':case['expected_status'],
             'matches_expected_observation':matched,'detail':detail}
        rows.append(row);write_json(out/(case['id']+'.assessment.json'),row)
        print(case['id'],detail['status'],'matched='+str(matched),flush=True)
    return rows


def operational_controls(parent,env,out,go):
    rows=[]
    # An actual process start failure; no path guessing outside this temp root.
    required=[('example.com/evidencefixture','TestRequired')]
    blocked=execute([str(parent/'does-not-exist')],parent,env,out,'O01-missing-tool')
    detail=assess(blocked,required)
    rows.append({'id':'O01-missing-tool','observed':detail['status'],'expected':'BLOCKED',
                 'matches_expected_observation':detail['status']=='BLOCKED','detail':detail})
    # Real runner interruption of a precompiled long-running fixture, not a mocked timeout.
    cwd=parent/'O02-timeout';shutil.copytree(HERE/'fixtures/C01-pass',cwd)
    (cwd/'fixture_test.go').write_text('package evidencefixture\nimport("testing";"time")\nfunc TestRequired(t *testing.T){time.Sleep(30*time.Second)}\n')
    build,status=compile_check(go,cwd,env,out,'O02-timeout')
    if status=='PASS':
        capture=execute([go,'tool','test2json','-p',required[0][0],str(cwd/'probe.test'),'-test.v=test2json'],cwd,env,out,'O02-timeout',timeout=0.5)
        detail=assess(capture,required)
    else:
        detail={'status':status}
    rows.append({'id':'O02-timeout','observed':detail['status'],'expected':'TIMEOUT',
                 'matches_expected_observation':detail['status']=='TIMEOUT','detail':detail})
    for row in rows:
        write_json(out/(row['id']+'.assessment.json'),row)
        print(row['id'],row['observed'],'matched='+str(row['matches_expected_observation']),flush=True)
    return rows


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--phase',choices=('all','historical','challenges'),default='all')
    args=parser.parse_args()
    output=args.output.resolve()
    if output.exists(): parser.exit(2,'Use a NEW output directory.\n')
    if output==HERE or HERE in output.parents: parser.exit(2,'Output must be outside evals/rc3.\n')
    output.mkdir(parents=True)
    before=frozen_inputs();go=shutil.which('go');rows=[]
    summary={'kind':'controlled_evaluator_and_go_fixture_checks_not_agent_AB',
             'started_utc':datetime.now(timezone.utc).isoformat(), 'phase':args.phase,
             'input_hashes':before,'go_version':None,'observations':rows,'status':'RUNNING'}
    write_json(output/'summary.json',summary)
    try:
        if not go:
            summary['status']='BLOCKED';summary['reason']='local Go executable unavailable'
            return 2
        with tempfile.TemporaryDirectory(prefix='clean-code-rc3-') as name:
            parent=Path(name);env=os.environ.copy()
            env.update(GOTOOLCHAIN='local',GOPROXY='off',GOSUMDB='off',GOWORK='off',
                       GOENV='off',GOFLAGS='-mod=mod',GOMODCACHE=str(parent/'modcache'))
            version=execute([go,'version'],parent,env,output,'toolchain')
            if command_status(version)!='PASS':
                summary['status']='BLOCKED';summary['reason']='cannot run local Go';return 2
            summary['go_version']=version.stdout.strip()
            if args.phase in ('all','historical'):
                rows.extend(historical_matrix(parent,env,output,go))
            if args.phase in ('all','challenges'):
                rows.extend(challenges(parent,env,output,go))
                rows.extend(attribution_challenges(parent,env,output,go))
                rows.extend(operational_controls(parent,env,output,go))
        summary['inputs_unchanged']=before==frozen_inputs()
        okay=bool(rows) and summary['inputs_unchanged'] and all(r['matches_expected_observation'] for r in rows)
        summary['status']='EXPECTED_OBSERVATIONS_REPRODUCED' if okay else 'UNEXPECTED_RESULT'
        return 0 if okay else 1
    except Exception as exc:
        summary['status']='RUNNER_ERROR';summary['reason']=repr(exc)
        raise
    finally:
        summary['finished_utc']=datetime.now(timezone.utc).isoformat()
        write_json(output/'summary.json',summary)

if __name__=='__main__': raise SystemExit(main())
