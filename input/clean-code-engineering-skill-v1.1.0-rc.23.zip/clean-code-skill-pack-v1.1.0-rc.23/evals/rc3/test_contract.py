"""Current document entry: 31 unchanged rc2 checks plus rc3 checks.

Original version-specific entry points remain unchanged. These checks validate
text/contracts, not agent compliance or code quality.
"""
import importlib.util
import json
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[2]
MAIN=ROOT/'clean-code-engineering'

class RC3DocumentChecks(unittest.TestCase):
    def text(self,path):
        return (ROOT/path).read_text(encoding='utf-8')
    def test_01_version(self):
        self.assertEqual(self.text('VERSION').strip(),'1.1.0-rc.3')
        self.assertEqual(self.text('VERSION'),self.text('clean-code-engineering/VERSION'))
    def test_02_main_has_execution_gate(self):
        text=self.text('clean-code-engineering/SKILL.md')
        for term in ('进程退出','目标测试','实际执行','11-test-oracle.md'):
            self.assertIn(term,text)
    def test_03_statuses_are_not_merged(self):
        text=self.text('clean-code-engineering/references/11-test-oracle.md')
        for term in ('NO_TESTS','INCOMPLETE','SKIP','TIMEOUT','INVALID_EVIDENCE'):
            self.assertIn(term,text)
    def test_04_ownership(self):
        text=self.text('clean-code-engineering/references/11-test-oracle.md')
        for term in ('包路径','精确','子用例','Output'):
            self.assertIn(term,text)
    def test_05_negative_is_separate(self):
        text=self.text('clean-code-engineering/references/11-test-oracle.md')
        for term in ('编译','诊断','无关','预期失败'):
            self.assertIn(term,text)
    def test_06_scope_does_not_expand_for_formatting(self):
        text=self.text('clean-code-engineering/references/11-test-oracle.md')
        self.assertIn('格式',text)
        self.assertIn('没有测试用例',text)
        self.assertIn('不要求',text)
    def test_07_real_runs_are_not_model_AB(self):
        text=self.text('evals/rc3/README.md')
        for term in ('受控','不是独立代理','旧','原 A/B','已知','Linux'):
            self.assertIn(term,text)
    def test_08_sources_and_provenance(self):
        data=json.loads(self.text('provenance/rc3/sources.json'))
        self.assertEqual(data['classification'],'execution_adaptation_not_book_text')
        self.assertTrue(data['sources'])
    def test_09_original_book_hashes(self):
        data=json.loads(self.text('provenance/rc3/preservation-check.json'))
        self.assertTrue(data['book_references_unchanged'])
        self.assertTrue(data['original_artifacts_unchanged'])
        self.assertTrue(data['rc2_matrix_unchanged'])
    def test_10_current_entry_is_documented(self):
        text=self.text('README.md')
        self.assertIn('python evals/rc3/run_checks.py',text)
        self.assertIn('python evals/rc3/test_evidence.py',text)
        self.assertIn('历史',text)

def suite():
    spec=importlib.util.spec_from_file_location('unchanged_rc2_contract',ROOT/'evals/rc2/test_contract.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    result=unittest.TestSuite()
    def add(items):
        for test in items:
            if isinstance(test,unittest.TestSuite): add(test)
            elif test._testMethodName!='test_01_rc2_version': result.addTest(test)
    add(old.suite())
    result.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(RC3DocumentChecks))
    return result

if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(suite())
    raise SystemExit(0 if result.wasSuccessful() else 1)
