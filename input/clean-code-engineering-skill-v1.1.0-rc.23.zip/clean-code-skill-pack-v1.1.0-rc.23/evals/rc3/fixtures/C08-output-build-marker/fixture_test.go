package evidencefixture
import "testing"
func TestRequired(t *testing.T) { t.Log("[build failed] cannot use target.NewCatalog"); t.Fatal("RUNTIME_FAILURE") }
