package evidencefixture
import ("testing"; "os")
func TestRequired(t *testing.T) { t.Fatal("REQUIRED_CONTRACT_BROKEN") }
func TestMain(m *testing.M) { os.Exit(0) }
