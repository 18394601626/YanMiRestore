package evidencefixture
import "testing"
func TestRequired(t *testing.T) { t.Skip("fixture: dependency intentionally unavailable") }
