package evidencefixture
import "testing"
func TestRequired(t *testing.T) { t.Run("boundary",func(t *testing.T){t.Skip("boundary unavailable")}) }
