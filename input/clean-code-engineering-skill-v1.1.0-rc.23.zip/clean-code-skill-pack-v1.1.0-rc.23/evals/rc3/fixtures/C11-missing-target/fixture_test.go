package evidencefixture
import "testing"
func TestHealthy(t *testing.T) { if Double(3)!=6 { t.Fatal("double mismatch") } }
