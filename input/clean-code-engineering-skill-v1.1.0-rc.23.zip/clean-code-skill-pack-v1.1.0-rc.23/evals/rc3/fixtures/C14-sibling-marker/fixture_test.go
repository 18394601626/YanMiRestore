package evidencefixture
import "testing"
func TestRequired(t *testing.T) {
    t.Run("healthy", func(t *testing.T) { t.Log("BROKEN") })
    t.Run("bad", func(t *testing.T) { t.Fatal("DIFFERENT") })
}
