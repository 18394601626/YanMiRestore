package evidencefixture

func Double(n int) int { return n*2 }
