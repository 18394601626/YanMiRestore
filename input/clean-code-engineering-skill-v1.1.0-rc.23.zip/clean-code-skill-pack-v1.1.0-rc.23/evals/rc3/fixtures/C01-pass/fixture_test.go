package evidencefixture
import "testing"
func TestRequired(t *testing.T) { if Double(3)!=6 { t.Fatal("double mismatch") } }
