package evidencefixture
import "testing"
var attempt int
func TestRequired(t *testing.T) {
    attempt++
    if attempt == 1 { t.Log("BROKEN"); return }
    t.Fatal("DIFFERENT")
}
