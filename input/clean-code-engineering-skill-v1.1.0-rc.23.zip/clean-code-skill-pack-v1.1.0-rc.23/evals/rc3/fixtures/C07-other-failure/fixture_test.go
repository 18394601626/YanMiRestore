package evidencefixture
import "testing"
func TestRequired(t *testing.T) { t.Skip("not executed") }
func TestOther(t *testing.T) { t.Log("TestRequired REQUIRED_CONTRACT_BROKEN"); t.Fatal("UNRELATED_FAILURE") }
