package evidencefixture
import "testing"
func TestRequired(t *testing.T) { t.Fatal("REQUIRED_CONTRACT_BROKEN") }
