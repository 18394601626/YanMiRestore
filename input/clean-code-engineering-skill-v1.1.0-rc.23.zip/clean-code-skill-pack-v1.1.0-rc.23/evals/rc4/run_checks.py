"""Replay known ownership fixtures, never a no-Skill/Skill generation experiment.

Python 3.9+, Go offline. Uses the rc3 capture/parser unchanged. Requires a new
output directory; executes only packaged fixtures in disposable copies. This is
not a hostile-code sandbox and is only tested on Linux amd64.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(ROOT / 'evals/rc3'))
from run_checks import execute, command_status, write_json
from evidence import assess


def hashes():
    return {str(p.relative_to(HERE/'fixtures')): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((HERE/'fixtures').rglob('*')) if p.is_file()}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args=parser.parse_args()
    out=args.output.resolve()
    # Do not write reports into frozen packaged fixtures or historical logs.
    if out == ROOT or ROOT in out.parents:
        parser.error('output must be outside this package')
    out.mkdir(parents=True, exist_ok=False)
    frozen=json.loads((HERE/'fixture-hashes.json').read_text())
    if hashes()!=frozen:
        write_json(out/'summary.json', {'status':'INPUT_CHANGED','matches_expected':False})
        return 2
    go=shutil.which('go')
    if not go:
        write_json(out/'summary.json', {'status':'BLOCKED','reason':'Go tool not found','matches_expected':False})
        return 2
    env=dict(os.environ, GOTOOLCHAIN='local', GOPROXY='off', GOSUMDB='off',
             GOWORK='off', GOENV='off', GOFLAGS='-mod=mod')
    rows=[]
    with tempfile.TemporaryDirectory(prefix='ownership-rc4-') as tmp:
        parent=Path(tmp)
        for case in json.loads((HERE/'cases.json').read_text()):
            cwd=parent/case['id']
            shutil.copytree(HERE/'fixtures'/case['fixture'],cwd)
            cmd=[go,'test','-json','-count='+str(case['runs']),'-timeout=15s',*case['args'],'./...']
            capture=execute(cmd,cwd,env,out,case['id'],timeout=90)
            detail=assess(capture,[tuple(t) for t in case['required']],required_runs=case['runs'])
            actual_counts=Counter(v for t in detail['tests'] for v in t['outcomes'])
            matched=(detail['status']==case['expected'] and detail['evidence_complete']
                     and not detail['missing_targets'] and not detail['skipped_tests']
                     and sorted(detail['failed_tests'])==case['failed']
                     and capture.exit_code==(1 if case['failed'] else 0)
                     and not capture.stderr.strip())
            row={'id':case['id'],'scope':'known_fixture_replay_not_agent_trial',
                 'observed':detail['status'],'expected':case['expected'],
                 'matches_expected_observation':matched,'outcomes':dict(actual_counts),'detail':detail}
            write_json(out/(case['id']+'.assessment.json'),row)
            rows.append(row)
            print(case['id'],row['observed'],'matched='+str(matched),flush=True)
        cwd=parent/'commands';shutil.copytree(HERE/'fixtures/repaired',cwd)
        commands=[('R09-vet',[go,'vet','./...']),('R10-build',[go,'build','./...'])]
        gofmt=Path(go).with_name('gofmt')
        commands.append(('R11-format',[str(gofmt),'-l',*[str(p) for p in sorted(cwd.rglob('*.go'))]]))
        for label,cmd in commands:
            capture=execute(cmd,cwd,env,out,label,timeout=90)
            status=command_status(capture)
            matched=(status=='PASS' and not capture.stderr.strip()
                     and (label!='R11-format' or not capture.stdout.strip()))
            rows.append({'id':label,'observed':status,'expected':'PASS',
                         'scope':'command_only_not_test_execution','matches_expected_observation':matched})
            print(label,status,'matched='+str(matched),flush=True)
        version=execute([go,'version'],parent,env,out,'environment')
    unchanged=hashes()==frozen
    summary={'generated_at':datetime.now(timezone.utc).isoformat(),
             'classification':'controlled_fixtures_no_independent_agent_or_AB',
             'go_version':version.stdout.strip(),'python':sys.version,
             'inputs_unchanged':unchanged,'observations':rows,
             'status_counts':dict(Counter(r['observed'] for r in rows)),
             'all_expected_observations_reproduced':unchanged and all(r['matches_expected_observation'] for r in rows)}
    write_json(out/'summary.json',summary)
    return 0 if summary['all_expected_observations_reproduced'] else 1

if __name__=='__main__':
    raise SystemExit(main())
