"""Document and frozen-input checks only, not agent behavior evaluation."""
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[2]
class RC4DocumentChecks(unittest.TestCase):
    def text(self,path):return (ROOT/path).read_text(encoding='utf-8')
    def test_01_rc4_version(self):
        self.assertEqual(self.text('VERSION').strip(),'1.1.0-rc.4')
        self.assertEqual(self.text('VERSION'),self.text('clean-code-engineering/VERSION'))
    def test_02_ownership_route(self):
        self.assertIn('12-data-resource-ownership.md',self.text('clean-code-engineering/SKILL.md'))
        self.assertIn('12-data-resource-ownership.md',self.text('clean-code-engineering/references/08-go.md'))
    def test_03_copy_policy(self):
        text=self.text('clean-code-engineering/references/12-data-resource-ownership.md')
        for term in ('执行适配','借用','外层','并发修改','不盲目'):
            self.assertIn(term,text)
    def test_04_io_capability_contract(self):
        text=self.text('clean-code-engineering/references/12-data-resource-ownership.md')
        for term in ('n > 0','EOF','ErrShortWrite','WriterTo','ReaderFrom','部分'):
            self.assertIn(term,text)
    def test_05_cleanup_and_cancel(self):
        text=self.text('clean-code-engineering/references/12-data-resource-ownership.md')
        for term in ('Close','defer','错误优先级','输出','取消','同时就绪'):
            self.assertIn(term,text)
    def test_06_double_history(self):
        text=self.text('clean-code-engineering/references/11-test-oracle.md')
        self.assertIn('ReaderFrom',text)
        self.assertIn('12-data-resource-ownership.md',text)
        change=self.text('provenance/rc4/stream-test-double-v1-to-v2.diff')
        self.assertIn('type limitedWriter',change)
        self.assertNotIn('-    if !errors.Is',change)
    def test_07_new_entry_documented(self):
        text=self.text('README.md')
        for term in ('python evals/rc4/run_checks.py','python evals/rc4/test_contract.py','历史'):
            self.assertIn(term,text)
        text=self.text('evals/rc4/README.md')
        for term in ('受控','不是独立','测试替身','23','未验证'):
            self.assertIn(term,text)
    def test_08_inputs_frozen(self):
        f=ROOT/'evals/rc4/fixtures'
        expected=json.loads(self.text('evals/rc4/fixture-hashes.json'))
        actual={str(p.relative_to(f)):hashlib.sha256(p.read_bytes()).hexdigest() for p in f.rglob('*') if p.is_file()}
        self.assertEqual(actual,expected)
        for suffix in ('','-v2'):
            left=f/('baseline'+suffix);right=f/('corrected'+suffix)
            for p in left.rglob('*_test.go'):
                self.assertEqual(p.read_bytes(),(right/p.relative_to(left)).read_bytes())
    def test_09_original_book_references(self):
        expected=json.loads(self.text('provenance/rc4/book-reference-hashes.json'))
        self.assertEqual(len(expected),6)
        for rel,digest in expected.items():
            self.assertEqual(hashlib.sha256((ROOT/rel).read_bytes()).hexdigest(),digest)

def suite():
    spec=importlib.util.spec_from_file_location('rc3_unchanged_docs',ROOT/'evals/rc3/test_contract.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    result=unittest.TestSuite()
    def add(items):
        for test in items:
            if isinstance(test,unittest.TestSuite):add(test)
            elif test._testMethodName!='test_01_version':result.addTest(test)
    add(old.suite())
    result.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(RC4DocumentChecks))
    return result
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(suite())
    raise SystemExit(0 if result.wasSuccessful() else 1)
