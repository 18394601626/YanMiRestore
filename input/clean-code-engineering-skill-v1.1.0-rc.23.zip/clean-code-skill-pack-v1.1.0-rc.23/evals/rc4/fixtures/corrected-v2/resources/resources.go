package resources

import (
    "fmt"
    "io"
)

type Opener func(string)(io.ReadCloser,error)

// ProcessFiles owns each successfully opened resource until consume returns.
// It releases that resource before opening another and stops on the first error.
func ProcessFiles(paths []string,open Opener,consume func(io.Reader)error)error {
    for _,path:=range paths {
        if err:=processOne(path,open,consume);err!=nil{return err}
    }
    return nil
}

func processOne(path string,open Opener,consume func(io.Reader)error)(err error) {
    resource,err:=open(path)
    if err!=nil{return fmt.Errorf("open %q: %w",path,err)}
    defer func(){
        closeErr:=resource.Close()
        // The declared contract prioritizes the consumer failure.
        if err==nil && closeErr!=nil {err=fmt.Errorf("close %q: %w",path,closeErr)}
    }()
    if err=consume(resource);err!=nil{return fmt.Errorf("consume %q: %w",path,err)}
    return nil
}
