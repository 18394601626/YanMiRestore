package stream

import "io"

// Transfer borrows src and dst; ownership and closing remain with the caller.
// Successfully written bytes are not rolled back when a later operation fails.
func Transfer(dst io.Writer,src io.Reader)(int64,error) {
    return io.Copy(dst,src)
}
