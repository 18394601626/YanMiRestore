package resources

import (
	"errors"
	"fmt"
	"io"
	"strings"
	"testing"
)

type trackedHandle struct {
	io.Reader
	onClose  func()
	closeErr error
	closes   int
}

func (h *trackedHandle) Close() error {
	h.closes++
	if h.onClose != nil {
		h.onClose()
	}
	return h.closeErr
}
func consumeAll(r io.Reader) error { _, err := io.Copy(io.Discard, r); return err }
func TestBatchReleasesBeforeNextOpen(t *testing.T) {
	active, peak := 0, 0
	var opened []*trackedHandle
	open := func(name string) (io.ReadCloser, error) {
		if active != 0 {
			return nil, fmt.Errorf("previous handle still open before %s", name)
		}
		active++
		if active > peak {
			peak = active
		}
		h := &trackedHandle{Reader: strings.NewReader(name), onClose: func() { active-- }}
		opened = append(opened, h)
		return h, nil
	}
	if err := ProcessFiles([]string{"a", "b", "c"}, open, consumeAll); err != nil {
		t.Fatal(err)
	}
	if len(opened) != 3 || peak != 1 || active != 0 {
		t.Fatalf("resource counts opened=%d peak=%d active=%d", len(opened), peak, active)
	}
	for _, h := range opened {
		if h.closes != 1 {
			t.Fatalf("close count=%d", h.closes)
		}
	}
}
func TestBatchClosesOnConsumerFailure(t *testing.T) {
	fault := errors.New("decode failed")
	h := &trackedHandle{Reader: strings.NewReader("x")}
	opens := 0
	open := func(string) (io.ReadCloser, error) { opens++; return h, nil }
	err := ProcessFiles([]string{"a", "b"}, open, func(io.Reader) error { return fault })
	if !errors.Is(err, fault) || h.closes != 1 || opens != 1 {
		t.Fatalf("failure err=%v closes=%d opens=%d", err, h.closes, opens)
	}
}
func TestBatchReportsCloseFailure(t *testing.T) {
	fault := errors.New("close failed")
	h := &trackedHandle{Reader: strings.NewReader("x"), closeErr: fault}
	err := ProcessFiles([]string{"a"}, func(string) (io.ReadCloser, error) { return h, nil }, consumeAll)
	if !errors.Is(err, fault) || h.closes != 1 {
		t.Fatalf("close failure lost: err=%v closes=%d", err, h.closes)
	}
}
func TestBatchPreservesPrimaryConsumerError(t *testing.T) {
	primary := errors.New("consume failed")
	secondary := errors.New("close failed")
	h := &trackedHandle{Reader: strings.NewReader("x"), closeErr: secondary}
	err := ProcessFiles([]string{"a"}, func(string) (io.ReadCloser, error) { return h, nil }, func(io.Reader) error { return primary })
	// This fixture's explicit contract prioritizes consume; not a universal logging policy.
	if !errors.Is(err, primary) || errors.Is(err, secondary) || h.closes != 1 {
		t.Fatalf("primary error changed: %v", err)
	}
}
func TestBatchPreservesOpenFailure(t *testing.T) {
	fault := errors.New("open failed")
	calls := 0
	err := ProcessFiles([]string{"a", "b"}, func(string) (io.ReadCloser, error) { calls++; return nil, fault }, consumeAll)
	if !errors.Is(err, fault) || calls != 1 {
		t.Fatalf("open failure lost: %v calls=%d", err, calls)
	}
}
func TestBatchClosesOnConsumerPanic(t *testing.T) {
	h := &trackedHandle{Reader: strings.NewReader("x")}
	marker := &struct{}{}
	func() {
		defer func() {
			if got := recover(); got != marker {
				t.Fatalf("panic changed: %#v", got)
			}
		}()
		_ = ProcessFiles([]string{"a"}, func(string) (io.ReadCloser, error) { return h, nil }, func(io.Reader) error { panic(marker) })
	}()
	if h.closes != 1 {
		t.Fatalf("panic cleanup count=%d", h.closes)
	}
}
func TestBatchEmptyDoesNotOpen(t *testing.T) {
	err := ProcessFiles(nil, func(string) (io.ReadCloser, error) { t.Fatal("unexpected open"); return nil, nil }, consumeAll)
	if err != nil {
		t.Fatal(err)
	}
}
