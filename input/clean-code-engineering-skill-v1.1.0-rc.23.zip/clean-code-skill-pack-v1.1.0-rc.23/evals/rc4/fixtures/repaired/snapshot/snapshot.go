package snapshot

type Record struct {
	ID      string
	Payload []byte
	Labels  map[string]string
}

// Snapshot makes independent copies of this model's mutable fields.
// Callers must not mutate the input concurrently while it is being copied.
func Snapshot(records []Record) []Record {
	if records == nil {
		return nil
	}
	result := make([]Record, len(records))
	for i, record := range records {
		result[i] = record
		if record.Payload != nil {
			result[i].Payload = make([]byte, len(record.Payload))
			copy(result[i].Payload, record.Payload)
		}
		if record.Labels != nil {
			result[i].Labels = make(map[string]string, len(record.Labels))
			for key, value := range record.Labels {
				result[i].Labels[key] = value
			}
		}
	}
	return result
}
