package forward

import "context"

// Forward borrows both channels. Every channel wait is cancelable.
// Simultaneous cancellation and readiness may permit a final transfer.
func Forward(ctx context.Context, input <-chan int, output chan<- int) error {
	if err := ctx.Err(); err != nil {
		return err
	}
	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case value, ok := <-input:
			if !ok {
				return nil
			}
			select {
			case <-ctx.Done():
				return ctx.Err()
			case output <- value:
			}
		}
	}
}
