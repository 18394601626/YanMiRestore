package forward

import (
	"context"
	"errors"
	"testing"
	"time"
)

func waitDone(t *testing.T, done <-chan error) error {
	t.Helper()
	select {
	case err := <-done:
		return err
	case <-time.After(time.Second):
		t.Fatal("worker did not finish")
		return nil
	}
}
func TestForwardStopsWhileOutputBlocked(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	input := make(chan int)
	output := make(chan int)
	done := make(chan error, 1)
	go func() { done <- Forward(ctx, input, output) }()
	select {
	case input <- 7:
	case <-time.After(time.Second):
		t.Fatal("input not received")
	}
	cancel()
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatalf("cancel error=%v", err)
		}
	case <-time.After(time.Second):
		// Release a deliberately broken fixture before failing, rather than leaking it.
		select {
		case <-output:
		case <-time.After(time.Second):
			t.Fatal("could not release blocked writer")
		}
		_ = waitDone(t, done)
		t.Fatal("output send ignored cancellation")
	}
}
func TestForwardStopsWhileInputBlocked(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	input := make(chan int)
	output := make(chan int)
	done := make(chan error, 1)
	go func() { done <- Forward(ctx, input, output) }()
	cancel()
	if err := waitDone(t, done); !errors.Is(err, context.Canceled) {
		t.Fatalf("cancel error=%v", err)
	}
}
func TestForwardPreservesValuesAndLeavesOutputOpen(t *testing.T) {
	input := make(chan int, 2)
	input <- 3
	input <- 5
	close(input)
	output := make(chan int, 3)
	if err := Forward(context.Background(), input, output); err != nil {
		t.Fatal(err)
	}
	if <-output != 3 || <-output != 5 {
		t.Fatal("forwarded values changed")
	}
	// The caller owns output; this send detects an unauthorized close.
	output <- 9
	if <-output != 9 {
		t.Fatal("output ownership changed")
	}
}
func TestForwardCanceledEntryDoesNotConsume(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	input := make(chan int, 1)
	input <- 7
	output := make(chan int, 1)
	if err := Forward(ctx, input, output); !errors.Is(err, context.Canceled) {
		t.Fatalf("entry cancel: %v", err)
	}
	if len(input) != 1 || len(output) != 0 {
		t.Fatal("canceled entry consumed input")
	}
}
