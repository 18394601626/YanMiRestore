package stream

import "io"

// Transfer borrows both arguments; it must not close them.
func Transfer(dst io.Writer,src io.Reader)(int64,error) {
    if closer,ok:=src.(io.Closer);ok{defer closer.Close()}
    buffer:=make([]byte,4096)
    var total int64
    for {
        n,err:=src.Read(buffer)
        if err==io.EOF{return total,nil}
        if err!=nil{return total,err}
        written,writeErr:=dst.Write(buffer[:n]);total+=int64(written)
        if writeErr!=nil{return total,writeErr}
    }
}
