package resources

import "io"

type Opener func(string)(io.ReadCloser,error)

// ProcessFiles owns the resources it opens, releasing each before the next.
func ProcessFiles(paths []string,open Opener,consume func(io.Reader)error)error {
    for _,path:=range paths {
        resource,err:=open(path)
        if err!=nil{return err}
        defer resource.Close()
        if err:=consume(resource);err!=nil{return err}
    }
    return nil
}
