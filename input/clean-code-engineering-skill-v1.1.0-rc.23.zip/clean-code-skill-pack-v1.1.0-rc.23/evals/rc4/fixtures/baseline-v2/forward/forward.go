package forward

import "context"

// Forward borrows both channels and leaves output open.
func Forward(ctx context.Context,input <-chan int,output chan<- int)error {
    if err:=ctx.Err();err!=nil{return err}
    for {
        select {
        case <-ctx.Done():return ctx.Err()
        case value,ok:=<-input:
            if !ok{return nil}
            output<-value
        }
    }
}
