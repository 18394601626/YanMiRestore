module example.com/ownershipcheck

go 1.20
