package snapshot

type Record struct {
    ID string
    Payload []byte
    Labels map[string]string
}

// Snapshot intends to return independently mutable records.
func Snapshot(records []Record) []Record {
    if records == nil { return nil }
    result := make([]Record,len(records))
    copy(result,records)
    return result
}
