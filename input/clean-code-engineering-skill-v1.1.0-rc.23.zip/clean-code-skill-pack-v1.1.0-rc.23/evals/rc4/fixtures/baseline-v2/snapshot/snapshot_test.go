package snapshot

import "testing"

func sourceRecords() []Record {
    return []Record{{ID:"u1", Payload:[]byte("abc"), Labels:map[string]string{"role":"reader"}}}
}

func TestSnapshotPayloadDoesNotAliasInput(t *testing.T) {
    src := sourceRecords()
    dst := Snapshot(src)
    dst[0].Payload[0] = 'z'
    if string(src[0].Payload) != "abc" { t.Fatal("payload aliases input") }
}
func TestSnapshotMapDoesNotAliasInput(t *testing.T) {
    src := sourceRecords(); dst := Snapshot(src)
    dst[0].Labels["role"] = "writer"
    if src[0].Labels["role"] != "reader" { t.Fatal("labels alias input") }
}
func TestSnapshotSurvivesSourceMutation(t *testing.T) {
    src := sourceRecords(); dst := Snapshot(src)
    src[0].Payload[0] = 'z'; src[0].Labels["role"] = "writer"
    if string(dst[0].Payload) != "abc" || dst[0].Labels["role"] != "reader" {
        t.Fatal("source mutation changed snapshot")
    }
}
func TestSnapshotPreservesNilAndEmpty(t *testing.T) {
    if Snapshot(nil) != nil { t.Fatal("nil outer slice changed") }
    if Snapshot([]Record{}) == nil { t.Fatal("empty outer slice changed to nil") }
    got := Snapshot([]Record{{ID:"nil"}, {ID:"empty",Payload:[]byte{},Labels:map[string]string{}}})
    if got[0].Payload != nil || got[0].Labels != nil { t.Fatal("nil fields changed") }
    if got[1].Payload == nil || got[1].Labels == nil { t.Fatal("empty fields changed to nil") }
}
func TestSnapshotPreservesOrderAndValues(t *testing.T) {
    src := sourceRecords(); src = append(src, Record{ID:"u2"})
    got := Snapshot(src)
    if len(got)!=2 || got[0].ID!="u1" || got[1].ID!="u2" || string(got[0].Payload)!="abc" {
        t.Fatalf("unexpected snapshot: %#v",got)
    }
    got[0].ID="new"
    if src[0].ID!="u1" { t.Fatal("outer slice aliases input") }
}
