package doubleprobe

import (
    "bytes"
    "io"
    "testing"
)

type readerOnly struct { done bool }
func (r *readerOnly) Read(p []byte) (int,error) {
    if r.done { return 0,io.EOF }
    r.done=true
    return copy(p,"abcd"),nil
}
type embeddedWriter struct { bytes.Buffer; writes int }
func (w *embeddedWriter) Write(p []byte)(int,error) {
    w.writes++
    return w.Buffer.Write(p[:1])
}
type explicitWriter struct { buffer bytes.Buffer; writes int }
func (w *explicitWriter) Write(p []byte)(int,error) {
    w.writes++
    return w.buffer.Write(p[:1])
}
func TestEmbeddedBufferPromotesReaderFromAndBypassesWrite(t *testing.T) {
    var dst embeddedWriter
    if _,ok:=interface{}(&dst).(io.ReaderFrom); !ok { t.Fatal("expected promoted ReaderFrom") }
    n,err:=io.Copy(&dst,&readerOnly{})
    if n!=4 || err!=nil || dst.writes!=0 || dst.String()!="abcd" {
       t.Fatalf("optional method not selected: n=%d err=%v writes=%d",n,err,dst.writes)
    }
}
func TestNamedBufferExercisesTheIntendedShortWrite(t *testing.T) {
    var dst explicitWriter
    if _,ok:=interface{}(&dst).(io.ReaderFrom); ok { t.Fatal("double accidentally implements ReaderFrom") }
    n,err:=io.Copy(&dst,&readerOnly{})
    if n!=1 || err!=io.ErrShortWrite || dst.writes!=1 {
       t.Fatalf("short write not exercised: n=%d err=%v writes=%d",n,err,dst.writes)
    }
}
