module example.com/doubleprobe

go 1.20
