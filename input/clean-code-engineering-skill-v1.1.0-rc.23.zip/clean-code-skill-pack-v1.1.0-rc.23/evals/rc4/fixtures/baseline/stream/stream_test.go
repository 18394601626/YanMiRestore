package stream

import (
    "bytes"
    "errors"
    "io"
    "strings"
    "testing"
)

type terminalReader struct { data string; terminal error; sent bool }
func (r *terminalReader) Read(p []byte) (int,error) {
    if r.sent { return 0, io.EOF }; r.sent=true
    return copy(p,r.data), r.terminal
}
type borrowedReader struct { io.Reader; closes int }
func (r *borrowedReader) Close() error { r.closes++; return nil }
type borrowedWriter struct { bytes.Buffer; closes int }
func (w *borrowedWriter) Close() error { w.closes++; return nil }
type limitedWriter struct { bytes.Buffer; err error }
func (w *limitedWriter) Write(p []byte)(int,error) {
    if len(p)==0{return 0,w.err}
    n,_:=w.Buffer.Write(p[:1]);return n,w.err
}
func TestCopyAcceptsDataWithEOF(t *testing.T) {
    var dst bytes.Buffer
    n,err:=Transfer(&dst,&terminalReader{data:"last",terminal:io.EOF})
    if err!=nil || n!=4 || dst.String()!="last" { t.Fatalf("lost final read: n=%d data=%q err=%v",n,dst.String(),err) }
}
func TestCopyKeepsPartialDataAndReadError(t *testing.T) {
    fault:=errors.New("source interrupted"); var dst bytes.Buffer
    n,err:=Transfer(&dst,&terminalReader{data:"part",terminal:fault})
    if !errors.Is(err,fault) || n!=4 || dst.String()!="part" { t.Fatalf("partial read lost: n=%d data=%q err=%v",n,dst.String(),err) }
}
func TestCopyDetectsShortWriteWithoutError(t *testing.T) {
    dst:=&limitedWriter{}
    // Nonconforming Writer is a defensive test, not a valid implementation example.
    n,err:=Transfer(dst,&terminalReader{data:"abcd",terminal:nil})
    if !errors.Is(err,io.ErrShortWrite) || n!=1 || dst.String()!="a" { t.Fatalf("short write reported success: n=%d err=%v",n,err) }
}
func TestCopyPreservesPartialWriteError(t *testing.T) {
    fault:=errors.New("destination unavailable");dst:=&limitedWriter{err:fault}
    n,err:=Transfer(dst,&terminalReader{data:"abcd",terminal:nil})
    if !errors.Is(err,fault) || n!=1 { t.Fatalf("write error lost: n=%d err=%v",n,err) }
}
func TestCopyDoesNotCloseBorrowedResources(t *testing.T) {
    src:=&borrowedReader{Reader:strings.NewReader("hello")}; dst:=&borrowedWriter{}
    n,err:=Transfer(dst,src)
    if n!=5 || err!=nil {t.Fatalf("copy failed: n=%d err=%v",n,err)}
    if src.closes!=0 || dst.closes!=0 { t.Fatalf("closed borrowed resource: reader=%d writer=%d",src.closes,dst.closes) }
}
func TestCopyEmptyInput(t *testing.T) {
    var dst bytes.Buffer
    n,err:=Transfer(&dst,strings.NewReader(""))
    if n!=0 || err!=nil || dst.Len()!=0 {t.Fatalf("empty: n=%d err=%v",n,err)}
}
func TestCopyHandlesMultipleChunks(t *testing.T) {
    data:=strings.Repeat("0123456789",1200)
    var dst bytes.Buffer
    n,err:=Transfer(&dst,strings.NewReader(data))
    if err!=nil || n!=int64(len(data)) || dst.String()!=data { t.Fatalf("chunked copy: n=%d err=%v",n,err) }
}
