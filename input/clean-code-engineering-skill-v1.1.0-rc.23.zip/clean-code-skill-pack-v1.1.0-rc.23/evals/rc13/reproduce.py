"""Replay the controlled document checks; no network, model or business runtime.

The stage inventory is fixed to this release. Raw outputs and counts are saved.
Only a new output directory outside the package is allowed. This is not a
sandbox for untrusted tests or a general-purpose CI result parser.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

STAGES = [
    ('package', 'evals/test_package.py', 8),
    ('book-index', 'evals/book/test_book_coverage.py', 12),
    ('source-corrections', 'evals/rc12/test_source_corrections.py', 5),
    ('consistency-regressions', 'evals/rc12/test_consistency.py', 22),
    ('original-boundary-probes', 'evals/rc13/test_boundary_probes.py', 12),
    ('navigation-inventory', 'evals/rc13/test_navigation_inventory.py', 27),
    ('replay-cli', 'evals/rc13/test_reproduce_cli.py', 4),
    ('corpus-inspection', 'evals/book/check_consistency.py', None),
]


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    if output.exists() or output == root or root in output.parents:
        parser.error('output must be new and outside the package root')
    output.mkdir(parents=True)
    env = dict(os.environ, BOOK_PACK_ROOT=str(root), AUDIT_PACK_ROOT=str(root),
               AUDIT_OUTPUT=str(output / 'original-boundary-details'),
               PYTHONDONTWRITEBYTECODE='1')
    env.pop('BOOK_CHECKER', None)
    results = []
    interrupted = False
    for label, script, expected in STAGES:
        row = {'stage': label, 'command': [sys.executable, '-S', script],
               'cwd': str(root), 'expected_methods': expected, 'observed_methods': 0,
               'started_utc': datetime.now(timezone.utc).isoformat()}
        stdout, stderr = b'', b''
        start = time.monotonic()
        if interrupted:
            row.update(status='NOT_RUN', exit_code=None)
        else:
            try:
                proc = subprocess.run(row['command'], cwd=root, env=env,
                                      capture_output=True, timeout=45)
                stdout, stderr = proc.stdout, proc.stderr
                row.update(exit_code=proc.returncode, status='FAIL')
                if expected is None:
                    corpus = json.loads(stdout)
                    if proc.returncode == 0 and corpus.get('ok') is True:
                        row['status'] = 'PASS'
                    row['corpus'] = corpus
                else:
                    found = re.findall(rb'^Ran (\d+) tests? in ', stderr, re.MULTILINE)
                    count = int(found[0]) if len(found) == 1 else 0
                    row['observed_methods'] = count
                    if count != expected:
                        row['status'] = 'INCOMPLETE'
                    elif proc.returncode == 0 and re.search(rb'^OK\s*$', stderr, re.MULTILINE):
                        row['status'] = 'PASS'
                    if label == 'original-boundary-probes':
                        details = json.loads((output / 'original-boundary-details/summary.json').read_text(encoding='utf-8'))
                        if (details['methods'] != expected or details['failures'] or details['errors']
                                or details['skipped'] or len(details['observations']) != expected):
                            row['status'] = 'FAIL'
            except subprocess.TimeoutExpired as exc:
                row.update(status='TIMEOUT', exit_code=None)
                stdout, stderr = exc.stdout or b'', exc.stderr or b''
            except KeyboardInterrupt:
                row.update(status='INTERRUPTED', exit_code=None)
                interrupted = True
            except (OSError, ValueError, KeyError, TypeError) as exc:
                row.update(status='ERROR', exit_code=None)
                stderr += (f'{type(exc).__name__}: {exc}\n').encode('utf-8')
        row.update(seconds=time.monotonic() - start,
                   stdout_sha256=sha(stdout), stderr_sha256=sha(stderr))
        (output / f'{label}.stdout').write_bytes(stdout)
        (output / f'{label}.stderr').write_bytes(stderr)
        results.append(row)
        print(label, row['status'], flush=True)
    summary = {'kind': 'controlled_document_checks_not_book_semantics_or_AI_AB',
               'version': (root / 'VERSION').read_text(encoding='utf-8').strip(),
               'stages': results, 'all_pass': all(r['status'] == 'PASS' for r in results),
               'observed_test_methods': sum(r['observed_methods'] for r in results),
               'semantic_source_verified': False, 'agent_behavior_tested': False}
    (output / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return 130 if interrupted else (0 if summary['all_pass'] else 1)


if __name__ == '__main__':
    raise SystemExit(main())
