"""Frozen corpus-copy probes; synthetic changes are NOT original-source errors.

These checks exercise the shipped read-only checker, not its internal helpers.
No model, external process, or network is used. Semantic truth is out of scope.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(os.environ.get('BOOK_PACK_ROOT', Path(__file__).resolve().parents[2])).resolve()
CHECKER = Path(os.environ.get('BOOK_CHECKER', ROOT / 'evals/book/check_consistency.py'))
spec = importlib.util.spec_from_file_location('navigation_inventory_subject', CHECKER)
subject = importlib.util.module_from_spec(spec)
spec.loader.exec_module(subject)


def fingerprint(root: Path) -> dict[str, str]:
    return {p.relative_to(root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in root.rglob('*') if p.is_file()}


class NavigationInventoryChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='rc13-corpus-test-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.book = self.root / 'clean-code-engineering/references/book'
        shutil.copytree(ROOT / 'clean-code-engineering/references/book', self.book)
        self.display = self.book / 'coverage.md'

    def outcome(self):
        before = fingerprint(self.book)
        result = subject.corpus_check(self.root)
        self.assertEqual(fingerprint(self.book), before, 'checker must not edit input')
        self.assertIs(result['semantic_source_verified'], False)
        self.assertIs(result['agent_behavior_tested'], False)
        return result

    def reject(self, prefix):
        result = self.outcome()
        self.assertFalse(result['ok'], result)
        self.assertTrue(any(e['kind'].startswith(prefix) for e in result['errors']), result)

    def change_cell(self, ident, column, value):
        lines = self.display.read_text(encoding='utf-8').splitlines(True)
        indices = [i for i, line in enumerate(lines) if line.startswith('| ' + ident + ' |')]
        self.assertEqual(len(indices), 1)
        i = indices[0]
        cells = [c.strip() for c in lines[i].strip().strip('|').split('|')]
        cells[column] = value
        lines[i] = '| ' + ' | '.join(cells) + ' |\n'
        self.display.write_text(''.join(lines), encoding='utf-8')

    def replace_once(self, old, new):
        text = self.display.read_text(encoding='utf-8')
        self.assertEqual(text.count(old), 1)
        self.display.write_text(text.replace(old, new, 1), encoding='utf-8')

    def note(self, content, name='notes/review.md'):
        path = self.book / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding='utf-8')

    def test_current_data_accepted(self):
        self.assertTrue(self.outcome()['ok'])

    def test_cell_padding_and_crlf_accepted(self):
        text = self.display.read_text(encoding='utf-8')
        self.display.write_bytes(text.replace(' | ', '  |  ').replace('\n', '\r\n').encode('utf-8'))
        self.assertTrue(self.outcome()['ok'])

    def test_display_title_drift_rejected(self):
        self.change_cell('7.7', 1, '测试标题；非原书')
        self.reject('coverage_display')

    def test_display_book_page_drift_rejected(self):
        self.change_cell('7.7', 2, '777')
        self.reject('coverage_display')

    def test_display_pdf_page_drift_rejected(self):
        self.change_cell('7.7', 3, '777')
        self.reject('coverage_display')

    def test_display_extra_annotation_in_link_cell_rejected(self):
        self.change_cell('7.7', 5, '[BK-7-7](ch07.md#bk-7-7) 全部完成')
        self.reject('coverage_display')

    def test_existing_summary_target_drift_rejected(self):
        self.change_cell('14.3', 5, '[既有概要](../01-writing.md)')
        self.reject('coverage_display')

    def test_missing_source_state_drift_rejected(self):
        self.change_cell('END', 4, '源页已提炼')
        self.reject('coverage_display')

    def test_duplicate_row_rejected(self):
        line = next(x for x in self.display.read_text(encoding='utf-8').splitlines(True) if x.startswith('| 7.7 |'))
        self.replace_once(line, line + line)
        self.reject('coverage_display')

    def test_swapped_rows_rejected(self):
        lines = self.display.read_text(encoding='utf-8').splitlines(True)
        a = next(i for i, x in enumerate(lines) if x.startswith('| 7.7 |'))
        b = next(i for i, x in enumerate(lines) if x.startswith('| 7.8 |'))
        lines[a], lines[b] = lines[b], lines[a]
        self.display.write_text(''.join(lines), encoding='utf-8')
        self.reject('coverage_display')

    def test_unknown_row_rejected(self):
        self.change_cell('7.7', 0, 'UNKNOWN-SECTION')
        self.reject('coverage_display')

    def test_missing_display_file_reported(self):
        self.display.unlink()
        self.reject('coverage_display')

    def test_truncated_table_header_rejected(self):
        self.replace_once('| 原目录编号 | 原标题 |', '| 未支持表头 | 原标题 |')
        self.reject('coverage_display')

    def test_bad_table_separator_rejected(self):
        self.replace_once('|---|---|---:|---:|---|---|', '|not-a-separator|---|---:|---:|---|---|')
        self.reject('coverage_display')

    def test_bad_column_count_rejected(self):
        self.change_cell('7.7', 1, '测试 | 多了一列')
        self.reject('coverage_display')

    def test_front_matter_table_drift_rejected(self):
        self.change_cell('封面', 1, '99—99')
        self.reject('coverage_display')

    def test_heuristic_table_drift_rejected(self):
        self.change_cell('C1', 3, '[原卡](../01-writing.md)')
        self.reject('coverage_display')

    def test_unknown_nested_card_anchor_rejected(self):
        self.note('<a id="bk-probe-nested"></a>\n## BK-PROBE-NESTED｜测试专用\n')
        self.reject('card_inventory')

    def test_duplicate_registered_card_in_new_file_rejected(self):
        self.note('<a id="bk-9-4"></a>\n## BK-9-4｜测试专用重复\n')
        self.reject('card_inventory')

    def test_unanchored_card_heading_rejected(self):
        self.note('## BK-PROBE-HEADING｜测试专用，未登记\n')
        self.reject('card_inventory')

    def test_uppercase_markdown_extension_scanned(self):
        self.note('<a id="bk-probe-extension"></a>\n', 'notes/review.MD')
        self.reject('card_inventory')

    def test_plain_navigation_note_accepted(self):
        self.note('# 审阅说明\n\n<a id="review-notes"></a>\n\n此文件不声明知识卡。\n')
        self.assertTrue(self.outcome()['ok'])

    def test_fenced_card_example_accepted(self):
        self.note('# 格式示例，不是新增知识卡\n\n```markdown\n<a id="bk-example-only"></a>\n## BK-EXAMPLE-ONLY｜展示语法\n```\n')
        self.assertTrue(self.outcome()['ok'])

    def test_tilde_fenced_card_example_accepted(self):
        self.note('~~~markdown\n<a id="bk-example-only"></a>\n## BK-EXAMPLE-ONLY｜展示语法\n~~~\n')
        self.assertTrue(self.outcome()['ok'])

    def test_real_card_after_fence_not_ignored(self):
        self.note('```markdown\n<a id="bk-example-only"></a>\n```\n<a id="bk-real-unindexed"></a>\n')
        self.reject('card_inventory')

    def test_extra_card_format_in_registered_file_rejected(self):
        with (self.book / 'ch09.md').open('a', encoding='utf-8') as f:
            f.write('\n## BK-PROBE-HEADING｜缺少锚点的测试卡\n')
        self.reject('card_inventory')

    def test_invalid_utf8_note_reported(self):
        (self.book / 'review.md').write_bytes(b'\xff')
        self.reject('card_inventory')


if __name__ == '__main__':
    unittest.main(verbosity=2)
