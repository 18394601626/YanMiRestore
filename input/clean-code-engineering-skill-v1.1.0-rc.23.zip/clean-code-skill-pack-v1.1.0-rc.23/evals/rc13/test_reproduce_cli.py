"""CLI guards for the controlled document-only replay entry point."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(os.environ.get('BOOK_PACK_ROOT', Path(__file__).resolve().parents[2])).resolve()
ENTRY = ROOT / 'evals/rc13/reproduce.py'

class ReplayCLI(unittest.TestCase):
    def invoke(self, *args):
        return subprocess.run([sys.executable, '-S', str(ENTRY), *args],
                              cwd=ROOT, capture_output=True, text=True, timeout=5)

    def test_help_succeeds(self):
        result = self.invoke('--help')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('--output', result.stdout)

    def test_missing_output_refused(self):
        result = self.invoke()
        self.assertEqual(result.returncode, 2)
        self.assertIn('required', result.stderr)

    def test_in_package_new_output_refused(self):
        target = ROOT / 'evals/rc13/__must_not_create_output__'
        self.assertFalse(target.exists())
        result = self.invoke('--output', str(target))
        self.assertEqual(result.returncode, 2)
        self.assertIn('outside', result.stderr)
        self.assertFalse(target.exists())

    def test_existing_output_not_overwritten(self):
        with tempfile.TemporaryDirectory() as temp:
            target = Path(temp)
            sentinel = target / 'keep.txt'
            sentinel.write_text('keep', encoding='utf-8')
            result = self.invoke('--output', str(target))
            self.assertEqual(result.returncode, 2)
            self.assertIn('new', result.stderr)
            self.assertEqual(sentinel.read_text(encoding='utf-8'), 'keep')
            self.assertEqual(list(target.iterdir()), [sentinel])

if __name__ == '__main__':
    unittest.main(verbosity=2)
