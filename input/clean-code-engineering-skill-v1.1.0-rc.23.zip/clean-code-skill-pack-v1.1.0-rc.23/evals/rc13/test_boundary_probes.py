"""Read-only rc.12 checker probes. All mutations exist only in disposable copies.
The new navigation/unindexed-card requirements are NOT claims that current data is wrong.
No AI generation, no network, no business runtime tests.
"""
from __future__ import annotations
import argparse
import difflib
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(os.environ["AUDIT_PACK_ROOT"]).resolve()
CHECKER = ROOT / "evals/book/check_consistency.py"
OUTPUT = Path(os.environ["AUDIT_OUTPUT"]).resolve()
OUTPUT.mkdir(parents=True, exist_ok=False)
spec = importlib.util.spec_from_file_location("rc12_subject_unchanged", CHECKER)
subject = importlib.util.module_from_spec(spec)
spec.loader.exec_module(subject)
OBSERVATIONS = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def state(path):
    return {p.relative_to(path).as_posix(): p.read_bytes()
            for p in path.rglob("*") if p.is_file()}

def apply_mutation(book: Path, kind: str) -> None:
    cards_path = book / "cards.json"
    cards = json.loads(cards_path.read_text(encoding="utf-8"))
    card = next(c for c in cards if c["id"] == "BK-9-4")
    md = book / card["target"].split("#")[0]
    if kind == "pristine":
        return
    if kind == "json_layout":
        cards_path.write_text(json.dumps(cards,ensure_ascii=False,sort_keys=True),encoding="utf-8")
        return
    if kind == "missing_chapter":
        md.unlink()
        return
    if kind == "markdown_body":
        text=md.read_text(encoding="utf-8")
        assert text.count(card["qualification"]) == 1
        md.write_text(text.replace(card["qualification"],"【测试用错误，不是原书内容】一切测试都只能有一个断言。"),encoding="utf-8")
        return
    if kind == "wrong_backlink":
        cp=book/"coverage.json"
        cov=json.loads(cp.read_text(encoding="utf-8"))
        row=next(x for x in cov["toc"] if x["id"]=="7.7")
        row["card_ids"]=["BK-7-8"]
        cp.write_text(json.dumps(cov,ensure_ascii=False,indent=2),encoding="utf-8")
        return
    if kind == "duplicate_anchor":
        text=md.read_text(encoding="utf-8")
        anchor='<a id="bk-9-4"></a>'
        assert text.count(anchor)==1
        md.write_text(text.replace(anchor,anchor+"\n"+anchor),encoding="utf-8")
        return
    if kind == "truncated_json":
        cards_path.write_text("[",encoding="utf-8")
        return
    if kind == "markdown_page":
        text=md.read_text(encoding="utf-8")
        old="书内 121—123 页；PDF第 135—137 页"
        assert text.count(old)==1
        md.write_text(text.replace(old,"书内 121—123 页；PDF第 135—138 页"),encoding="utf-8")
        return
    if kind in {"coverage_status","coverage_link","coverage_row_missing"}:
        path=book/"coverage.md"
        lines=path.read_text(encoding="utf-8").splitlines(keepends=True)
        ident={"coverage_status":"14.3","coverage_link":"7.7","coverage_row_missing":"4.4.19"}[kind]
        indices=[i for i,line in enumerate(lines) if line.startswith("| "+ident+" |")]
        assert len(indices)==1, indices
        i=indices[0]
        if kind=="coverage_status":
            assert "沿用概要，细节待核对" in lines[i], lines[i]
            lines[i]=lines[i].replace("沿用概要，细节待核对","源页已提炼")
        elif kind=="coverage_link":
            assert "[BK-7-7](ch07.md#bk-7-7)" in lines[i]
            lines[i]=lines[i].replace("[BK-7-7](ch07.md#bk-7-7)","[BK-7-8](ch07.md#bk-7-8)")
        else:
            del lines[i]
        path.write_text("".join(lines),encoding="utf-8")
        return
    if kind=="orphan_card":
        path=book/"ch14-unindexed-probe.md"
        assert not path.exists()
        path.write_text(
            '# 测试用未登记卡，非原书内容\n\n'
            '<a id="bk-probe-unindexed"></a>\n'
            '## BK-PROBE-UNINDEXED｜测试卡，不是正式知识\n'
            '原目录：14.3；书内 197 页；PDF第 211 页（从文件第一页起数）。\n\n'
            '**原书要点（重述）：** 【测试用占位，不是原书内容】\n\n'
            '**限定、反例或覆盖边界：** 该卡未登记到JSON，仅用于检出漏扫文件。\n\n'
            '**执行问题（非原书逐字规则）：** 是否应报告尚未登记的卡片？\n',
            encoding="utf-8")
        return
    raise ValueError(kind)

class CheckerBoundary(unittest.TestCase):
    def case(self,kind,expect_ok):
        with tempfile.TemporaryDirectory(prefix="rc12-readonly-probe-") as temp:
            local=Path(temp)
            book=local/"clean-code-engineering/references/book"
            shutil.copytree(ROOT/"clean-code-engineering/references/book",book)
            before=state(book)
            apply_mutation(book,kind)
            mutated=state(book)
            differences=[]
            diff=[]
            for rel in sorted(set(before)|set(mutated)):
                if before.get(rel)==mutated.get(rel):
                    continue
                differences.append({"path":rel,"before_sha256":sha(before[rel]) if rel in before else None,
                                    "after_sha256":sha(mutated[rel]) if rel in mutated else None})
                diff.extend(difflib.unified_diff(before.get(rel,b"").decode("utf-8").splitlines(True),
                                                mutated.get(rel,b"").decode("utf-8").splitlines(True),
                                                fromfile="before/"+rel,tofile="probe/"+rel))
            (OUTPUT/(kind+".diff")).write_text("".join(diff),encoding="utf-8")
            try:
                result=subject.corpus_check(local)
                exception=None
            except Exception as exc:
                result=None
                exception=f"{type(exc).__name__}: {exc}"
            after=state(book)
            row={"id":kind,"expected_ok":expect_ok,"result":result,
                 "exception":exception,"checker_writes": mutated!=after,
                 "diff":kind+".diff","changes":differences}
            OBSERVATIONS.append(row)
            self.assertIsNone(exception, "checker should return a diagnostic, not crash")
            self.assertEqual(after,mutated,"subject must not write corpus")
            self.assertEqual(result["ok"],expect_ok, f"{kind}: {result}")
            if not expect_ok:
                self.assertTrue(result["errors"])
    def test_01_current_data(self): self.case("pristine",True)
    def test_02_json_layout_only(self): self.case("json_layout",True)
    def test_03_missing_referenced_file(self): self.case("missing_chapter",False)
    def test_04_markdown_body_diverges(self): self.case("markdown_body",False)
    def test_05_wrong_existing_backlink(self): self.case("wrong_backlink",False)
    def test_06_duplicate_anchor(self): self.case("duplicate_anchor",False)
    def test_07_truncated_json(self): self.case("truncated_json",False)
    def test_08_markdown_page_diverges(self): self.case("markdown_page",False)
    def test_09_display_status_diverges(self): self.case("coverage_status",False)
    def test_10_display_target_diverges(self): self.case("coverage_link",False)
    def test_11_display_row_is_missing(self): self.case("coverage_row_missing",False)
    def test_12_new_unindexed_card(self): self.case("orphan_card",False)

if __name__=="__main__":
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(CheckerBoundary)
    res=unittest.TextTestRunner(verbosity=2).run(suite)
    summary={"kind":"checker_boundary_injected_inputs_not_source_errors_or_AI_AB",
             "target_sha256":sha(CHECKER.read_bytes()),
             "methods":res.testsRun,"failures":len(res.failures),"errors":len(res.errors),
             "skipped":len(res.skipped),"observations":OBSERVATIONS}
    (OUTPUT/"summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    raise SystemExit(0 if res.wasSuccessful() else 1)
