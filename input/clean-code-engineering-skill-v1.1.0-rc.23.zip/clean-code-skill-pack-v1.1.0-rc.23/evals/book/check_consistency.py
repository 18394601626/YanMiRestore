"""Check the owned book corpus mechanically; does NOT verify source meaning or completeness.

The accepted Markdown format is the existing anchored-card format, not arbitrary
Markdown. An unsupported format is reported, never silently accepted. No files
are written and no commands, models, or network services are invoked.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import re

ANCHOR = re.compile(r'^<a id="([^"\n]+)"></a>[ \t]*$', re.MULTILINE)
FIELDS = (
    ("principle", "**原书要点（重述）：** "),
    ("qualification", "**限定、反例或覆盖边界：** "),
    ("execution_question", "**执行问题（非原书逐字规则）：** "),
)


def _page_range(value: list[int]) -> str:
    if not isinstance(value, list) or len(value) != 2:
        raise ValueError("page range must contain two integers")
    if any(type(x) is not int for x in value) or not 1 <= value[0] <= value[1]:
        raise ValueError("invalid page range")
    return str(value[0]) if value[0] == value[1] else f"{value[0]}—{value[1]}"


def _unique_index(rows: list[dict], label: str, errors: list[dict]) -> dict:
    if not isinstance(rows, list):
        raise ValueError(f"{label} must be a list")
    counts = Counter(row["id"] for row in rows)
    for ident, count in counts.items():
        if not isinstance(ident, str) or not ident:
            raise ValueError(f"invalid {label} id")
        if count != 1:
            errors.append({"kind": "duplicate_id", "collection": label, "id": ident})
    return {row["id"]: row for row in rows}


def _edges(row: dict, key: str, errors: list[dict]) -> list[str]:
    values = row[key]
    if not isinstance(values, list) or any(not isinstance(x, str) or not x for x in values):
        raise ValueError(f"invalid {key} for {row['id']}")
    if len(values) != len(set(values)):
        errors.append({"kind": "duplicate_edge", "id": row["id"], "field": key})
    return values


def _check_links(cards: list[dict], toc: list[dict], errors: list[dict]) -> None:
    card_map = _unique_index(cards, "cards", errors)
    section_map = _unique_index(toc, "toc", errors)
    reverse = defaultdict(set)
    for card in cards:
        for section in _edges(card, "section_ids", errors):
            if section not in section_map:
                errors.append({"kind": "unknown_section", "card": card["id"], "section": section})
            reverse[section].add(card["id"])
    for row in toc:
        links = _edges(row, "card_ids", errors)
        for ident in links:
            if ident not in card_map:
                errors.append({"kind": "unknown_card", "section": row["id"], "card": ident})
        expected = reverse[row["id"]]
        if set(links) != expected:
            errors.append({"kind": "two_way_reference_mismatch", "section": row["id"],
                           "expected": sorted(expected), "actual": sorted(set(links))})


def _read_segments(path: Path) -> dict[str, list[str]]:
    text = path.read_text(encoding="utf-8")
    markers = list(ANCHOR.finditer(text))
    result = defaultdict(list)
    for index, marker in enumerate(markers):
        end = markers[index + 1].start() if index + 1 < len(markers) else len(text)
        result[marker.group(1)].append(text[marker.end():end].strip())
    return result


def _check_card(card: dict, segment: str, errors: list[dict]) -> None:
    # Paragraph boundaries matter: a substring search misses appended contradictions.
    blocks = segment.split("\n\n")
    if len(blocks) != 4:
        errors.append({"kind": "markdown_structure", "card": card["id"], "blocks": len(blocks)})
        return
    expected_header = (
        f"## {card['id']}｜{card['title']}\n"
        f"原目录：{'、'.join(card['section_ids'])}；书内 {_page_range(card['book_pages'])} 页；"
        f"PDF第 {_page_range(card['pdf_pages'])} 页（从文件第一页起数）。"
    )
    if blocks[0] != expected_header:
        errors.append({"kind": "markdown_metadata_mismatch", "card": card["id"]})
    for (field, prefix), block in zip(FIELDS, blocks[1:]):
        value = card[field]
        if not isinstance(value, str) or not value.strip():
            raise ValueError(f"{card['id']} has empty or non-text {field}")
        if block != prefix + value:
            errors.append({"kind": "markdown_json_mismatch", "card": card["id"], "field": field})


def _check_markdown(book: Path, cards: list[dict], errors: list[dict]) -> None:
    files = {}
    targets = Counter()
    for card in cards:
        parts = card["target"].split("#")
        if len(parts) != 2 or not all(parts):
            raise ValueError(f"invalid target for {card['id']}")
        filename, anchor = parts
        path = (book / filename).resolve()
        try:
            path.relative_to(book.resolve())
        except ValueError:
            errors.append({"kind": "target_outside_book", "card": card["id"]})
            continue
        if path.suffix != ".md":
            raise ValueError(f"target must be a Markdown file for {card['id']}")
        targets[(path, anchor)] += 1
        if path not in files:
            files[path] = _read_segments(path)
        segments = files[path].get(anchor, [])
        if len(segments) != 1:
            errors.append({"kind": "anchor_count", "card": card["id"], "count": len(segments)})
            continue
        _check_card(card, segments[0], errors)
    for path, segments in files.items():
        for anchor, blocks in segments.items():
            if targets[(path, anchor)] != 1:
                errors.append({"kind": "anchor_mapping_count", "file": path.name,
                               "anchor": anchor, "count": targets[(path, anchor)]})


STATUS_LABELS = {
    "SOURCE_SUMMARIZED": "源页已提炼",
    "PARTIAL_SOURCE": "部分源文可见",
    "INHERITED_SUMMARY": "沿用概要，细节待核对",
    "SOURCE_MISSING": "源文件缺失",
    "REFERENCE_ONLY": "资料定位，不转规则",
    "CHAPTER_INDEX": "章节入口",
}


def _table_cells(line: str) -> list[str] | None:
    """Read our pipe-delimited table format, not general Markdown tables."""
    line = line.strip()
    if not (line.startswith("|") and line.endswith("|")):
        return None
    return [cell.strip() for cell in line[1:-1].split("|")]


def _check_display_table(lines: list[str], label: str, header: list[str],
                         expected: list[list[str]], errors: list[dict]) -> int:
    starts = [i for i, line in enumerate(lines) if _table_cells(line) == header]
    if len(starts) != 1:
        errors.append({"kind": "coverage_display_header", "table": label,
                       "count": len(starts)})
        return 0
    index = starts[0] + 1
    separator = _table_cells(lines[index]) if index < len(lines) else None
    if (separator is None or len(separator) != len(header)
            or any(re.fullmatch(r":?-{3,}:?", cell) is None for cell in separator)):
        errors.append({"kind": "coverage_display_separator", "table": label})
        return 0
    actual = []
    for line in lines[index + 1:]:
        if not line.lstrip().startswith("|"):
            break
        cells = _table_cells(line)
        if cells is None or len(cells) != len(header):
            errors.append({"kind": "coverage_display_columns", "table": label,
                           "row": len(actual) + 1, "actual": cells})
        actual.append(cells)
    if len(actual) != len(expected):
        errors.append({"kind": "coverage_display_row_count", "table": label,
                       "expected": len(expected), "actual": len(actual)})
    # Position is part of the contract: detects reordering, duplicates and missing rows.
    for position, (got, want) in enumerate(zip(actual, expected), 1):
        if got != want:
            errors.append({"kind": "coverage_display_row_mismatch", "table": label,
                           "row": position, "id": want[0], "expected": want, "actual": got})
    return len(actual)


def _check_coverage_display(book: Path, cards: list[dict], coverage: dict,
                            errors: list[dict]) -> dict:
    try:
        lines = (book / "coverage.md").read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError) as exc:
        errors.append({"kind": "coverage_display_unreadable", "type": type(exc).__name__,
                       "message": str(exc)})
        return {}
    card_map = {card["id"]: card for card in cards}
    toc_rows = []
    for row in coverage["toc"]:
        links = "、".join(f"[{cid}]({card_map[cid]['target']})" for cid in row["card_ids"])
        if not links:
            target = row.get("existing_reference")
            links = f"[既有概要]({target})" if target else "无；不补写"
        toc_rows.append([row["id"], row["title"], str(row["toc_book_page"]),
                         str(row["pdf_start"]) if row["pdf_start"] is not None else "缺失",
                         STATUS_LABELS[row["status"]], links])
    # Front-matter and existing heuristic rows are displays of the same manifest.
    # Comparing them does not re-audit their meaning against the scanned book.
    front_rows = [[row["title"], f"{row['pdf_pages'][0]}—{row['pdf_pages'][1]}", row["note"]]
                  for row in coverage["front_matter"]]
    heuristic_rows = [[row["id"], row["title"],
                       f"{row['book_pages'][0]}—{row['book_pages'][1]}",
                       f"[原卡]({row['target']})"] for row in coverage["heuristics"]]
    tables = [
        ("toc", ["原目录编号", "原标题", "目录书内起页", "PDF起页", "当前状态", "新卡 / 既有资料"], toc_rows),
        ("front_matter", ["内容", "PDF页", "状态与处理"], front_rows),
        ("heuristics", ["编号", "已有标题", "书内页", "资料"], heuristic_rows),
    ]
    return {label: _check_display_table(lines, label, header, rows, errors)
            for label, header, rows in tables}


CARD_HEADING = re.compile(r"^##[ \t]+(BK-[^｜\n]+)｜")
FENCE = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")


def _unfenced_lines(text: str):
    """Ignore fenced examples in standalone notes; keep actual card declarations."""
    fence_char, fence_length = None, 0
    for line in text.splitlines():
        match = FENCE.match(line)
        if fence_char is not None:
            if (match and match.group(1)[0] == fence_char
                    and len(match.group(1)) >= fence_length and not match.group(2).strip()):
                fence_char = None
            continue
        if match:
            fence_char, fence_length = match.group(1)[0], len(match.group(1))
        else:
            yield line


def _check_card_inventory(book: Path, cards: list[dict], errors: list[dict]) -> dict:
    expected_anchors, expected_headings = Counter(), Counter()
    for card in cards:
        filename, anchor = card["target"].split("#")
        try:
            relative = (book / filename).resolve().relative_to(book.resolve()).as_posix()
        except ValueError:
            # The referenced-file check already reports out-of-book targets.
            continue
        expected_anchors[(relative, anchor)] += 1
        expected_headings[(relative, card["id"])] += 1
    actual_anchors, actual_headings = Counter(), Counter()
    scanned = 0
    for path in sorted(book.rglob("*")):
        if path.suffix.lower() != ".md":
            continue
        relative = path.relative_to(book).as_posix()
        if path.is_symlink():
            errors.append({"kind": "card_inventory_unsupported_link", "file": relative})
            continue
        if not path.is_file():
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError) as exc:
            errors.append({"kind": "card_inventory_unreadable", "file": relative,
                           "type": type(exc).__name__, "message": str(exc)})
            continue
        scanned += 1
        for line in _unfenced_lines(text):
            anchor = ANCHOR.fullmatch(line)
            if anchor and anchor.group(1).startswith("bk-"):
                actual_anchors[(relative, anchor.group(1))] += 1
            heading = CARD_HEADING.match(line)
            if heading:
                actual_headings[(relative, heading.group(1))] += 1
    for marker, expected, actual in [("anchor", expected_anchors, actual_anchors),
                                     ("heading", expected_headings, actual_headings)]:
        for filename, ident in sorted(set(expected) | set(actual)):
            key = (filename, ident)
            if expected[key] != actual[key]:
                errors.append({"kind": "card_inventory_mismatch", "marker": marker,
                               "file": filename, "id": ident,
                               "expected": expected[key], "actual": actual[key]})
    return {"markdown_files_scanned": scanned, "card_anchors_found": sum(actual_anchors.values()),
            "card_headings_found": sum(actual_headings.values())}


def corpus_check(root: Path) -> dict:
    """Return structured diagnostics, including for missing or malformed owned data."""
    errors: list[dict] = []
    result = {"kind": "mechanical_consistency_only", "errors": errors,
              "semantic_source_verified": False, "agent_behavior_tested": False}
    book = Path(root).resolve() / "clean-code-engineering/references/book"
    try:
        cards = json.loads((book / "cards.json").read_text(encoding="utf-8"))
        coverage = json.loads((book / "coverage.json").read_text(encoding="utf-8"))
        toc = coverage["toc"]
        _check_links(cards, toc, errors)
        counts = dict(Counter(row["status"] for row in toc))
        for key, actual in [("card_count", len(cards)), ("toc_count", len(toc)), ("toc_status_counts", counts)]:
            if coverage[key] != actual:
                errors.append({"kind": "metadata_mismatch", "field": key,
                               "declared": coverage[key], "actual": actual})
        _check_markdown(book, cards, errors)
        result["display_table_rows"] = _check_coverage_display(book, cards, coverage, errors)
        result["card_inventory"] = _check_card_inventory(book, cards, errors)
        result.update(card_count=len(cards), toc_count=len(toc), status_counts=counts,
                      linked_toc_count=sum(bool(row["card_ids"]) for row in toc))
    except (OSError, UnicodeError, ValueError, TypeError, KeyError, AttributeError) as exc:
        errors.append({"kind": "invalid_corpus", "type": type(exc).__name__, "message": str(exc)})
    result["ok"] = not errors
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[2])
    args = parser.parse_args()
    result = corpus_check(args.root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
