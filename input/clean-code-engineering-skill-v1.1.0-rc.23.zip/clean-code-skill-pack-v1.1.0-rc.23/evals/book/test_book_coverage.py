"""Check source indexing and document consistency, not semantic exhaustiveness or agent behavior."""
import hashlib,json,os,re,unittest
from pathlib import Path
ROOT=Path(os.environ['BOOK_PACK_ROOT']).resolve()
SKILL=ROOT/'clean-code-engineering'
BOOK=SKILL/'references/book'
EXPECTED=[line.split('\t') for line in Path(__file__).with_name('toc.tsv').read_text(encoding='utf-8').splitlines()]
class BookCoverage(unittest.TestCase):
 def data(self):return json.loads((BOOK/'coverage.json').read_text(encoding='utf-8'))
 def cards(self):return json.loads((BOOK/'cards.json').read_text(encoding='utf-8'))
 def test_toc_exact_entries_and_order(self):
  self.assertEqual([(x['id'],x['title'],str(x['toc_book_page'])) for x in self.data()['toc']], [tuple(x) for x in EXPECTED])
 def test_unique_cards_and_valid_sections(self):
  cards=self.cards();self.assertEqual(len(cards),len({x['id'] for x in cards}));ids={r[0] for r in EXPECTED}
  for c in cards:self.assertTrue(set(c['section_ids'])<=ids)
 def test_missing_source_not_filled_from_knowledge(self):
  rows={x['id']:x for x in self.data()['toc']}
  for k in ['8.3','END']:
   self.assertEqual(rows[k]['status'],'SOURCE_MISSING');self.assertFalse(rows[k]['card_ids']);self.assertIsNone(rows[k]['pdf_start'])
  self.assertEqual(rows['8.2']['status'],'PARTIAL_SOURCE')
 def test_checked_cards_have_paraphrase_boundary_and_question(self):
  for c in self.cards():
   for field in ['principle','qualification','execution_question','book_pages','pdf_pages','target']:
    self.assertTrue(c[field],(c['id'],field))
   self.assertEqual(c['execution_label'],'执行转化（非原书逐字规则）')
 def test_source_pages_exist_and_are_in_read_ranges(self):
  covered=set()
  for lo,hi in self.data()['reviewed_pdf_ranges']:covered.update(range(lo,hi+1))
  for c in self.cards():
   lo,hi=c['pdf_pages'];self.assertTrue(set(range(lo,hi+1))<=covered,c['id'])
   self.assertLessEqual(1,lo);self.assertLessEqual(hi,402)
   for p in range(c['book_pages'][0],c['book_pages'][1]+1):self.assertNotIn(p,[108,109,389])
 def test_toc_is_not_reported_as_semantic_completion(self):
  d=self.data();self.assertFalse(d['all_knowledge_points_complete']);self.assertFalse(d['agent_behavior_tested'])
  self.assertIn('目录项不等于知识点', (BOOK/'INDEX.md').read_text())
  self.assertTrue(any(x['status']=='INHERITED_SUMMARY' for x in d['toc']))
 def test_case_backtracking_not_flattened_into_one_way_rule(self):
  text=(BOOK/'ch15-junit.md').read_text()
  for term in ['shouldNotBeCompacted','formatCompactedComparison','prefixLength','suffixLength','折返','不是']:
   self.assertIn(term,text)
 def test_each_summary_links_to_real_card_anchor(self):
  cs={x['id']:x for x in self.cards()}
  for r in self.data()['toc']:
   if r['status'] in ['SOURCE_SUMMARIZED','PARTIAL_SOURCE']:self.assertTrue(r['card_ids'],r['id'])
   for cid in r['card_ids']:self.assertIn(cid,cs)
  for c in cs.values():
   file,anchor=c['target'].split('#');self.assertIn(f'id="{anchor}"',(BOOK/file).read_text())
 def test_heuristics_numbering_and_original_files_unchanged(self):
  manifest=json.loads((ROOT/'provenance/book-expansion/baseline-runtime.json').read_text())
  for path,h in manifest.items():
   if path.startswith('references/') or path.startswith('assets/'):
    self.assertEqual(hashlib.sha256((SKILL/path).read_bytes()).hexdigest(),h,path)
  text=(SKILL/'references/05-heuristics.md').read_text()
  expected=[f'{p}{i}' for p,n in [('C',5),('E',2),('F',4),('G',36),('J',3),('N',7),('T',9)] for i in range(1,n+1)]
  self.assertEqual(re.findall(r'^### ([CEFGJNT]\d+)\s',text,re.M),expected)
 def test_book_layer_is_routed_but_not_always_loaded(self):
  text=(SKILL/'SKILL.md').read_text()
  self.assertIn('references/book/INDEX.md',text);self.assertIn('按需',text)
  self.assertIn('全书主干',text);self.assertNotIn('全书逐知识点无遗漏版',text)
 def test_non_rule_material_is_explicit(self):
  rows={x['id']:x for x in self.data()['toc']}
  for k in ['1.9','3.15','11.12','17.9']:self.assertEqual(rows[k]['status'],'REFERENCE_ONLY')
  self.assertTrue(self.data()['front_matter'])
 def test_no_false_read_claim_for_unexpanded_long_cases(self):
  rows={x['id']:x for x in self.data()['toc']}
  for k in ['14.3','16.2','A.10.1','B']:self.assertEqual(rows[k]['status'],'INHERITED_SUMMARY')
  self.assertEqual(rows['9.5']['toc_book_page'],122)
  self.assertTrue(any(c['book_pages'][0]==123 for c in self.cards() if '9.5' in c['section_ids']))
if __name__=='__main__':unittest.main(verbosity=2)
