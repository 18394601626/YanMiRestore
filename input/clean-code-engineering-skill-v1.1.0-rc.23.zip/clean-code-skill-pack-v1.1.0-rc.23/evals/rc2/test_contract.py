"""RC2 static documentation checks. These are not agent-effect tests.

Reuse 18 RC1 content checks unmodified; its one literal rc1 version assertion
remains preserved and is replaced here by a separate rc2 version assertion.
Run the original 19-check file against the original rc1 package, not rc2.
"""
import importlib.util
import json
import os
from pathlib import Path
import unittest

PACKAGE = Path(__file__).resolve().parents[2]
ROOT = Path(os.environ.get('SKILL_PACKAGE_ROOT', str(PACKAGE))).resolve()
MAIN = 'clean-code-engineering/'

class RC2DocumentChecks(unittest.TestCase):
    def text(self, relative):
        path = ROOT/relative
        self.assertTrue(path.is_file(), relative)
        return path.read_text(encoding='utf-8')

    def test_01_rc2_version(self):
        self.assertEqual(self.text('VERSION').strip(), '1.1.0-rc.2')
        self.assertEqual(self.text(MAIN+'VERSION'), self.text('VERSION'))

    def test_02_routes_compatibility(self):
        self.assertIn('references/10-compatibility-gate.md', self.text(MAIN+'SKILL.md'))
        self.assertIn('references/11-test-oracle.md', self.text(MAIN+'SKILL.md'))

    def test_03_old_caller_types(self):
        text=self.text(MAIN+'references/10-compatibility-gate.md')
        for term in ['函数值', '方法集', '可变参数', '旧调用者', '编译']:
            self.assertIn(term,text)

    def test_04_nil_and_wire(self):
        text=self.text(MAIN+'references/10-compatibility-gate.md')
        for term in ['typed nil', 'null', '[]', 'errors.Is', 'errors.As']:
            self.assertIn(term,text)

    def test_05_private_injection_not_public_breakage(self):
        text=self.text(MAIN+'references/10-compatibility-gate.md')
        for term in ['NewCatalog', '私有', 'func(*Repository) *Catalog', '默认不改变']:
            self.assertIn(term,text)

    def test_06_oracle_allows_alternative_design(self):
        text=self.text(MAIN+'references/11-test-oracle.md')
        for term in ['行为断言', '类型契约', '接口', '函数', '替代实现']:
            self.assertIn(term,text)

    def test_07_no_test_rewriting_for_green(self):
        text=self.text(MAIN+'references/11-test-oracle.md')
        for term in ['冻结', '历史', '版本', '失败', 'SKIP', '未运行']:
            self.assertIn(term,text)

    def test_08_compatibility_record(self):
        text=self.text(MAIN+'assets/compatibility-record.md')
        for term in ['旧契约', '允许变化', '证据', '未验证']:
            self.assertIn(term,text)

    def test_09_go_and_abstraction_link_to_gate(self):
        for name in ['08-go.md','09-abstraction-decisions.md']:
            self.assertIn('10-compatibility-gate.md',self.text(MAIN+'references/'+name))

    def test_10_source_and_non_book_boundary(self):
        text=self.text(MAIN+'references/10-compatibility-gate.md')
        for term in ['执行适配', '不是原书', 'go.dev/ref/spec', 'go.dev/blog/module-compatibility']:
            self.assertIn(term,text)

    def test_11_evaluation_limit(self):
        text=self.text('evals/rc2/README.md')
        for term in ['不是独立代理', 'A/B', '受控', '版本绑定', '10-compatibility-gate']:
            self.assertIn(term,text)

    def test_12_old_checks_not_deleted(self):
        text=self.text('evals/v1_1/test_upgrade_contract.py')
        self.assertIn("self.text('VERSION').strip(), '1.1.0-rc.1'",text)
        self.assertIn('test_17_version_and_evidence_limit',text)

    def test_13_provenance(self):
        data=json.loads(self.text('provenance/rc2/sources.json'))
        self.assertEqual(data['classification'],'execution_adaptation_not_book_text')
        self.assertTrue(data['sources'])
        self.assertIn('selftest-rc1-report.md.txt',self.text('CHANGELOG.md'))

    def test_14_no_automatic_business_rewriter(self):
        text=self.text('evals/rc2/README.md')
        self.assertIn('不会扫描或修改你的业务仓库',text)
        self.assertIn('原 A/B',text)


def suite():
    result=unittest.TestSuite()
    loader=unittest.TestLoader()
    spec=importlib.util.spec_from_file_location('preserved_rc1_checks',PACKAGE/'evals/v1_1/test_upgrade_contract.py')
    legacy=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(legacy)
    for name in loader.getTestCaseNames(legacy.UpgradeContractChecks):
        if name!='test_17_version_and_evidence_limit':
            result.addTest(legacy.UpgradeContractChecks(name))
    result.addTests(loader.loadTestsFromTestCase(RC2DocumentChecks))
    return result

if __name__=='__main__':
    outcome=unittest.TextTestRunner(verbosity=2).run(suite())
    raise SystemExit(0 if outcome.wasSuccessful() else 1)
