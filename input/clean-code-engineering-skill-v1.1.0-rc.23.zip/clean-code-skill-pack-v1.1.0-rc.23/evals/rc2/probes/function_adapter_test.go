package a03_interface

import "context"

func makeTimeoutCatalog() *Catalog {
	return &Catalog{find: func(context.Context, string) (string, error) {
		return "", context.DeadlineExceeded
	}}
}
