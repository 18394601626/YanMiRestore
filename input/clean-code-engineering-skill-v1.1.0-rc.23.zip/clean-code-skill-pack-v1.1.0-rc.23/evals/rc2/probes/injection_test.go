package a03_interface

import (
	"context"
	"errors"
	"testing"
)

// makeTimeoutCatalog is supplied by a test-only adapter for each implementation.
// This test asserts timeout propagation, not whether the implementation uses
// an interface, function field, factory, or a named private constructor.
func TestTimeoutBehavior(t *testing.T) {
	got, err := makeTimeoutCatalog().Name(context.Background(), "u1")
	if got != "" || !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("timeout lost: name=%q err=%v", got, err)
	}
}
