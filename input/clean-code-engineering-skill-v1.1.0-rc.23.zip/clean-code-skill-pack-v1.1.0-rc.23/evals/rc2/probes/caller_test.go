package a03_interface_test

import (
	"context"
	"errors"
	"testing"

	target "example.com/skill-effect-lab/a03_interface"
)

func TestDirectConsumer(t *testing.T) {
	got, err := target.NewCatalog(target.NewRepository()).Name(context.Background(), "u1")
	if err != nil || got != "alice" {
		t.Fatalf("name=%q err=%v", got, err)
	}
}

func TestNilConstructorContract(t *testing.T) {
	// The frozen Repository method accepts a nil receiver. This is a fixture
	// contract, not a recommendation to make all production constructors do so.
	var repository *target.Repository
	for _, catalog := range []*target.Catalog{target.NewCatalog(nil), target.NewCatalog(repository)} {
		if catalog == nil {
			t.Fatal("nil constructor behavior changed")
		}
		got, err := catalog.Name(context.Background(), "u1")
		if err != nil || got != "alice" {
			t.Fatalf("nil receiver: name=%q err=%v", got, err)
		}
	}
}

func TestCallerCancellation(t *testing.T) {
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	_, err := target.NewCatalog(target.NewRepository()).Name(ctx, "u1")
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("cancellation lost: %v", err)
	}
}

func TestMethodExpression(t *testing.T) {
	var name func(*target.Catalog, context.Context, string) (string, error) = (*target.Catalog).Name
	got, err := name(target.NewCatalog(target.NewRepository()), context.Background(), "u1")
	if err != nil || got != "alice" {
		t.Fatalf("method expression: %q %v", got, err)
	}
}
