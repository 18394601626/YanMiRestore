package a03_interface

import "context"

type timeoutReader struct{}

func (timeoutReader) FindByID(context.Context, string) (string, error) {
	return "", context.DeadlineExceeded
}
func makeTimeoutCatalog() *Catalog { return newCatalog(timeoutReader{}) }
