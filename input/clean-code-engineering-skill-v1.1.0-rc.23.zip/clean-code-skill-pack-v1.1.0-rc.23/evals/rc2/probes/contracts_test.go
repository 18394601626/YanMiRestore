package contracts_test

import (
	"errors"
	"fmt"
	"testing"

	target "example.com/skill-effect-lab/contracts"
)

type externalReader struct{}

func (externalReader) Read() (string, error) { return "ok", nil }

func TestExternalReaderStillImplements(t *testing.T) {
	var reader target.Reader = externalReader{}
	got, err := reader.Read()
	if err != nil || got != "ok" {
		t.Fatalf("reader: %q %v", got, err)
	}
}

func TestValueMethodSet(t *testing.T) {
	var label fmt.Stringer = target.Label("ok")
	if label.String() != "ok" {
		t.Fatal("String behavior changed")
	}
}

func TestSuccessIsNilError(t *testing.T) {
	if err := target.Validate(true); err != nil {
		t.Fatalf("success has a non-nil error: %v", err)
	}
}

func TestErrorChain(t *testing.T) {
	if !errors.Is(target.Missing(), target.ErrMissing) {
		t.Fatal("missing error chain lost")
	}
}

func TestConcreteErrorType(t *testing.T) {
	var problem *target.ValidationError
	if !errors.As(target.Validate(false), &problem) {
		t.Fatal("validation error type lost")
	}
}

func TestHiddenErrorStaysHidden(t *testing.T) {
	cause := errors.New("internal dependency")
	if errors.Is(target.Hide(cause), cause) {
		t.Fatal("hidden error exposed")
	}
}

func TestWireContract(t *testing.T) {
	for _, tc := range []struct {
		name  string
		items []string
		want  string
	}{
		{"nil", nil, `{"items":null}`},
		{"empty", []string{}, `{"items":[]}`},
		{"nonempty", []string{"x"}, `{"items":["x"]}`},
	} {
		t.Run(tc.name, func(t *testing.T) {
			got, err := target.Encode(tc.items)
			if err != nil || string(got) != tc.want {
				t.Fatalf("wire=%s want=%s err=%v", got, tc.want, err)
			}
		})
	}
}
