package a03_interface_test

import (
	"context"
	"testing"

	target "example.com/skill-effect-lab/a03_interface"
)

func TestLegacyFunctionValue(t *testing.T) {
	// The old exported function type is part of the frozen source contract.
	var constructor func(*target.Repository) *target.Catalog = target.NewCatalog
	got, err := constructor(target.NewRepository()).Name(context.Background(), "u1")
	if err != nil || got != "alice" {
		t.Fatalf("legacy constructor: %q %v", got, err)
	}
}
