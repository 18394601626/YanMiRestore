"""Reproduce known Go compatibility failures; NOT a model A/B evaluator.

Python 3.9+, local Go. No third-party packages or network calls. Only packaged
fixtures execute. Original sources are read-only; build copies use temp dirs.
Expected failures are recorded as failures, not as candidate PASS results.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import tempfile
import time
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
MODULE = 'module example.com/skill-effect-lab\n\ngo 1.20\n'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    return {str(p.relative_to(HERE)): sha(p)
            for folder in ('fixtures', 'probes')
            for p in sorted((HERE/folder).rglob('*')) if p.is_file()}


def replace_once(text, old, new):
    if text.count(old) != 1:
        raise ValueError('mutation target not unique: ' + old)
    return text.replace(old, new, 1)


def run_command(command, cwd, env, output, label, expected='PASS', marker=''):
    start = time.monotonic()
    timed_out = False
    process = subprocess.Popen(command, cwd=cwd, env=env, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True, encoding='utf-8',
                               errors='replace', start_new_session=(os.name != 'nt'))
    try:
        text, _ = process.communicate(timeout=120)
    except subprocess.TimeoutExpired:
        timed_out = True
        if os.name == 'nt':
            process.kill()
        else:
            os.killpg(process.pid, signal.SIGKILL)
        text, _ = process.communicate()
    observed = ('TIMEOUT' if timed_out else 'PASS' if process.returncode == 0
                else 'COMPILE_FAIL' if '[build failed]' in text
                else 'TEST_FAIL' if '--- FAIL:' in text else 'PROCESS_ERROR')
    matched = observed == expected and (not marker or marker in text)
    result = {'id': label, 'command': command, 'exit_code': process.returncode,
              'observed': observed, 'expected': expected,
              'diagnostic_marker': marker, 'matches_expected_observation': matched,
              'seconds': round(time.monotonic()-start, 3)}
    (output/(label+'.log')).write_text(text, encoding='utf-8')
    (output/(label+'.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(label, observed, 'matched='+str(matched), flush=True)
    return result


def workspace(parent, name, package, source, tests):
    root = parent/name
    pkg = root/package
    pkg.mkdir(parents=True)
    (root/'go.mod').write_text(MODULE, encoding='utf-8')
    (pkg/'fixture.go').write_text(source, encoding='utf-8')
    for test in tests:
        shutil.copy2(HERE/'probes'/test, pkg/test)
    return root


def historical(parent, env, output, go):
    results = []
    for label, fixture, expected in (
        ('H01-original', 'before', 'PASS'),
        ('H02-regressed', 'regressed', 'COMPILE_FAIL'),
        ('H03-repaired', 'repaired', 'PASS'),
    ):
        source = (HERE/'fixtures'/fixture/'catalog.go').read_text(encoding='utf-8')
        root = workspace(parent, label, 'a03_interface', source, ['caller_test.go'])
        # Direct-call tests alone are intentionally insufficient: observe this.
        results.append(run_command([go,'test','-count=1','-run=^TestDirectConsumer$','./...'],root,env,output,label+'-direct'))
        behavior_expected = 'TEST_FAIL' if fixture == 'regressed' else 'PASS'
        results.append(run_command([go,'test','-count=1','./...'],root,env,output,label+'-behavior',
                                   behavior_expected, 'TestNilConstructorContract' if fixture == 'regressed' else ''))
        shutil.copy2(HERE/'probes/function_type_test.go', root/'a03_interface/function_type_test.go')
        results.append(run_command([go,'test','-count=1','./...'],root,env,output,label+'-compat',
                                   expected, 'cannot use target.NewCatalog' if expected != 'PASS' else ''))
    repaired = parent/'H03-repaired'
    for test in ('injection_test.go','interface_adapter_test.go'):
        shutil.copy2(HERE/'probes'/test, repaired/'a03_interface'/test)
    results.append(run_command([go,'test','-race','-count=1','./...'],repaired,env,output,'H04-repaired-injection-race'))
    results.append(run_command([go,'vet','./...'],repaired,env,output,'H05-repaired-vet'))
    results.append(run_command([go,'build','./...'],repaired,env,output,'H06-repaired-build'))

    # A second valid design demonstrates why public 'parameter must be an
    # interface' is the wrong oracle. The only changed test file is a private
    # adapter; the behavior and external compatibility assertions are identical.
    source = (HERE/'fixtures/repaired/catalog.go').read_text(encoding='utf-8')
    start = source.index('type reader interface')
    end = source.index('func (c *Catalog) Name')
    source = source[:start] + '''type Catalog struct {
    find func(context.Context, string) (string, error)
}
func NewCatalog(repository *Repository) *Catalog {
    return &Catalog{find: repository.FindByID}
}
''' + source[end:]
    source = replace_once(source, 'c.reader.FindByID(ctx, id)', 'c.find(ctx, id)')
    alternate = workspace(parent, 'H07-function-boundary', 'a03_interface', source,
                           ['caller_test.go','function_type_test.go','injection_test.go','function_adapter_test.go'])
    results.append(run_command([go,'test','-race','-count=1','./...'],alternate,env,output,'H07-alternative-behavior'))
    return results


def mutations(parent, env, output, go):
    results = []
    good = (HERE/'fixtures/contracts/contracts.go').read_text(encoding='utf-8')
    root = workspace(parent,'M00-correct','contracts',good,['contracts_test.go'])
    results.append(run_command([go,'test','-race','-count=1','./...'],root,env,output,'M00-correct'))
    variants = [
        ('M01-interface-expanded', 'type Reader interface{ Read() (string, error) }',
         'type Reader interface{ Read() (string, error); Close() error }', 'COMPILE_FAIL','missing method Close'),
        ('M02-pointer-receiver', 'func (l Label) String() string { return string(l) }',
         'func (l *Label) String() string { return string(*l) }', 'COMPILE_FAIL','pointer receiver'),
        ('M03-typed-nil', 'if ok {\n\t\treturn nil\n\t}',
         'if ok {\n var err *ValidationError\n return err\n }', 'TEST_FAIL','TestSuccessIsNilError'),
        ('M04-error-chain', 'fmt.Errorf("lookup: %w", ErrMissing)',
         'fmt.Errorf("lookup: %v", ErrMissing)', 'TEST_FAIL','TestErrorChain'),
        ('M05-error-type', 'return &ValidationError{}',
         'return errors.New("invalid")', 'TEST_FAIL','TestConcreteErrorType'),
        ('M06-hidden-cause', 'fmt.Errorf("dependency: %v", err)',
         'fmt.Errorf("dependency: %w", err)', 'TEST_FAIL','TestHiddenErrorStaysHidden'),
        ('M07-null-to-empty', 'return json.Marshal(Reply{Items: items})',
         'if items == nil { items = []string{} }; return json.Marshal(Reply{Items: items})', 'TEST_FAIL','TestWireContract/nil'),
        ('M08-field-renamed', '`json:"items"`', '`json:"data"`', 'TEST_FAIL','TestWireContract'),
    ]
    # All mutants use the exact same frozen caller/test bytes.
    for label, old, new, expected, marker in variants:
        source = replace_once(good, old, new)
        root = workspace(parent,label,'contracts',source,['contracts_test.go'])
        results.append(run_command([go,'test','-count=1','./...'],root,env,output,label,expected,marker))
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--phase', choices=['historical','mutations','all'], default='all')
    args = parser.parse_args()
    go = shutil.which('go')
    if not go:
        parser.exit(2, 'BLOCKED: local Go executable not found\n')
    output = args.output.resolve()
    if output.exists():
        parser.exit(2, 'Output already exists; choose a new directory.\n')
    if output == HERE or HERE in output.parents:
        parser.exit(2, 'Use an output directory outside evals/rc2.\n')
    output.mkdir(parents=True)
    before = snapshot()
    results = []
    with tempfile.TemporaryDirectory(prefix='skill-rc2-') as tmp:
        root = Path(tmp)
        env = os.environ.copy()
        env.update(GOTOOLCHAIN='local', GOPROXY='off', GOSUMDB='off', GOWORK='off',
                   GOENV='off', GOFLAGS='-mod=mod', GOMODCACHE=str(root/'modcache'))
        version = subprocess.run([go,'version'],env=env,capture_output=True,text=True,check=True).stdout.strip()
        try:
            if args.phase in ('historical','all'): results += historical(root,env,output,go)
            if args.phase in ('mutations','all'): results += mutations(root,env,output,go)
        except Exception as exc:
            (output/'runner-error.txt').write_text(repr(exc),encoding='utf-8')
            raise
    unchanged = before == snapshot()
    summary = {'utc':datetime.now(timezone.utc).isoformat(),'go_version':version,
               'phase':args.phase,'kind':'controlled_fixture_regression_not_agent_AB',
               'input_hashes':before,'inputs_unchanged':unchanged,'commands':results,
               'all_expected_observations_reproduced': unchanged and all(x['matches_expected_observation'] for x in results),
               'limitations':['No independent model runs','Not general compatibility proof',
                              'No production project or real database','Other Go toolchains not run']}
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return 0 if summary['all_expected_observations_reproduced'] else 1

if __name__ == '__main__':
    raise SystemExit(main())
