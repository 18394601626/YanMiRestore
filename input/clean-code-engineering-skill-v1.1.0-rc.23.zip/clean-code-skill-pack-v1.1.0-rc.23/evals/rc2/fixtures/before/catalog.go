package a03_interface

import (
	"context"
	"errors"
	"fmt"
)

type Repository struct{}

func NewRepository() *Repository { return &Repository{} }
func (*Repository) FindByID(ctx context.Context, id string) (string, error) {
	if err := ctx.Err(); err != nil {
		return "", err
	}
	if id != "u1" {
		return "", errors.New("missing")
	}
	return "alice", nil
}
func (*Repository) Delete(string) error { return nil }
func (*Repository) List() []string      { return []string{"alice"} }

type Catalog struct{ reader *Repository }

func NewCatalog(reader *Repository) *Catalog { return &Catalog{reader: reader} }
func (c *Catalog) Name(ctx context.Context, id string) (string, error) {
	name, err := c.reader.FindByID(ctx, id)
	if err != nil {
		return "", fmt.Errorf("read catalog: %w", err)
	}
	return name, nil
}
