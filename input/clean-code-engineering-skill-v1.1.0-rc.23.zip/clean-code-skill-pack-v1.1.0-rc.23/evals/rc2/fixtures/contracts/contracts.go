// Package contracts is a controlled compatibility fixture, not application code.
package contracts

import (
	"encoding/json"
	"errors"
	"fmt"
)

type Reader interface{ Read() (string, error) }
type Label string

func (l Label) String() string { return string(l) }

type ValidationError struct{}

func (*ValidationError) Error() string { return "invalid" }

func Validate(ok bool) error {
	if ok {
		return nil
	}
	return &ValidationError{}
}

var ErrMissing = errors.New("missing")

func Missing() error       { return fmt.Errorf("lookup: %w", ErrMissing) }
func Hide(err error) error { return fmt.Errorf("dependency: %v", err) }

type Reply struct {
	Items []string `json:"items"`
}

func Encode(items []string) ([]byte, error) { return json.Marshal(Reply{Items: items}) }
