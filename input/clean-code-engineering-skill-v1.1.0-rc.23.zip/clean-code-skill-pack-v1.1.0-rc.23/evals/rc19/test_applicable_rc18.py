"""Reuse original rc18 checks; exact rc18 version and whole-release hash are version-bound.

Those two original methods are preserved, ran on the frozen rc18 baseline, and
are replaced for rc19 by current identity and a declared-edit-set hash check.
"""
import importlib.util
from pathlib import Path
import unittest
R=Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('original_rc18',R/'evals/rc18/test_support.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
if __name__=='__main__':
    excluded={'test_prior_card_bytes_stable','test_current_version'}
    suite=unittest.TestSuite(m.ExpansionChecks(n) for n in unittest.defaultTestLoader.getTestCaseNames(m.ExpansionChecks) if n not in excluded)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
