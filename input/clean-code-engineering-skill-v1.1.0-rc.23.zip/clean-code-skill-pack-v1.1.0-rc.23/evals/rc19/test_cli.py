import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
SCRIPT=ROOT/'evals/rc19/reproduce.py'
class CliTests(unittest.TestCase):
    def call(self,*args):return subprocess.run([sys.executable,'-S',str(SCRIPT),*args],capture_output=True,text=True,timeout=10)
    def test_help(self):
        p=self.call('--help');self.assertEqual(p.returncode,0);self.assertIn('--tools-only',p.stdout)
    def test_existing_output_is_not_overwritten(self):
        with tempfile.TemporaryDirectory() as td:
            f=Path(td)/'keep';f.write_text('preserve')
            p=self.call('--output',td)
            self.assertEqual(p.returncode,2);self.assertIn('new and outside',p.stderr)
            self.assertEqual(f.read_text(),'preserve');self.assertFalse((Path(td)/'summary.json').exists())
    def test_inside_package_is_not_created(self):
        path=ROOT/'rc19-this-directory-must-not-exist'
        p=self.call('--output',str(path));self.assertEqual(p.returncode,2)
        self.assertIn('new and outside',p.stderr);self.assertFalse(path.exists())
    def test_all_is_not_implicitly_every_language(self):
        p=self.call('--output','/tmp/rc19-unused','--languages','all')
        self.assertEqual(p.returncode,2);self.assertIn('unrecognized arguments',p.stderr)
if __name__=='__main__':unittest.main(verbosity=2)
