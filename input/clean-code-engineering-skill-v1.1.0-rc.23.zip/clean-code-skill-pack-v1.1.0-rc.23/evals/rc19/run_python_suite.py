"""Collect individual unittest outcomes for the controlled rc19 suites."""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
import unittest

class RecordedResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.records=[]
    def record(self,test,state,diagnostic=None):
        row={'test':test.id().rsplit('.',1)[-1],'status':state}
        if diagnostic:row['diagnostic']=diagnostic
        self.records.append(row)
    def addSuccess(self,test):super().addSuccess(test);self.record(test,'PASS')
    def addFailure(self,test,err):super().addFailure(test,err);self.record(test,'FAIL',self._exc_info_to_string(err,test))
    def addError(self,test,err):super().addError(test,err);self.record(test,'ERROR',self._exc_info_to_string(err,test))
    def addSkip(self,test,reason):super().addSkip(test,reason);self.record(test,'SKIP',reason)
    def addSubTest(self,test,subtest,err):
        super().addSubTest(test,subtest,err)
        if err is not None:self.record(test,'SUBTEST_FAILURE',self._exc_info_to_string(err,test))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suite',choices=['sql','bash','python'],required=True)
    parser.add_argument('--report',type=Path,required=True)
    args=parser.parse_args()
    spec=importlib.util.spec_from_file_location('rc19_suite',Path(__file__).parent/f'cases_{args.suite}.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    suite=unittest.defaultTestLoader.loadTestsFromModule(m)
    result=unittest.TextTestRunner(verbosity=2,resultclass=RecordedResult).run(suite)
    report={'suite':args.suite,'tests_run':result.testsRun,'success':result.wasSuccessful(),
      'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),
      'unexpected_successes':len(result.unexpectedSuccesses),'records':result.records}
    args.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    sys.exit(0 if result.wasSuccessful() else 1)
