import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import path from 'node:path';
const {replaceQuantities,runBatch,snapshot}=await import(pathToFileURL(path.resolve(process.argv[2])));
const cases=[
 ()=>{const original=[8];const err=new Error('iterator');const values={*[Symbol.iterator](){yield 2;throw err;}};
      assert.throws(()=>replaceQuantities(original,values),e=>e===err);assert.deepEqual(original,[8]);},
 ()=>{const a=[1,2];assert.equal(replaceQuantities(a,a),a);assert.deepEqual(a,[1,2]);},
 ()=>{const a=[7];assert.throws(()=>replaceQuantities(a,new Array(2)),TypeError);assert.deepEqual(a,[7]);},
 ()=>{const a=[7];const values=Object.freeze([0,Number.MAX_SAFE_INTEGER]);replaceQuantities(a,values);assert.deepEqual(a,[...values]);
      for(const x of [true,NaN,Infinity,Number.MAX_SAFE_INTEGER+1]){const before=[...a];assert.throws(()=>replaceQuantities(a,[1,x]),TypeError);assert.deepEqual(a,before);}},
 async()=>{const expected=new Error('work');const visited=[];
      await assert.rejects(runBatch([1,2,3],async x=>{visited.push(x);if(x===2)throw expected;return x;}),e=>e===expected);assert.deepEqual(visited,[1,2]);},
 async()=>{const events=[];const result=await runBatch([1,2],async x=>{events.push(`start${x}`);await Promise.resolve();events.push(`end${x}`);return x*2;});
      assert.deepEqual(result,[2,4]);assert.deepEqual(events,['start1','end1','start2','end2']);}
];
let failures=0;
for(let i=0;i<cases.length;i++){const id=`JS19${String(i+1).padStart(2,'0')}`;try{await cases[i]();console.log(`CASE ${id} PASS`);}catch(e){failures++;console.log(`CASE ${id} FAIL`);console.error(e.stack);}}
process.exitCode=failures?1:0;
