"""Run the existing Bash fixture in subprocesses and real temporary directories."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT=Path(os.environ.get('RC19_TARGET_ROOT',Path(__file__).resolve().parents[2]))
SOURCE=ROOT/'evals/rc17/fixtures/bash/fixed/solution.sh'

class BashBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='rc19-shell-');self.addCleanup(self.temp.cleanup)
        self.cwd=Path(self.temp.name)

    def shell(self,script,*args,stdin=b''):
        return subprocess.run(['bash','--noprofile','--norc','-c',
            'source "$1"; shift; '+script,'probe',str(SOURCE),*args],
            input=stdin,cwd=self.cwd,capture_output=True,timeout=10,
            env={k:v for k,v in os.environ.items() if k not in {'BASH_ENV','ENV','SHELLOPTS','BASHOPTS'}})

    def check_directory(self,name):
        p=self.cwd/name;p.mkdir();(p/'keep').write_bytes(b'existing\x00data')
        result=self.shell('owned_work "$1"',name)
        self.assertEqual(result.returncode,23,result.stderr.decode(errors='replace'))
        self.assertEqual(sorted(x.name for x in p.iterdir()),['keep'])
        self.assertEqual((p/'keep').read_bytes(),b'existing\x00data')

    def test_leading_dash_directory(self): self.check_directory('-workspace')
    def test_spaces_unicode_and_newline_directory(self): self.check_directory('中文 空间\nline')
    def test_long_directory_component(self):
        length=os.pathconf(self.cwd,'PC_NAME_MAX')
        self.assertGreater(length,0);self.check_directory('x'*min(length,255))

    def test_failure_does_not_delete_unrelated_file(self):
        keep=self.cwd/'keep';keep.write_text('untouched')
        result=self.shell('owned_work "$1"','missing/parent')
        self.assertNotEqual(result.returncode,0)
        self.assertEqual(keep.read_text(),'untouched');self.assertEqual(sorted(p.name for p in self.cwd.iterdir()),['keep'])

    def test_parent_exit_trap_preserved(self):
        (self.cwd/'target').mkdir()
        result=self.shell('trap \'printf "PARENT_EXIT\\n"\' EXIT; owned_work target; rc=$?; exit "$rc"')
        self.assertEqual(result.returncode,23,result.stderr.decode())
        self.assertEqual(result.stdout,b'PARENT_EXIT\n')
        self.assertEqual(list((self.cwd/'target').iterdir()),[])

    def test_parent_shell_options_preserved(self):
        (self.cwd/'target').mkdir()
        result=self.shell('set -u; set -o pipefail; before=$(set +o); owned_work target; rc=$?; after=$(set +o); [[ "$before" == "$after" && $rc == 23 ]]')
        self.assertEqual(result.returncode,0,result.stderr.decode())

    def test_unterminated_line_and_crlf_preserved(self):
        for data,expected in [(b'  x\\y  ',b'  x\\y  '),(b'abc\r\nnext',b'abc\r')]:
            with self.subTest(data=data):
                result=self.shell('first_line',stdin=data)
                self.assertEqual(result.returncode,0);self.assertEqual(result.stdout,expected)

    def test_empty_input_is_not_success(self):
        result=self.shell('first_line');self.assertNotEqual(result.returncode,0);self.assertEqual(result.stdout,b'')

if __name__=='__main__':unittest.main(verbosity=2)
