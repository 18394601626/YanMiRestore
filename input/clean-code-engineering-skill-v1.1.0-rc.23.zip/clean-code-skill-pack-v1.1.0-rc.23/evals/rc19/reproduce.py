"""Replay rc19: applicable tool checks, 10 historical languages, TS/SQLite, C#/Dart,
and 42 new controlled boundary contracts. --native adds prior C/C++ fixtures.
This is an explicit requested scope, NOT all 30 languages and NOT an AI trial.
"""
import argparse
from datetime import datetime,timezone
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
previous=load('rc19_previous',ROOT/'evals/rc18/reproduce.py')
old=previous.old
regressions=load('rc19_boundaries',HERE/'run_regressions.py')
STAGES=[(name,'evals/rc19/test_applicable_rc18.py',8) if name=='rc18-support' else (name,path,count)
        for name,path,count in previous.STAGES]
STAGES += [('rc19-release','evals/rc19/test_release.py',5),('rc19-cli','evals/rc19/test_cli.py',4)]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--tools-only',action='store_true',help='only document/tool checks; no language behavior')
    parser.add_argument('--native',action='store_true',help='also request existing C/C++ compiler/sanitizer fixtures')
    args=parser.parse_args();out=args.output.resolve()
    if args.tools_only and args.native:parser.error('--native cannot be combined with --tools-only')
    if out.exists() or out==ROOT or ROOT in out.parents:parser.error('output must be new and outside package')
    out.mkdir(parents=True)
    os.environ.update(PACK_ROOT=str(ROOT),RC18_ROOT=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
    summary={'version':(ROOT/'VERSION').read_text().strip(),'kind':'controlled_replay_not_AI_AB',
      'started_utc':datetime.now(timezone.utc).isoformat(),'status':'RUNNING',
      'environment':{'python':sys.version,'platform':platform.platform()},'stages':[], 'runtime':[],
      'requested_runtime':[] if args.tools_only else ['rc17-ten-language-batch','typescript-extra','sql-baseline','sql-fixed','csharp','dart','new-42'],
      'not_in_scope':['Rust behavior','server databases','frameworks','IDE loading','independent AI A/B','source-book semantic audit']}
    if args.native:summary['requested_runtime']+=['native-core','native-extra','native-ctest']
    def save():old.save(out,summary)
    save();code=1
    def stop_if_interrupted(row):
        if row['status']=='INTERRUPTED':raise KeyboardInterrupt
    def child(name,script,args,subdir,timeout=150):
        row=old.launch(out,name,[sys.executable,'-S',script,*args,'--output',str(subdir)],timeout)
        stop_if_interrupted(row)
        if row['status']=='FINISHED' and (subdir/'summary.json').exists():
            data=json.loads((subdir/'summary.json').read_text());row['details']=data
            if name=='native-ctest':
                # The historical probe has no status/exit_code fields on success.
                rows=data.get('observations',[])
                exact={x.get('case') for x in rows}=={'matching','borrowed','false-success'} and len(rows)==3
                passed=row['exit_code']==0 and data.get('all_expected') is True and exact and all(x.get('matches') is True for x in rows)
                row['status']='PASS' if passed else ('BLOCKED' if row['exit_code']==2 and data.get('status')=='BLOCKED' else 'FAIL')
            else:
                row['status']=data['status'] if data.get('exit_code')==row['exit_code'] else 'INVALID_EVIDENCE'
        summary['runtime'].append(row);save();return row
    try:
        row=old.launch(out,'book',[sys.executable,'-S','evals/rc13/reproduce.py','--output',str(out/'book-details')],120)
        if row['status']=='FINISHED' and (out/'book-details/summary.json').exists():
            d=json.loads((out/'book-details/summary.json').read_text());row['observed_methods']=d['observed_test_methods']
            row['status']='PASS' if row['exit_code']==0 and d['all_pass'] is True and row['observed_methods']==90 else 'FAIL'
        summary['stages'].append(row);save();stop_if_interrupted(row)
        for name,path,count in STAGES:
            row=old.launch(out,name,[sys.executable,'-S',path],90);old.check_unittest(row,out,count)
            summary['stages'].append(row);save();stop_if_interrupted(row)
        summary['stages'].append(old.replay_original(out));save()
        if not args.tools_only:
            child('rc17-ten-language-batch','evals/rc17/run_batch.py',['--languages','batch'],out/'batch-details',300)
            for action in (lambda:previous.typescript(out),lambda:previous.sql(out,'baseline'),lambda:previous.sql(out,'fixed'),
                           lambda:previous.source_attempt(out,'csharp'),lambda:previous.source_attempt(out,'dart')):
                row=action();summary['runtime'].append(row);save();stop_if_interrupted(row)
            newdir=out/'new-boundaries';newdir.mkdir();row=regressions.run_all(newdir,ROOT)
            row['id']='new-42';summary['runtime'].append(row);save();stop_if_interrupted(row)
            if args.native:
                child('native-core','evals/rc14/run_checks.py',['--language','native'],out/'native-core',240)
                child('native-extra','evals/rc16/run_extra.py',[],out/'native-extra',180)
                child('native-ctest','evals/rc16/run_real_ctest.py',['--root',str(ROOT)],out/'native-ctest',90)
        accepted={'PASS','CONTROL_OBSERVATIONS_MATCH','EXPECTED_OBSERVATIONS_REPRODUCED'}
        if any(r['status']!='PASS' for r in summary['stages']) or any(r['status'] not in accepted|{'BLOCKED','PARTIAL_BLOCKED'} for r in summary['runtime']):
            summary['status']='FAIL';code=1
        elif any(r['status'] in {'BLOCKED','PARTIAL_BLOCKED'} for r in summary['runtime']):summary['status']='PARTIAL_BLOCKED';code=2
        else:summary['status']='REQUESTED_SCOPE_PASSED';code=0
    except KeyboardInterrupt:summary['status']='INTERRUPTED';code=130
    except Exception as exc:summary.update(status='ERROR',reason=type(exc).__name__+': '+str(exc));code=1
    finally:
        summary['exit_code']=code;summary['tool_methods']=sum(r.get('observed_methods',0) for r in summary['stages'])
        summary['finished_utc']=datetime.now(timezone.utc).isoformat();save()
    print(summary['status'],'tool_methods='+str(summary['tool_methods']))
    for r in summary['stages']:print(r['id'],r['status'],r.get('observed_methods',0))
    for r in summary['runtime']:print(r['id'],r['status'],r.get('executed'))
    return code
if __name__=='__main__':raise SystemExit(main())
