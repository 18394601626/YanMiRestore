"""Current release checks; not a model or source-book semantic evaluation."""
import hashlib
import json
from pathlib import Path
import unittest
R=Path(__file__).resolve().parents[2]
S=R/'clean-code-engineering'
# Reviewed edit set. The original archive remains untouched.
ALLOWED={
 'VERSION','README.md','CHANGELOG.md','VALIDATION.md','LANGUAGE_MATRIX.md','SHA256SUMS.txt',
 'clean-code-engineering/VERSION','clean-code-engineering/assets/language-support.json',
 'clean-code-engineering/references/languages/sql.md',
 'clean-code-engineering/references/languages/php.md',
 'clean-code-engineering/references/languages/bash.md',
 'evals/rc18/sql/fixed/solution.py',
 'evals/rc17/fixtures/php/fixed/solution.php',
 'evals/rc17/fixtures/bash/fixed/solution.sh'
}
class ReleaseChecks(unittest.TestCase):
    def test_version(self):
        for path in (R/'VERSION',S/'VERSION'):self.assertEqual(path.read_text().strip(),'1.1.0-rc.19')
        self.assertEqual(json.loads((S/'assets/language-support.json').read_text())['version'],'1.1.0-rc.19')
    def test_old_files_protected_outside_declared_changes(self):
        data=json.loads((R/'provenance/rc19/baseline-manifest.json').read_text())
        for name,digest in data.items():
            if name not in ALLOWED:
                with self.subTest(file=name):
                    self.assertTrue((R/name).is_file())
                    self.assertEqual(hashlib.sha256((R/name).read_bytes()).hexdigest(),digest)
    def test_guides_state_the_specific_contract_and_scope(self):
        for name,terms in {
            'sql':['rc.19','INTEGER','ValueError','IntegrityError','行为收紧'],
            'php':['rc.19','引用','双向','标量'],
            'bash':['rc.19','mktemp --','短横线','POSIX']
        }.items():
            text=(S/'references/languages'/f'{name}.md').read_text()
            for term in terms:
                with self.subTest(language=name,term=term):self.assertIn(term,text)
    def test_frozen_behavior_tests_unchanged(self):
        data=json.loads((R/'provenance/rc19/frozen-tests.json').read_text())['files']
        self.assertEqual(len(data),5)
        for name,digest in data.items():self.assertEqual(hashlib.sha256((R/name).read_bytes()).hexdigest(),digest)
    def test_registry_does_not_widen_support_claims(self):
        data=json.loads((S/'assets/language-support.json').read_text())
        self.assertEqual(len(data['languages']),30);self.assertFalse(data['independent_agent_AB'])
        self.assertEqual(data['languages']['sql']['dialects']['postgresql']['status'],'NOT_RUN')
        self.assertNotEqual(data['languages']['csharp']['execution']['status'],'PASS')
        self.assertNotEqual(data['languages']['dart']['execution']['status'],'PASS')
        for lang in ('python','javascript','php','bash','sql'):
            self.assertIn('rc19_additional_cases',data['languages'][lang])
if __name__=='__main__':unittest.main(verbosity=2)
