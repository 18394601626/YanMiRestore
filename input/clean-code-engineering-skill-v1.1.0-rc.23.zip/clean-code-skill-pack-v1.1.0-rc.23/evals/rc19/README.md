# rc.19 验证入口与契约

## 本轮范围

修复既有SQLite/PHP/Bash样例，不新增语言数量。新42项由 SQLite16、Bash8、Python6、Node JavaScript6、PHP6 组成。PHP是独立整数列表契约，SQL是实际int/有符号64位契约，Bash是GNU工具下路径/退出清理契约。不是任意应用的强制API设计。

```bash
python -S evals/rc19/reproduce.py --output ../rc19-run --native
python -S evals/rc19/reproduce.py --output ../rc19-tools --tools-only
python -S evals/rc19/run_regressions.py --output ../rc19-only-new
```

默认复现包含旧十语言60项、TS8项、旧SQLite12项、C#/Dart尝试、新42项；可选native执行旧C/C++核心23项和扩展16项，以及三个真实CTest输出控制。不是全部30项执行。仅运行受控包，不是任意不可信源码沙箱；不触碰生产数据、不自动安装工具、不发布服务。

缺工具为BLOCKED，部分阻塞退出2；断言/编译/证据不符退出1；完整请求范围通过退出0；中断退出130。只运行工具检查不能推断业务通过。SQLite使用临时磁盘数据库和独立连接，不能替代PostgreSQL/MySQL/Spring。

## 精确行为变化

- SQL以前允许SQLite隐式转换浮点、数字文本、bool。新边界明确ID与quantity是Python实际int；其他类型ValueError，超出有符号64位OverflowError。负整数仍由原CHECK产生IntegrityError，缺行LookupError、迭代器原异常、事务归属和失败回滚保留。这是行为收紧，不是纯重构或SQLite缺陷。NaN在旧版本已触发IntegrityError；新规则将其归到输入类型错误，不声称原来接受NaN。
- PHP原array_values可能保留数组内引用；逐值构造整数列表后才替换，避免输入/结果互相回写。只解除本例的标量引用，不是通用深拷贝；目标本身的引用参数语义保留。
- Bash加GNU mktemp的`--`分隔。保留原临时工作失败码23与本次文件清理，不改变父级trap、选项或未触及文件。本轮不认证POSIX/dash/BusyBox。

## 原断言保护与计数

原rc18全部233项在原包上实际通过。当前复用231项；两项仅绑定rc18版本/该版本全文件哈希的原断言留存，改由5项当前版本/精确编辑集合/指南/冻结检查替代，并新增4项CLI检查：231+5+4=240。不是删除业务断言换绿灯，原业务消费者字节全部保留。

五份行为测试文件在实施前保存哈希。相同测试针对旧版为31通过、10断言失败、1运行错误（NaN预期异常类型不同）；新版本42通过。另两轮同样42项重复通过，重复不增加独立样本。新报告按测试身份/数量、运行退出码和终态核对；它不能认证一个恶意程序伪造全部输出。

## 执行环境

实际版本与命令见包根验证报告和evidence/rc19/environment.json。编译/生成物不打包，复现时重建；报告保留原路径用于追踪当次运行。独立模型效果与原书完整性不由这些测试证明。
