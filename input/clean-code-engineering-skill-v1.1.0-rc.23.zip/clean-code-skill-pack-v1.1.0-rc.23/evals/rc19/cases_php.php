<?php
declare(strict_types=1);
require $argv[1];
function check19(bool $ok):void {if(!$ok)throw new RuntimeException('contract not met');}
$tests=[
  function(){ $input=3;$values=[&$input];$target=[9];replace_quantities($target,$values);$input=7;check19($target===[3]); },
  function(){ $input=3;$values=[&$input];$target=[9];replace_quantities($target,$values);$target[0]=7;check19($input===3&&$values===[3]); },
  function(){ $original=[7];try{replace_quantities($original,[1,true]);}catch(InvalidArgumentException $e){check19($original===[7]);return;}throw new RuntimeException('boolean accepted'); },
  function(){ $values=['a'=>0,'b'=>PHP_INT_MAX];$target=[];replace_quantities($target,$values);check19($target===[0,PHP_INT_MAX]);check19(array_keys($values)===['a','b']); },
  function(){ $target=[1,2];replace_quantities($target,$target);check19($target===[1,2]); },
  function(){ $h=tmpfile();if($h===false)throw new RuntimeException('tmpfile unavailable');$result=consume_owned($h,fn($handle)=>fwrite($handle,"\x00x"));check19($result===2&&!is_resource($h)); }
];
$failures=0;
foreach($tests as $i=>$test){$id=sprintf('PH19%02d',$i+1);try{$test();echo "CASE $id PASS\n";}catch(Throwable $e){$failures++;echo "CASE $id FAIL\n";fwrite(STDERR,get_class($e).': '.$e->getMessage()."\n");}}
exit($failures?1:0);
