"""SQLite quantity boundary contracts; real temporary files, no server DB claim.

New type requirement: IDs and quantities are Python int (not bool). Integer
quantities use signed int64 storage. Negative ints retain the pre-existing
SQLite IntegrityError contract. This is a behavior tightening, not refactoring.
"""
from contextlib import closing
import importlib.util
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest

ROOT = Path(os.environ.get('RC19_TARGET_ROOT', Path(__file__).resolve().parents[2]))
SPEC = importlib.util.spec_from_file_location('quantity_adapter', ROOT/'evals/rc18/sql/fixed/solution.py')
solution = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(solution)

class QuantityBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='rc19-sql-')
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name)/'actual.sqlite'
        self.db = sqlite3.connect(self.path, isolation_level=None, timeout=0.2)
        self.addCleanup(self.db.close)
        self.db.execute('PRAGMA foreign_keys=ON')
        self.db.executescript('''
          CREATE TABLE accounts(id INTEGER PRIMARY KEY, name TEXT,
          quantity INTEGER NOT NULL CHECK(quantity >= 0), deleted INTEGER NOT NULL DEFAULT 0);
          INSERT INTO accounts VALUES(1,'Ada',10,0),(2,'Bo',20,0);
        ''')

    def committed(self):
        with closing(sqlite3.connect(self.path)) as other:
            return other.execute('SELECT id,quantity,typeof(quantity) FROM accounts ORDER BY id').fetchall()

    def assert_invalid(self, quantity):
        before = self.committed()
        with self.assertRaises(ValueError):
            solution.replace_quantities(self.db, [(1, 11), (2, quantity)])
        self.assertEqual(self.committed(), before)
        self.assertFalse(self.db.in_transaction)

    def test_fractional_float_rejected(self): self.assert_invalid(1.5)
    def test_integral_float_rejected(self): self.assert_invalid(2.0)
    def test_numeric_text_rejected(self): self.assert_invalid('3')
    def test_bool_quantity_rejected(self): self.assert_invalid(True)
    def test_infinity_rejected(self): self.assert_invalid(float('inf'))
    def test_nan_rejected(self): self.assert_invalid(float('nan'))

    def test_text_id_rejected_without_partial_write(self):
        before = self.committed()
        with self.assertRaises(ValueError):
            solution.replace_quantities(self.db, [(2, 11), ('1', 12)])
        self.assertEqual(before, self.committed()); self.assertFalse(self.db.in_transaction)

    def test_bool_id_rejected_without_partial_write(self):
        before = self.committed()
        with self.assertRaises(ValueError):
            solution.replace_quantities(self.db, [(2, 11), (True, 12)])
        self.assertEqual(before, self.committed()); self.assertFalse(self.db.in_transaction)

    def test_int64_max_and_zero_keep_integer_storage(self):
        maximum = 2**63-1
        solution.replace_quantities(self.db, [(1, maximum), (2, 0)])
        self.assertEqual(self.committed(), [(1, maximum, 'integer'), (2, 0, 'integer')])

    def test_oversized_int_preserves_overflow_error(self):
        before = self.committed()
        with self.assertRaises(OverflowError):
            solution.replace_quantities(self.db, [(1, 11), (2, 2**63)])
        self.assertEqual(before, self.committed()); self.assertFalse(self.db.in_transaction)

    def test_negative_int_preserves_integrity_error(self):
        before = self.committed()
        with self.assertRaises(sqlite3.IntegrityError):
            solution.replace_quantities(self.db, [(1, 11), (2, -1)])
        self.assertEqual(before, self.committed()); self.assertFalse(self.db.in_transaction)

    def test_iterator_failure_rolls_back_and_preserves_exception(self):
        expected = RuntimeError('iterator stopped')
        def rows():
            yield (1, 44)
            raise expected
        before = self.committed()
        with self.assertRaises(RuntimeError) as caught:
            solution.replace_quantities(self.db, rows())
        self.assertIs(caught.exception, expected)
        self.assertEqual(before, self.committed()); self.assertFalse(self.db.in_transaction)

    def test_commit_failure_rollback_then_connection_reusable(self):
        self.db.executescript('''
          CREATE TABLE allowed(value INTEGER PRIMARY KEY);
          INSERT INTO allowed VALUES(10),(20);
          CREATE TABLE audit(value INTEGER REFERENCES allowed(value) DEFERRABLE INITIALLY DEFERRED);
          CREATE TRIGGER record_quantity AFTER UPDATE OF quantity ON accounts
          BEGIN INSERT INTO audit VALUES(NEW.quantity); END;
        ''')
        before = self.committed(); statements=[]
        self.db.set_trace_callback(statements.append)
        with self.assertRaises(sqlite3.IntegrityError):
            solution.replace_quantities(self.db, [(1,20),(2,999)])
        self.assertTrue(any(s.strip().upper()=='COMMIT' for s in statements))
        self.assertEqual(self.committed(), before); self.assertFalse(self.db.in_transaction)
        with closing(sqlite3.connect(self.path)) as other:
            self.assertEqual(other.execute('SELECT count(*) FROM audit').fetchone()[0],0)
        solution.replace_quantities(self.db, [(1,20)])
        self.assertEqual(self.committed()[0], (1,20,'integer'))

    def test_caller_transaction_rejected_before_iterator_consumed(self):
        consumed=[]
        def rows():
            consumed.append(True)
            yield (2,7)
        self.db.execute('BEGIN'); self.db.execute('UPDATE accounts SET quantity=11 WHERE id=1')
        with self.assertRaises(RuntimeError): solution.replace_quantities(self.db, rows())
        self.assertEqual(consumed, []); self.assertTrue(self.db.in_transaction)
        self.assertEqual(self.committed()[0][1],10)
        self.db.rollback()

    def test_empty_batch_keeps_rows_and_ends_owned_transaction(self):
        before=self.committed(); solution.replace_quantities(self.db, [])
        self.assertEqual(before,self.committed()); self.assertFalse(self.db.in_transaction)

    def test_repeated_id_last_write_semantics_preserved(self):
        solution.replace_quantities(self.db, [(1,3),(1,4)])
        self.assertEqual(self.committed()[0], (1,4,'integer'))

if __name__=='__main__': unittest.main(verbosity=2)
