"""Run exactly 42 new controlled contracts: SQLite16, Bash8, Python6, JS6, PHP6.

The optional target is a reviewed copy of this package. Not a code sandbox.
Original source files are not rewritten; all logs go to a fresh external path.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
support=load('rc19_process',ROOT/'evals/rc8/run_integration.py')
batch=load('rc19_markers',ROOT/'evals/rc17/run_batch.py')

def run_all(output,target):
    expected=json.loads((HERE/'expected.json').read_text())
    summary={'kind':'known_contracts_not_independent_AI_AB','target':str(target),
      'requested':list(expected),'runs':[],'status':'RUNNING','started_utc':datetime.now(timezone.utc).isoformat()}
    def save():
        tmp=output/'summary.json.tmp';tmp.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');tmp.replace(output/'summary.json')
    save();prior=os.environ.get('RC19_TARGET_ROOT');os.environ['RC19_TARGET_ROOT']=str(target)
    try:
        for key,targets in expected.items():
            report=output/(key+'.json')
            if key in ('sql','bash','python'):
                cmd=[sys.executable,'-S',str(HERE/'run_python_suite.py'),'--suite',key,'--report',str(report)]
            elif key=='javascript':
                cmd=['node','--unhandled-rejections=strict',str(HERE/'cases_javascript.mjs'),str(target/'evals/rc17/fixtures/javascript/fixed/solution.mjs')]
            else:
                cmd=['php',str(HERE/'cases_php.php'),str(target/'evals/rc17/fixtures/php/fixed/solution.php')]
            log=output/(key+'.log');record=support.execute(cmd,output,log,30)
            row={'language':key,'status':record['status'],'executed':0,'command':record,'log':log.name,'expected_targets':targets}
            if record['status']=='FINISHED':
                if key in ('sql','bash','python') and report.exists():
                    d=json.loads(report.read_text());row['report']=d;row['executed']=d['tests_run']
                    ids=[x['test'] for x in d['records']]
                    exact=(sorted(ids)==sorted(targets) and len(ids)==len(targets) and d['tests_run']==len(targets))
                    good=exact and d['success'] is True and not d['skipped'] and not d['unexpected_successes'] and record['exit_code']==0
                    row['status']='PASS' if good else ('TEST_FAIL' if record['exit_code']==1 and not d['success'] else 'INVALID_EVIDENCE')
                elif key in ('javascript','php'):
                    row.update(batch.inspect(log.read_text(errors='replace'),record['exit_code'],targets))
                else:row['status']='INVALID_EVIDENCE'
            summary['runs'].append(row);save()
            if row['status']=='INTERRUPTED':raise KeyboardInterrupt
        states=[r['status'] for r in summary['runs']]
        summary['status']='FAIL' if any(s not in ('PASS','BLOCKED') for s in states) else ('PARTIAL_BLOCKED' if 'BLOCKED' in states else 'PASS')
    except KeyboardInterrupt:summary['status']='INTERRUPTED'
    except Exception as e:summary.update(status='ERROR',reason=type(e).__name__+': '+str(e))
    finally:
        if prior is None:os.environ.pop('RC19_TARGET_ROOT',None)
        else:os.environ['RC19_TARGET_ROOT']=prior
        summary['not_started']=[x for x in expected if x not in {r['language'] for r in summary['runs']}]
        summary['exit_code']={'PASS':0,'PARTIAL_BLOCKED':2,'INTERRUPTED':130}.get(summary['status'],1)
        summary['finished_utc']=datetime.now(timezone.utc).isoformat();save()
    return summary

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--target-root',type=Path,default=ROOT)
    args=parser.parse_args();out=args.output.resolve();target=args.target_root.resolve()
    if not (target/'evals/rc18/sql/fixed/solution.py').is_file():parser.error('target is not the reviewed fixture package')
    if out.exists() or ROOT==out or ROOT in out.parents or target==out or target in out.parents:parser.error('output must be new and outside both packages')
    out.mkdir(parents=True);data=run_all(out,target);print(data['status'])
    for row in data['runs']:print(row['language'],row['status'],row['executed'])
    raise SystemExit(data['exit_code'])
