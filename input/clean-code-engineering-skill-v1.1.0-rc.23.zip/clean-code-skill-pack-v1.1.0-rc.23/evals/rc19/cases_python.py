"""New controlled Python boundary checks using the unchanged fixture."""
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
ROOT=Path(os.environ.get('RC19_TARGET_ROOT',Path(__file__).resolve().parents[2]))
spec=importlib.util.spec_from_file_location('python_quantity',ROOT/'evals/rc17/fixtures/python/fixed/solution.py')
solution=importlib.util.module_from_spec(spec);spec.loader.exec_module(solution)

class PythonBoundaryTests(unittest.TestCase):
    def test_iterator_exception_preserves_target_and_error(self):
        old=[7];error=RuntimeError('iterator')
        def values():
            yield 3
            raise error
        with self.assertRaises(RuntimeError) as caught:solution.replace_quantities(old,values())
        self.assertIs(caught.exception,error);self.assertEqual(old,[7])
    def test_alias_input_prepared_before_target_change(self):
        old=[1,2,3];result=solution.replace_quantities(old,old)
        self.assertIs(result,old);self.assertEqual(old,[1,2,3])
    def test_bool_not_integer_quantity(self):
        old=[7]
        with self.assertRaises(ValueError):solution.replace_quantities(old,[1,True])
        self.assertEqual(old,[7])
    def test_snapshot_nested_two_way_isolation(self):
        original={'tags':[{'values':[1]}]};copy=solution.snapshot(original)
        copy['tags'][0]['values'].append(2);original['tags'].append({'values':[3]})
        self.assertEqual(original['tags'][0]['values'],[1]);self.assertEqual(len(copy['tags']),1)
    def test_real_owned_file_closed_on_callback_failure(self):
        handle=tempfile.TemporaryFile();self.addCleanup(handle.close);fd=handle.fileno();expected=RuntimeError('read')
        def work(stream):
            self.assertIs(stream,handle);stream.write(b'\x00x');raise expected
        with self.assertRaises(RuntimeError) as caught:solution.consume_owned(handle,work)
        self.assertIs(caught.exception,expected);self.assertTrue(handle.closed)
        with self.assertRaises(OSError):os.fstat(fd)
    def test_explicit_empty_list_keeps_caller_identity(self):
        caller=[];result=solution.add_tag('x',caller)
        self.assertIs(result,caller);self.assertEqual(caller,['x']);self.assertEqual(solution.add_tag('y'),['y'])

if __name__=='__main__':unittest.main(verbosity=2)
