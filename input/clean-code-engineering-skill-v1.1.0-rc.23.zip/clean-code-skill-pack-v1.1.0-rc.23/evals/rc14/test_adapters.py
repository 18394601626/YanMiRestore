"""Document contracts only. No claim of AI obedience or Rust compilation."""
from pathlib import Path
import hashlib,json,re,unittest
ROOT=Path(__file__).resolve().parents[2]
SKILL=ROOT/'clean-code-engineering'
class AdapterContracts(unittest.TestCase):
    def test_rust_guide_and_route(self):
        text=(SKILL/'references/17-rust.md').read_text()
        for token in ('执行适配','rust-version','Cargo.lock','Arc','unsafe','FFI','Result','BLOCKED','all-features'):
            self.assertIn(token,text)
        self.assertIn('references/17-rust.md',(SKILL/'SKILL.md').read_text())
    def test_c_guide_and_route(self):
        text=(SKILL/'references/18-c.md').read_text()
        for token in ('执行适配','SIZE_MAX','realloc','errno','goto','NUL','extern','compile_commands'):
            self.assertIn(token,text)
        self.assertIn('references/18-c.md',(SKILL/'SKILL.md').read_text())
    def test_cpp_guide_and_route(self):
        text=(SKILL/'references/19-cpp.md').read_text()
        for token in ('执行适配','RAII','string_view','unique_ptr','shared_ptr','noexcept','ABI','CMake'):
            self.assertIn(token,text)
        self.assertIn('references/19-cpp.md',(SKILL/'SKILL.md').read_text())
    def test_ambiguous_header_not_assigned_by_suffix(self):
        text=(SKILL/'SKILL.md').read_text()
        self.assertIn('共享 .h',text);self.assertIn('实际编译命令',text)
    def test_support_level_not_all_languages_verified(self):
        data=json.loads((SKILL/'assets/language-support.json').read_text())
        self.assertEqual(set(data['languages']),{'go','java','rust','c','cpp'})
        for item in data['languages'].values():
            self.assertIn('guide',item);self.assertIn('evidence_scope',item)
        self.assertFalse(data['independent_agent_AB'])
    def test_prior_runtime_and_test_sources_preserved(self):
        frozen=json.loads((ROOT/'provenance/rc14/protected-files.json').read_text())
        for path,h in frozen.items():
            self.assertEqual(hashlib.sha256((ROOT/path).read_bytes()).hexdigest(),h,path)
    def test_headers_and_behavior_tests_frozen(self):
        frozen=json.loads((ROOT/'provenance/rc14/tests-frozen.json').read_text())
        for path,h in frozen.items():
            self.assertEqual(hashlib.sha256((ROOT/path).read_bytes()).hexdigest(),h,path)
    def test_entry_does_not_grow_unbounded(self):
        text=(SKILL/'SKILL.md').read_text()
        self.assertLess(len(text.splitlines()),170)
    def test_release_version(self):
        self.assertEqual((ROOT/'VERSION').read_text().strip(),'1.1.0-rc.14')
        self.assertEqual((SKILL/'VERSION').read_text().strip(),'1.1.0-rc.14')
    def test_new_rule_ids_unique(self):
        all_ids=[]
        for file in ('17-rust.md','18-c.md','19-cpp.md'):
            text=(SKILL/'references'/file).read_text()
            ids=re.findall(r'^## ([A-Z]+-\d+) ',text,re.M)
            self.assertGreaterEqual(len(ids),6);all_ids+=ids
        self.assertEqual(len(all_ids),len(set(all_ids)))
if __name__=='__main__': unittest.main(verbosity=2)
