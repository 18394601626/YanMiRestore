# rc.14 语言适配验证

这不是普通AI与Skill AI的A/B实验。baseline为手工错误控制，fixed为同一助手按声明契约编写的候选，验收在编写实现之前保存。所验证的是这些具体代码和工具，不是保证模型总能执行规则。

## 入口和依赖

`python -S run_checks.py --language native --output <包外新目录>`需要Python3.9+、CMake/CTest3.21+、GCC/G++与Clang/Clang++。其中ASan/UBSan还需要本机运行库支持。测试使用现有工具，不安装依赖，不调用外部服务。

`--language rust`需要rustc；`--language all`运行两部分。Rust入口直接用rustc编译库和8个测试，不替代Cargo workspace/features/doc-tests矩阵；另提供零第三方依赖的Cargo示例，src/lib.rs与fixed.rs相同。其Cargo构建、格式、Clippy和MSRV仍待验证。

输出状态：0表示所请求的预期观察重现（包含被正确拒绝的坏控制）；1表示观察不符或执行错误；2表示所请求工具缺失；130表示被中断。缺少Rust时仍保留已完成的C/C++结果。新输出必须在包外且不存在。

## 范围

C有12项行为契约，C++有10项，另有1项C目标文件被C++调用的链接/执行检查。四个编译器/标准组合重复同23项测试：GCC/Clang × C11/C++17、C17/C++20。Clang另运行一次相同23项的ASan+UBSan。只有GCC C11/C++17运行手工bad控制，故意失败9项；不把重复次数累加为独立任务。

额外2类编译/链接控制：旧C++函数指针签名通过，改变返回类型时编译失败；去掉共享头的C语言链接声明时链接失败。它们是本地受控变化，不证明跨平台/跨版本ABI。

C使用真实malloc/free与缓冲区；C++资源测试用计数器模拟拥有资源，未测试系统文件句柄。所有控制都避免故意执行悬空指针或越界写来制造错误。Sanitizer无报告只覆盖实际执行及启用检查。

## 冻结与历史

headers、原始行为测试和contracts的哈希位于provenance/rc14/tests-frozen.json；不得为了green修改它们。旧资料的90个检查使用未修改的rc13入口，新版增加10个文档契约和10个报告解析检查。

资料检查通过不证明源文完备或模型遵循；Rust缺少工具不能用C/C++通过代替。当前结果见包根VALIDATION，原日志见evidence/rc14。
