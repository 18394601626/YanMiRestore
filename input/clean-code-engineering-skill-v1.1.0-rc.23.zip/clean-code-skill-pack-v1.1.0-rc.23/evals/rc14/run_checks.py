"""Run only bundled native/Rust examples in a fresh output directory.

No automatic downloads, toolchain upgrade, production data or external service.
This is a controlled fixture experiment, not a model A/B or untrusted-code sandbox.
Missing requested tools => exit 2; mismatched observations => exit 1.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('rc14_process_support', ROOT/'evals/rc8/run_integration.py')
support = importlib.util.module_from_spec(spec)
spec.loader.exec_module(support)

# This map identifies failures in our versioned test program, not arbitrary logs.
REASONS = {'C02':'!checked_product(SIZE_MAX,2,&n)', 'C05':'==BUFFER_SPACE',
           'C06':'memcmp(out,"xyz",3)==0', 'C10':'preserved',
           'CPP01':'a[0]->tags[0]=="old"', 'CPP02':'b[0]->tags.size()==1',
           'CPP05':'out==std::vector<int>({99})', 'CPP07':'c.live==0', 'CPP10':'caught'}

def _case_markers(output):
    """Only unquoted, whole-line records from the bundled fixture protocol."""
    lines = output.splitlines()
    outcomes = [line for line in lines
                if re.fullmatch(r'CASE_(?:OK|FAIL) [^\r\n]+', line)]
    failures = [line for line in lines if line.startswith('CONTRACT_FAIL ')]
    return outcomes, failures


def _check_ctest_case(case, expected_failed, result):
    name = case.get('name')
    terminal = [n for n in case if n.tag in ('failure', 'error', 'skipped')]
    if len(terminal) > 1:
        raise ValueError('Contradictory outcomes for ' + name)
    outputs = case.findall('system-out')
    if len(outputs) > 1:
        raise ValueError('Duplicate system-out for ' + name)
    output = case.findtext('system-out', '')
    outcome = terminal[0].tag if terminal else 'pass'
    status = case.get('status')
    allowed = {'pass': {'run'}, 'failure': {'fail'}, 'error': {'fail'},
               'skipped': {'notrun', 'disabled'}}[outcome]
    if status is not None and status not in allowed:
        raise ValueError('Inconsistent/unknown CTest status for ' + name)
    markers, diagnostics = _case_markers(output)
    if outcome == 'skipped':
        result['skipped'].append(name)
        return outcome
    if outcome in ('failure', 'error'):
        result['failed'].append(name)
        reason = expected_failed.get(name)
        # C emits name:line: expression; C++ emits name: expression.
        # The configured reason can be an expression fragment, but it must
        # belong to this single case-local CONTRACT_FAIL record.
        match = (re.fullmatch(r'CONTRACT_FAIL ' + re.escape(name)
                            + r':(?:(?:[0-9]+):)?[ \t]*(.+)', diagnostics[0])
                 if len(diagnostics) == 1 else None)
        confirmed = (reason and match and reason in match.group(1)
                     and markers == ['CASE_FAIL ' + name])
        if not confirmed:
            result['issues'].append('Unconfirmed failure cause: ' + name)
        else:
            result['confirmed_failure_causes'][name] = diagnostics[0]
    else:
        result['passed'].append(name)
        if markers != ['CASE_OK ' + name] or diagnostics:
            result['issues'].append('Missing/contradictory execution marker: ' + name)
    return outcome


def _check_ctest_counts(tree, cases, outcomes):
    # Counts are optional for backward-compatible minimal reports. When
    # provided they must agree with the actual case nodes; missing != zero.
    counts = {'tests': len(cases), 'failures': outcomes.count('failure'),
              'errors': outcomes.count('error'), 'skipped': outcomes.count('skipped'),
              'disabled': sum(c.get('status') == 'disabled' for c in cases)}
    for attribute, expected in counts.items():
        value = tree.get(attribute)
        if value is not None and (not re.fullmatch(r'[0-9]+', value)
                                  or int(value) != expected):
            raise ValueError('Inconsistent CTest count: ' + attribute)


def inspect_ctest(path, exit_code, expected, expected_failed):
    """Validate our CTest fixtures, not arbitrary JUnit or untrusted authors.

    Existing status fields are retained; confirmed diagnostics are additive.
    This checks report consistency, not the authenticity of a reporting program.
    """
    result = {'status': 'INVALID_EVIDENCE', 'executed': 0, 'passed': [],
              'failed': [], 'skipped': [], 'issues': [], 'confirmed_failure_causes': {}}
    try:
        tree = support.read_report(Path(path))
        if tree.tag != 'testsuite':
            raise ValueError('Expected a single CTest testsuite')
        cases = tree.findall('testcase')
        names = [c.get('name') for c in cases]
        if len(set(names)) != len(names) or any(not n for n in names):
            raise ValueError('Missing/duplicate test name')
        outcomes = [_check_ctest_case(c, expected_failed, result) for c in cases]
        result['executed'] = len(result['passed']) + len(result['failed'])
        _check_ctest_counts(tree, cases, outcomes)
        if set(names) != set(expected) or not cases:
            result['issues'].append('Missing/extra test targets')
        if result['skipped']:
            result['issues'].append('Skipped targets')
        if set(result['failed']) != set(expected_failed):
            result['issues'].append('Unexpected failures')
        if (expected_failed and exit_code != 8) or (not expected_failed and exit_code != 0):
            result['issues'].append('Process status does not match CTest outcome')
        result['status'] = ('MISMATCH' if result['issues'] else
                            ('EXPECTED_FAILURES' if expected_failed else 'PASS'))
    except Exception as exc:
        # Invalid evidence never erases already-recorded command results.
        result.update(status='INVALID_EVIDENCE', reason=type(exc).__name__ + ': ' + str(exc))
    return result

class ExecutionStopped(Exception):
    pass

def run_native(output, commands, contract):
    expected = contract['c']+contract['cpp']+contract['mixed']
    native = HERE/'native'
    reports = []
    def step(label, command, cwd=ROOT):
        log=output/(label+'.log')
        row=support.execute(command,cwd,log,45)
        row.update(id=label,log=log.name)
        commands.append(row)
        if row['status']=='INTERRUPTED': raise ExecutionStopped()
        return row
    if not all(shutil.which(x) for x in ('cmake','ctest','gcc','g++','clang','clang++')):
        return {'status':'BLOCKED','reason':'Native matrix needs cmake/ctest/GCC/G++/Clang/Clang++','runs':[]}
    configs=[('baseline-gcc-c11-cpp17','baseline','gcc','g++',11,17,False),
             ('fixed-gcc-c11-cpp17','fixed','gcc','g++',11,17,False),
             ('fixed-clang-c11-cpp17','fixed','clang','clang++',11,17,False),
             ('fixed-gcc-c17-cpp20','fixed','gcc','g++',17,20,False),
             ('fixed-clang-c17-cpp20','fixed','clang','clang++',17,20,False),
             ('fixed-clang-sanitized','fixed','clang','clang++',11,17,True)]
    for label,fixture,cc,cxx,cs,cpps,sanitized in configs:
        build=output/(label+'-build')
        row={'id':label,'fixture':fixture,'sanitized':sanitized,'status':'NOT_RUN'}
        cfg=step(label+'-configure',['cmake','-S',str(native),'-B',str(build),'-DFIXTURE='+fixture,
                 '-DCMAKE_C_COMPILER='+shutil.which(cc),'-DCMAKE_CXX_COMPILER='+shutil.which(cxx),
                 '-DCMAKE_C_STANDARD='+str(cs),'-DCMAKE_CXX_STANDARD='+str(cpps),
                 '-DENABLE_SANITIZERS='+('ON' if sanitized else 'OFF')])
        if cfg['status']!='FINISHED' or cfg['exit_code']!=0:
            row['status']='CONFIGURE_FAILED'; reports.append(row); continue
        compiled=step(label+'-build',['cmake','--build',str(build),'-j2'])
        if compiled['status']!='FINISHED' or compiled['exit_code']!=0:
            row['status']='COMPILE_FAILED';reports.append(row);continue
        report=output/(label+'.xml')
        tested=step(label+'-ctest',['ctest','--test-dir',str(build),'--output-on-failure','--no-tests=error','--output-junit',str(report)])
        if tested['status']!='FINISHED':
            row['status']=tested['status']
        else:
            row.update(inspect_ctest(report,tested['exit_code'],expected,REASONS if fixture=='baseline' else {}))
        reports.append(row)
    # Compiler/linker checks are separate from runtime tests.
    include=HERE/'native/include'
    old_client=HERE/'native/tests/cpp_old_client.cpp'
    for broken in (False,True):
        label='cpp-public-signature-'+('changed' if broken else 'preserved')
        cmd=['g++','-std=c++17','-I'+str(include),'-c',str(old_client),'-o',str(output/(label+'.o'))]
        if broken: cmd.insert(1,'-DBREAK_RETURN_CONTRACT')
        row=step(label,cmd)
        log=(output/row['log']).read_text(errors='replace')
        ok=(row['status']=='FINISHED' and ((row['exit_code']==0 and not broken) or
            (row['exit_code']!=0 and broken and 'owned_name' in log and ('conversion' in log or 'invalid' in log))))
        reports.append({'id':label,'status':'EXPECTED_COMPILE_REJECTION' if ok and broken else ('PASS' if ok else 'MISMATCH')})
    label='c-cpp-linkage-removed'
    library=output/'fixed-gcc-c11-cpp17-build/libc_bytes.a'
    if library.exists():
        row=step(label,['g++','-std=c++17','-DOMIT_C_LINKAGE','-I'+str(include),str(native/'tests/c_abi_probe.cpp'),str(library),'-o',str(output/'invalid-link')])
        log=(output/row['log']).read_text(errors='replace')
        ok=row['status']=='FINISHED' and row['exit_code']!=0 and 'undefined reference' in log and 'checked_product' in log
        reports.append({'id':label,'status':'EXPECTED_LINK_REJECTION' if ok else 'MISMATCH'})
    else: reports.append({'id':label,'status':'NOT_RUN'})
    accepted={'PASS','EXPECTED_FAILURES','EXPECTED_COMPILE_REJECTION','EXPECTED_LINK_REJECTION'}
    return {'status':'EXPECTED_OBSERVATIONS_REPRODUCED' if all(r['status'] in accepted for r in reports) else 'MISMATCH',
            'unique_runtime_contracts':len(expected),'runs':reports,
            'note':'Repeated compiler/configuration runs are not independent model trials.'}

def run_rust(output,commands,contract):
    # Invoke a real tool, record a launch failure if absent. Never substitute C/C++.
    probe=support.execute(['rustc','--version'],ROOT,output/'rustc-version.log',10)
    probe.update(id='rustc-version',log='rustc-version.log');commands.append(probe)
    if probe['status']=='INTERRUPTED':raise ExecutionStopped()
    if probe['status']!='FINISHED' or probe['exit_code']!=0:
        return {'status':'BLOCKED','reason':'rustc could not run','executed_tests':0,'runs':[]}
    rows=[]
    for fixture in ('baseline','fixed'):
        dest=output/('rust-'+fixture);dest.mkdir()
        def step(label,cmd):
            row=support.execute(cmd,ROOT,dest/(label+'.log'),45)
            row.update(id='rust-'+fixture+'-'+label,log=str((dest/(label+'.log')).relative_to(output)));commands.append(row)
            if row['status']=='INTERRUPTED':raise ExecutionStopped()
            return row
        lib=dest/'librc14_contracts.rlib'
        compiled=step('library',['rustc','--edition=2021','--crate-type=lib','--crate-name=rc14_contracts',str(HERE/'rust'/(fixture+'.rs')),'-o',str(lib)])
        if compiled['status']!='FINISHED' or compiled['exit_code']!=0:
            rows.append({'fixture':fixture,'status':'COMPILE_FAILED'});continue
        binary=dest/'contracts'
        tests=step('test-build',['rustc','--edition=2021','--test',str(HERE/'rust/tests/contracts.rs'),'--extern','rc14_contracts='+str(lib),'-o',str(binary)])
        if tests['status']!='FINISHED' or tests['exit_code']!=0:
            rows.append({'fixture':fixture,'status':'TEST_COMPILE_FAILED'});continue
        for name in contract['rust']:
            row=step(name,[str(binary),name,'--exact','--nocapture'])
            log=(output/row['log']).read_text(errors='replace')
            want_fail=fixture=='baseline' and name in contract['baseline_expected_rust_failures']
            outcome='FAILED' if want_fail else 'ok'
            ok=(row['status']=='FINISHED' and row['exit_code']==(101 if want_fail else 0)
                and 'running 1 test' in log and re.search(r'test '+re.escape(name)+r' \.\.\. '+outcome+r'\b',log))
            rows.append({'fixture':fixture,'test':name,'status':('EXPECTED_FAILURE' if want_fail else 'PASS') if ok else 'MISMATCH'})
    return {'status':'EXPECTED_OBSERVATIONS_REPRODUCED' if len(rows)==16 and all(r['status'] in ('PASS','EXPECTED_FAILURE') for r in rows) else 'MISMATCH',
            'executed_tests':sum('test' in r for r in rows),'runs':rows}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=('native','rust','all'),default='all')
    args=parser.parse_args();output=args.output.resolve()
    if output.exists() or output==ROOT or ROOT in output.parents:
        parser.error('output must be new and outside the package')
    output.mkdir(parents=True)
    summary={'version':(ROOT/'VERSION').read_text().strip(), 'kind':'manual_fault_controls_not_AI_AB',
             'started_utc':datetime.now(timezone.utc).isoformat(),'commands':[],'languages':{}}
    contract=json.loads((HERE/'contracts.json').read_text())
    code=1
    try:
        if args.language in ('native','all'):summary['languages']['native']=run_native(output,summary['commands'],contract)
        if args.language in ('rust','all'):summary['languages']['rust']=run_rust(output,summary['commands'],contract)
        states=[r['status'] for r in summary['languages'].values()]
        mismatch=any(s not in ('EXPECTED_OBSERVATIONS_REPRODUCED','BLOCKED') for s in states)
        blocked='BLOCKED' in states
        summary['status']='MISMATCH' if mismatch else ('PARTIAL_BLOCKED' if blocked else 'EXPECTED_OBSERVATIONS_REPRODUCED')
        code=1 if mismatch else (2 if blocked else 0)
    except (KeyboardInterrupt,ExecutionStopped):
        summary['status']='INTERRUPTED';code=130
    except Exception as exc:
        summary.update(status='ERROR',reason=type(exc).__name__+': '+str(exc));code=1
    finally:
        summary['exit_code']=code
        (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(summary['status'])
    for name,data in summary['languages'].items():print(name,data['status'])
    return code

if __name__=='__main__':raise SystemExit(main())
