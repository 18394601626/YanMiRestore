#include "work.hpp"
#include <stdexcept>
#include <utility>

namespace rc14 {
Records snapshot(const Records& input) {
    Records result;
    result.reserve(input.size());
    for (const auto& record : input) {
        result.push_back(record ? std::make_shared<Record>(*record) : nullptr);
    }
    return result;
}

void replace_numbers(std::vector<int>& output, const std::vector<std::string>& input) {
    std::vector<int> parsed;
    parsed.reserve(input.size());
    for (const auto& text : input) {
        std::size_t consumed = 0;
        const int value = std::stoi(text, &consumed);
        if (consumed != text.size()) throw std::invalid_argument("trailing input");
        parsed.push_back(value);
    }
    // Commit only when parsing the complete batch succeeded.
    output.swap(parsed);
}

namespace {
class Lease final {
public:
    explicit Lease(ResourceCounts& counts) : counts_(counts) { ++counts_.live; }
    ~Lease() noexcept { --counts_.live; ++counts_.closed; }
    Lease(const Lease&) = delete;
    Lease& operator=(const Lease&) = delete;
private:
    ResourceCounts& counts_;
};
}

void with_resource(ResourceCounts& counts, const std::function<void()>& work) {
    Lease lease(counts);
    work();
}
std::unique_ptr<int> make_owner(int value) { return std::make_unique<int>(value); }
std::string owned_name(const std::string& input) { return input; }
}
