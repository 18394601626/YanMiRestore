#include "bytes.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

int checked_product(size_t count, size_t width, size_t *out) {
    if (!out || (count != 0 && width > SIZE_MAX / count)) return 0;
    *out = count * width;
    return 1;
}

enum buffer_status copy_label(char *dst, size_t capacity, const char *src, size_t *written) {
    if (!dst || !src || !written) return BUFFER_INVALID;
    const size_t length = strlen(src);
    if (length >= capacity) return BUFFER_SPACE;
    /* Check first: length+1 fits, overlap is explicitly supported. */
    memmove(dst, src, length + 1);
    *written = length;
    return BUFFER_OK;
}

enum buffer_status replace_blob(struct blob *dst, const void *src, size_t size, allocate_bytes alloc) {
    if (!dst || !alloc || (!src && size != 0)) return BUFFER_INVALID;
    if (size == 0) {
        release_blob(dst);
        return BUFFER_OK;
    }
    unsigned char *next = alloc(size);
    if (!next) return BUFFER_NOMEM;
    /* Copy before release: src is allowed to alias the current buffer. */
    memcpy(next, src, size);
    free(dst->data);
    dst->data = next;
    dst->size = size;
    return BUFFER_OK;
}

void release_blob(struct blob *value) {
    if (!value) return;
    free(value->data);
    value->data = NULL;
    value->size = 0;
}
