#ifndef RC14_WORK_HPP
#define RC14_WORK_HPP
#include <functional>
#include <memory>
#include <string>
#include <string_view>
#include <vector>
namespace rc14 {
struct Record { std::vector<std::string> tags; };
using Records=std::vector<std::shared_ptr<Record>>;
/* Returned non-null records must not share mutable state with input. */
Records snapshot(const Records& input);
/* All strings must be fully parsed; failure preserves the original vector. */
void replace_numbers(std::vector<int>& output,const std::vector<std::string>& input);
struct ResourceCounts { int live=0; int closed=0; };
/* Own a single logical test resource, release exactly once even on exception. */
void with_resource(ResourceCounts& counts,const std::function<void()>& work);
std::unique_ptr<int> make_owner(int value);
#ifdef BREAK_RETURN_CONTRACT
std::string_view owned_name(const std::string& input);
#else
std::string owned_name(const std::string& input);
#endif
}
#endif
