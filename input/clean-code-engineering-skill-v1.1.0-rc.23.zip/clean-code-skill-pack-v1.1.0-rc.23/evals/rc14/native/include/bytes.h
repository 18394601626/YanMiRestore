#ifndef RC14_BYTES_H
#define RC14_BYTES_H
#include <stddef.h>
#if defined(__cplusplus) && !defined(OMIT_C_LINKAGE)
extern "C" {
#endif
enum buffer_status { BUFFER_OK, BUFFER_INVALID, BUFFER_SPACE, BUFFER_NOMEM };
struct blob { unsigned char *data; size_t size; };
typedef void *(*allocate_bytes)(size_t);
/* Overflow/failure leaves out unchanged. A NULL out is invalid. */
int checked_product(size_t count, size_t width, size_t *out);
/* src is a valid NUL-terminated string. Supports overlapping src/dst.
   capacity includes the terminator. Failure leaves dst and written unchanged. */
enum buffer_status copy_label(char *dst, size_t capacity, const char *src, size_t *written);
/* dst owns malloc-compatible storage or is {NULL,0}. Input may alias it.
   Allocation failure preserves dst; zero length releases storage. */
enum buffer_status replace_blob(struct blob *dst, const void *src, size_t size, allocate_bytes alloc);
void release_blob(struct blob *value);
#if defined(__cplusplus) && !defined(OMIT_C_LINKAGE)
}
#endif
#endif
