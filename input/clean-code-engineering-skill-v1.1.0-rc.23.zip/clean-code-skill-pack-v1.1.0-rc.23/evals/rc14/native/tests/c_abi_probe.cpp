#include "bytes.h"
#include <iostream>
int main() { size_t out=0;if(!checked_product(3,4,&out)||out!=12)return 1;std::cout<<"CASE_OK C_ABI\n"; }
