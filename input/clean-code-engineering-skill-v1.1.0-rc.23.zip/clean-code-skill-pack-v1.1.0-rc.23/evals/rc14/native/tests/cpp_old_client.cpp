#include "work.hpp"
using ExistingSignature=std::string (*)(const std::string&);
ExistingSignature existing_client = &rc14::owned_name;
