#include "work.hpp"
#include <iostream>
#include <stdexcept>
#include <utility>
#define CHECK(expr) do { if (!(expr)) throw std::runtime_error(std::string("CONTRACT_FAIL ")+__func__+": "+#expr); } while (false)
using namespace rc14;
static Records original() { return {std::make_shared<Record>(Record{{"old"}}),nullptr}; }
static void CPP01() { auto a=original();auto b=snapshot(a);b[0]->tags[0]="new";CHECK(a[0]->tags[0]=="old"); }
static void CPP02() { auto a=original();auto b=snapshot(a);a[0]->tags.push_back("later");CHECK(b[0]->tags.size()==1); }
static void CPP03() { auto a=original();auto b=snapshot(a);CHECK(b.size()==2);CHECK(b[1]==nullptr);CHECK(snapshot({}).empty()); }
static void CPP04() { std::vector<int> out={99};replace_numbers(out,{"2","-3","0"});CHECK(out==std::vector<int>({2,-3,0})); }
static void CPP05() { std::vector<int> out={99};bool caught=false;try {replace_numbers(out,{"2","bad"});}catch(const std::invalid_argument&) {caught=true;} CHECK(caught);CHECK(out==std::vector<int>({99})); }
static void CPP06() { ResourceCounts c;with_resource(c,[&]{CHECK(c.live==1);});CHECK(c.live==0);CHECK(c.closed==1); }
static void CPP07() { ResourceCounts c;bool caught=false;try {with_resource(c,[]{throw std::logic_error("body");});}catch(const std::logic_error& e){caught=std::string(e.what())=="body";}CHECK(caught);CHECK(c.live==0);CHECK(c.closed==1); }
static void CPP08() { auto p=make_owner(7);CHECK(p && *p==7);auto q=std::move(p);CHECK(!p);CHECK(q && *q==7); }
static void CPP09() { std::string s="Ada";auto out=owned_name(s);s[0]='X';CHECK(out=="Ada"); }
static void CPP10() { std::vector<int> out={99};bool caught=false;try {replace_numbers(out,{"2tail"});}catch(const std::invalid_argument&){caught=true;}CHECK(caught);CHECK(out==std::vector<int>({99})); }
struct Test { const char *id;void (*run)(); };
int main(int argc,char **argv) {
    const Test tests[]={{"CPP01",CPP01},{"CPP02",CPP02},{"CPP03",CPP03},{"CPP04",CPP04},{"CPP05",CPP05},
        {"CPP06",CPP06},{"CPP07",CPP07},{"CPP08",CPP08},{"CPP09",CPP09},{"CPP10",CPP10}};
    if(argc!=2) return 2;
    for(const auto& t:tests) if(std::string(argv[1])==t.id) {
        try {t.run();std::cout<<"CASE_OK "<<t.id<<'\n';return 0;}
        catch(const std::exception& e){std::cerr<<e.what()<<'\n';std::cout<<"CASE_FAIL "<<t.id<<'\n';return 1;}
    }
    return 2;
}
