#include "bytes.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(expr) do { if (!(expr)) { fprintf(stderr, "CONTRACT_FAIL %s:%d: %s\n", __func__, __LINE__, #expr); return 1; } } while (0)
static void *deny_alloc(size_t size) { (void)size; return NULL; }
static int C01(void) {
    size_t n = 9;
    for (size_t a = 0; a < 32; ++a) for (size_t b = 0; b < 32; ++b) {
        CHECK(checked_product(a,b,&n)); CHECK(n == a*b);
    }
    return 0;
}
static int C02(void) { size_t n=19; CHECK(!checked_product(SIZE_MAX,2,&n)); CHECK(n==19); return 0; }
static int C03(void) { size_t n=19; CHECK(checked_product(SIZE_MAX,0,&n)); CHECK(n==0); CHECK(!checked_product(2,3,NULL)); return 0; }
static int C04(void) { char out[5]={'x','x','x','x','x'}; size_t n=99; CHECK(copy_label(out,sizeof out,"Ada",&n)==BUFFER_OK); CHECK(n==3); CHECK(memcmp(out,"Ada\0",4)==0); CHECK(out[4]=='x'); return 0; }
static int C05(void) { char out[4]={'x','x','x','x'}; size_t n=99; CHECK(copy_label(out,3,"Ada",&n)==BUFFER_SPACE); CHECK(n==99); CHECK(memcmp(out,"xxxx",4)==0); return 0; }
static int C06(void) { char out[3]={'x','y','z'}; size_t n=99; CHECK(copy_label(out,2,"Ada",&n)==BUFFER_SPACE); CHECK(n==99); CHECK(memcmp(out,"xyz",3)==0); return 0; }
static int C07(void) { char out[8]="abcdef"; size_t n=0; CHECK(copy_label(out+1,7,out,&n)==BUFFER_OK); CHECK(memcmp(out+1,"abcdef\0",7)==0); CHECK(n==6); return 0; }
static int C08(void) { char out[2]={'x','y'}; size_t n=99; CHECK(copy_label(NULL,0,"",&n)==BUFFER_INVALID); CHECK(copy_label(out,2,NULL,&n)==BUFFER_INVALID); CHECK(copy_label(out,2,"",NULL)==BUFFER_INVALID); CHECK(copy_label(out,0,"",&n)==BUFFER_SPACE); CHECK(out[0]=='x'); return 0; }
static int C09(void) {
    struct blob b={NULL,0}; unsigned char src[3]={0,255,7};
    enum buffer_status status=replace_blob(&b,src,sizeof src,malloc);
    int bad=status!=BUFFER_OK || b.data==NULL || b.size!=3;
    if (!bad) { src[1]=8; bad=b.data[1]!=255; b.data[2]=9; bad=bad || src[2]!=7; }
    release_blob(&b); CHECK(!bad); return 0;
}
static int C10(void) {
    struct blob b={NULL,0}; const unsigned char old[3]={1,2,3};
    CHECK(replace_blob(&b,old,3,malloc)==BUFFER_OK);
    enum buffer_status status=replace_blob(&b,"new",3,deny_alloc);
    int preserved=b.size==3 && b.data!=NULL && memcmp(b.data,old,3)==0;
    release_blob(&b); CHECK(status==BUFFER_NOMEM); CHECK(preserved); return 0;
}
static int C11(void) {
    struct blob b={NULL,0}; CHECK(replace_blob(&b,"abcde",5,malloc)==BUFFER_OK);
    enum buffer_status status=replace_blob(&b,b.data+1,3,malloc);
    int valid=status==BUFFER_OK && b.size==3 && b.data && memcmp(b.data,"bcd",3)==0;
    release_blob(&b); CHECK(valid); return 0;
}
static int C12(void) {
    struct blob b={NULL,0}; CHECK(replace_blob(&b,"a",1,malloc)==BUFFER_OK);
    CHECK(replace_blob(&b,NULL,0,malloc)==BUFFER_OK); CHECK(b.data==NULL && b.size==0);
    release_blob(&b); release_blob(&b); release_blob(NULL); CHECK(b.data==NULL && b.size==0); return 0;
}
struct testcase { const char *name; int (*run)(void); };
int main(int argc,char **argv) {
    static const struct testcase tests[]={
        {"C01",C01},{"C02",C02},{"C03",C03},{"C04",C04},{"C05",C05},{"C06",C06},
        {"C07",C07},{"C08",C08},{"C09",C09},{"C10",C10},{"C11",C11},{"C12",C12}};
    if (argc!=2) return 2;
    for (size_t i=0;i<sizeof tests/sizeof tests[0];++i) if (!strcmp(argv[1],tests[i].name)) {
        int code=tests[i].run(); printf("CASE_%s %s\n",code?"FAIL":"OK",tests[i].name); return code;
    }
    return 2;
}
