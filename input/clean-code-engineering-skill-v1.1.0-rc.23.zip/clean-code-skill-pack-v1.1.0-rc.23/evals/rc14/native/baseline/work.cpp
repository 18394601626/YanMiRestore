// MANUAL FAULT CONTROL. No deliberate dangling references or undefined behavior.
#include "work.hpp"
namespace rc14 {
Records snapshot(const Records& input) {return input;}
void replace_numbers(std::vector<int>& output,const std::vector<std::string>& input) {
    output.clear();for(const auto& text:input) output.push_back(std::stoi(text));
}
void with_resource(ResourceCounts& counts,const std::function<void()>& work) {
    ++counts.live;work();--counts.live;++counts.closed;
}
std::unique_ptr<int> make_owner(int value) {return std::make_unique<int>(value);}
std::string owned_name(const std::string& input) {return input;}
}
