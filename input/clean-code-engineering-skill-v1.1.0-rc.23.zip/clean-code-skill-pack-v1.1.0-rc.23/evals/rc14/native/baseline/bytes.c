/* MANUAL FAULT CONTROL. Deliberate contract violations; not an AI output. */
#include "bytes.h"
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
int checked_product(size_t count,size_t width,size_t *out) {
    if (!out) return 0;
    *out=count*width; return 1; /* wrong: unsigned wrap is not rejected */
}
enum buffer_status copy_label(char *dst,size_t cap,const char *src,size_t *written) {
    if (!dst || !src || !written) return BUFFER_INVALID;
    size_t len=strlen(src);
    if (len>cap || cap==0) { if(cap) dst[0]='\0'; return BUFFER_SPACE; }
    memmove(dst,src,len); if(len<cap) dst[len]='\0'; *written=len;
    return BUFFER_OK; /* wrong: cap==len leaves no terminator */
}
enum buffer_status replace_blob(struct blob *dst,const void *src,size_t n,allocate_bytes alloc) {
    if (!dst || !alloc || (!src && n)) return BUFFER_INVALID;
    if (!n) {release_blob(dst);return BUFFER_OK;}
    unsigned char *next=alloc(n);
    if (!next) {release_blob(dst);return BUFFER_NOMEM;} /* wrong: loses old value */
    memcpy(next,src,n);free(dst->data);dst->data=next;dst->size=n;return BUFFER_OK;
}
void release_blob(struct blob *value) {if(value){free(value->data);value->data=NULL;value->size=0;}}
