"""Controlled CTest report contract; not a universal JUnit/security parser."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

class Reports(unittest.TestCase):
    def setUp(self):
        path=Path(__file__).with_name('run_checks.py')
        spec=importlib.util.spec_from_file_location('rc14_runner',path)
        self.runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(self.runner)
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.report=Path(self.temp.name)/'report.xml'
    def parse(self,body,code=0,expected=None,failed=None):
        self.report.write_text(body)
        return self.runner.inspect_ctest(self.report,code,expected or ['T1'],failed or {})
    def test_valid_pass(self):
        result=self.parse('<testsuite tests="1" failures="0" skipped="0"><testcase name="T1"><system-out>CASE_OK T1</system-out></testcase></testsuite>')
        self.assertEqual(result['status'],'PASS')
    def test_valid_failure(self):
        result=self.parse('<testsuite tests="1" failures="1"><testcase name="T1"><failure/><system-out>CONTRACT_FAIL T1: expected reason\nCASE_FAIL T1</system-out></testcase></testsuite>',8,failed={'T1':'expected reason'})
        self.assertEqual(result['status'],'EXPECTED_FAILURES')
    def test_wrong_reason_is_rejected(self):
        result=self.parse('<testsuite tests="1" failures="1"><testcase name="T1"><failure/><system-out>CONTRACT_FAIL T1: unrelated\nCASE_FAIL T1</system-out></testcase></testsuite>',8,failed={'T1':'expected reason'})
        self.assertEqual(result['status'],'MISMATCH')
    def test_no_tests_is_rejected(self):
        self.assertNotEqual(self.parse('<testsuite tests="0" failures="0"/>')['status'],'PASS')
    def test_duplicate_is_rejected(self):
        xml='<testsuite tests="2"><testcase name="T1"/><testcase name="T1"/></testsuite>'
        self.assertEqual(self.parse(xml)['status'],'INVALID_EVIDENCE')
    def test_skip_is_not_pass(self):
        xml='<testsuite tests="1"><testcase name="T1"><skipped/><system-out>CASE_OK T1</system-out></testcase></testsuite>'
        self.assertNotEqual(self.parse(xml)['status'],'PASS')
    def test_nonzero_exit_is_not_pass(self):
        xml='<testsuite tests="1" failures="0"><testcase name="T1"><system-out>CASE_OK T1</system-out></testcase></testsuite>'
        self.assertNotEqual(self.parse(xml,code=1)['status'],'PASS')
    def test_invalid_xml_is_structured(self):
        self.assertEqual(self.parse('<testsuite>')['status'],'INVALID_EVIDENCE')
    def test_dtd_is_rejected(self):
        self.assertEqual(self.parse('<!DOCTYPE testsuite [<!ENTITY v "CASE_OK T1">]><testsuite tests="1"><testcase name="T1"><system-out>&v;</system-out></testcase></testsuite>')['status'],'INVALID_EVIDENCE')
    def test_missing_execution_marker_is_not_pass(self):
        self.assertNotEqual(self.parse('<testsuite tests="1"><testcase name="T1"/></testsuite>')['status'],'PASS')

if __name__=='__main__': unittest.main(verbosity=2)
