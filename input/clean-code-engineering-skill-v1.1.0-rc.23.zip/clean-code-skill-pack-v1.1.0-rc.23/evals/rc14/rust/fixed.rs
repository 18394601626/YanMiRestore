// Candidate example; consult VALIDATION.md for actual compiler availability.
use std::sync::{Arc, Mutex};
#[derive(Debug, PartialEq, Eq)]
pub enum LimitError { Invalid, Zero, Poisoned }

pub fn parse_limit(input: &str) -> Result<u32, LimitError> {
    let value = input.parse::<u32>().map_err(|_| LimitError::Invalid)?;
    if value == 0 { Err(LimitError::Zero) } else { Ok(value) }
}

pub fn append_batch(out: &mut Vec<u32>, input: &[&str]) -> Result<(), LimitError> {
    let parsed: Result<Vec<u32>, LimitError> = input.iter().map(|text| parse_limit(text)).collect();
    out.extend(parsed?);
    Ok(())
}

pub fn snapshot(input: &Arc<Mutex<Vec<String>>>) -> Result<Arc<Mutex<Vec<String>>>, LimitError> {
    // The guard protects only the copy. The result owns independent strings.
    let copied = input.lock().map_err(|_| LimitError::Poisoned)?.clone();
    Ok(Arc::new(Mutex::new(copied)))
}
