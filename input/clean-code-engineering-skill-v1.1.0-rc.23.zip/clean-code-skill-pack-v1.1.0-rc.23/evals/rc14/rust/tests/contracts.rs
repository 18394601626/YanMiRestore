use rc14_contracts::{append_batch, parse_limit, snapshot, LimitError};
use std::sync::{Arc, Mutex};
#[test]
fn r01_valid() { assert_eq!(parse_limit("12"), Ok(12)); }
#[test]
fn r02_invalid_is_error() {
    let outcome = std::panic::catch_unwind(|| parse_limit("invalid"));
    assert!(outcome.is_ok(), "ordinary invalid input must not panic");
    assert_eq!(outcome.unwrap(), Err(LimitError::Invalid));
}
#[test]
fn r03_zero_rejected() { assert_eq!(parse_limit("0"), Err(LimitError::Zero)); }
#[test]
fn r04_failure_is_atomic() {
    let mut output = vec![99];
    let outcome = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| append_batch(&mut output, &["2", "0"])));
    assert!(outcome.is_ok()); assert_eq!(outcome.unwrap(), Err(LimitError::Zero));
    assert_eq!(output, vec![99]);
}
#[test]
fn r05_append_success() {
    let mut output = vec![99];assert_eq!(append_batch(&mut output, &["2", "3"]), Ok(()));
    assert_eq!(output, vec![99, 2, 3]);
}
#[test]
fn r06_snapshot_output_is_independent() {
    let original = Arc::new(Mutex::new(vec![String::from("old")]));
    let result = snapshot(&original).unwrap();
    result.lock().unwrap()[0] = String::from("new");
    assert_eq!(original.lock().unwrap()[0], "old");
}
#[test]
fn r07_snapshot_input_is_independent() {
    let original = Arc::new(Mutex::new(vec![String::from("old")]));
    let result = snapshot(&original).unwrap();original.lock().unwrap().push(String::from("later"));
    assert_eq!(result.lock().unwrap().len(), 1);
}
#[test]
fn r08_poison_is_reported() {
    let original = Arc::new(Mutex::new(Vec::<String>::new()));
    let cloned = Arc::clone(&original);
    let _ = std::thread::spawn(move || { let _guard = cloned.lock().unwrap();panic!("test poison"); }).join();
    let outcome = std::panic::catch_unwind(|| snapshot(&original));
    assert!(outcome.is_ok()); assert!(matches!(outcome.unwrap(), Err(LimitError::Poisoned)));
}
