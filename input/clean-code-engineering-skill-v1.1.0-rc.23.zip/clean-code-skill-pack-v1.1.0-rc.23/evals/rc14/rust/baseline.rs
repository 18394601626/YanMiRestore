// MANUAL FAULT CONTROL, not a no-Skill model result.
use std::sync::{Arc, Mutex};
#[derive(Debug, PartialEq, Eq)]
pub enum LimitError { Invalid, Zero, Poisoned }
pub fn parse_limit(input: &str) -> Result<u32, LimitError> {
    let value = input.parse::<u32>().unwrap();
    if value == 0 { Err(LimitError::Zero) } else { Ok(value) }
}
pub fn append_batch(out: &mut Vec<u32>, input: &[&str]) -> Result<(), LimitError> {
    for text in input { out.push(parse_limit(text)?); }
    Ok(())
}
pub fn snapshot(input: &Arc<Mutex<Vec<String>>>) -> Result<Arc<Mutex<Vec<String>>>, LimitError> {
    Ok(Arc::clone(input))
}
