"""Validate package structure only; this does not test an agent's behavior."""
from pathlib import Path
import json
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
SKILL = ROOT / "clean-code-engineering"

class PackageChecks(unittest.TestCase):
    def test_required_files(self):
        required = [
            'README.md', 'clean-code-engineering/SKILL.md',
            'clean-code-engineering/references/01-writing.md',
            'clean-code-engineering/references/02-design.md',
            'clean-code-engineering/references/03-testing-concurrency.md',
            'clean-code-engineering/references/04-refactoring.md',
            'clean-code-engineering/references/05-heuristics.md',
            'clean-code-engineering/references/06-source-map.md',
            'clean-code-engineering/assets/change-contract.md',
            'clean-code-engineering/assets/review-report.md',
            'clean-code-engineering/assets/completion-report.md',
            'adapters/project-rule.md', 'evals/scenarios.json', 'evals/README.md'
        ]
        for relative in required:
            with self.subTest(path=relative):
                self.assertTrue((ROOT / relative).is_file(), relative)

    def test_frontmatter(self):
        text = (SKILL / 'SKILL.md').read_text(encoding='utf-8')
        self.assertTrue(text.startswith('---\n'))
        parts = text.split('---', 2)
        self.assertEqual(len(parts), 3)
        fields = dict(re.findall(r'^(name|description): (.+)$', parts[1], re.M))
        self.assertEqual(fields.get('name'), SKILL.name)
        self.assertRegex(fields['name'], r'^[a-z0-9]+(?:-[a-z0-9]+)*$')
        self.assertLessEqual(len(fields['name']), 64)
        self.assertTrue(0 < len(fields.get('description', '')) <= 1024)
        self.assertLess(len(text.splitlines()), 500)

    def test_relative_markdown_links(self):
        for file in ROOT.rglob('*.md'):
            text = file.read_text(encoding='utf-8')
            for link in re.findall(r'\]\(([^)]+)\)', text):
                if '://' in link or link.startswith('#'):
                    continue
                path = link.split('#', 1)[0]
                with self.subTest(file=str(file.relative_to(ROOT)), link=path):
                    resolved = (file.parent / path).resolve()
                    self.assertTrue(resolved.is_relative_to(ROOT.resolve()))
                    self.assertTrue(resolved.exists(), str(resolved))

    def test_heuristics_66_exactly_once(self):
        text = (SKILL / 'references/05-heuristics.md').read_text(encoding='utf-8')
        actual = re.findall(r'^### ([CEFGJNT]\d+)\s', text, re.M)
        expected = [f'{prefix}{i}' for prefix, count in
                    [('C', 5), ('E', 2), ('F', 4), ('G', 36), ('J', 3), ('N', 7), ('T', 9)]
                    for i in range(1, count + 1)]
        self.assertEqual(actual, expected)
        self.assertEqual(len(set(actual)), 66)

    def test_chapter_and_appendix_mapping(self):
        text = (SKILL / 'references/06-source-map.md').read_text(encoding='utf-8')
        for chapter in range(1, 18):
            self.assertRegex(text, rf'\| 第 {chapter} 章 ')
        self.assertIn('| 附录 A ', text)
        self.assertIn('| 附录 B ', text)
        self.assertIn('108—109', text)
        self.assertIn('389', text)
        self.assertIn('执行适配', text)

    def test_behavioral_scenarios_are_not_reported_as_run(self):
        scenarios = json.loads((ROOT / 'evals/scenarios.json').read_text(encoding='utf-8'))
        self.assertGreaterEqual(len(scenarios), 16)
        self.assertEqual(len({x['id'] for x in scenarios}), len(scenarios))
        for item in scenarios:
            self.assertEqual(item['status'], 'not_run')
            self.assertTrue(item['prompt'])
            self.assertGreaterEqual(len(item['expected']), 2)
            self.assertTrue(item['must_not'])

    def test_all_references_reachable_from_skill(self):
        main = (SKILL / 'SKILL.md').read_text(encoding='utf-8')
        for file in (SKILL / 'references').glob('*.md'):
            self.assertIn(f'references/{file.name}', main)

    def test_text_files_utf8_and_no_nul(self):
        for file in ROOT.rglob('*'):
            if file.is_file() and file.suffix in {'.md', '.json', '.py', '.txt'}:
                text = file.read_text(encoding='utf-8')
                self.assertNotIn('\x00', text)

if __name__ == '__main__':
    unittest.main(verbosity=2)
