"""RC5 document and preservation checks. Static checks only; not agent behavior evaluation."""
import importlib.util, os, sys, unittest
from pathlib import Path
ROOT=Path(os.environ.get('SKILL_ROOT', Path(__file__).resolve().parents[2])).resolve()

class RC5Contract(unittest.TestCase):
    def text(self, rel): return (ROOT/rel).read_text(encoding='utf-8')
    def test_01_version(self):
        self.assertEqual(self.text('VERSION').strip(),'1.1.0-rc.5')
        self.assertEqual(self.text('VERSION'),self.text('clean-code-engineering/VERSION'))
    def test_02_change_impact_reference_exists(self):
        self.assertTrue((ROOT/'clean-code-engineering/references/13-change-impact.md').is_file())
    def test_03_scope_ledger_exists(self):
        self.assertTrue((ROOT/'clean-code-engineering/assets/impact-ledger.md').is_file())
    def test_04_main_routes_large_repo_risks(self):
        text=self.text('clean-code-engineering/SKILL.md')
        for needle in ['变更影响面','go.work','构建标签','生成代码','迁移','热点']:
            with self.subTest(needle=needle): self.assertIn(needle,text)
    def test_05_reference_covers_required_topics(self):
        text=self.text('clean-code-engineering/references/13-change-impact.md')
        for needle in ['编辑集合','检查集合','保护集合','验证集合','多模块','构建标签','生成代码','契约与迁移','性能敏感','分阶段兼容','停止条件']:
            with self.subTest(needle=needle): self.assertIn(needle,text)
    def test_06_readme_navigation(self):
        text=self.text('README.md')
        self.assertIn('13-change-impact.md',text); self.assertIn('impact-ledger.md',text)
    def test_07_go_route(self):
        text=self.text('clean-code-engineering/references/08-go.md')
        self.assertIn('13-change-impact.md',text)
        self.assertIn('go.work',text)
    def test_08_large_repo_fixture_present(self):
        for n in ['large-repo-baseline','large-repo-bad','large-repo-good']:
            self.assertTrue((ROOT/'evals/rc5/fixtures'/n/'go.work').is_file())

def previous_suite():
    spec=importlib.util.spec_from_file_location('rc4_docs',ROOT/'evals/rc4/test_contract.py')
    old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
    out=unittest.TestSuite()
    def add(items):
        for t in items:
            if isinstance(t,unittest.TestSuite): add(t)
            elif t._testMethodName!='test_01_rc4_version': out.addTest(t)
    add(old.suite())
    return out

def suite():
    s=previous_suite(); s.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(RC5Contract)); return s
if __name__=='__main__':
    r=unittest.TextTestRunner(verbosity=2).run(suite()); raise SystemExit(0 if r.wasSuccessful() else 1)
