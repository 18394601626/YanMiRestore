package account
import("encoding/json";"strings";"testing")
func TestAccountWireCompatibility(t *testing.T){
 b,err:=json.Marshal(Account{Name:"Ada",DisplayName:"A"});if err!=nil{t.Fatal(err)};s:=string(b)
 if !strings.Contains(s,`"name":"Ada"`)||!strings.Contains(s,`"display_name":"A"`){t.Fatalf("wire=%s",s)}
}
func TestPreferredNameFallback(t *testing.T){ if (Account{Name:"Ada"}).PreferredName()!="Ada"{t.Fatal("fallback")}; if (Account{Name:"Ada",DisplayName:"A"}).PreferredName()!="A"{t.Fatal("preferred")} }
