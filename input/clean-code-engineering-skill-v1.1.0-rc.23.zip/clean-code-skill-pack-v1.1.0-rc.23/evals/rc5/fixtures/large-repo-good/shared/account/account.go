package account

type Account struct {
    Name string `json:"name"`
    DisplayName string `json:"display_name,omitempty"`
}
func (a Account) PreferredName() string { if a.DisplayName!="" { return a.DisplayName }; return a.Name }
// LegacyCode is part of an older integration still compiled in enterprise builds.
func LegacyCode(a Account) string { return "acct:"+a.Name }
