package profile
import("context";"reflect";"testing";"example.com/shared/account")
type fakeLocale struct{calls int}
func(f *fakeLocale)Locale(context.Context)(string,error){f.calls++;return "en",nil}
func TestRenderPrefersDisplayName(t *testing.T){ if got:=Render(account.Account{Name:"Ada",DisplayName:"A"});got!="A"{t.Fatal(got)} }
func TestRenderFallsBackName(t *testing.T){ if got:=Render(account.Account{Name:"Ada"});got!="Ada"{t.Fatal(got)} }
func TestRenderBatchOutput(t *testing.T){p:=&fakeLocale{};got,err:=RenderBatch(context.Background(),p,[]account.Account{{Name:"A"},{Name:"B",DisplayName:"Bee"}});if err!=nil{t.Fatal(err)};want:=[]string{"en:A","en:Bee"};if !reflect.DeepEqual(got,want){t.Fatalf("%v",got)}}
