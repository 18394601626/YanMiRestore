package profile
import (
    "context"
    "example.com/shared/account"
)
type LocaleProvider interface { Locale(context.Context) (string,error) }
func Render(a account.Account) string { return a.PreferredName() }
func RenderBatch(ctx context.Context,p LocaleProvider,accounts []account.Account)([]string,error){
    out:=make([]string,0,len(accounts))
    for _,a:=range accounts{
        locale,err:=p.Locale(ctx); if err!=nil{return nil,err}
        out=append(out,locale+":"+Render(a))
    }
    return out,nil
}
