//go:build impact

package profile

import (
    "context"
    "testing"
    "example.com/shared/account"
)

func TestBatchLoadsLocaleOnce(t *testing.T) {
    p := &fakeLocale{}
    _, err := RenderBatch(context.Background(), p, []account.Account{{}, {}, {}})
    if err != nil { t.Fatal(err) }
    if p.calls != 1 { t.Fatalf("locale calls=%d want=1", p.calls) }
}
