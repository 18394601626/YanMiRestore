package legacy

func Weird(x int) int { if x < 0 { return 0 }; return x }
