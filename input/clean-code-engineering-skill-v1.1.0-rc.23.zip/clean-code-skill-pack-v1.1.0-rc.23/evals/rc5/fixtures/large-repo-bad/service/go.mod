module example.com/service

go 1.20

require example.com/shared v0.0.0
replace example.com/shared => ../shared
