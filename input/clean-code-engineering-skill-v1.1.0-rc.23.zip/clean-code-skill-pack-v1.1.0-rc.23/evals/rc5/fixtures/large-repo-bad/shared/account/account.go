package account

type Account struct {
    DisplayName string `json:"display_name"`
}
func (a Account) PreferredName() string { return a.DisplayName }
