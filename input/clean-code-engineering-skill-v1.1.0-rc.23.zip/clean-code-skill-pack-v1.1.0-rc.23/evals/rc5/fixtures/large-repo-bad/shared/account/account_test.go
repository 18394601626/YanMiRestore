package account

import (
    "encoding/json"
    "strings"
    "testing"
)

func TestAccountWireName(t *testing.T) {
    b, err := json.Marshal(Account{Name: "Ada"})
    if err != nil { t.Fatal(err) }
    if !strings.Contains(string(b), `"name":"Ada"`) { t.Fatalf("wire=%s", b) }
}
