//go:build enterprise

package consumer

import "example.com/shared/account"

func EnterpriseOnly() string {
    return account.LegacyCode(account.Account{Name:"Ops"})
}
