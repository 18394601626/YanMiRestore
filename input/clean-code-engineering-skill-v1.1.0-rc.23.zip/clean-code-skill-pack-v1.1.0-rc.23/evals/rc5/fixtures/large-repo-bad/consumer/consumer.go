package consumer

import "example.com/shared/account"

func Existing() string {
    a:=account.Account{Name:"Ada"}
    return account.LegacyCode(a)
}
