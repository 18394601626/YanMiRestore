//go:build enterprise

package consumer
import "testing"
func TestEnterpriseOnly(t *testing.T){ if EnterpriseOnly()!="acct:Ops" { t.Fatal(EnterpriseOnly()) } }
