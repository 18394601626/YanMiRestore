package consumer
import "testing"
func TestExisting(t *testing.T){ if Existing()!="acct:Ada" { t.Fatal(Existing()) } }
