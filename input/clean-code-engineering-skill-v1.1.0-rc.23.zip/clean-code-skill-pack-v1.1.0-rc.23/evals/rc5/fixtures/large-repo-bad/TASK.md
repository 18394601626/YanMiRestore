# Change request
Add optional `display_name` support to account profiles.

Required behavior:
- `name` remains source/API compatible for this release.
- `display_name` is optional; profile rendering prefers it when non-empty and otherwise uses `name`.
- existing consumers, including enterprise build-tag consumers, keep compiling.
- API schema and generated client stay synchronized; generated files are regenerated from source, not hand-edited.
- database migration is additive and reversible at the application-compatibility level: do not rename/drop `name` in this release.
- batch rendering must not increase locale-provider calls per batch.
- do not clean unrelated legacy code.
