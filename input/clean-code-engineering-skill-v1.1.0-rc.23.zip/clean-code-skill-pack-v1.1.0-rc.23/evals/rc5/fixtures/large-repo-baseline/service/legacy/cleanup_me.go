package legacy

// intentionally awkward but unrelated to the requested change.
func Weird(x int) int { if x>0 { return x }; return 0 }
