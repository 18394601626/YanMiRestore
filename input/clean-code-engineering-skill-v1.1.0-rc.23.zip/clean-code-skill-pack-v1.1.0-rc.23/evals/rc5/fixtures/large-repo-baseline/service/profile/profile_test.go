package profile

import (
    "context"
    "reflect"
    "testing"
    "example.com/shared/account"
)

type fakeLocale struct{ calls int }
func (f *fakeLocale) Locale(context.Context) (string,error) { f.calls++; return "en",nil }

func TestRenderUsesName(t *testing.T) {
    if got := Render(account.Account{Name:"Ada"}); got != "Ada" { t.Fatalf("got %q",got) }
}

func TestRenderBatchOutput(t *testing.T) {
    p:=&fakeLocale{}
    got,err:=RenderBatch(context.Background(),p,[]account.Account{{Name:"A"},{Name:"B"}})
    if err!=nil { t.Fatal(err) }
    want:=[]string{"en:A","en:B"}
    if !reflect.DeepEqual(got,want) { t.Fatalf("got %v",got) }
}
