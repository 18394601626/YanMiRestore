package account

type Account struct {
    Name string `json:"name"`
}

func (a Account) PreferredName() string { return a.Name }

// LegacyCode is part of an older integration still compiled in enterprise builds.
func LegacyCode(a Account) string { return "acct:" + a.Name }
