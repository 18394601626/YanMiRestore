# rc.5 大型项目变更影响面评估

这是受控工程夹具，不是模型 A/B。`large-repo-bad` 人工模拟“局部 module 测试通过，但跨模块/标签/生成/迁移/性能检查失败”；`large-repo-good` 是兼容实现。两者用于验证验收矩阵和说明为何大型仓库不能停在局部绿色。

运行：

```text
python evals/rc5/test_contract.py
python evals/rc5/run_large_repo.py --output ../rc5-large-repo-run
```

输出目录必须不存在。脚本不联网下载依赖，使用当前本地 Go 工具链。坏候选的失败属于预期控制，不应写成“rc.4 模型生成失败”。
