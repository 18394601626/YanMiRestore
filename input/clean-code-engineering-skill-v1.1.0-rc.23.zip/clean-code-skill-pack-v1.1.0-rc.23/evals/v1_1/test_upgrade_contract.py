"""Static document contracts only; NOT an evaluation of coding-agent behavior.

Python 3.9+. Set SKILL_PACKAGE_ROOT to check a different extracted package.
No network access, source rewriting, model calls, or project execution.
"""
from pathlib import Path
import hashlib
import json
import os
import unittest

PACKAGE = Path(__file__).resolve().parents[2]
ROOT = Path(os.environ.get('SKILL_PACKAGE_ROOT', str(PACKAGE))).resolve()
FROZEN = json.loads((PACKAGE / 'provenance/original-manifest.json').read_text(encoding='utf-8'))
SKILL = 'clean-code-engineering/'


class UpgradeContractChecks(unittest.TestCase):
    def text(self, relative):
        path = ROOT / relative
        self.assertTrue(path.is_file(), f'missing required document: {relative}')
        return path.read_text(encoding='utf-8')

    def require(self, relative, *terms):
        text = self.text(relative)
        for term in terms:
            self.assertIn(term, text, f'{relative}: missing declared contract {term!r}')
        return text

    def test_01_required_upgrade_files(self):
        for name in ['VERSION', 'README.md', 'CHANGELOG.md',
                     'clean-code-engineering/VERSION',
                     'clean-code-engineering/references/07-task-depth.md',
                     'clean-code-engineering/references/08-go.md',
                     'clean-code-engineering/references/09-abstraction-decisions.md',
                     'evals/v1_1/README.md', 'evals/v1_1/scenarios.json',
                     'provenance/original-manifest.json', 'provenance/sources.json']:
            with self.subTest(path=name): self.text(name)

    def test_02_main_routes_execution_depth(self):
        self.require(SKILL+'SKILL.md', 'light', 'standard', 'deep',
                     'references/07-task-depth.md', '认证', '并发')

    def test_03_depth_does_not_grant_write_permission(self):
        self.require(SKILL+'references/07-task-depth.md',
                     '执行深度不授予修改权限', 'review', 'format', '已有明确授权')

    def test_04_small_tasks_do_not_skip_verification(self):
        self.require(SKILL+'references/07-task-depth.md',
                     '轻量不等于免测试', '全量回归未运行', '不新增计划文件')

    def test_05_go_rules_have_an_explicit_trigger(self):
        self.require(SKILL+'SKILL.md', '.go', 'go.mod', 'references/08-go.md')

    def test_06_go_errors_and_wire_compatibility(self):
        self.require(SKILL+'references/08-go.md',
                     'errors.Is', 'errors.As', '%w', 'panic', 'typed nil', 'null', '[]')

    def test_07_go_context_and_lifetime_rules(self):
        self.require(SKILL+'references/08-go.md',
                     'context.Context', 'cancel', 'goroutine', 'context.Background()', '所有者')

    def test_08_go_resource_and_transaction_rules(self):
        self.require(SKILL+'references/08-go.md',
                     'Close', 'rows.Err()', 'Commit', 'Rollback', 'sql.Tx', 'sql.DB')

    def test_09_go_version_is_not_forced(self):
        self.require(SKILL+'references/08-go.md',
                     'go.mod', 'go.work', 'toolchain', '不升级', 'Go 官方资料')

    def test_10_abstraction_requires_current_evidence(self):
        self.require(SKILL+'references/09-abstraction-decisions.md',
                     '当前问题', '最小方案', '引入成本', '验证方式', '不拆分')

    def test_11_abstraction_counterexamples_present(self):
        self.require(SKILL+'references/09-abstraction-decisions.md',
                     'switch', 'DTO', '接口', '事务', '锁', '行数')

    def assert_original_bytes(self, list_name):
        self.assertTrue(FROZEN[list_name])
        for rel in FROZEN[list_name]:
            with self.subTest(path=rel):
                path = ROOT / rel
                self.assertTrue(path.is_file(), rel)
                self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(),
                                 FROZEN['original_files'][rel], rel)

    def test_12_six_book_references_unchanged(self):
        self.assertEqual(len(FROZEN['protected_book_files']), 6)
        self.assert_original_bytes('protected_book_files')

    def test_13_original_evaluations_unchanged(self):
        self.assert_original_bytes('protected_eval_files')

    def test_14_original_templates_unchanged(self):
        self.assert_original_bytes('protected_assets')

    def test_15_new_scenarios_separate_and_not_run(self):
        items = json.loads(self.text('evals/v1_1/scenarios.json'))
        self.assertEqual(len(items), 18)
        self.assertEqual(len({x['id'] for x in items}), 18)
        self.assertEqual({x['category'] for x in items}, {'depth', 'go', 'abstraction'})
        for item in items:
            with self.subTest(id=item['id']):
                self.assertEqual(item['status'], 'not_run')
                self.assertTrue(item['prompt'])
                self.assertTrue(item['expected'])
                self.assertTrue(item['must_not'])
                self.assertEqual(item['observed'], None)

    def test_16_external_sources_are_explicit(self):
        self.require(SKILL+'references/08-go.md', '执行适配', '不是原书', '[GO-')
        sources = json.loads(self.text('provenance/sources.json'))
        self.assertTrue(sources['sources'])
        for source in sources['sources']:
            self.assertTrue(source['url'].startswith('https://'))
            self.assertTrue(source['checked_on'])
            self.assertTrue(source['scope'])

    def test_17_version_and_evidence_limit(self):
        self.assertEqual(self.text('VERSION').strip(), '1.1.0-rc.1')
        self.assertEqual(self.text(SKILL+'VERSION'), self.text('VERSION'))
        self.require('evals/v1_1/README.md', '不是代理行为测试', '原 A/B', 'NOT_RUN')

    def test_18_frozen_experiment_not_reassigned(self):
        self.require('CHANGELOG.md', 'A/B', '未修改', '新实验', '1.0.0')
        self.assertIn('go-login-skill-ab-test-pack.zip', FROZEN['frozen_archives'])
        self.assertIn('go-login-demo.zip', FROZEN['frozen_archives'])

    def test_19_existing_principles_and_bounds_remain(self):
        text = self.text(SKILL+'SKILL.md')
        for term in ['write', 'refactor', 'review', 'format', 'F.I.R.S.T.',
                     '不伪造', '序列化字段', 'references/05-heuristics.md', '必要顺序']:
            self.assertIn(term, text)


if __name__ == '__main__':
    unittest.main(verbosity=2)
