"""Checks for this bounded 10-language fixture harness, not arbitrary test logs."""
import importlib.util
from pathlib import Path
import unittest
HERE=Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location("batch_runner",HERE/"run_batch.py")
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class RunnerTests(unittest.TestCase):
 def test_complete(self):
  self.assertEqual(m.inspect("CASE X1 PASS\nCASE X2 PASS\n",0,["X1","X2"])['status'],'PASS')
 def test_zero_cases(self):
  self.assertEqual(m.inspect("",0,["X1"])['status'],'INVALID_EVIDENCE')
 def test_duplicate(self):
  self.assertEqual(m.inspect("CASE X1 PASS\nCASE X1 PASS\n",0,["X1"])['status'],'INVALID_EVIDENCE')
 def test_exit_mismatch(self):
  self.assertEqual(m.inspect("CASE X1 FAIL\n",0,["X1"])['status'],'INVALID_EVIDENCE')
 def test_unexpected_case(self):
  self.assertEqual(m.inspect("CASE Y PASS\n",0,["X1"])['status'],'INVALID_EVIDENCE')
 def test_known_failure(self):
  r=m.inspect("CASE X1 FAIL\nCASE X2 PASS\n",1,["X1","X2"])
  self.assertEqual(r['status'],'TEST_FAIL');self.assertEqual(r['failed'],['X1'])
 def test_compile_failure_not_tests(self):
  self.assertEqual(m.inspect("cannot find solution",1,["X1"])['executed'],0)
 def test_no_signal_as_expected_failure(self):
  self.assertEqual(m.inspect("CASE X1 FAIL\n",-9,["X1"])['status'],'INVALID_EVIDENCE')
 def test_request_batch_is_explicit(self):
  self.assertEqual(len(m.select_languages('batch')),10)
 def test_unknown_not_silent(self):
  with self.assertRaises(ValueError):m.select_languages('swift,unknown')
 def test_unique_request(self):
  with self.assertRaises(ValueError):m.select_languages('python,python')
 def test_request_subset(self):
  self.assertEqual(m.select_languages('python,typescript'),['python','typescript'])
if __name__=='__main__':unittest.main(verbosity=2)
