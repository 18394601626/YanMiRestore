"""Reuse prior general checks; exact historical version/count checks stay archived."""
from pathlib import Path
import importlib.util
import unittest
R=Path(__file__).resolve().parents[2]
def load(name,path):
 s=importlib.util.spec_from_file_location(name,R/path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
a=load('rc17_legacy_adapters','evals/rc14/test_adapters.py')
b=load('rc17_legacy_docs','evals/rc15/test_current_release.py')
if __name__=='__main__':
 suite=unittest.TestSuite()
 for name in unittest.defaultTestLoader.getTestCaseNames(a.AdapterContracts):
  if name not in {'test_release_version','test_prior_runtime_and_test_sources_preserved','test_support_level_not_all_languages_verified'}:
   suite.addTest(a.AdapterContracts(name))
 for name in ('test_stop_input_contract_documented','test_frozen_regressions'):suite.addTest(b.CurrentReleaseTests(name))
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 raise SystemExit(0 if result.wasSuccessful() else 1)
