"""Execute the ten rc17 language fixtures only; never means every language.

Copies sources to a fresh directory, reuses the existing bounded process helper,
and preserves real compilation/run logs. Does not download, contact production,
invoke an AI, authenticate malicious test output, or implement a code sandbox.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('rc17_process', ROOT/'evals/rc8/run_integration.py')
support = importlib.util.module_from_spec(spec)
spec.loader.exec_module(support)
PREFIX = {'python':'PY','javascript':'JS','typescript':'TS','php':'PH','ruby':'RB',
          'kotlin':'KT','swift':'SW','perl':'PL','bash':'SH','fortran':'FT'}
EXPECTED_BAD = {'python':[2,3,4,5,6],'javascript':[1,2,3,4,5,6],
 'typescript':[2,3,4,5,6],'php':[1,2,3,4,5,6],'ruby':[1,2,3,4,5,6],
 'kotlin':[1,2,3,4,5,6],'swift':[1,2,3,4,5,6], 'perl':[1,2,3,4,5],
 'bash':[1,2,3,4,5], 'fortran':[1,2,4,6]}


def select_languages(value):
    names = list(PREFIX) if value == 'batch' else value.split(',')
    if not names or len(names) != len(set(names)) or any(n not in PREFIX for n in names):
        raise ValueError('use batch or a nonempty, unique comma-separated list: '+','.join(PREFIX))
    return names


def inspect(text, exit_code, expected):
    records = re.findall(r'^CASE ([A-Z]+[0-9]+) (PASS|FAIL)$', text, re.M)
    names = [a for a, _ in records]
    passed = [a for a,b in records if b=='PASS']
    failed = [a for a,b in records if b=='FAIL']
    valid = (set(names)==set(expected) and len(names)==len(expected)
             and len(set(names))==len(names) and bool(names)
             and exit_code == (1 if failed else 0))
    return {'status': ('TEST_FAIL' if failed else 'PASS') if valid else 'INVALID_EVIDENCE',
            'executed': len(records), 'passed': passed, 'failed': failed,
            'expected_targets': expected}


def commands(language):
    """All commands apply only to the supplied fixture, not users' projects."""
    if language=='python': return [], [sys.executable,'-S','cases.py']
    if language=='javascript': return [], ['node','--unhandled-rejections=strict','cases.mjs']
    if language=='typescript':
        return [['tsc','--strict','--noEmitOnError','--target','ES2020','--module','commonjs',
                 '--outDir','dist','solution.ts','cases.ts']], ['node','dist/cases.js']
    if language=='php': return [['php','-l','solution.php'],['php','-l','cases.php']], ['php','cases.php']
    if language=='ruby': return [['ruby','-c','solution.rb'],['ruby','-c','cases.rb']], ['ruby','cases.rb']
    if language=='kotlin':
        return [['kotlinc','Solution.kt','Cases.kt','-jvm-target','1.8','-include-runtime','-d','cases.jar']], ['java','-jar','cases.jar']
    if language=='swift':
        return [['swiftc','-swift-version','5','Solution.swift','Cases.swift','-o','cases']], ['./cases']
    if language=='perl': return [['perl','-c','solution.pl'],['perl','-c','cases.pl']], ['perl','cases.pl']
    if language=='bash': return [['bash','-n','solution.sh'],['bash','-n','cases.sh']], ['bash','cases.sh']
    if language=='fortran':
        return [['gfortran','-std=f2008','-Wall','-Wextra','-fcheck=all','-fbacktrace',
                 'solution.f90','cases.f90','-o','cases']], ['./cases']
    raise ValueError(language)


def run_one(language, variant, output):
    directory = output/(language+'-'+variant)
    directory.mkdir()
    source = HERE/'fixtures'/language
    for p in source.iterdir():
        if p.is_file(): shutil.copy2(p,directory/p.name)
    for p in (source/variant).iterdir():
        if p.is_file(): shutil.copy2(p,directory/p.name)
    builds, command = commands(language)
    row={'language':language,'variant':variant,'status':'NOT_RUN','commands':[], 'executed':0}
    for i,cmd in enumerate(builds+[command]):
        phase='compile' if i<len(builds) else 'test'
        # Check PATH only for tools, not the just-built local executable.
        if not cmd[0].startswith('./') and not Path(cmd[0]).is_absolute() and shutil.which(cmd[0]) is None:
            row.update(status='BLOCKED',reason='missing tool: '+cmd[0]);return row
        log=directory/(f'{i:02d}-{phase}.log')
        record=support.execute(cmd,directory,log,90)
        record['log']=str(log.relative_to(output));row['commands'].append(record)
        if record['status']!='FINISHED':row['status']=record['status'];return row
        if phase=='compile' and record['exit_code']!=0:
            row['status']='COMPILE_FAIL';return row
        if phase=='test':
            expected=[PREFIX[language]+f'{n:02d}' for n in range(1,7)]
            row.update(inspect(log.read_text(errors='replace'),record['exit_code'],expected))
    bad=[PREFIX[language]+f'{n:02d}' for n in EXPECTED_BAD[language]]
    row['expected_observation']=(row['status']=='PASS' if variant=='fixed' else
                                 row['status']=='TEST_FAIL' and row['failed']==bad)
    return row


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--languages', default='batch', help='batch = exactly the ten new rc17 languages, or comma-separated IDs')
    parser.add_argument('--variant',choices=('both','baseline','fixed'),default='both')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    try: selected=select_languages(args.languages)
    except ValueError as e:parser.error(str(e))
    output=args.output.resolve()
    if output.exists() or output==ROOT or ROOT in output.parents:
        parser.error('output must be new and outside package root')
    output.mkdir(parents=True)
    variants=['baseline','fixed'] if args.variant=='both' else [args.variant]
    summary={'kind':'controlled_language_contracts_not_independent_AI_AB', 'requested_languages':selected,
             'requested_variants':variants,'utc':datetime.now(timezone.utc).isoformat(),
             'scope':'ten rc17 languages only; no framework/platform claims', 'runs':[], 'status':'RUNNING'}
    def save():
        target=output/'summary.json'
        temp=output/'summary.json.tmp';temp.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');temp.replace(target)
    save();code=1
    try:
        for language in selected:
            for variant in variants:
                row=run_one(language,variant,output);summary['runs'].append(row);save()
                if row['status']=='INTERRUPTED':raise KeyboardInterrupt
        bad=[r for r in summary['runs'] if r['status']!='BLOCKED' and not r.get('expected_observation',False)]
        if bad: summary['status']='MISMATCH';code=1
        elif any(r['status']=='BLOCKED' for r in summary['runs']):summary['status']='PARTIAL_BLOCKED';code=2
        else:summary['status']='EXPECTED_OBSERVATIONS_REPRODUCED';code=0
    except KeyboardInterrupt:summary['status']='INTERRUPTED';code=130
    except Exception as e:summary.update(status='ERROR',reason=type(e).__name__+': '+str(e));code=1
    finally:
        summary['exit_code']=code;summary['finished_utc']=datetime.now(timezone.utc).isoformat();save()
    for row in summary['runs']:print(row['language'],row['variant'],row['status'],row.get('failed',[]),flush=True)
    print(summary['status']);return code
if __name__=='__main__':raise SystemExit(main())
