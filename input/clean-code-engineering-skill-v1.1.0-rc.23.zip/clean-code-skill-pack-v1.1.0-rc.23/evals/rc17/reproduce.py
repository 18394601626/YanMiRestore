"""Run current/legacy tool checks plus an explicitly selected rc17 language batch.

batch means only the ten added languages. No package downloads, old business
matrices, model generation, mobile frameworks or production service connections.
"""
from datetime import datetime, timezone
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('rc17_replay_helpers',ROOT/'evals/rc15/reproduce.py')
old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
s=importlib.util.spec_from_file_location('rc17_batch',ROOT/'evals/rc17/run_batch.py')
batch=importlib.util.module_from_spec(s);s.loader.exec_module(batch)
STAGES=[('native-parser','evals/rc14/test_runner.py',10),
('old-stop','evals/rc6/test_change_control.py',7),('strict-stop','evals/rc15/test_stop_contract.py',38),
('old-cli','evals/rc15/test_reproduce_cli.py',4),('native-evidence','evals/rc16/test_native_evidence.py',26),
('rc16-cli','evals/rc16/test_reproduce_cli.py',4),('applicable-legacy','evals/rc17/test_legacy_applicable.py',9),
('support','evals/rc17/test_support.py',12),('runner','evals/rc17/test_runner.py',12)]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--languages',default='batch',help='none, batch (ten new languages), or explicit IDs')
 a=p.parse_args();out=a.output.resolve()
 if out.exists() or out==ROOT or ROOT in out.parents:p.error('output must be new and outside package')
 try:selected=[] if a.languages=='none' else batch.select_languages(a.languages)
 except ValueError as e:p.error(str(e))
 out.mkdir(parents=True);os.environ.update(PYTHONDONTWRITEBYTECODE='1', PACK_ROOT=str(ROOT))
 result={'version':(ROOT/'VERSION').read_text().strip(),'utc':datetime.now(timezone.utc).isoformat(),
 'kind':'tool_regression_and_controlled_new_language_batch_not_AI_AB','stages':[],
 'requested_languages':selected,'languages':{'status':'NOT_RUN' if selected else 'NOT_REQUESTED'},
 'not_run':'Go/Java/C/C++/Rust business matrices, remaining planned languages, frameworks, IDE and agent A/B',
 'status':'RUNNING'}
 def save():old.save(out,result)
 save();code=1
 try:
  row=old.launch(out,'book',[sys.executable,'-S','evals/rc13/reproduce.py','--output',str(out/'book-details')],120)
  if row['status']=='FINISHED':
   d=json.loads((out/'book-details/summary.json').read_text());row['observed_methods']=d['observed_test_methods']
   row['status']='PASS' if row['exit_code']==0 and d['all_pass'] is True and row['observed_methods']==90 else 'FAIL'
  result['stages'].append(row);save()
  for name,path,count in STAGES:
   row=old.launch(out,name,[sys.executable,'-S',path],90);old.check_unittest(row,out,count)
   result['stages'].append(row);save()
   if row['status']=='INTERRUPTED':raise KeyboardInterrupt
  row=old.replay_original(out);result['stages'].append(row);save()
  if selected:
   row=old.launch(out,'language-batch',[sys.executable,'-S','evals/rc17/run_batch.py','--languages',','.join(selected),'--output',str(out/'language-details')],300)
   if row['status']=='FINISHED' and (out/'language-details/summary.json').is_file():
    d=json.loads((out/'language-details/summary.json').read_text())
    result['languages']=d if d.get('exit_code')==row['exit_code'] else {'status':'INVALID_EVIDENCE'}
   else:result['languages']={'status':row['status']}
   result['language_process']=row;save()
  if any(r['status']!='PASS' for r in result['stages']):result['status']='FAIL';code=1
  elif result['languages']['status']=='PARTIAL_BLOCKED':result['status']='PARTIAL_BLOCKED';code=2
  elif result['languages']['status'] not in ('NOT_REQUESTED','EXPECTED_OBSERVATIONS_REPRODUCED'):result['status']='FAIL';code=1
  else:result['status']='REQUESTED_SCOPE_PASSED';code=0
 except KeyboardInterrupt:result['status']='INTERRUPTED';code=130
 except Exception as e:result.update(status='ERROR',reason=type(e).__name__+': '+str(e));code=1
 finally:
  result['tool_methods']=sum(r.get('observed_methods',0) for r in result['stages'])
  result['exit_code']=code;save()
 print(result['status'],'tool_methods='+str(result['tool_methods']))
 for row in result['stages']:print(row['id'],row['status'],row.get('observed_methods'))
 return code
if __name__=='__main__':raise SystemExit(main())
