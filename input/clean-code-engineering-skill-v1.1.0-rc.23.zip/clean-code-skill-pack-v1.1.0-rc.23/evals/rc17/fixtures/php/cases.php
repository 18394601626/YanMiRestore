<?php
declare(strict_types=1);
require __DIR__ . '/solution.php';
function check(bool $v): void { if (!$v) throw new RuntimeException('contract not met'); }
$tests = [
 'PH01' => function(){check(patch_name('old',[]) === 'old');check(patch_name('old',['name'=>null]) === null);},
 'PH02' => function(){check(!has_id('0',[0]));check(has_id(0,[0]));},
 'PH03' => function(){check(normalize_values([1,2,3]) === [2,4,6]);},
 'PH04' => function(){check(json_encode(positive_values([-1,2,3]),JSON_THROW_ON_ERROR) === '[2,3]');},
 'PH05' => function(){ $old=[9]; try {replace_quantities($old,[1,'2']);} catch (InvalidArgumentException $e){check($old===[9]);return;}throw new RuntimeException('string quantity accepted');},
 'PH06' => function(){ $h=tmpfile(); if($h===false)throw new RuntimeException('tmpfile unavailable'); $e=new RuntimeException('work'); try{consume_owned($h, function()use($e){throw $e;});}catch(RuntimeException $got){check($got===$e);check(!is_resource($h));return;}throw new RuntimeException('error swallowed');}
];
$failed=0;foreach($tests as $id=>$f){try{$f();echo "CASE $id PASS\n";}catch(Throwable $e){$failed++;echo "CASE $id FAIL\n";fwrite(STDERR,$e->getMessage()."\n");}}exit($failed?1:0);
