<?php
declare(strict_types=1);
function patch_name(?string $old, array $patch): ?string {
    return array_key_exists('name', $patch) ? $patch['name'] : $old;
}
function has_id(mixed $id, array $ids): bool {
    return in_array($id, $ids, true);
}
function normalize_values(array $values): array {
    // Avoid leaving a reference to the last element in the local loop variable.
    return array_map(fn(int $value): int => $value * 2, $values);
}
function positive_values(array $values): array {
    return array_values(array_filter($values, fn(int $v): bool => $v > 0));
}
function replace_quantities(array &$target, array $values): void {
    $prepared = [];
    foreach ($values as $value) {
        if (!is_int($value) || $value < 0) throw new InvalidArgumentException('invalid quantity');
        // Copy scalar values, not the input array's possible reference cells.
        $prepared[] = $value;
    }
    $target = $prepared;
}
function consume_owned($handle, callable $work): mixed {
    try { return $work($handle); }
    finally { fclose($handle); }
}
