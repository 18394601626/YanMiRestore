<?php
declare(strict_types=1);
// Controlled baseline with known faults.
function patch_name(?string $old, array $patch): ?string { return isset($patch['name']) ? $patch['name'] : $old; }
function has_id(mixed $id, array $ids): bool { return in_array($id,$ids); }
function normalize_values(array $values): array {
    foreach($values as &$v){$v *= 2;}
    foreach($values as $v){}
    return $values;
}
function positive_values(array $values): array { return array_filter($values,fn($v)=>$v>0); }
function replace_quantities(array &$target, array $values): void {
    $target=[];foreach($values as $value){if(!is_numeric($value)||$value<0)throw new InvalidArgumentException('invalid');$target[]=(int)$value;}
}
function consume_owned($handle, callable $work): mixed {$result=$work($handle);fclose($handle);return $result;}
