use strict;
use warnings;

sub patch_name {
    my ($old, $patch) = @_;
    return exists($patch->{name}) ? $patch->{name} : $old;
}
sub default_name {
    my ($value) = @_;
    return defined($value) ? $value : 'default';
}
sub snapshot {
    my ($source) = @_;
    return { %$source, tags => [ @{$source->{tags}} ] };
}
sub parse_quantity {
    my ($text) = @_;
    die "invalid quantity\n" unless defined($text) && $text =~ /\A[0-9]{1,6}\z/;
    return 0 + $text;
}
sub upper_values {
    my ($values) = @_;
    return [ map { uc($_) } @$values ];
}
1;
