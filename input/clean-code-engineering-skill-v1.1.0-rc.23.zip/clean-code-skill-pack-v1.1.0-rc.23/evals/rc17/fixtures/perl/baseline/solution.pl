use strict;
use warnings;
sub patch_name {my($old,$patch)=@_;return $patch->{name} || $old;}
sub default_name {return $_[0] || 'default';}
sub snapshot {my($source)=@_;return {%$source};}
sub parse_quantity {return 0+$_[0];}
sub upper_values {my($values)=@_;$_=uc($_) for @$values;return $values;}
1;
