use strict;
use warnings;
use FindBin;
require "$FindBin::Bin/solution.pl";
sub check { die "contract not met\n" unless $_[0]; }
my @tests=(
 sub {check(patch_name('old',{}) eq 'old');check(!defined patch_name('old',{name=>undef}));},
 sub {check(default_name('0') eq '0');check(default_name(undef) eq 'default');},
 sub {my $a={tags=>['a']};my $b=snapshot($a);push @{$b->{tags}},'b';check(@{$a->{tags}}==1);},
 sub {check(parse_quantity('12')==12);my $ok=eval{parse_quantity('12x');1};check(!$ok);},
 sub {my @a=('a','b');my $b=upper_values(\@a);check($a[0] eq 'a' && $b->[0] eq 'A');},
 sub {my $a=upper_values([]);check(ref($a) eq 'ARRAY' && @$a==0);}
);
my $failed=0;for my $i (0..$#tests){my $id=sprintf('PL%02d',$i+1);my $ok=eval{$tests[$i]->();1};if($ok){print "CASE $id PASS\n";}else{$failed++;print "CASE $id FAIL\n";warn $@;}}
exit($failed?1:0);
