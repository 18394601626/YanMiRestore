import java.io.Closeable

data class Profile(val tags: MutableList<String>)

fun snapshot(source: Profile): Profile = source.copy(tags = source.tags.toMutableList())

fun checkedAdd(a: Int, b: Int): Int = Math.addExact(a, b)

fun parseQuantity(text: String): Int = text.toIntOrNull()?.takeIf { it >= 0 }
    ?: throw IllegalArgumentException("invalid quantity")

fun defaultName(value: String?): String = value ?: "default"

fun <T> consumeOwned(resource: Closeable, work: () -> T): T = resource.use { work() }

fun replaceQuantities(target: MutableList<Int>, texts: List<String>) {
    val prepared = texts.map(::parseQuantity)
    target.clear()
    target.addAll(prepared)
}
