import java.io.Closeable
data class Profile(val tags:MutableList<String>)
fun snapshot(source:Profile):Profile=source.copy()
fun checkedAdd(a:Int,b:Int):Int=a+b
fun parseQuantity(text:String):Int=text.takeWhile{it.isDigit()}.toInt()
fun defaultName(value:String?):String=if(value.isNullOrEmpty())"default" else value
fun <T> consumeOwned(resource:Closeable,work:()->T):T {val result=work();resource.close();return result}
fun replaceQuantities(target:MutableList<Int>,texts:List<String>){target.clear();for(text in texts)target.add(parseQuantity(text))}
