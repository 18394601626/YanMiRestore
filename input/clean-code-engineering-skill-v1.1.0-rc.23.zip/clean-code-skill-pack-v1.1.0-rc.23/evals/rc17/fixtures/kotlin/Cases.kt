import java.io.Closeable
class Probe : Closeable { var closed=false; override fun close(){closed=true} }
fun expect(value:Boolean){check(value){"contract not met"}}
fun main(){
 val cases=listOf<()->Unit>(
  {val a=Profile(mutableListOf("a"));val b=snapshot(a);b.tags.add("b");expect(a.tags==listOf("a"))},
  {try{checkedAdd(Int.MAX_VALUE,1);error("overflow accepted")}catch(e:ArithmeticException){}},
  {expect(parseQuantity("12")==12);try{parseQuantity("12x");error("invalid accepted")}catch(e:IllegalArgumentException){}},
  {expect(defaultName("")=="");expect(defaultName(null)=="default")},
  {val p=Probe();try{consumeOwned(p){throw IllegalStateException("work")}}catch(e:IllegalStateException){expect(e.message=="work")};expect(p.closed)},
  {val old=mutableListOf(9);try{replaceQuantities(old,listOf("1","bad"));error("invalid accepted")}catch(e:IllegalArgumentException){};expect(old==listOf(9))}
 )
 var failed=0
 for((i,test) in cases.withIndex()){val id="KT%02d".format(i+1);try{test();println("CASE $id PASS")}catch(e:Throwable){failed++;println("CASE $id FAIL");System.err.println(e.toString())}}
 if(failed!=0)throw IllegalStateException("$failed tests failed")
}
