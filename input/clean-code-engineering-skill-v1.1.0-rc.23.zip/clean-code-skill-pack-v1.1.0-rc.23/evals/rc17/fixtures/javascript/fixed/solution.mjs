// These examples preserve a simple, explicitly owned data model.
export const chooseLimit = value => value ?? 10;
export const snapshot = source => ({...source, tags: [...source.tags]});

export async function runBatch(values, work) {
  const result = [];
  for (const value of values) result.push(await work(value));
  return result;
}

export function replaceQuantities(target, values) {
  const prepared = [...values];
  if (prepared.some(n => typeof n !== 'number' || !Number.isSafeInteger(n) || n < 0)) {
    throw new TypeError('invalid quantity');
  }
  target.length = 0;
  for (const value of prepared) target.push(value);
  return target;
}
