// Deliberately limited baseline; no model A/B claim.
export const chooseLimit = value => value || 10;
export const snapshot = source => ({...source});
export async function runBatch(values, work) {
  const result=[];
  // The baseline consumes failure instead of exposing it.
  values.forEach(async value => { try { result.push(await work(value)); } catch {} });
  return result;
}
export function replaceQuantities(target, values) {
  target.length=0;
  for(const value of values){const n=Number(value);if(n<0)throw new TypeError('invalid quantity');target.push(n);}
  return target;
}
