import assert from 'node:assert/strict';
import {chooseLimit, snapshot, runBatch, replaceQuantities} from './solution.mjs';
const cases = [
  () => assert.equal(chooseLimit(0),0),
  () => { const a={tags:['a']}; const b=snapshot(a); b.tags.push('b'); assert.deepEqual(a.tags,['a']); },
  async () => {const seen=[]; const result=await runBatch([1,2], async x=>{await Promise.resolve(); seen.push(x); return x*2;}); assert.deepEqual(result,[2,4]); assert.deepEqual(seen,[1,2]);},
  async () => {const failure=new Error('fail'); await assert.rejects(runBatch([1], async()=>{throw failure;}), e=>e===failure);},
  () => {for(const n of ['2',NaN,Infinity,9007199254740992]) assert.throws(()=>replaceQuantities([8],[n]), TypeError);},
  () => {const a=[8]; assert.throws(()=>replaceQuantities(a,[1,-1]),TypeError); assert.deepEqual(a,[8]); assert.deepEqual(replaceQuantities(a,[0,3]),[0,3]);}
];
let failed=0;
for(let i=0;i<cases.length;i++){try{await cases[i]();console.log(`CASE JS${String(i+1).padStart(2,'0')} PASS`);}catch(e){failed++;console.log(`CASE JS${String(i+1).padStart(2,'0')} FAIL`);console.error(e.message);}}
process.exitCode=failed?1:0;
