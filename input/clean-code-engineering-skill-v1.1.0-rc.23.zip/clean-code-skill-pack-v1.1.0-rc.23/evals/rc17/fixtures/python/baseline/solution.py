# Deliberately limited baseline; not output from an independent AI.
def add_tag(tag, tags=[]):
    tags.append(tag)
    return tags

def snapshot(source):
    return source.copy()

def apply_patch(source, patch):
    result = source.copy()
    result["name"] = patch.get("name") or source["name"]
    return result

def replace_quantities(target, values):
    target.clear()
    for value in values:
        if not isinstance(value, int) or value < 0:
            raise ValueError("invalid quantity")
        target.append(value)
    return target

def consume_owned(stream, work):
    result = work(stream)
    stream.close()
    return result
