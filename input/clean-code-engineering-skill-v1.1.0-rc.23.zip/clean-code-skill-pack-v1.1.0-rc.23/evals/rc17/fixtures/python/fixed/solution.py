"""Small contract examples; not a general-purpose data validation library."""
from copy import deepcopy

def add_tag(tag, tags=None):
    if tags is None:
        tags = []
    tags.append(tag)
    return tags

def snapshot(source):
    # This example owns only plain nested dict/list/scalar data.
    return deepcopy(source)

def apply_patch(source, patch):
    result = source.copy()
    if "name" in patch:
        result["name"] = patch["name"]
    return result

def replace_quantities(target, values):
    prepared = list(values)
    if any(type(value) is not int or value < 0 for value in prepared):
        raise ValueError("invalid quantity")
    target[:] = prepared
    return target

def consume_owned(stream, work):
    with stream:
        return work(stream)
