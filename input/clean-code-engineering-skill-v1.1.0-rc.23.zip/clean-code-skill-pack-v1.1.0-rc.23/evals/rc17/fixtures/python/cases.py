import sys, io
from solution import add_tag, snapshot, apply_patch, replace_quantities, consume_owned

def check(value):
    if not value: raise AssertionError('contract not met')
def case01():
    check(replace_quantities([9], [0, 2]) == [0, 2])
def case02():
    old = [9]
    try: replace_quantities(old, [1, True])
    except ValueError: pass
    else: raise AssertionError('boolean must not be accepted as a quantity')
    check(old == [9])
def case03():
    check(add_tag('first') == ['first'])
    check(add_tag('second') == ['second'])
def case04():
    source = {'tags': ['a'], 'options': {'limit': 0}}
    dest = snapshot(source)
    dest['tags'].append('b'); source['options']['limit'] = 3
    check(source['tags'] == ['a'] and dest['options']['limit'] == 0)
def case05():
    stream = io.StringIO('abc')
    error = RuntimeError('failure')
    def work(_): raise error
    try: consume_owned(stream, work)
    except RuntimeError as exc: check(exc is error)
    else: raise AssertionError('failure was swallowed')
    check(stream.closed)
def case06():
    check(apply_patch({'name': 'old'}, {}) == {'name': 'old'})
    check(apply_patch({'name': 'old'}, {'name': None}) == {'name': None})
    check(apply_patch({'name': 'old'}, {'name': ''}) == {'name': ''})
failed = 0
for i in range(1,7):
    ident = f'PY{i:02d}'
    try: globals()[f'case{i:02d}']()
    except Exception as exc:
        failed += 1; print(f'CASE {ident} FAIL'); print(type(exc).__name__ + ': ' + str(exc), file=sys.stderr)
    else: print(f'CASE {ident} PASS')
sys.exit(1 if failed else 0)
