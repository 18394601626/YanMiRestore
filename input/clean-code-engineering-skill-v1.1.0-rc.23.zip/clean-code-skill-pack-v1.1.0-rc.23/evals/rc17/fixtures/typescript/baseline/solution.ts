export function decodeQuantity(input: unknown): number {
  return (input as {quantity:number}).quantity;
}
export function snapshot(source: {tags: readonly string[]}): {tags:string[]} {
  return {tags: source.tags as string[]};
}
export function applyPatch(old: string|null, patch: {name?:string|null}):string|null {
  return patch.name || old;
}
export function replaceQuantities(target:number[], values:unknown[]):number[]{
  target.length=0;
  for(const value of values){const n=decodeQuantity(value);if(n<0)throw new TypeError('invalid');target.push(n);}
  return target;
}
