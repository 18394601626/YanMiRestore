// Public input stays unknown until runtime checks establish its shape.
export function decodeQuantity(input: unknown): number {
  if (input === null || typeof input !== 'object' || Array.isArray(input) ||
      !Object.prototype.hasOwnProperty.call(input, 'quantity')) {
    throw new TypeError('quantity object required');
  }
  const value = (input as Record<string, unknown>).quantity;
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 0) {
    throw new TypeError('invalid quantity');
  }
  return value;
}

export function snapshot(source: {tags: readonly string[]}): {tags: string[]} {
  return {tags: [...source.tags]};
}

export function applyPatch(old: string|null, patch: {name?:string|null}): string|null {
  return Object.prototype.hasOwnProperty.call(patch, 'name') ? patch.name ?? null : old;
}

export function replaceQuantities(target: number[], values: unknown[]): number[] {
  if (!Array.isArray(values)) throw new TypeError('quantity array required');
  // The boundary requires a dense payload. Inherited indices are not payload data.
  const prepared: number[] = [];
  const length = values.length;
  for (let index = 0; index < length; index++) {
    if (!Object.prototype.hasOwnProperty.call(values, index)) {
      throw new TypeError('sparse quantity array');
    }
    prepared.push(decodeQuantity(values[index]));
  }
  target.length = 0;
  for (const value of prepared) target.push(value);
  return target;
}
