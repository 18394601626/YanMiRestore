import {decodeQuantity, snapshot, applyPatch, replaceQuantities} from './solution';
function check(value: boolean): void { if(!value) throw new Error('contract not met'); }
function rejects(f:()=>unknown):void{try{f();}catch(e){if(e instanceof TypeError)return;throw e;}throw new Error('invalid input accepted');}
const tests: Array<()=>void> = [
 ()=>check(decodeQuantity({quantity:0})===0),
 ()=>rejects(()=>decodeQuantity({quantity:'2'} as unknown)),
 ()=>{check(applyPatch('old',{})==='old');check(applyPatch('old',{name:null})===null);check(applyPatch('old',{name:''})==='');},
 ()=>{const source={tags:['a']};const dest=snapshot(source);dest.tags.push('b');check(source.tags.length===1);},
 ()=>{rejects(()=>decodeQuantity({quantity:9007199254740992}));rejects(()=>decodeQuantity(null));},
 ()=>{const old=[8];rejects(()=>replaceQuantities(old,[{quantity:1},{quantity:-1}]));check(old[0]===8&&old.length===1);}
];
let failed=0;
for(let i=0;i<tests.length;i++){try{tests[i]();console.log(`CASE TS${String(i+1).padStart(2,'0')} PASS`);}catch(e){failed++;console.log(`CASE TS${String(i+1).padStart(2,'0')} FAIL`);console.error(String(e));}}
if(failed)throw new Error(`${failed} test failures`);
