import Foundation

enum Problem: Error { case invalid, overflow }
final class TagBox {
    var tags: [String]
    init(_ tags: [String]) { self.tags = tags }
}
struct Profile { let box: TagBox }
final class Probe {
    var closed = false
    func close() { closed = true }
}

func snapshot(_ source: Profile) -> Profile {
    Profile(box: TagBox(source.box.tags))
}

func fitsUTF8(_ text: String, maximum: Int) -> Bool {
    text.utf8.count <= maximum
}

func checkedAdd(_ a: Int, _ b: Int) throws -> Int {
    let (value, overflow) = a.addingReportingOverflow(b)
    guard !overflow else { throw Problem.overflow }
    return value
}

func defaultName(_ value: String?) -> String { value ?? "default" }

func consumeOwned(_ resource: Probe, work: () throws -> Void) throws {
    defer { resource.close() }
    try work()
}

func replaceQuantities(_ target: inout [Int], _ texts: [String]) throws {
    let prepared = try texts.map { text -> Int in
        guard let value = Int(text), value >= 0 else { throw Problem.invalid }
        return value
    }
    target = prepared
}
