import Foundation
enum Problem:Error {case invalid, overflow}
final class TagBox {var tags:[String];init(_ tags:[String]){self.tags=tags}}
struct Profile {let box:TagBox}
final class Probe {var closed=false;func close(){closed=true}}
func snapshot(_ source:Profile)->Profile {source}
func fitsUTF8(_ text:String,maximum:Int)->Bool {text.count<=maximum}
func checkedAdd(_ a:Int,_ b:Int)throws->Int {a &+ b}
func defaultName(_ value:String?)->String {value==nil || value=="" ? "default":value!}
func consumeOwned(_ resource:Probe,work:()throws->Void)throws{try work();resource.close()}
func replaceQuantities(_ target:inout [Int],_ texts:[String])throws {target=[];for text in texts{guard let n=Int(text),n>=0 else{throw Problem.invalid};target.append(n)}}
