import Foundation
func check(_ value: Bool) throws { if !value { throw Problem.invalid } }
@main struct Cases {
 static func main() {
  let tests: [() throws -> Void] = [
   {let a=Profile(box:TagBox(["a"]));let b=snapshot(a);b.box.tags.append("b");try check(a.box.tags==["a"])},
   {try check(!fitsUTF8("é",maximum:1));try check(fitsUTF8("é",maximum:2))},
   {do{_ = try checkedAdd(Int.max,1);throw Problem.invalid}catch Problem.overflow{}},
   {try check(defaultName("")=="");try check(defaultName(nil)=="default")},
   {let p=Probe();do{try consumeOwned(p){throw Problem.invalid}}catch Problem.invalid{};try check(p.closed)},
   {var old=[9];do{try replaceQuantities(&old,["1","bad"]);throw Problem.overflow}catch Problem.invalid{};try check(old==[9])}
  ]
  var failed=0
  for(i,test) in tests.enumerated(){let id=String(format:"SW%02d",i+1);do{try test();print("CASE \(id) PASS")}catch{failed += 1;print("CASE \(id) FAIL");fputs("\(error)\n",stderr)}}
  if failed>0 { exit(1) }
 }
}
