# Controlled Bash baseline; intentionally unsafe splitting and lifecycle.
emit_args(){ printf '%s\n' $@; }
checked_pipeline(){ false | cat; }
owned_work(){ local file;file=$(mktemp "$1/work.XXXXXX") || return 1;return 23; }
default_name(){ printf '%s' "${1:-default}"; }
first_line(){ local line;read line;printf '%s' "$line"; }
