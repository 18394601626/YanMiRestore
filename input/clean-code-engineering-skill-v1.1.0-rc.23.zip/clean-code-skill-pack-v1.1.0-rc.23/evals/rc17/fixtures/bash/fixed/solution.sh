# Bash-specific examples. Caller owns its shell settings and any input streams.
emit_args(){
    (( $# == 0 )) && return 0
    printf '%s\n' "$@"
}
checked_pipeline(){ ( set -o pipefail; false | cat ); }
owned_work(){ (
    local file
    file=$(mktemp -- "$1/work.XXXXXX") || return 1
    trap 'rm -f -- "$file"' EXIT
    return 23
); }
default_name(){ printf '%s' "${1-default}"; }
first_line(){
    local line
    IFS= read -r line || [[ -n "$line" ]] || return 1
    printf '%s' "$line"
}
