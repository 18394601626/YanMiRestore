#!/usr/bin/env bash
# Bash contract tests; each case runs in a subshell to isolate shell options.
source "$(dirname -- "${BASH_SOURCE[0]}")/solution.sh"
case01(){ local output; output=$(emit_args 'a b' '*' '-n'); [[ "$output" == $'a b\n*\n-n' ]]; }
case02(){ ! checked_pipeline; }
case03(){ local root status;root=$(mktemp -d) || return 1; owned_work "$root";status=$?;local files=("$root"/*);[[ $status == 23 && ! -e "${files[0]}" ]];local ok=$?;rm -f -- "$root"/work.*;rmdir -- "$root";return "$ok"; }
case04(){ [[ $(default_name '0') == '0' && $(default_name '') == '' && $(default_name) == 'default' ]]; }
case05(){ local data=$'  a\\b  ';[[ $(printf '%s\n' "$data" | first_line) == "$data" ]]; }
case06(){ set +o pipefail; checked_pipeline; [[ $(set -o | grep '^pipefail') == *off ]]; }
failed=0
for number in 01 02 03 04 05 06;do
 if ( "case$number" );then printf 'CASE SH%s PASS\n' "$number";else failed=$((failed+1));printf 'CASE SH%s FAIL\n' "$number";fi
done
(( failed == 0 ))
