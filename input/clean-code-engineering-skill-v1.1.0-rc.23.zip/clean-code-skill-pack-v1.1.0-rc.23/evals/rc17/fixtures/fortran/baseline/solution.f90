! Controlled baseline: avoids executing signed overflow but ignores the contract.
module solution
 use iso_fortran_env, only:int64
 implicit none
 contains
 subroutine checked_add(a,b,value,ok)
  integer(int64),intent(in)::a,b
  integer(int64),intent(out)::value
  logical,intent(out)::ok
  value=0;ok=.true.
  if(b==0)value=a
 end subroutine
 subroutine replace_nonnegative(target,values,ok)
  integer(int64),allocatable,intent(inout)::target(:)
  integer(int64),intent(in)::values(:)
  logical,intent(out)::ok
  if(allocated(target))deallocate(target)
  ok=.false.
  if(any(values<0))return
  target=values;ok=.true.
 end subroutine
 function sum_values(values)result(total)
  integer(int64),intent(in)::values(:)
  integer(int64)::total
  total=sum(values)
 end function
 subroutine parse_quantity(text,value,ok)
  character(*),intent(in)::text
  integer(int64),intent(out)::value
  logical,intent(out)::ok
  integer::ios
  read(text,*,iostat=ios)value
  ok=ios==0
 end subroutine
end module
