program cases
  use iso_fortran_env, only: int64, error_unit
  use solution
  implicit none
  integer :: failed, i
  integer(int64) :: value
  integer(int64), allocatable :: old(:), empty(:)
  integer(int64) :: source(-2:3)
  logical :: ok, results(6)
  character(4) :: id
  failed=0
  call checked_add(huge(0_int64), 1_int64, value, ok)
  results(1)=.not.ok
  call checked_add(-huge(0_int64), -1_int64, value, ok)
  results(2)=ok
  if(ok) results(2)=value==(-huge(0_int64)-1_int64)
  allocate(old(1), empty(0));old=9
  call replace_nonnegative(old,empty,ok)
  results(3)=ok.and.allocated(old)
  if(allocated(old))results(3)=results(3).and.size(old)==0
  if(allocated(old))deallocate(old)
  allocate(old(1));old=9
  call replace_nonnegative(old,[1_int64,-1_int64],ok)
  results(4)=.not.ok.and.allocated(old)
  if(allocated(old))then
    results(4)=results(4).and.size(old)==1
    if(size(old)==1)results(4)=results(4).and.old(1)==9
  end if
  source=[1_int64,2_int64,3_int64,4_int64,5_int64,6_int64]
  results(5)=sum_values(source(-2:3:2))==9_int64
  call parse_quantity('12,34',value,ok)
  results(6)=.not.ok
  do i=1,6
    write(id,'("FT",I2.2)')i
    if(results(i))then
      print '(A)', 'CASE '//id//' PASS'
    else
      failed=failed+1
      print '(A)', 'CASE '//id//' FAIL'
      write(error_unit,'(A)') 'contract not met: '//id
    end if
  end do
  if(failed>0)stop 1
end program
