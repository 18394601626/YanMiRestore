module solution
  use iso_fortran_env, only: int64
  implicit none
contains
  subroutine checked_add(a, b, value, ok)
    integer(int64), intent(in) :: a, b
    integer(int64), intent(out) :: value
    logical, intent(out) :: ok
    integer(int64), parameter :: hi=huge(0_int64), lo=-huge(0_int64)-1_int64
    value=0; ok=.false.
    ! Fortran logical expressions must not be used as short-circuit guards.
    if (b>0) then
      if(a>hi-b) return
    else if(b<0) then
      if(a<lo-b) return
    end if
    value=a+b; ok=.true.
  end subroutine

  subroutine replace_nonnegative(target, values, ok)
    integer(int64), allocatable, intent(inout) :: target(:)
    integer(int64), intent(in) :: values(:)
    logical, intent(out) :: ok
    integer(int64), allocatable :: prepared(:)
    integer :: status
    ok=.false.
    if(any(values<0))return
    allocate(prepared(size(values)), stat=status)
    if(status/=0)return
    prepared=values
    call move_alloc(prepared, target)
    ok=.true.
  end subroutine

  function sum_values(values) result(total)
    integer(int64), intent(in) :: values(:)
    integer(int64) :: total
    ! Caller supplies values whose sum is representable; strides are supported.
    total=sum(values)
  end function

  subroutine parse_quantity(text, value, ok)
    character(*), intent(in) :: text
    integer(int64), intent(out) :: value
    logical, intent(out) :: ok
    integer :: i, status, count
    count=len_trim(text); value=0; ok=.false.
    if(count<1) return
    do i=1,count
      if(text(i:i)<'0' .or. text(i:i)>'9')return
    end do
    read(text,*,iostat=status)value
    if(status/=0) then
      value=0
      return
    end if
    ok=.true.
  end subroutine
end module
