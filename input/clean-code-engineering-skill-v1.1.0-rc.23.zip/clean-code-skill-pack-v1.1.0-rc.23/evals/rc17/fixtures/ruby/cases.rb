require_relative 'solution'
require 'stringio'
def check(v); raise 'contract not met' unless v; end
cases = [
 -> {check(parse_quantity('12')==12);begin;parse_quantity('12x');raise 'invalid accepted';rescue ArgumentError;end},
 -> {a={tags:['a']};b=snapshot(a);b[:tags][0]<<'x';check(a[:tags]==['a'])},
 -> {check(patch_name('old',{})=='old');check(patch_name('old',{name:nil}).nil?)},
 -> {r=StringIO.new('data');begin;consume_owned(r){raise ArgumentError,'work'};rescue ArgumentError=>e;check(e.message=='work');end;check(r.closed?)},
 -> {check(option(false)==false);check(option(nil)==true)},
 -> {old=[9];begin;replace_quantities(old,['1','bad']);raise 'invalid accepted';rescue ArgumentError;end;check(old==[9])}
]
failed=0;cases.each_with_index do |test,i|
 id=format('RB%02d',i+1)
 begin;test.call;puts "CASE #{id} PASS";rescue StandardError=>e;failed+=1;puts "CASE #{id} FAIL";warn e.message;end
end
exit(failed.zero? ? 0 : 1)
