# Controlled baseline with known faults.
def parse_quantity(text);text.to_i;end
def snapshot(source);source.dup;end
def patch_name(old,patch);patch[:name] || old;end
def consume_owned(resource);result=yield(resource);resource.close;result;end
def option(value);value || true;end
def replace_quantities(target, texts)
 target.clear
 texts.each{|text|target << parse_quantity(text)}
 target
end
