# The snapshot contract here is Hash<Symbol, Array<String>>, not arbitrary objects.
def parse_quantity(text)
  raise ArgumentError, 'invalid quantity' unless text.is_a?(String) && /\A[0-9]+\z/.match?(text)
  Integer(text, 10)
end

def snapshot(source)
  source.merge(tags: source.fetch(:tags).map(&:dup))
end

def patch_name(old, patch)
  patch.key?(:name) ? patch[:name] : old
end

def consume_owned(resource)
  yield(resource)
ensure
  resource.close
end

def option(value)
  value.nil? ? true : value
end

def replace_quantities(target, texts)
  prepared = texts.map { |text| parse_quantity(text) }
  target.replace(prepared)
end
