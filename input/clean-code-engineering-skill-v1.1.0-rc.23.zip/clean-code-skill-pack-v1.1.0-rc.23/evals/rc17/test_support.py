"""Language guide, provenance and scope checks, not model capability tests."""
import hashlib
import json
from pathlib import Path
import re
import unittest
R=Path(__file__).resolve().parents[2]
S=R/'clean-code-engineering'
NEW=('python','javascript','typescript','php','ruby','kotlin','swift','perl','bash','fortran')
OLD=('go','java','rust','c','cpp')
ALLOWED={'README.md','CHANGELOG.md','VALIDATION.md','VERSION','SHA256SUMS.txt','FIX_SUMMARY.json',
'clean-code-engineering/SKILL.md','clean-code-engineering/VERSION','clean-code-engineering/assets/language-support.json'}
class SupportChecks(unittest.TestCase):
 def registry(self):return json.loads((S/'assets/language-support.json').read_text())
 def test_new_guides_exist(self):
  for name in NEW:
   with self.subTest(language=name):self.assertTrue((S/f'references/languages/{name}.md').is_file())
 def test_guides_have_distinct_sections_and_scope(self):
  for name in NEW:
   with self.subTest(language=name):
    text=(S/f'references/languages/{name}.md').read_text()
    self.assertGreaterEqual(len(re.findall(r'^## ',text,re.M)),6)
    for token in ('执行适配','项目','未验证','来源'):self.assertIn(token,text)
 def test_fifteen_real_guides(self):
  d=self.registry();self.assertEqual(set(d['languages']),set(NEW+OLD));self.assertFalse(d['independent_agent_AB'])
 def test_roadmap_not_supported(self):
  d=self.registry();planned=d['planned_languages'];self.assertEqual(len(planned),15)
  for item in planned.values():self.assertEqual(item['status'],'PLANNED');self.assertIsNone(item['guide'])
 def test_router_reachable(self):
  self.assertIn('references/20-language-routing.md',(S/'SKILL.md').read_text())
  text=(S/'references/20-language-routing.md').read_text()
  for name in NEW:self.assertIn('languages/'+name+'.md',text)
 def test_no_indiscriminate_all_loading(self):
  text=(S/'references/20-language-routing.md').read_text()
  for term in ('.m','.pl','.h','shebang','POSIX','NOT_RUN','不是自动发现','不全量加载'):self.assertIn(term,text)
 def test_runtime_and_framework_separate(self):
  for name in NEW:
   d=self.registry()['languages'][name];self.assertIn('execution',d);self.assertEqual(d['framework_validation'],'NOT_RUN');self.assertFalse(d['agent_behavior_tested'])
 def test_old_book_and_code_bytes_unchanged(self):
  hashes=json.loads((R/'provenance/rc17/source-files.json').read_text())
  for name,digest in hashes.items():
   if name not in ALLOWED:
    with self.subTest(file=name):self.assertEqual(hashlib.sha256((R/name).read_bytes()).hexdigest(),digest)
 def test_frozen_consumers_unchanged(self):
  hashes=json.loads((R/'provenance/rc17/tests-frozen.json').read_text());self.assertEqual(len(hashes),10)
  for name,digest in hashes.items():self.assertEqual(hashlib.sha256((R/name).read_bytes()).hexdigest(),digest)
 def test_entry_stays_small(self):self.assertLess(len((S/'SKILL.md').read_text().splitlines()),170)
 def test_source_records(self):
  sources=json.loads((R/'provenance/rc17/sources.json').read_text())
  self.assertEqual(set(sources['languages']),set(NEW))
  for links in sources['languages'].values():self.assertGreaterEqual(len(links),2)
 def test_version_identity(self):
  for f in (R/'VERSION',S/'VERSION'):self.assertEqual(f.read_text().strip(),'1.1.0-rc.17')
if __name__=='__main__':unittest.main(verbosity=2)
