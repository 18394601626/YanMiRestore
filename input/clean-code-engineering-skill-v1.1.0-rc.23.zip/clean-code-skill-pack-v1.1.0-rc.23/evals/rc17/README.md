# rc17 十语言契约实验

## 运行与范围

```bash
python -S evals/rc17/reproduce.py --output ../rc17-all-new --languages batch
python -S evals/rc17/run_batch.py --output ../rc17-one --languages python --variant both
python -S evals/rc17/test_runner.py
python -S evals/rc17/test_support.py
```

首条运行222个文档/工具方法和10语言的baseline/fixed；第二条只运行Python的两个候选。
`batch` 严格等于 python,javascript,typescript,php,ruby,kotlin,swift,perl,bash,fortran。
旧语言不自动加入；未请求语言不继承通过状态。输出必须为包外新目录，脚本从冻结源文件复制到输出目录再编译执行。实际命令、退出码、日志摘要和每个case记录保存在summary.json。只有工具缺失标BLOCKED；编译失败与测试失败分别记录。输出目录由调用者管理；需要清理自己的构建文件时只清理该目录。

## 测试契约

| 语言 | 六项实际行为 |
|---|---|
| Python | 正常替换、bool拒绝与原子失败、默认参数隔离、嵌套快照、异常资源清理、缺失/null/空 |
| JavaScript | 零值、嵌套副本、异步等待、错误传播、安全整数、失败不部分提交 |
| TypeScript | unknown解析、断言不等于校验、缺失/null、readonly别名、安全整数、原子替换 |
| PHP | null键存在性、严格ID、引用foreach、列表JSON、输入类型、临时文件关闭 |
| Ruby | 完整整数、嵌套字符串、Hash key、ensure、false值、批量原子失败 |
| Kotlin | copy浅层、Int溢出、完整解析、null/空、use关闭、批量状态 |
| Swift | struct引用成员、UTF8长度、溢出、nil/空、defer、批量状态 |
| Perl | exists/undef、字符串0、引用副本、完整十进制、参数不变、空arrayref |
| Bash | 引用、管道失败、临时文件清理、缺失/空/0、IFS/read、调用者选项 |
| Fortran | 溢出、最小值、零尺寸分配、失败保留、stride、拒绝尾随输入 |

每个语义只针对样例的明确数据模型。不是通用深拷贝、全类型解析器或事务库；内存耗尽、磁盘故障和并发等未列项目不作保证。Bash依赖GNU命令；Swift资源用逻辑对象，不是真实文件；Fortran求和前提是结果可表示。Python/PHP/Ruby清理使用实际标准库/临时流，但不是外部服务。

## 反控制与结果

baseline是有意写入已知缺陷的校准候选，不是普通AI的输出，也不是上一版Skill生成的代码。所有消费者测试先保存哈希，再编写baseline，观察54个指定行为失败后写fixed。二者实际编译/解释执行相同消费者。固定候选每语言6项通过；从中只能确认这些断言可区分这些版本，不证明其他代理会自动产出fixed。

新runner解析12项检查只核对自有受控格式和退出状态，不鉴别恶意源码；CASE标记也不是密码学证据。历史POSIX进程助手复用原实现，作用范围见旧说明。某个测试自己打印完全一致的谎报无法通过本工具鉴真。

## 文档检查和版本约束

在原rc.16上原入口203项先通过。新包222项为198项适用的历史断言加24项新检查。旧rc.16精确发行/哈希检查与旧“语言必须恰好5种”的检查保持原字节，只适用于旧发行；新SupportChecks按15项、明确计划项及新的保护清单检验。没有改掉旧测试要求来宣称旧精确版本断言在新版通过。

## 测试先行与记录

新runner文件不存在时出现缺文件基线，表示功能尚未实现，不是代理失败；语言指南检查也因新资料/路由不存在出现失败，不证明无Skill代理会漏掉这些点。实际语义RED来自baseline的54个指定断言失败。新文档首次Fortran只缺少“未验证”精确标签，第一次聚合少传PACK_ROOT；两者均归为文档/组装问题，原日志保留。

## 尚未验证

独立代理压力/盲测、IDE自动加载、最低语言版本、多版本矩阵、Web/移动/数据库框架、生产负载与性能。Swift使用swift-version5、Kotlin生成JVM1.8目标但只在JDK21运行。Node/TypeScript不是浏览器测试。Bash不代表POSIX sh。所有样例无第三方依赖下载。
