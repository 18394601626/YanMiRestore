import unittest
from change_control_eval import assess

class ChangeControlChecks(unittest.TestCase):
    def test_complete_standard_change_can_stop(self):
        r=assess({
            'depth':'standard','requirement_met':True,
            'required_nodes':['service','consumer','schema'],
            'confirmed_verified_nodes':['service','consumer','schema'],
            'semantic':[{'dimension':'public','state':'CHANGED','authorized':True},{'dimension':'error','state':'SAME','authorized':False}],
            'protect_violations':[],'missing_validation':[],'unexplained_diff':[],
            'next_change':'unrelated_cleanup'
        })
        self.assertTrue(r['stop_ready'])

    def test_local_green_missing_consumer_blocks_stop(self):
        r=assess({
            'depth':'deep','requirement_met':True,
            'required_nodes':['service','consumer'],
            'confirmed_verified_nodes':['service'],
            'semantic':[{'dimension':'public','state':'CHANGED','authorized':True}],
            'protect_violations':[],'missing_validation':['consumer module'],'unexplained_diff':[],
            'next_change':'none'
        })
        self.assertFalse(r['stop_ready']); self.assertIn('consumer', ' '.join(r['reasons']))

    def test_unknown_high_risk_semantic_blocks_stop(self):
        r=assess({
            'depth':'deep','requirement_met':True,
            'required_nodes':['api'],'confirmed_verified_nodes':['api'],
            'semantic':[{'dimension':'serialization','state':'UNKNOWN','authorized':False,'high_risk':True}],
            'protect_violations':[],'missing_validation':[],'unexplained_diff':[],'next_change':'none'
        })
        self.assertFalse(r['stop_ready']); self.assertTrue(any('UNKNOWN' in x for x in r['reasons']))

    def test_unauthorized_refactor_semantic_change_blocks_stop(self):
        r=assess({
            'mode':'refactor','depth':'standard','requirement_met':True,
            'required_nodes':['pkg'],'confirmed_verified_nodes':['pkg'],
            'semantic':[{'dimension':'error','state':'CHANGED','authorized':False}],
            'protect_violations':[],'missing_validation':[],'unexplained_diff':[],'next_change':'none'
        })
        self.assertFalse(r['stop_ready']); self.assertTrue(any('unauthorized' in x for x in r['reasons']))

    def test_protected_edit_blocks_stop(self):
        r=assess({
            'depth':'standard','requirement_met':True,
            'required_nodes':['service'],'confirmed_verified_nodes':['service'],
            'semantic':[{'dimension':'behavior','state':'SAME','authorized':False}],
            'protect_violations':['legacy/cleanup.go'],'missing_validation':[],'unexplained_diff':[],'next_change':'none'
        })
        self.assertFalse(r['stop_ready']); self.assertIn('legacy/cleanup.go',' '.join(r['reasons']))

    def test_light_private_rename_needs_no_full_graph(self):
        r=assess({
            'mode':'refactor','depth':'light','requirement_met':True,
            'required_nodes':[],'confirmed_verified_nodes':[],
            'semantic':[],'protect_violations':[],'missing_validation':[],'unexplained_diff':[],
            'next_change':'unrelated_cleanup'
        })
        self.assertTrue(r['stop_ready'])

    def test_unexplained_diff_blocks_stop(self):
        r=assess({
            'depth':'standard','requirement_met':True,
            'required_nodes':['service'],'confirmed_verified_nodes':['service'],
            'semantic':[],'protect_violations':[],'missing_validation':[],
            'unexplained_diff':['go.mod'],'next_change':'none'
        })
        self.assertFalse(r['stop_ready']); self.assertIn('go.mod',' '.join(r['reasons']))

if __name__=='__main__': unittest.main(verbosity=2)
