from pathlib import Path
import importlib.util
import unittest

ROOT = Path(__file__).resolve().parents[2]
SKILL = ROOT / 'clean-code-engineering'

class RC6Contract(unittest.TestCase):
    def read(self, rel):
        return (ROOT / rel).read_text(encoding='utf-8')

    def test_version(self):
        self.assertEqual(self.read('VERSION').strip(), '1.1.0-rc.6')
        self.assertEqual(self.read('clean-code-engineering/VERSION').strip(), '1.1.0-rc.6')

    def test_change_control_reference_exists(self):
        self.assertTrue((SKILL / 'references/14-change-control.md').is_file())

    def test_skill_routes_to_change_control(self):
        s = self.read('clean-code-engineering/SKILL.md')
        self.assertIn('规则路由', s)
        self.assertIn('references/14-change-control.md', s)
        self.assertIn('最小加载', s)

    def test_change_graph_contract(self):
        s = self.read('clean-code-engineering/references/14-change-control.md')
        for token in ['变更图', '节点', '边', '证据', 'confirmed', 'suspected']:
            self.assertIn(token, s)

    def test_graph_edges_cover_non_code_contracts(self):
        s = self.read('clean-code-engineering/references/14-change-control.md')
        for token in ['generated-from', 'persists-to', 'serializes-as', 'built-under']:
            self.assertIn(token, s)

    def test_semantic_diff_contract(self):
        s = self.read('clean-code-engineering/references/14-change-control.md')
        for token in ['语义差异', '公开契约', '错误语义', '序列化', '持久化', '并发', '资源', '外部调用', '性能']:
            self.assertIn(token, s)

    def test_refactor_requires_same_unless_authorized(self):
        s = self.read('clean-code-engineering/references/14-change-control.md')
        self.assertIn('refactor', s)
        self.assertIn('SAME', s)
        self.assertIn('授权', s)

    def test_rule_router_is_conditional_and_escalating(self):
        s = self.read('clean-code-engineering/references/14-change-control.md')
        for token in ['最小加载集', '证据触发', '升级加载', '不要预加载全部']:
            self.assertIn(token, s)

    def test_stop_gate_is_explicit(self):
        s = self.read('clean-code-engineering/references/14-change-control.md')
        for token in ['停止闸门', 'STOP', '未验证', '无关清理']:
            self.assertIn(token, s)

    def test_impact_ledger_has_graph_semantic_and_stop_slots(self):
        s = self.read('clean-code-engineering/assets/impact-ledger.md')
        for token in ['变更图', '语义差异', '停止闸门']:
            self.assertIn(token, s)

    def test_light_tasks_do_not_require_heavy_ledger(self):
        s = self.read('clean-code-engineering/references/14-change-control.md')
        self.assertIn('light', s)
        self.assertIn('不建立完整变更图', s)

    def test_execution_adaptation_is_explicit(self):
        s = self.read('clean-code-engineering/references/14-change-control.md')
        self.assertIn('执行适配', s)
        self.assertIn('不是《代码整洁之道》的新增章节', s)

def historical_suite():
    spec = importlib.util.spec_from_file_location('rc5_docs', ROOT / 'evals/rc5/test_contract.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    out = unittest.TestSuite()
    def add(items):
        for t in items:
            if isinstance(t, unittest.TestSuite):
                add(t)
            elif getattr(t, '_testMethodName', '') != 'test_01_version':
                out.addTest(t)
    add(mod.suite())
    return out

def suite():
    s = historical_suite()
    s.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(RC6Contract))
    return s

if __name__ == '__main__':
    result = unittest.TextTestRunner(verbosity=2).run(suite())
    raise SystemExit(0 if result.wasSuccessful() else 1)
