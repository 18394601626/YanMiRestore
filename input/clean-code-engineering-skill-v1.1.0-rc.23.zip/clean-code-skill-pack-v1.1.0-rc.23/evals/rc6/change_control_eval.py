"""Check the consistency of a caller-supplied completion record.

This is a controlled evaluation helper, not an authorization engine. It neither
executes tests nor verifies that the caller's claims match repository reality.
Missing evidence is not an empty successful check. Malformed JSON-like input
returns a diagnostic rejection rather than relying on Python truthiness.
"""

MODES = frozenset(('write', 'refactor', 'review', 'format'))
DEPTHS = frozenset(('light', 'standard', 'deep'))
SEMANTIC_STATES = frozenset(('SAME', 'CHANGED', 'UNKNOWN'))
NAME_LISTS = ('required_nodes', 'confirmed_verified_nodes', 'protect_violations',
              'missing_validation', 'unexplained_diff')


def _verdict(reasons):
    return {'stop_ready': not reasons, 'reasons': reasons}


def _names(record, field, reasons):
    """Validate before any set conversion; a string is not a node collection."""
    if field not in record:
        reasons.append(f'missing required field: {field}')
        return []
    values = record[field]
    if type(values) is not list:
        reasons.append(f'{field} must be a list of nonblank strings')
        return []
    seen = set()
    for index, value in enumerate(values):
        if type(value) is not str or not value.strip():
            reasons.append(f'{field}[{index}] must be a nonblank string')
        elif value in seen:
            reasons.append(f'duplicate entry in {field}: {value}')
        else:
            seen.add(value)
    return values


def _semantics(record, reasons):
    if 'semantic' not in record:
        reasons.append('missing required field: semantic')
        return []
    rows = record['semantic']
    if type(rows) is not list:
        reasons.append('semantic must be a list of objects')
        return []
    dimensions = set()
    for index, row in enumerate(rows):
        prefix = f'semantic[{index}]'
        if type(row) is not dict:
            reasons.append(f'{prefix} must be an object')
            continue
        dimension = row.get('dimension')
        if type(dimension) is not str or not dimension.strip():
            reasons.append(f'{prefix}.dimension must be a nonblank string')
        elif dimension in dimensions:
            reasons.append(f'duplicate semantic dimension: {dimension}')
        else:
            dimensions.add(dimension)
        state = row.get('state')
        if type(state) is not str or state not in SEMANTIC_STATES:
            reasons.append(f'{prefix}.state must be SAME, CHANGED or UNKNOWN')
        # Safe legacy defaults: absence is not authorization and is not low risk.
        for flag, default in (('authorized', False), ('high_risk', True)):
            if type(row.get(flag, default)) is not bool:
                reasons.append(f'{prefix}.{flag} must be a boolean')
    return rows


def assess(record):
    """Return stop_ready/reasons without mutating the supplied record.

    mode may be omitted for legacy callers (write); depth must be explicit.
    All evidence collections must be supplied. Light tasks may declare empty
    graph/semantics; non-light modifications require both inventories. Optional
    metadata is ignored, never treated as authority or as proof of execution.
    """
    reasons = []
    if type(record) is not dict:
        return _verdict(['completion record must be an object'])

    mode = record.get('mode', 'write')
    if type(mode) is not str or mode not in MODES:
        reasons.append('mode must be write, refactor, review or format')
    depth = record.get('depth')
    if type(depth) is not str or depth not in DEPTHS:
        reasons.append('depth must be explicitly light, standard or deep')
    if 'requirement_met' not in record:
        reasons.append('missing required field: requirement_met')
    elif type(record['requirement_met']) is not bool:
        reasons.append('requirement_met must be a boolean')

    lists = {field: _names(record, field, reasons) for field in NAME_LISTS}
    semantic = _semantics(record, reasons)
    if reasons:
        return _verdict(reasons)

    if record['requirement_met'] is not True:
        reasons.append('requirement not met')
    if depth != 'light':
        if not lists['required_nodes']:
            reasons.append('standard/deep task requires a nonempty required_nodes inventory')
        if mode in ('write', 'refactor') and not semantic:
            reasons.append('standard/deep modification requires a semantic inventory')

    required = set(lists['required_nodes'])
    verified = set(lists['confirmed_verified_nodes'])
    for node in sorted(required - verified):
        reasons.append(f'unverified required node: {node}')

    for row in semantic:
        state, dimension = row['state'], row['dimension']
        if mode == 'format' and state != 'SAME':
            # A flag cannot expand a format-only task into a behavior change.
            reasons.append(f'format mode requires unchanged semantics: {dimension} ({state})')
        if state == 'UNKNOWN' and row.get('high_risk', True):
            reasons.append(f'UNKNOWN high-risk semantic: {dimension}')
        if state == 'CHANGED' and row.get('authorized', False) is not True:
            reasons.append(f'unauthorized semantic change: {dimension}')

    for field, prefix in (('protect_violations', 'protected scope changed'),
                          ('missing_validation', 'missing validation'),
                          ('unexplained_diff', 'unexplained diff')):
        reasons.extend(f'{prefix}: {value}' for value in lists[field])
    return _verdict(reasons)
