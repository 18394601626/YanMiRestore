# rc.6 验证说明

本目录验证 rc.6 的**规则契约与受控停止门禁**，不是独立模型 A/B。

- `test_contract.py`：先在 rc.5 内容上运行得到 RED，再在 rc.6 上验证规则路由、变更图、语义差异和停止闸门；同时复用 rc.1—rc.5 的非版本绑定文档检查。
- `test_change_control.py`：对受控记录验证完成判定，覆盖局部绿但漏跨模块、语义 UNKNOWN、保护区越界、refactor 未授权语义变化、无法解释 diff，以及 light 任务不需要完整图。
- `scenarios.json`：12 个未来 fresh-context agent 压力/应用场景，当前状态为 `NOT_RUN_AGENT_BEHAVIOR`，不能计为模型通过。

历史动态夹具仍使用 rc.3/rc.4/rc.5 原入口重放，不复制为新的独立样本。
