from pathlib import Path
import argparse, json, shutil, subprocess, time
HERE=Path(__file__).resolve().parent
CASES=HERE/'fixtures'

def run(cmd,cwd,timeout=20):
    t=time.time()
    p=subprocess.run(cmd,cwd=cwd,text=True,capture_output=True,timeout=timeout)
    return {'cmd':cmd,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':round(time.time()-t,4)}

def one(case,variant,out):
    work=out/case/variant
    work.mkdir(parents=True)
    shutil.copy(CASES/case/variant/'Target.java',work/'Target.java')
    shutil.copy(CASES/case/'VisibleTest.java',work/'VisibleTest.java')
    shutil.copy(CASES/case/'HiddenTest.java',work/'HiddenTest.java')
    vis_compile=run(['javac','Target.java','VisibleTest.java'],work)
    vis_run=run(['java','VisibleTest'],work) if vis_compile['exit']==0 else None
    hid_compile=run(['javac','HiddenTest.java'],work) if vis_compile['exit']==0 else None
    hid_run=run(['java','HiddenTest'],work) if hid_compile and hid_compile['exit']==0 else None
    visible_ok=bool(vis_compile['exit']==0 and vis_run and vis_run['exit']==0)
    hidden_ok=bool(hid_compile and hid_compile['exit']==0 and hid_run and hid_run['exit']==0)
    return {'case':case,'variant':variant,'visible_ok':visible_ok,'hidden_ok':hidden_ok,
            'visible_compile':vis_compile,'visible_run':vis_run,'hidden_compile':hid_compile,'hidden_run':hid_run}

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output',required=True); a=ap.parse_args(); out=Path(a.output)
    if out.exists(): raise SystemExit('output exists')
    out.mkdir(parents=True)
    results=[]
    for case in sorted(p.name for p in CASES.iterdir() if p.is_dir()):
        for variant in ('bad','good'): results.append(one(case,variant,out))
    checks=[]
    for case in sorted(set(x['case'] for x in results)):
        b=next(x for x in results if x['case']==case and x['variant']=='bad')
        g=next(x for x in results if x['case']==case and x['variant']=='good')
        checks.append({'case':case,'bad_visible_pass':b['visible_ok'],'bad_hidden_rejected':not b['hidden_ok'],
                       'good_visible_pass':g['visible_ok'],'good_hidden_pass':g['hidden_ok']})
    ok=all(all(v for k,v in c.items() if k!='case') for c in checks)
    summary={'java_version':subprocess.run(['java','-version'],text=True,capture_output=True).stderr.splitlines()[0],
             'kind':'controlled_jdk_fixtures_not_spring_integration_not_agent_ab','cases':checks,'all_expected':ok,'raw':results}
    (out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print(json.dumps({'all_expected':ok,'cases':checks},ensure_ascii=False,indent=2))
    raise SystemExit(0 if ok else 1)
if __name__=='__main__': main()
