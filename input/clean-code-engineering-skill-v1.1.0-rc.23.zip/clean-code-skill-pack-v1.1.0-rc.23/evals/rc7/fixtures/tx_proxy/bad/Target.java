import java.lang.annotation.*; import java.lang.reflect.*;
interface Api { void create(); }
@Retention(RetentionPolicy.RUNTIME) @java.lang.annotation.Target(ElementType.METHOD) @interface Tx {}
class TxContext { static final ThreadLocal<Boolean> ACTIVE=ThreadLocal.withInitial(()->false); static boolean active(){return ACTIVE.get();} }
class ProxyFactory { static Api wrap(Target t){ return (Api)Proxy.newProxyInstance(Api.class.getClassLoader(),new Class[]{Api.class},(p,m,a)->{ Method impl=Target.class.getMethod(m.getName(),m.getParameterTypes()); boolean tx=impl.isAnnotationPresent(Tx.class); boolean prev=TxContext.ACTIVE.get(); if(tx) TxContext.ACTIVE.set(true); try{return impl.invoke(t,a);} finally {TxContext.ACTIVE.set(prev);} }); } }
public class Target implements Api { private boolean savedInTx; public void create(){ save(); } @Tx public void save(){ savedInTx=TxContext.active(); } boolean savedInTx(){return savedInTx;} static Api proxied(Target t){return ProxyFactory.wrap(t);} }
