from pathlib import Path
import importlib.util, unittest
ROOT=Path(__file__).resolve().parents[2]
SKILL=ROOT/'clean-code-engineering'
class RC7Contract(unittest.TestCase):
    def read(self, rel): return (ROOT/rel).read_text(encoding='utf-8')
    def test_version(self):
        self.assertEqual(self.read('VERSION').strip(),'1.1.0-rc.7')
        self.assertEqual(self.read('clean-code-engineering/VERSION').strip(),'1.1.0-rc.7')
    def test_java_reference_exists(self): self.assertTrue((SKILL/'references/15-java-spring.md').is_file())
    def test_skill_routes_java(self):
        s=self.read('clean-code-engineering/SKILL.md')
        for t in ['references/15-java-spring.md','.java','pom.xml','build.gradle']: self.assertIn(t,s)
    def test_version_first(self):
        s=self.read('clean-code-engineering/references/15-java-spring.md')
        for t in ['JDK','Spring Boot','pom.xml','build.gradle','不擅自升级']: self.assertIn(t,s)
    def test_proxy_boundaries(self):
        s=self.read('clean-code-engineering/references/15-java-spring.md')
        for t in ['@Transactional','self-invocation','proxy','@Async','@Cacheable']: self.assertIn(t,s)
    def test_transaction_contract(self):
        s=self.read('clean-code-engineering/references/15-java-spring.md')
        for t in ['rollbackFor','noRollbackFor','传播','异常','事务边界']: self.assertIn(t,s)
    def test_persistence_contract(self):
        s=self.read('clean-code-engineering/references/15-java-spring.md')
        for t in ['MyBatis','MyBatis-Plus','N+1','批量','逻辑删除','Wrapper']: self.assertIn(t,s)
    def test_json_contract(self):
        s=self.read('clean-code-engineering/references/15-java-spring.md')
        for t in ['Jackson','null','缺失','枚举','record','Lombok']: self.assertIn(t,s)
    def test_concurrency_contract(self):
        s=self.read('clean-code-engineering/references/15-java-spring.md')
        for t in ['ThreadLocal','remove','CompletableFuture','ForkJoinPool.commonPool','InterruptedException']: self.assertIn(t,s)
    def test_resource_contract(self):
        s=self.read('clean-code-engineering/references/15-java-spring.md')
        for t in ['try-with-resources','suppressed','AutoCloseable']: self.assertIn(t,s)
    def test_java_api_compat(self):
        s=self.read('clean-code-engineering/references/15-java-spring.md')
        for t in ['方法引用','重载','泛型','接口','反射']: self.assertIn(t,s)
    def test_execution_adaptation(self):
        s=self.read('clean-code-engineering/references/15-java-spring.md')
        self.assertIn('执行适配',s); self.assertIn('不是《代码整洁之道》的新增章节',s)

def historical_suite():
    spec=importlib.util.spec_from_file_location('rc6_docs',ROOT/'evals/rc6/test_contract.py')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    out=unittest.TestSuite()
    def add(items):
        for t in items:
            if isinstance(t,unittest.TestSuite): add(t)
            elif getattr(t,'_testMethodName','')!='test_version': out.addTest(t)
    add(mod.suite()); return out

def suite():
    s=historical_suite(); s.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(RC7Contract)); return s
if __name__=='__main__':
    r=unittest.TextTestRunner(verbosity=2).run(suite()); raise SystemExit(0 if r.wasSuccessful() else 1)
