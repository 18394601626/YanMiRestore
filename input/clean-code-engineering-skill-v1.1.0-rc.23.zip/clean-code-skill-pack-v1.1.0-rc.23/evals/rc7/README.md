# rc.7 Java / Spring 适配评估

本目录新增 Java/JVM 受控夹具与文档契约。它们验证规则覆盖和可观察行为，不是独立模型 A/B，也不是真实 Spring/MyBatis/Jackson 集成测试。

运行：

```text
python evals/rc7/test_contract.py
python evals/rc7/run_java_cases.py --output <包外新目录>
```

Java 动态夹具仅依赖 `javac`/`java`，本轮实际环境为 OpenJDK 21。项目级框架行为仍须使用项目自己的依赖和配置验证。
