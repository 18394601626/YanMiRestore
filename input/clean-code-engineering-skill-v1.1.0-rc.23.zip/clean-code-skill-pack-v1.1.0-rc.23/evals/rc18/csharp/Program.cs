using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
internal sealed class Resource : IDisposable { public bool Closed; public void Dispose() { Closed=true; } }
internal static class Program {
 static void Check(bool ok) { if(!ok) throw new Exception("contract failed"); }
 static void Expect<T>(Action action) where T : Exception { try {action();} catch(T) {return;} throw new Exception("expected failure missing"); }
 static int Main() {
  Action[] cases = {
   () => {var src=new List<List<string>> {new List<string>{"a"}}; var dst=Domain.Snapshot(src);dst[0].Add("b");Check(src[0].Count==1);},
   () => {Check(Domain.Patch("old",new Dictionary<string,string?>())=="old");Check(Domain.Patch("old",new Dictionary<string,string?>{{"name",null}})==null);},
   () => {var dst=new List<int>{7}; Expect<ArgumentException>(()=>Domain.Replace(dst,new object?[]{1,-1}));Check(dst.Count==1&&dst[0]==7);Domain.Replace(dst,new object?[]{0,2});Check(dst.Count==2&&dst[0]==0&&dst[1]==2);},
   () => {var r=new Resource();Expect<InvalidOperationException>(()=>Domain.Use(r,()=>throw new InvalidOperationException("work")));Check(r.Closed);},
   () => {using(var c=new CancellationTokenSource()){c.Cancel();bool called=false;Expect<OperationCanceledException>(()=>Domain.CheckAsync(c.Token,()=>{called=true;return Task.FromResult(1);}).GetAwaiter().GetResult());Check(!called);}},
   () => {Func<string,string> legacy=Domain.Name;Check(legacy("Ada")=="Ada");}
  };
  int failed=0;for(int i=0;i<cases.Length;i++){try{cases[i]();Console.WriteLine($"CASE CS18{i+1:00} PASS");}catch(Exception e){failed++;Console.WriteLine($"CASE CS18{i+1:00} FAIL");Console.Error.WriteLine(e.GetType().Name+": "+e.Message);}}
  return failed==0?0:1;
 }
}
