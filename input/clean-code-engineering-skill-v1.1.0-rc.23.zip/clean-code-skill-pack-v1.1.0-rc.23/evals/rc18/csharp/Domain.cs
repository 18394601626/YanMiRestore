using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
public static class Domain {
 public static List<List<string>> Snapshot(List<List<string>> source) {
  var copy=new List<List<string>>();foreach(var row in source)copy.Add(new List<string>(row));return copy;
 }
 public static string? Patch(string? previous,IReadOnlyDictionary<string,string?> patch) {
  return patch.TryGetValue("name",out var value)?value:previous;
 }
 public static void Replace(List<int> target,IEnumerable<object?> input) {
  var prepared=new List<int>();foreach(var value in input){if(value is not int n||n<0)throw new ArgumentException("invalid quantity");prepared.Add(n);}target.Clear();target.AddRange(prepared);
 }
 public static void Use(IDisposable owned,Action work) {using(owned){work();}}
 public static async Task<int> CheckAsync(CancellationToken token,Func<Task<int>> work) {token.ThrowIfCancellationRequested();return await work().ConfigureAwait(false);}
 public static string Name(string name) {return name;}
}
