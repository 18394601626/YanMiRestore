"""Reuses unchanged rc17 checks except the three exact release/inventory assertions."""
import importlib.util
from pathlib import Path
import unittest
R=Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('rc18_original_support',R/'evals/rc17/test_support.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
if __name__=='__main__':
 skipped={'test_fifteen_real_guides','test_roadmap_not_supported','test_version_identity'}
 suite=unittest.TestSuite(m.SupportChecks(n) for n in unittest.defaultTestLoader.getTestCaseNames(m.SupportChecks) if n not in skipped)
 result=unittest.TextTestRunner(verbosity=2).run(suite)
 raise SystemExit(0 if result.wasSuccessful() else 1)
