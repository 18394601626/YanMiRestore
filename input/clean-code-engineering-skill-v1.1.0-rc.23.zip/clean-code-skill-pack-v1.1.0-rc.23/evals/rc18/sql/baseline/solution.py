"""Hand-seeded counterexample, not an AI/no-skill baseline."""
from pathlib import Path

def active_ids(db):
    return [r[0] for r in db.execute((Path(__file__).parent/'active.sql').read_text())]

def update_name(db, identifier, patch):
    if identifier is None:
        db.execute('UPDATE accounts SET name=?',(patch.get('name'),))
    else:
        db.execute('UPDATE accounts SET name=? WHERE id=?',(patch.get('name'),identifier))

def replace_quantities(db, rows):
    for identifier, quantity in rows:
        db.execute('UPDATE accounts SET quantity=? WHERE id=?',(quantity,identifier))
    db.commit()

def migrate(db):
    db.executescript((Path(__file__).parent/'migration.sql').read_text())
