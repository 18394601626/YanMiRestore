SELECT a.id FROM accounts AS a
WHERE a.deleted=0 AND a.id NOT IN (SELECT account_id FROM opted_out);
