SELECT a.id FROM accounts AS a
WHERE a.deleted=0
  AND NOT EXISTS (SELECT 1 FROM opted_out AS o WHERE o.account_id=a.id)
ORDER BY a.id;
