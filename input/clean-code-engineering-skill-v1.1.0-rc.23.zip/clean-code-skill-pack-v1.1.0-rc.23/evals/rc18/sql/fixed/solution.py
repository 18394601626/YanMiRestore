"""Small SQLite adapter for explicit fixture contracts, not a generic ORM."""
import logging
from pathlib import Path
import sqlite3

def active_ids(db):
    query=(Path(__file__).parent/'active.sql').read_text()
    return [row[0] for row in db.execute(query)]

def update_name(db, identifier, patch):
    if type(identifier) is not int:
        raise ValueError('an account ID is required')
    if 'name' not in patch:
        return
    db.execute('UPDATE accounts SET name=? WHERE id=?', (patch['name'],identifier))

def replace_quantities(db, rows):
    # The fixture owns a new transaction, never a caller's existing one.
    if db.in_transaction:
        raise RuntimeError('caller already owns a transaction')
    db.execute('BEGIN')
    try:
        for identifier, quantity in rows:
            # Do not delegate application types to SQLite affinity coercion.
            if type(identifier) is not int:
                raise ValueError('an account ID is required')
            if type(quantity) is not int:
                raise ValueError('quantity must be an integer')
            if not -(2**63) <= quantity < 2**63:
                raise OverflowError('quantity is outside signed int64')
            # Negative integers retain the existing DB CHECK/IntegrityError.
            result=db.execute('UPDATE accounts SET quantity=? WHERE id=?',(quantity,identifier))
            if result.rowcount != 1:
                raise LookupError('account not found')
        # Pair explicit BEGIN with SQL completion in legacy and autocommit=True modes.
        db.execute('COMMIT')
    except BaseException as original:
        try:
            # Some errors (e.g. RAISE(ROLLBACK)) already ended the transaction.
            if db.in_transaction:
                db.execute('ROLLBACK')
        except sqlite3.Error as cleanup_error:
            # Cleanup must not convert cancellation or an input error into a DB
            # error. Do not disable the caller's policy or close its connection.
            note = (
                f'SQLite rollback did not complete ({type(cleanup_error).__name__}). '
                'Connection state is unverified; its owner must explicitly recover '
                'or discard the connection before reuse.'
            )
            # Reporting is best effort: user exception methods and log handlers
            # may themselves fail. Ordinary telemetry errors must not replace
            # the primary failure. New BaseException cancellations still escape.
            try:
                add_note = getattr(original, 'add_note', None)
                if callable(add_note):
                    add_note(note)
                else:
                    _log_cleanup_failure(note)
            except Exception:
                _log_cleanup_failure(note)
        raise

def _log_cleanup_failure(note):
    try:
        logging.getLogger(__name__).error(note)
    except Exception:
        # Do not configure logging, recurse into another handler, or report
        # cleanup as successful. The connection owner must inspect/recover it.
        pass


def migrate(db):
    # A once-only migration applied by the fixture; not an idempotent migration manager.
    db.execute((Path(__file__).parent/'migration.sql').read_text())
