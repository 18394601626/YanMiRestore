ALTER TABLE accounts ADD COLUMN display_name TEXT NULL;
