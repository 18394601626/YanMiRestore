"""Runs actual SQLite statements on temporary disk databases; no server DB claims."""
from contextlib import closing
from pathlib import Path
import sqlite3, tempfile, unittest
import solution

class SqlContracts(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='rc18-sql-');self.path=Path(self.tmp.name)/'db.sqlite'
  self.db=sqlite3.connect(self.path, isolation_level=None)
  self.db.executescript("""CREATE TABLE accounts(id INTEGER PRIMARY KEY, name TEXT,
    quantity INTEGER NOT NULL CHECK(quantity>=0), deleted INTEGER NOT NULL DEFAULT 0);
    CREATE TABLE opted_out(account_id INTEGER);
    INSERT INTO accounts(id,name,quantity,deleted) VALUES(1,'Ada',10,0),(2,'Bo',20,0),(3,'Cy',30,1);""")
 def tearDown(self):self.db.close();self.tmp.cleanup()
 def rows(self):
  with closing(sqlite3.connect(self.path)) as other:
   return other.execute('SELECT id,name,quantity,deleted FROM accounts ORDER BY id').fetchall()
 def test_sql01_null_in_opt_out_not_exclude_everything(self):
  self.db.execute('INSERT INTO opted_out VALUES(NULL)');self.assertEqual(solution.active_ids(self.db),[1,2])
 def test_sql02_deleted_and_opted_out_excluded(self):
  self.db.execute('INSERT INTO opted_out VALUES(2)');self.assertEqual(solution.active_ids(self.db),[1])
 def test_sql03_explicit_null_updates_only_one_row(self):
  solution.update_name(self.db,1,{'name':None});self.assertIsNone(self.rows()[0][1]);self.assertEqual(self.rows()[1][1],'Bo')
 def test_sql04_omitted_patch_preserves_value(self):
  before=self.rows();solution.update_name(self.db,1,{});self.assertEqual(self.rows(),before)
 def test_sql05_parameter_kept_as_literal(self):
  value="name'; DELETE FROM accounts; --";solution.update_name(self.db,1,{'name':value});self.assertEqual(self.rows()[0][1],value);self.assertEqual(len(self.rows()),3)
 def test_sql06_empty_id_must_not_update_all(self):
  before=self.rows()
  with self.assertRaises(ValueError):solution.update_name(self.db,None,{'name':'x'})
  self.assertEqual(self.rows(),before)
 def test_sql07_constraint_failure_rolls_back_entire_batch(self):
  before=self.rows()
  with self.assertRaises(sqlite3.IntegrityError):solution.replace_quantities(self.db,[(1,11),(2,-1)])
  self.assertEqual(self.rows(),before);self.assertFalse(self.db.in_transaction)
 def test_sql08_success_visible_to_independent_connection(self):
  solution.replace_quantities(self.db,[(1,11),(2,22)]);self.assertEqual([r[2] for r in self.rows()],[11,22,30]);self.assertFalse(self.db.in_transaction)
 def test_sql09_caller_transaction_not_stolen(self):
  self.db.execute('BEGIN');self.db.execute('UPDATE accounts SET quantity=7 WHERE id=1')
  with self.assertRaises(RuntimeError):solution.replace_quantities(self.db,[(2,8)])
  self.assertTrue(self.db.in_transaction);self.assertEqual(self.rows()[0][2],10)
  self.db.rollback();self.assertEqual(self.rows()[0][2],10)
 def test_sql10_missing_row_rolls_back_prior_writes(self):
  before=self.rows()
  with self.assertRaises(LookupError):solution.replace_quantities(self.db,[(1,1),(999,3)])
  self.assertEqual(self.rows(),before)
 def test_sql11_order_explicit_even_with_reverse_scan(self):
  self.db.execute('PRAGMA reverse_unordered_selects=ON');self.assertEqual(solution.active_ids(self.db),[1,2])
 def test_sql12_additive_migration_preserves_legacy_reader(self):
  solution.migrate(self.db)
  self.assertEqual(self.db.execute('SELECT name FROM accounts WHERE id=1').fetchone()[0],'Ada')
  self.assertIsNone(self.db.execute('SELECT display_name FROM accounts WHERE id=1').fetchone()[0])
if __name__=='__main__':unittest.main(verbosity=2)
