import subprocess,sys,tempfile,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
SCRIPT=ROOT/'evals/rc18/reproduce.py'
class CliContracts(unittest.TestCase):
 def run_cli(self,*args):return subprocess.run([sys.executable,'-S',str(SCRIPT),*args],capture_output=True,text=True,timeout=10)
 def test_help_without_running(self):
  p=self.run_cli('--help');self.assertEqual(p.returncode,0);self.assertIn('--tools-only',p.stdout)
 def test_existing_output_refused(self):
  with tempfile.TemporaryDirectory() as td:
   p=self.run_cli('--output',td);self.assertEqual(p.returncode,2);self.assertIn('new and outside',p.stderr);self.assertFalse((Path(td)/'summary.json').exists())
 def test_inside_package_refused(self):
  target=ROOT/'inside-probe-that-must-not-be-created'
  p=self.run_cli('--output',str(target));self.assertEqual(p.returncode,2);self.assertIn('new and outside',p.stderr);self.assertFalse(target.exists())
 def test_unknown_all_not_silently_accepted(self):
  p=self.run_cli('--output','/tmp/unused-rc18','--languages','all');self.assertEqual(p.returncode,2);self.assertIn('unrecognized arguments',p.stderr)
if __name__=='__main__':unittest.main(verbosity=2)
