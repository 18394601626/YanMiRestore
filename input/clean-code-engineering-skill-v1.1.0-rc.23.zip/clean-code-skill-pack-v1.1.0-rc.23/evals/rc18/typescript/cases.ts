import {replaceQuantities, decodeQuantity} from './solution';
function check(ok: boolean): void { if (!ok) throw new Error('contract failed'); }
function rejects(work: () => unknown): void { try { work(); } catch(e) { if(e instanceof TypeError) return; throw e; } throw new Error('input accepted'); }
function unchanged(values: unknown[]): void { const target=[77,88]; rejects(()=>replaceQuantities(target, values)); check(JSON.stringify(target)==='[77,88]'); }
const tests: [string,()=>void][] = [
 ['TS1801',()=>unchanged(new Array(2))],
 ['TS1802',()=>{const a: unknown[]=[{quantity:1},{quantity:2}]; delete a[1]; unchanged(a);}],
 ['TS1803',()=>{const a: unknown[]=new Array(1); const proto=Object.create(Array.prototype); proto[0]={quantity:2}; Object.setPrototypeOf(a,proto); unchanged(a);}],
 ['TS1804',()=>unchanged([{quantity:1},{quantity:'2'}])],
 ['TS1805',()=>{const target=[99]; check(replaceQuantities(target,[{quantity:0},{quantity:3}])===target); check(target.join(',')==='0,3');}],
 ['TS1806',()=>{const target=[99]; replaceQuantities(target,[]); check(target.length===0);}],
 ['TS1807',()=>{const source=[{quantity:7}]; const target: number[]=[]; replaceQuantities(target,source); check(target[0]===7 && source[0].quantity===7);}],
 ['TS1808',()=>{unchanged([{quantity:1}, Object.create({quantity:2})]); check(decodeQuantity({quantity:9007199254740991})===9007199254740991);}]
];
let failed=0; for (const [name,test] of tests) {try {test(); console.log(`CASE ${name} PASS`);}catch(e){failed++;console.log(`CASE ${name} FAIL`);console.error(String(e));}}
if(failed) throw new Error(`${failed} failures`);
