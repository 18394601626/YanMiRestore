"""Collect unittest events from the frozen SQLite tests; invoked in a fresh subprocess."""
import argparse,importlib.util,json,os,sys,unittest,traceback,sqlite3
from pathlib import Path
class RecordingResult(unittest.TextTestResult):
 def __init__(self,*a,**kw):super().__init__(*a,**kw);self.observations=[]
 def startTest(self,test):super().startTest(test);self.observations.append({'test':test.id(),'status':'RUNNING'})
 def addSuccess(self,test):super().addSuccess(test);self.observations[-1]['status']='PASS'
 def addFailure(self,test,err):
  super().addFailure(test,err);self.observations[-1].update(status='FAIL',diagnostic=''.join(traceback.format_exception(*err)))
 def addError(self,test,err):
  super().addError(test,err);self.observations[-1].update(status='ERROR',diagnostic=''.join(traceback.format_exception(*err)))
 def addSkip(self,test,reason):super().addSkip(test,reason);self.observations[-1].update(status='SKIP',reason=reason)
def main():
 p=argparse.ArgumentParser();p.add_argument('--workdir',type=Path,required=True);p.add_argument('--report',type=Path,required=True);a=p.parse_args()
 sys.path.insert(0,str(a.workdir));spec=importlib.util.spec_from_file_location('sqlite_contracts',a.workdir/'cases.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 result=unittest.TextTestRunner(verbosity=2,resultclass=RecordingResult).run(unittest.defaultTestLoader.loadTestsFromTestCase(m.SqlContracts))
 data={'engine':'SQLite','engine_version':sqlite3.sqlite_version,'driver':'Python sqlite3','tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'observations':result.observations,'success':result.wasSuccessful()}
 a.report.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');return 0 if result.wasSuccessful() else 1
if __name__=='__main__':raise SystemExit(main())
