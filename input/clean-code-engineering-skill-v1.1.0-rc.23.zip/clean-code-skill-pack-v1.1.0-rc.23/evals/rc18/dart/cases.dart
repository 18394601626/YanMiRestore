import 'solution.dart';
void check(bool ok) {if(!ok) throw StateError('contract failed');}
Future<void> main() async {
 final tests=<Future<void> Function()>[
  () async {final src=[['a']];final dst=snapshot(src);dst[0].add('b');check(src[0].length==1);},
  () async {check(patch('old',{})=='old');check(patch('old',{'name':null})==null);check(patch('old',{'name':''})=='');},
  () async {final dst=[7];bool rejected=false;try{replace(dst,[1,-1]);} on FormatException {rejected=true;}check(rejected&&dst.length==1&&dst[0]==7);replace(dst,[0,2]);check(dst.length==2&&dst[1]==2);},
  () async {final r=Owned();bool failed=false;try{await consume(r,() async {throw FormatException('work');});} on FormatException {failed=true;}check(failed&&r.closed);},
  () async {final r=Owned();final value=await consume(r,() async {await Future<void>.delayed(Duration.zero);check(!r.closed);return 3;});check(value==3&&r.closed);},
  () async {check(label(name:'Ada')=='Ada');}
 ];
 var failed=0;for(var i=0;i<tests.length;i++){try{await tests[i]();print('CASE DT18${(i+1).toString().padLeft(2,'0')} PASS');}catch(e){failed++;print('CASE DT18${(i+1).toString().padLeft(2,'0')} FAIL');print(e);}}
 if(failed>0) throw StateError('$failed failed');
}
