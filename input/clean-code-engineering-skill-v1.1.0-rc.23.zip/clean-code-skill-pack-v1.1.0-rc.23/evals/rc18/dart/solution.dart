// Owned plain nested lists only; no claim about arbitrary object graphs.
List<List<String>> snapshot(List<List<String>> source)=>source.map((row)=>List<String>.of(row)).toList();
String? patch(String? previous,Map<String,String?> input)=>input.containsKey('name')?input['name']:previous;
void replace(List<int> target,List<Object?> input) {
 final prepared=<int>[];for(final value in input){if(value is! int||value<0)throw FormatException('invalid quantity');prepared.add(value);}target..clear()..addAll(prepared);
}
class Owned {bool closed=false;Future<void> close() async {closed=true;}}
Future<T> consume<T>(Owned resource,Future<T> Function() work) async {try{return await work();}finally{await resource.close();}}
String label({required String name})=>name;
