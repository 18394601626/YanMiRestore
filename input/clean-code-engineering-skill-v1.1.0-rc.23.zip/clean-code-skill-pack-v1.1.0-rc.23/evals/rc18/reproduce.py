"""Replay rc18: tool checks, the old ten-language batch, TS boundaries, SQLite, C#/Dart attempts.

This scope is explicit; it is not 'all 30 languages'. Uses supplied fixtures only,
not untrusted source, production databases, external models or deployment tools.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent

def module(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    loaded=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded

old=module('rc18_replay',ROOT/'evals/rc15/reproduce.py')
batch=module('rc18_batch',ROOT/'evals/rc17/run_batch.py')
STAGES=[('native-parser','evals/rc14/test_runner.py',10),
 ('old-stop','evals/rc6/test_change_control.py',7),
 ('strict-stop','evals/rc15/test_stop_contract.py',38),
 ('old-cli','evals/rc15/test_reproduce_cli.py',4),
 ('native-evidence','evals/rc16/test_native_evidence.py',26),
 ('rc16-cli','evals/rc16/test_reproduce_cli.py',4),
 ('applicable-legacy','evals/rc17/test_legacy_applicable.py',9),
 ('applicable-rc17-support','evals/rc18/test_legacy_support.py',9),
 ('batch-runner','evals/rc17/test_runner.py',12),
 ('rc18-support','evals/rc18/test_support.py',10),
 ('rc18-cli','evals/rc18/test_cli.py',4)]


def execute(row,cmd,cwd,log):
    r=old.support.execute(cmd,cwd,log,90)
    r['log']=str(log)
    row.setdefault('commands',[]).append(r)
    if r['status']=='INTERRUPTED':
        row['status']='INTERRUPTED'
        raise KeyboardInterrupt
    return r


def typescript(out):
    work=out/'typescript-extra';work.mkdir()
    shutil.copy2(ROOT/'evals/rc17/fixtures/typescript/fixed/solution.ts',work/'solution.ts')
    shutil.copy2(HERE/'typescript/cases.ts',work/'cases.ts')
    row={'id':'typescript-extra','status':'NOT_RUN','executed':0}
    build=execute(row,['tsc','--strict','--noEmitOnError','--target','ES2020','--module','commonjs','--outDir','dist','solution.ts','cases.ts'],work,work/'compile.log')
    if build['status']!='FINISHED' or build['exit_code']!=0:
        row['status']=build['status'] if build['status']!='FINISHED' else 'COMPILE_FAIL';return row
    run=execute(row,['node','dist/cases.js'],work,work/'run.log')
    if run['status']!='FINISHED':row['status']=run['status'];return row
    row.update(batch.inspect((work/'run.log').read_text(errors='replace'),run['exit_code'],[f'TS18{i:02d}' for i in range(1,9)]))
    return row


def sql(out,variant):
    work=out/('sql-'+variant);work.mkdir()
    shutil.copy2(HERE/'sql/cases.py',work/'cases.py')
    for f in (HERE/'sql'/variant).iterdir():shutil.copy2(f,work/f.name)
    row={'id':'sql-sqlite-'+variant,'status':'NOT_RUN','executed':0,'not_tested_dialects':['postgresql','mysql','sqlserver']}
    report=work/'test-report.json'
    run=execute(row,[sys.executable,'-S',str(HERE/'run_sql_cases.py'),'--workdir',str(work),'--report',str(report)],work,work/'run.log')
    if run['status']!='FINISHED':row['status']=run['status'];return row
    if not report.exists():row['status']='INVALID_EVIDENCE';return row
    d=json.loads(report.read_text());row['report']=d;row['executed']=d['tests_run']
    if d['engine']!='SQLite' or d['tests_run']!=12 or d['skips']:
        row['status']='INVALID_EVIDENCE';return row
    if variant=='fixed':
        row['status']='PASS' if d['success'] is True and run['exit_code']==0 else 'TEST_FAIL'
    else:
        failures={x['test'].rsplit('.',1)[-1].split('_')[1] for x in d['observations'] if x['status']=='FAIL'}
        errors=[x for x in d['observations'] if x['status']=='ERROR']
        expected=failures=={'sql01','sql04','sql06','sql07','sql09','sql10','sql11'}
        expected=expected and len(errors)==1 and 'test_sql12_' in errors[0]['test'] and 'no such column: name' in errors[0]['diagnostic']
        row['status']='CONTROL_OBSERVATIONS_MATCH' if expected and run['exit_code']==1 else 'MISMATCH'
    return row


def source_attempt(out,key):
    work=out/key;shutil.copytree(HERE/key,work)
    row={'id':key,'status':'NOT_RUN','source_cases':6,'executed':0}
    commands=([['dotnet','build','--nologo','--verbosity','minimal','--ignore-failed-sources','-o','build'],['dotnet','build/Cases.dll']] if key=='csharp' else [['dart','analyze','.'],['dart','run','cases.dart']])
    for i,cmd in enumerate(commands):
        log=work/f'{i:02d}.log';r=execute(row,cmd,work,log)
        if r['status']!='FINISHED':row['status']=r['status'];return row
        if i==0 and r['exit_code']!=0:row['status']='COMPILE_FAIL';return row
        if i==1:
            prefix='CS18' if key=='csharp' else 'DT18'
            row.update(batch.inspect(log.read_text(errors='replace'),r['exit_code'],[prefix+f'{i:02d}' for i in range(1,7)]))
    return row


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--tools-only',action='store_true',help='do not execute any language fixtures')
    args=parser.parse_args();out=args.output.resolve()
    if out.exists() or out==ROOT or ROOT in out.parents:parser.error('output must be new and outside package')
    out.mkdir(parents=True)
    os.environ.update(PYTHONDONTWRITEBYTECODE='1',PACK_ROOT=str(ROOT),RC18_ROOT=str(ROOT))
    requested=[] if args.tools_only else ['rc17-ten-language-batch','typescript-extra','sql-sqlite-baseline','sql-sqlite-fixed','csharp','dart']
    result={'version':(ROOT/'VERSION').read_text().strip(),'started_utc':datetime.now(timezone.utc).isoformat(),
       'kind':'controlled_replay_and_language_contracts_not_independent_AI_AB','status':'RUNNING',
       'environment':{'python':sys.version,'platform':platform.platform()},'stages':[],
       'requested_runtime_checks':requested,'runtime':[], 'guide_count':30,
       'not_executed_by_this_entry':['old Go/Java/C/C++ business matrices','Rust','Objective-C','Scala','Groovy','F#','VB.NET','R','Julia','MATLAB','Lua','PowerShell','Elixir','Erlang','server SQL engines','frameworks','IDE loading','independent model A/B']}
    def save():old.save(out,result)
    save();code=1
    try:
        row=old.launch(out,'book',[sys.executable,'-S','evals/rc13/reproduce.py','--output',str(out/'book-details')],120)
        if row['status']=='FINISHED' and (out/'book-details/summary.json').exists():
            d=json.loads((out/'book-details/summary.json').read_text());row['observed_methods']=d['observed_test_methods']
            row['status']='PASS' if row['exit_code']==0 and d['all_pass'] is True and row['observed_methods']==90 else 'FAIL'
        result['stages'].append(row);save()
        if row['status']=='INTERRUPTED':raise KeyboardInterrupt
        for name,path,count in STAGES:
            row=old.launch(out,name,[sys.executable,'-S',path],90);old.check_unittest(row,out,count)
            result['stages'].append(row);save()
            if row['status']=='INTERRUPTED':raise KeyboardInterrupt
        result['stages'].append(old.replay_original(out));save()
        if not args.tools_only:
            row=old.launch(out,'batch',[sys.executable,'-S','evals/rc17/run_batch.py','--languages','batch','--output',str(out/'batch-details')],300)
            if row['status']=='INTERRUPTED':raise KeyboardInterrupt
            if row['status']=='FINISHED' and (out/'batch-details/summary.json').exists():
                d=json.loads((out/'batch-details/summary.json').read_text())
                row['details']=d;row['status']=d['status'] if d.get('exit_code')==row['exit_code'] else 'INVALID_EVIDENCE'
            result['runtime'].append(row);save()
            for action in (lambda:typescript(out),lambda:sql(out,'baseline'),lambda:sql(out,'fixed'),lambda:source_attempt(out,'csharp'),lambda:source_attempt(out,'dart')):
                result['runtime'].append(action());save()
        accepted={'PASS','CONTROL_OBSERVATIONS_MATCH','EXPECTED_OBSERVATIONS_REPRODUCED'}
        if any(r['status']!='PASS' for r in result['stages']) or any(r['status'] not in accepted|{'BLOCKED','PARTIAL_BLOCKED'} for r in result['runtime']):
            result['status']='FAIL';code=1
        elif any(r['status'] in {'BLOCKED','PARTIAL_BLOCKED'} for r in result['runtime']):result['status']='PARTIAL_BLOCKED';code=2
        else:result['status']='REQUESTED_SCOPE_PASSED';code=0
    except KeyboardInterrupt:result['status']='INTERRUPTED';code=130
    except Exception as exc:result.update(status='ERROR',reason=type(exc).__name__+': '+str(exc));code=1
    finally:
        result['unstarted_runtime_checks']=[name for name in requested if name not in {r['id'] for r in result['runtime']} and not (name=='rc17-ten-language-batch' and any(r['id']=='batch' for r in result['runtime']))]
        result['tool_methods']=sum(r.get('observed_methods',0) for r in result['stages'])
        result['finished_utc']=datetime.now(timezone.utc).isoformat();result['exit_code']=code;save()
    print(result['status'],'tool_methods='+str(result['tool_methods']))
    for r in result['stages']:print(r['id'],r['status'],r.get('observed_methods',0))
    for r in result['runtime']:print(r['id'],r['status'],r.get('executed'))
    return code
if __name__=='__main__':raise SystemExit(main())
