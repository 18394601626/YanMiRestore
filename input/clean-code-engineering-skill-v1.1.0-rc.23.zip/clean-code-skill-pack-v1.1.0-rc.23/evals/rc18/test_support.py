"""These are document/integrity checks, not language compiler or agent tests."""
import json, os, re, unittest
from pathlib import Path
R=Path(os.environ.get('RC18_ROOT', Path(__file__).resolve().parents[2]))
S=R/'clean-code-engineering'
NEW=('csharp','dart','objective-c','scala','groovy','fsharp','vbnet','r','julia','matlab','lua','powershell','sql','elixir','erlang')
class ExpansionChecks(unittest.TestCase):
 def registry(self): return json.loads((S/'assets/language-support.json').read_text())
 def test_thirty_entries_not_claimed_thirty_runtimes(self):
  d=self.registry(); self.assertEqual(len(d['languages']),30); self.assertFalse(d['independent_agent_AB'])
 def test_pending_entries_are_replaced_by_real_guides(self):
  for key in NEW:
   with self.subTest(key=key):
    d=self.registry()['languages'][key]; self.assertTrue((S/d['guide']).is_file()); self.assertNotIn(key,self.registry()['planned_languages'])
 def test_six_specific_sections_and_scope(self):
  for key in NEW:
   with self.subTest(key=key):
    text=(S/'references/languages'/f'{key}.md').read_text()
    self.assertGreaterEqual(len(re.findall(r'^## ',text,re.M)),6)
    for word in ('执行适配','项目','未验证','来源'): self.assertIn(word,text)
 def test_new_guides_have_official_sources(self):
  d=json.loads((R/'provenance/rc18/sources.json').read_text())
  self.assertEqual(set(d['languages']),set(NEW))
  for urls in d['languages'].values(): self.assertTrue(urls);self.assertTrue(all(u.startswith('https://') for u in urls))
 def test_index_reaches_all_new_guides(self):
  text=(S/'references/20-language-routing.md').read_text()
  for key in NEW:self.assertIn(f'languages/{key}.md',text)
 def test_unexecuted_guides_not_passing(self):
  for key in set(NEW)-{'sql'}:
   with self.subTest(key=key):
    d=self.registry()['languages'][key]; self.assertNotEqual(d.get('execution',{}).get('status'),'PASS'); self.assertFalse(d['agent_behavior_tested'])
 def test_sql_is_dialect_specific(self):
  d=self.registry()['languages']['sql']; self.assertIn('SQLite',d['evidence_scope'])
  for db in ('postgresql','mysql','sqlserver'):self.assertNotEqual(d['dialects'][db]['status'],'PASS')
 def test_prior_card_bytes_stable(self):
  import hashlib
  d=json.loads((R/'provenance/rc18/preserved.json').read_text())
  self.assertGreater(len(d),50)
  for name,h in d.items():
   with self.subTest(file=name):self.assertEqual(hashlib.sha256((R/name).read_bytes()).hexdigest(),h)
 def test_entry_length_bounded(self):self.assertLessEqual(len((S/'SKILL.md').read_text().splitlines()),170)
 def test_current_version(self):
  self.assertEqual((R/'VERSION').read_text().strip(),'1.1.0-rc.18'); self.assertEqual((S/'VERSION').read_text().strip(),'1.1.0-rc.18')
if __name__=='__main__':unittest.main(verbosity=2)
