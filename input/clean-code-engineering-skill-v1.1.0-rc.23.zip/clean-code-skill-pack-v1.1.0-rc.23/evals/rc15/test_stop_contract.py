"""Synthetic STOP records; not agent traces, real authorization, or code validation.

These tests freeze the valid/invalid input contract before changing the helper.
Set STOP_GATE_TARGET only to re-run the SAME assertions against a saved baseline.
"""
from __future__ import annotations
import copy
import importlib.util
import json
import os
from pathlib import Path
import random
import unittest

ROOT = Path(__file__).resolve().parents[2]
TARGET = Path(os.environ.get('STOP_GATE_TARGET', ROOT / 'evals/rc6/change_control_eval.py'))
spec = importlib.util.spec_from_file_location('tested_stop_gate', TARGET)
gate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(gate)


def complete():
    return {
        'mode': 'refactor', 'depth': 'standard', 'requirement_met': True,
        'required_nodes': ['api', 'consumer'],
        'confirmed_verified_nodes': ['api', 'consumer'],
        'semantic': [{'dimension': 'public', 'state': 'SAME', 'authorized': False, 'high_risk': True}],
        'protect_violations': [], 'missing_validation': [], 'unexplained_diff': [],
        'next_change': 'none',
    }


class StopContractTests(unittest.TestCase):
    def verdict(self, record, expected):
        before = copy.deepcopy(record)
        result = gate.assess(record)
        self.assertIsInstance(result, dict)
        self.assertIs(type(result.get('stop_ready')), bool)
        self.assertIsInstance(result.get('reasons'), list)
        self.assertTrue(all(isinstance(x, str) and x.strip() for x in result['reasons']))
        self.assertIs(result['stop_ready'], expected, result)
        if not expected:
            self.assertTrue(result['reasons'], 'a rejection must state why')
        self.assertEqual(record, before, 'assessment must not mutate caller input')
        return result

    def test_complete_standard(self):
        self.verdict(complete(), True)

    def test_complete_deep(self):
        r = complete(); r['depth'] = 'deep'
        self.verdict(r, True)

    def test_legacy_omitted_mode_still_defaults_to_write(self):
        r = complete(); del r['mode']
        self.verdict(r, True)

    def test_light_explicit_empty_graph(self):
        r = complete(); r.update(depth='light', required_nodes=[], confirmed_verified_nodes=[], semantic=[])
        self.verdict(r, True)

    def test_format_light_empty_semantics(self):
        r = complete(); r.update(mode='format', depth='light', required_nodes=[], confirmed_verified_nodes=[], semantic=[])
        self.verdict(r, True)

    def test_format_standard_same_semantics(self):
        r = complete(); r['mode'] = 'format'
        self.verdict(r, True)

    def test_review_can_have_no_semantic_changes(self):
        r = complete(); r.update(mode='review', semantic=[])
        self.verdict(r, True)

    def test_write_explicitly_authorized_change(self):
        r = complete(); r['mode'] = 'write'; r['semantic'][0].update(state='CHANGED', authorized=True)
        self.verdict(r, True)

    def test_refactor_explicitly_authorized_change_keeps_existing_contract(self):
        r = complete(); r['semantic'][0].update(state='CHANGED', authorized=True)
        self.verdict(r, True)

    def test_non_dict_root_rejected_without_exception(self):
        for value in (None, False, 1, '', [], ['mode'], ('x',)):
            with self.subTest(value=repr(value)): self.verdict(value, False)

    def test_all_evidence_fields_required(self):
        fields = ('depth', 'requirement_met', 'required_nodes', 'confirmed_verified_nodes', 'semantic',
                  'protect_violations', 'missing_validation', 'unexplained_diff')
        for key in fields:
            with self.subTest(field=key):
                r = complete(); del r[key]; self.verdict(r, False)

    def test_light_missing_evidence_not_silently_empty(self):
        self.verdict({'mode': 'refactor', 'depth': 'light', 'requirement_met': True}, False)

    def test_invalid_mode(self):
        for value in ('FORMAT', 'repair', '', None, True, [], {}):
            with self.subTest(value=repr(value)):
                r = complete(); r['mode'] = value; self.verdict(r, False)

    def test_invalid_depth(self):
        for value in ('DEEP', 'depp', '', None, True, [], {}):
            with self.subTest(value=repr(value)):
                r = complete(); r['depth'] = value; self.verdict(r, False)

    def test_requirement_boolean_is_not_coerced(self):
        for value in ('false', 'true', 0, 1, None, [], {}, 0.0, 1.0):
            with self.subTest(value=repr(value)):
                r = complete(); r['requirement_met'] = value; self.verdict(r, False)

    def test_false_requirement_blocks(self):
        r = complete(); r['requirement_met'] = False; self.verdict(r, False)

    def test_list_fields_have_exact_list_type(self):
        for key in ('required_nodes', 'confirmed_verified_nodes', 'protect_violations', 'missing_validation', 'unexplained_diff'):
            for value in ('api', {'api': True}, None, False, ('api',)):
                with self.subTest(field=key, value=repr(value)):
                    r = complete(); r[key] = value; self.verdict(r, False)

    def test_list_members_are_nonblank_strings(self):
        for key in ('required_nodes', 'confirmed_verified_nodes', 'protect_violations', 'missing_validation', 'unexplained_diff'):
            for value in ('', '  ', None, 0, True, ['nested'], {'nested': 'x'}):
                with self.subTest(field=key, value=repr(value)):
                    r = complete(); r[key] = [value]; self.verdict(r, False)

    def test_duplicate_node_identifiers(self):
        for key in ('required_nodes', 'confirmed_verified_nodes'):
            with self.subTest(field=key):
                r = complete(); r[key] = ['api', 'api', 'consumer']; self.verdict(r, False)

    def test_deep_empty_required_graph(self):
        r = complete(); r.update(depth='deep', required_nodes=[], confirmed_verified_nodes=[])
        self.verdict(r, False)

    def test_standard_empty_required_graph(self):
        r = complete(); r.update(required_nodes=[], confirmed_verified_nodes=[])
        self.verdict(r, False)

    def test_nonlight_modification_needs_semantic_inventory(self):
        for mode in ('write', 'refactor'):
            for depth in ('standard', 'deep'):
                with self.subTest(mode=mode, depth=depth):
                    r = complete(); r.update(mode=mode, depth=depth, semantic=[]); self.verdict(r, False)

    def test_semantic_has_list_type(self):
        for value in (None, {}, '', False):
            with self.subTest(value=repr(value)):
                r = complete(); r['semantic'] = value; self.verdict(r, False)

    def test_semantic_rows_have_object_type(self):
        for value in (None, [], 'SAME', 3):
            with self.subTest(value=repr(value)):
                r = complete(); r['semantic'] = [value]; self.verdict(r, False)

    def test_semantic_dimension_required_and_nonblank(self):
        for row in ({'state': 'SAME'}, {'dimension': '', 'state': 'SAME'}, {'dimension': [], 'state': 'SAME'}):
            with self.subTest(row=row):
                r = complete(); r['semantic'] = [row]; self.verdict(r, False)

    def test_semantic_state_required_and_known(self):
        for value in (None, 'UNKOWN', 'CHNAGED', 'same', '', [], {}):
            with self.subTest(value=repr(value)):
                r = complete(); r['semantic'][0]['state'] = value; self.verdict(r, False)
        r = complete(); del r['semantic'][0]['state']; self.verdict(r, False)

    def test_duplicate_semantic_dimensions(self):
        r = complete(); r['semantic'].append(dict(r['semantic'][0])); self.verdict(r, False)

    def test_authorization_requires_actual_boolean(self):
        for value in ('false', 'true', 0, 1, None, [], {}):
            with self.subTest(value=repr(value)):
                r = complete(); r['semantic'][0].update(state='CHANGED', authorized=value); self.verdict(r, False)

    def test_risk_flag_requires_actual_boolean(self):
        for value in ('false', 'true', 0, 1, None, [], {}):
            with self.subTest(value=repr(value)):
                r = complete(); r['semantic'][0].update(state='UNKNOWN', high_risk=value); self.verdict(r, False)

    def test_missing_authorization_denies_changed_semantics(self):
        r = complete(); r['semantic'][0]['state'] = 'CHANGED'; del r['semantic'][0]['authorized']
        self.verdict(r, False)

    def test_missing_risk_flag_defaults_to_high_risk(self):
        r = complete(); r['semantic'][0]['state'] = 'UNKNOWN'; del r['semantic'][0]['high_risk']
        self.verdict(r, False)

    def test_format_change_not_overridden_by_authorized(self):
        for depth in ('light', 'standard', 'deep'):
            with self.subTest(depth=depth):
                r = complete(); r.update(mode='format', depth=depth)
                r['semantic'][0].update(state='CHANGED', authorized=True); self.verdict(r, False)

    def test_format_unknown_not_cleared_by_low_risk(self):
        r = complete(); r['mode'] = 'format'; r['semantic'][0].update(state='UNKNOWN', high_risk=False)
        self.verdict(r, False)

    def test_missing_consumer_diagnostic(self):
        r = complete(); r['confirmed_verified_nodes'] = ['api']
        out = self.verdict(r, False); self.assertIn('consumer', '\n'.join(out['reasons']))

    def test_each_existing_blocker_preserves_diagnostic(self):
        for field, value in (('protect_violations', 'legacy.go'), ('missing_validation', 'integration'), ('unexplained_diff', 'go.mod')):
            with self.subTest(field=field):
                r = complete(); r[field] = [value]
                out = self.verdict(r, False); self.assertIn(value, '\n'.join(out['reasons']))

    def test_valid_metadata_does_not_invent_obligations(self):
        r = complete(); r['notes'] = {'ticket': 'demo', 'no_other_changes': True}
        self.verdict(r, True)

    def test_localized_node_names_are_preserved(self):
        r = complete(); r.update(required_nodes=['用户接口', '客户 端'], confirmed_verified_nodes=['客户 端', '用户接口'])
        self.verdict(r, True)

    def test_generated_type_boundary_samples(self):
        # Deterministic type-boundary sampling, not model sampling or performance.
        rng = random.Random(1515)
        invalid = [None, 'false', 'true', 0, 1, 0.0, 1.0, [], {}]
        for i in range(160):
            r = complete()
            if rng.randrange(2):
                r['requirement_met'] = copy.deepcopy(rng.choice(invalid))
            else:
                r['semantic'][0].update(state='CHANGED', authorized=copy.deepcopy(rng.choice(invalid)))
            with self.subTest(sample=i): self.verdict(json.loads(json.dumps(r)), False)

if __name__ == '__main__':
    unittest.main(verbosity=2)
