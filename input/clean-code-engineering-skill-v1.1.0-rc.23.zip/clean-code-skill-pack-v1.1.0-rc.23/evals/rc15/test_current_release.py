"""Current release checks plus unchanged, applicable rc14 adapter assertions."""
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('rc14_adapter_checks', ROOT/'evals/rc14/test_adapters.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)

# The old exact VERSION assertion and immutable rc14 proof still belong to rc14.
# Preserve those tests as bytes; do not rewrite their historical expectations.
OLD_EXCLUSIONS = {'test_release_version', 'test_prior_runtime_and_test_sources_preserved'}
CHANGED_OLD_FILES = {
    'README.md', 'CHANGELOG.md', 'VALIDATION.md', 'VERSION', 'SHA256SUMS.txt',
    'clean-code-engineering/VERSION',
    'clean-code-engineering/assets/language-support.json',
    'evals/rc6/change_control_eval.py',
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

class CurrentReleaseTests(unittest.TestCase):
    def test_release_identity(self):
        for path in ('VERSION', 'clean-code-engineering/VERSION'):
            self.assertEqual((ROOT/path).read_text().strip(), '1.1.0-rc.15')
        self.assertEqual(json.loads((ROOT/'clean-code-engineering/assets/language-support.json').read_text())['version'], '1.1.0-rc.15')

    def test_protected_original_content(self):
        baseline = json.loads((ROOT/'provenance/rc15/baseline-hashes.json').read_text())
        for path, sha in baseline.items():
            if path not in CHANGED_OLD_FILES:
                with self.subTest(path=path): self.assertEqual(digest(ROOT/path), sha)

    def test_stop_input_contract_documented(self):
        text = (ROOT/'evals/rc15/README.md').read_text()
        for expected in ('机器记录输入边界', 'requirement_met', 'confirmed_verified_nodes', 'missing_validation',
                         '布尔值', 'light', '字符串', '授权引擎'):
            self.assertIn(expected, text)

    def test_frozen_regressions(self):
        frozen = json.loads((ROOT/'provenance/rc15/frozen-tests.json').read_text())
        for path, sha in frozen.items(): self.assertEqual(digest(ROOT/path), sha, path)

    def test_native_inputs_and_compiler_scenarios_unchanged(self):
        baseline = json.loads((ROOT/'provenance/rc15/baseline-hashes.json').read_text())
        matched = [path for path in baseline if path.startswith('evals/rc14/')]
        self.assertTrue(matched)
        for path in matched: self.assertEqual(digest(ROOT/path), baseline[path], path)

if __name__ == '__main__':
    loader = unittest.defaultTestLoader
    suite = unittest.TestSuite(old.AdapterContracts(name) for name in loader.getTestCaseNames(old.AdapterContracts)
                               if name not in OLD_EXCLUSIONS)
    suite.addTests(loader.loadTestsFromTestCase(CurrentReleaseTests))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
