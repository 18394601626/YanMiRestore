"""No compilers are started: these tests only verify CLI output guards."""
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import uuid

ROOT = Path(__file__).resolve().parents[2]
ENTRY = ROOT/'evals/rc15/reproduce.py'

class ReproduceCLITests(unittest.TestCase):
    def call(self, *args):
        return subprocess.run([sys.executable, '-S', str(ENTRY), *map(str,args)],
                              capture_output=True, text=True, timeout=10)

    def test_requires_output(self):
        p = self.call('--language','none')
        self.assertEqual(p.returncode, 2); self.assertIn('usage:',p.stderr)
        self.assertIn('--output',p.stderr)

    def test_does_not_overwrite_existing_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp);(out/'sentinel').write_text('unchanged')
            p=self.call('--language','none','--output',out)
            self.assertEqual(p.returncode,2);self.assertIn('new and outside',p.stderr)
            self.assertEqual((out/'sentinel').read_text(),'unchanged')
            self.assertEqual(list(out.iterdir()),[out/'sentinel'])

    def test_rejects_output_inside_package(self):
        out=ROOT/('rc15-invalid-output-'+uuid.uuid4().hex)
        p=self.call('--language','none','--output',out)
        self.assertEqual(p.returncode,2);self.assertIn('new and outside',p.stderr)
        self.assertFalse(out.exists())

    def test_rejects_unknown_language_before_making_output(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'new'
            p=self.call('--language','ALL','--output',out)
            self.assertEqual(p.returncode,2);self.assertIn('invalid choice',p.stderr)
            self.assertFalse(out.exists())

if __name__=='__main__': unittest.main(verbosity=2)
