"""Re-run rc15 checks in a fresh output directory; never download dependencies.

Only bundled controlled code is executed. This is not an untrusted-code sandbox,
an AI experiment, a source-book audit, or proof of real framework integration.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('rc15_process_support',ROOT/'evals/rc8/run_integration.py')
support = importlib.util.module_from_spec(spec)
spec.loader.exec_module(support)


def save(output, summary):
    temp=output/'summary.json.tmp'
    temp.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    temp.replace(output/'summary.json')


def launch(output, name, command, timeout=90):
    row=support.execute(command,ROOT,output/(name+'.log'),timeout)
    row.update(id=name,log=name+'.log',observed_methods=0)
    return row


def check_unittest(row, output, expected):
    row['expected_methods']=expected
    if row['status']!='FINISHED': return
    text=(output/row['log']).read_text(encoding='utf-8',errors='replace')
    found=re.findall(r'^Ran (\d+) tests? in ',text,re.MULTILINE)
    row['observed_methods']=int(found[0]) if len(found)==1 else 0
    row['status']='PASS' if (row['exit_code']==0 and row['observed_methods']==expected
                                and re.search(r'^OK\s*$',text,re.MULTILINE)) else 'FAIL'


def replay_original(output):
    # Preserve the historical test as bytes, including its hard-coded relative
    # rc13 location. The mirror holds a copy of the evaluator being tested now.
    with tempfile.TemporaryDirectory(prefix='rc15-stop-mirror-') as tmp:
        mirror=Path(tmp)
        source=HERE/'legacy_stop_probes.py'
        shutil.copyfile(source,mirror/'test_stop_gate_boundaries.py')
        target=mirror/'input-full/clean-code-skill-pack-v1.1.0-rc.13/evals/rc6/change_control_eval.py'
        target.parent.mkdir(parents=True)
        shutil.copyfile(ROOT/'evals/rc6/change_control_eval.py',target)
        row=launch(output,'original-stop', [sys.executable,'-S',str(mirror/'test_stop_gate_boundaries.py'),str(output/'original-stop-details')],30)
        row['test_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
        row['evaluator_sha256']=hashlib.sha256(target.read_bytes()).hexdigest()
        check_unittest(row,output,10)
        if row['status']=='PASS':
            details=json.loads((output/'original-stop-details/summary.json').read_text())
            if details['tests_run']!=10 or any(details[k] for k in ('failures','errors','skipped')):
                row['status']='FAIL'
        return row


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--language',choices=('none','native','rust','all'),default='all')
    args=parser.parse_args()
    output=args.output.resolve()
    if output.exists() or output==ROOT or ROOT in output.parents:
        parser.error('output must be new and outside the package root')
    output.mkdir(parents=True)
    os.environ['PYTHONDONTWRITEBYTECODE']='1'
    summary={'version':(ROOT/'VERSION').read_text().strip(),
             'kind':'controlled_tool_and_language_checks_not_AI_AB',
             'started_utc':datetime.now(timezone.utc).isoformat(),
             'status':'RUNNING','stages':[], 'language_request':args.language,
             'languages':{'status':'NOT_REQUESTED' if args.language=='none' else 'NOT_RUN'},
             'book_semantics_audited':False,'agent_behavior_tested':False,
             'framework_integration_run':False}
    save(output,summary)
    code=1
    try:
        row=launch(output,'book',[sys.executable,'-S','evals/rc13/reproduce.py','--output',str(output/'book-details')],120)
        if row['status']=='FINISHED':
            details=json.loads((output/'book-details/summary.json').read_text())
            row['observed_methods']=details['observed_test_methods']
            row['status']='PASS' if row['exit_code']==0 and details['all_pass'] is True and row['observed_methods']==90 else 'FAIL'
        summary['stages'].append(row);save(output,summary)
        if row['status']=='INTERRUPTED': raise KeyboardInterrupt
        specs=[('current-release','evals/rc15/test_current_release.py',13),
               ('native-parser','evals/rc14/test_runner.py',10),
               ('old-stop','evals/rc6/test_change_control.py',7),
               ('strict-stop','evals/rc15/test_stop_contract.py',38),
               ('reproduce-cli','evals/rc15/test_reproduce_cli.py',4)]
        for name,script,count in specs:
            row=launch(output,name,[sys.executable,'-S',script],45)
            check_unittest(row,output,count)
            summary['stages'].append(row);save(output,summary)
            if row['status']=='INTERRUPTED': raise KeyboardInterrupt
        row=replay_original(output)
        summary['stages'].append(row);save(output,summary)
        if row['status']=='INTERRUPTED': raise KeyboardInterrupt
        if args.language!='none':
            row=launch(output,'languages',[sys.executable,'-S','evals/rc14/run_checks.py','--language',args.language,
                                           '--output',str(output/'language-details')],240)
            summary['language_process']=row
            if row['status']=='INTERRUPTED': raise KeyboardInterrupt
            path=output/'language-details/summary.json'
            if row['status']=='FINISHED' and path.is_file():
                summary['languages']=json.loads(path.read_text())
                if summary['languages'].get('exit_code')!=row['exit_code']:
                    summary['languages']={'status':'INVALID_EVIDENCE','reason':'exit code mismatch'}
            else:
                summary['languages']={'status':row['status'],'reason':'language run did not complete with a summary'}
        all_tools=all(r['status']=='PASS' for r in summary['stages'])
        language_state=summary['languages']['status']
        if not all_tools or language_state not in ('NOT_REQUESTED','EXPECTED_OBSERVATIONS_REPRODUCED','PARTIAL_BLOCKED'):
            summary['status']='FAIL';code=1
        elif language_state=='PARTIAL_BLOCKED':
            summary['status']='PARTIAL_BLOCKED';code=2
        else:
            summary['status']='CHECKS_PASSED';code=0
    except KeyboardInterrupt:
        summary['status']='INTERRUPTED';code=130
    except Exception as exc:
        summary.update(status='ERROR',reason=type(exc).__name__+': '+str(exc));code=1
    finally:
        summary['exit_code']=code
        summary['observed_test_methods']=sum(r['observed_methods'] for r in summary['stages'])
        summary['finished_utc']=datetime.now(timezone.utc).isoformat()
        save(output,summary)
    print(summary['status'], 'tool_methods='+str(summary['observed_test_methods']))
    for row in summary['stages']: print(row['id'],row['status'],row['observed_methods'])
    return code

if __name__=='__main__': raise SystemExit(main())
