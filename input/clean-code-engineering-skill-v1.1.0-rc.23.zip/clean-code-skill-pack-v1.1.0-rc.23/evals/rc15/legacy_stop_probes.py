"""Additional RC13 STOP evaluator probes; synthetic records, not agent outputs.

Test scope extends the existing seven valid-input checks to absent/type-invalid
records and format-only semantics. Rejections may be a false verdict or a clear
ValueError/TypeError; no implementation is changed to force these tests green.
"""
import copy, hashlib, importlib.util, json, sys, unittest
from pathlib import Path
BASE=Path(__file__).resolve().parent
TARGET=BASE/'input-full/clean-code-skill-pack-v1.1.0-rc.13/evals/rc6/change_control_eval.py'
spec=importlib.util.spec_from_file_location('unchanged_stop_gate',TARGET)
gate=importlib.util.module_from_spec(spec);spec.loader.exec_module(gate)
OBS=[]

def complete():
 return {'mode':'refactor','depth':'standard','requirement_met':True,
         'required_nodes':['service','consumer'],'confirmed_verified_nodes':['service','consumer'],
         'semantic':[{'dimension':'public','state':'SAME','authorized':False,'high_risk':True}],
         'protect_violations':[],'missing_validation':[],'unexplained_diff':[], 'next_change':'none'}

class StopGateBoundaryChecks(unittest.TestCase):
 def check_record(self,record,expected):
  try:
   result=gate.assess(copy.deepcopy(record)); ready=result.get('stop_ready') is True
  except (TypeError,ValueError) as e:
   result={'rejected':type(e).__name__,'message':str(e)};ready=False
  OBS.append({'test':self._testMethodName,'synthetic_input':record,'expected_stop_ready':expected,'actual_result':result,'matches_expectation':ready is expected})
  self.assertIs(ready,expected,json.dumps(result,ensure_ascii=False))

 def test_complete_standard_positive(self): self.check_record(complete(),True)
 def test_light_empty_graph_positive(self):
  r=complete();r.update(depth='light',required_nodes=[],confirmed_verified_nodes=[],semantic=[]);self.check_record(r,True)
 def test_high_risk_unknown_negative_control(self):
  r=complete();r['semantic'][0]['state']='UNKNOWN';self.check_record(r,False)
 def test_missing_consumer_negative_control(self):
  r=complete();r['confirmed_verified_nodes']=['service'];self.check_record(r,False)
 def test_deep_missing_evidence_does_not_complete(self):
  self.check_record({'mode':'refactor','depth':'deep','requirement_met':True},False)
 def test_false_string_is_not_true_requirement(self):
  r=complete();r['requirement_met']='false';self.check_record(r,False)
 def test_false_string_is_not_authorization(self):
  r=complete();r['semantic'][0].update(state='CHANGED',authorized='false');self.check_record(r,False)
 def test_misspelled_semantic_state_does_not_complete(self):
  r=complete();r['semantic'][0]['state']='UNKOWN';self.check_record(r,False)
 def test_format_mode_rejects_semantic_change_even_if_flagged_authorized(self):
  r=complete();r['mode']='format';r['semantic'][0].update(state='CHANGED',authorized=True);self.check_record(r,False)
 def test_node_string_is_not_a_node_list(self):
  r=complete();r.update(required_nodes='api',confirmed_verified_nodes='api');self.check_record(r,False)

if __name__=='__main__':
 out=Path(sys.argv[1]);out.mkdir(parents=True,exist_ok=False)
 frozen={'test_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'target_sha256':hashlib.sha256(TARGET.read_bytes()).hexdigest(),'kind':'controlled_input_boundary_tests_not_agent_AB','count':10,'goal':'Preserve legitimate light/standard records; reject incomplete/invalid claims and format semantic changes.'}
 (out/'frozen-inputs.json').write_text(json.dumps(frozen,indent=2))
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(StopGateBoundaryChecks))
 (out/'observations.json').write_text(json.dumps(OBS,ensure_ascii=False,indent=2)+'\n')
 (out/'summary.json').write_text(json.dumps({'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'all_pass':result.wasSuccessful(),'production_changed':False},indent=2))
 raise SystemExit(0 if result.wasSuccessful() else 1)
