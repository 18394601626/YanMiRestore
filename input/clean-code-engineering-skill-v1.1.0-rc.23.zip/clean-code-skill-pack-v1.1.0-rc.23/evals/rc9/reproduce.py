"""Re-run fixed evaluator checks; does not start Maven or databases.

The original 16 probes run byte-for-byte outside the release tree. Synthetic
XML/process stubs remain labeled as such. Real integration uses the separate
explicit --run entry in evals/rc8/run_integration.py.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]


def execute_check(command, cwd, output, env, timeout=40):
    output.mkdir()
    start = time.monotonic()
    status, exit_code = 'FINISHED', None
    with (output/'stdout.log').open('wb') as out, (output/'stderr.log').open('wb') as err:
        try:
            exit_code = subprocess.run(command, cwd=cwd, env=env, stdout=out,
                                       stderr=err, timeout=timeout).returncode
        except subprocess.TimeoutExpired:
            status = 'TIMEOUT'
        except OSError as exc:
            status = 'BLOCKED'
            err.write(str(exc).encode())
    result = {'command': command, 'cwd': str(cwd), 'status': status, 'exit_code': exit_code,
              'elapsed_seconds': round(time.monotonic()-start, 3)}
    for stream in ['stdout.log', 'stderr.log']:
        result[stream+'_sha256'] = hashlib.sha256((output/stream).read_bytes()).hexdigest()
    (output/'command.json').write_text(json.dumps(result,indent=2)+'\n')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    if output.exists() or output.is_relative_to(ROOT):
        parser.error('Output must be a NEW directory outside the package')
    output.mkdir(parents=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', RC8_RELEASE_ROOT=str(ROOT))
    checks = ['evals/test_package.py', 'evals/rc9/test_contract.py',
              'evals/rc8/test_runner.py', 'evals/rc9/test_hardening.py',
              'evals/rc3/test_evidence.py', 'evals/rc3/test_failure_attribution.py',
              'evals/rc6/test_change_control.py']
    results = []
    for index, rel in enumerate(checks, 1):
        results.append(execute_check([sys.executable, rel], ROOT, output/f'{index:02d}', env))
    work = output/'frozen-work'
    (work/'probes').mkdir(parents=True)
    (work/'evidence').mkdir()
    source = ROOT/'provenance/rc9/test_new_probes.py.txt'
    target = work/'probes/test_new_probes.py'
    shutil.copy2(source, target)
    results.append(execute_check([sys.executable,str(target)],work,output/'08-frozen-probes',env))
    observations = json.loads((work/'evidence/probe-observations.json').read_text()) if (work/'evidence/probe-observations.json').exists() else None
    summary = {'kind':'evaluator_unit_and_document_tests_NOT_framework_or_agent_AB',
               'at':datetime.now(timezone.utc).isoformat(), 'version':(ROOT/'VERSION').read_text().strip(),
               'runs':results, 'frozen_probe_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
               'frozen_probes_byte_identical':target.read_bytes()==source.read_bytes(),
               'frozen_result':observations,
               'all_executed_checks_passed':all(x['status']=='FINISHED' and x['exit_code']==0 for x in results),
               'real_java_compile':'NOT_RUN','real_database_integration':'NOT_RUN'}
    (output/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'all_executed_checks_passed':summary['all_executed_checks_passed'], 'output':str(output)},ensure_ascii=False))
    return 0 if summary['all_executed_checks_passed'] else 1


if __name__=='__main__':
    raise SystemExit(main())
