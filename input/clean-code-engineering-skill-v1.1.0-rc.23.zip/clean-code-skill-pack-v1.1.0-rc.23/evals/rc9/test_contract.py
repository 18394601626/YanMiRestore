"""Packaging/document checks only; not agent adherence or Java compilation."""
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[2]
BASELINE=json.loads((ROOT/'provenance/rc9/baseline-files.json').read_text())
class RC9Contract(unittest.TestCase):
    def test_version(self):
        for rel in ['VERSION','clean-code-engineering/VERSION']:
            self.assertEqual((ROOT/rel).read_text().strip(),'1.1.0-rc.9')
    def test_all_previous_reference_topics_except_evidence_unchanged(self):
        for rel,digest in BASELINE.items():
            if rel.startswith('clean-code-engineering/references/') and not rel.endswith('16-real-integration.md'):
                self.assertEqual(hashlib.sha256((ROOT/rel).read_bytes()).hexdigest(),digest,rel)
    def test_original_test_runner_unchanged(self):
        rel='evals/rc8/test_runner.py'
        self.assertEqual(hashlib.sha256((ROOT/rel).read_bytes()).hexdigest(),BASELINE[rel])
    def test_production_java_and_pom_not_modified(self):
        for rel,digest in BASELINE.items():
            if rel.startswith('evals/rc8/integration-lab/src/main/') or rel=='evals/rc8/integration-lab/pom.xml':
                self.assertEqual(hashlib.sha256((ROOT/rel).read_bytes()).hexdigest(),digest,rel)
    def test_target_assertion_messages_have_frozen_reason_ids(self):
        contract=json.loads((ROOT/'evals/rc8/contract.json').read_text())
        source=(ROOT/'evals/rc8/integration-lab/src/test/java/example/rc8/IntegrationContractTest.java').read_text()
        for name in contract['expected_baseline_failures']:
            marker=contract['failure_expectations'][name]['message_prefix']
            self.assertIn(marker,source)
            self.assertEqual(marker,'EXPECTED_CONTROL_ASSERTION: '+name)
    def test_reference_explains_evidence_contract(self):
        text=(ROOT/'clean-code-engineering/references/16-real-integration.md').read_text()
        for term in ['FLAKY_PASS','INVALID_EVIDENCE','失败原因','运行身份','DTD','仅编译','不是安全沙箱']:
            self.assertIn(term,text)
    def test_main_entry_routes_existing_reference_not_new_generic_topic(self):
        text=(ROOT/'clean-code-engineering/SKILL.md').read_text()
        self.assertIn('references/16-real-integration.md',text)
        self.assertIn('重试后通过',text)
    def test_runner_docs_preserve_blocked_and_distinct_compile_phase(self):
        text=(ROOT/'evals/rc8/README.md').read_text()
        for term in ['--phase compile','--phase integration','BLOCKED','allow-fixed','没有实际编译']:
            self.assertIn(term,text)

def suite():
    spec=importlib.util.spec_from_file_location('previous_contract',ROOT/'evals/rc8/test_contract.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    result=unittest.TestSuite()
    def add(items):
        for test in items:
            if isinstance(test,unittest.TestSuite):add(test)
            elif getattr(test,'_testMethodName','')!='test_version':result.addTest(test)
    add(module.suite());result.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(RC9Contract))
    return result
if __name__=='__main__':
    res=unittest.TextTestRunner(verbosity=2).run(suite());raise SystemExit(0 if res.wasSuccessful() else 1)
