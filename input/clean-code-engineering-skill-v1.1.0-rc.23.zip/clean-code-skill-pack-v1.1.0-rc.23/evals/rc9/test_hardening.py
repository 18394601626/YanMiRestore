"""Synthetic evaluator contracts, NOT Java/database execution or agent A/B."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('candidate_runner', ROOT/'evals/rc8/run_integration.py')
r = importlib.util.module_from_spec(spec)
spec.loader.exec_module(r)
CONTRACT = json.loads((ROOT/'evals/rc8/contract.json').read_text())
C = CONTRACT['class']
NAMES = CONTRACT['tests']
NEGATIVE = set(CONTRACT['expected_baseline_failures'])
EXPECTED = {(C, n) for n in NAMES}

def xml(mode='fixed', *, retry=None, failure_type='org.opentest4j.AssertionFailedError', message=None):
    root = ET.Element('testsuite', tests=str(len(NAMES)), failures=str(len(NEGATIVE) if mode=='baseline' else 0), errors='0', skipped='0')
    for name in NAMES:
        case = ET.SubElement(root, 'testcase', classname=C, name=name)
        if mode=='baseline' and name in NEGATIVE:
            ET.SubElement(case, 'failure', type=failure_type, message=message or 'EXPECTED_CONTROL_ASSERTION: '+name).text='original assertion stack'
        if retry and name == ('runtimeFailureRollsBack' if mode=='baseline' else 'runtimeIdentity'):
            node=ET.SubElement(case, retry, type='org.opentest4j.AssertionFailedError', message='retry failure')
            ET.SubElement(node,'stackTrace').text='retry stack'
            ET.SubElement(node,'system-out').text='must not be used as an assertion message'
    return ET.tostring(root, encoding='unicode')

def parse(raw, code=0):
    with tempfile.TemporaryDirectory() as d:
        p=Path(d)/'TEST-fixture.xml'
        p.write_bytes(raw.encode() if isinstance(raw,str) else raw)
        return r.evaluate_reports(d, code, EXPECTED)

def run_simulation(*, engine='postgres', mode_meta=None, retry=None, policy='reject', phase='integration', make_classes=True, exit_override=None):
    """Only the orchestration runs; Maven and databases are deliberately stubbed."""
    def execute(command, cwd, log, timeout):
        cwd=Path(cwd);target=cwd/'target';target.mkdir(exist_ok=True)
        Path(log).write_text('SYNTHETIC TEST ONLY: no Maven/Java/database executed.\n')
        if 'test-compile' in command:
            if make_classes:
                for rel in ['classes/example/rc8/LabApplication.class','test-classes/example/rc8/IntegrationContractTest.class']:
                    p=target/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'synthetic fixture, not JVM bytecode')
            return {'status':'FINISHED','exit_code':0 if exit_override is None else exit_override,'synthetic_process_stub':True}
        mode='baseline' if cwd.name.endswith('-baseline') else 'fixed'
        (target/'surefire-reports').mkdir()
        (target/'surefire-reports/TEST-fixture.xml').write_text(xml(mode,retry=retry if mode=='fixed' else None))
        identity={'springBoot':'3.5.6','databaseProduct':'PostgreSQL' if engine=='postgres' else 'MySQL',
                  'databaseVersion':'16.4' if engine=='postgres' else '8.4.0',
                  'imageTag':'postgres:16.4' if engine=='postgres' else 'mysql:8.4.0','fixtureMode':mode}
        payload=mode_meta(mode,identity) if mode_meta else identity
        if payload is not None:
            (target/'rc8-runtime.json').write_text(payload if isinstance(payload,str) else json.dumps(payload))
        return {'status':'FINISHED','exit_code':(1 if mode=='baseline' else 0) if exit_override is None else exit_override,'synthetic_process_stub':True}
    with tempfile.TemporaryDirectory() as d:
        out=Path(d)/'out'
        with patch.object(r,'prerequisites',return_value={'status':'READY_FOR_ATTEMPT','issues':[]}),patch.object(r,'execute',side_effect=execute),contextlib.redirect_stdout(io.StringIO()):
            code=r.run(out,[engine],True,phase=phase,retry_policy=policy)
        return code,json.loads((out/'summary.json').read_text())

class EvidenceHardening(unittest.TestCase):
    def test_valid_encodings_remain_accepted(self):
        for encoding in ['UTF-8','UTF-16','UTF-16LE','UTF-16BE']:
            with self.subTest(encoding=encoding):
                data=('<?xml version="1.0" encoding="'+encoding+'"?>'+xml()).encode(encoding)
                self.assertEqual(parse(data)['status'],'PASS')
    def test_doctype_rejected_for_all_supported_encodings(self):
        for encoding in ['UTF-8','UTF-16','UTF-16LE','UTF-16BE']:
            with self.subTest(encoding=encoding):
                data=('<?xml version="1.0" encoding="'+encoding+'"?><!DOCTYPE testsuite [<!ENTITY small "ok">]>'+xml()).encode(encoding)
                self.assertEqual(parse(data)['status'],'INVALID_EVIDENCE')
    def test_external_doctype_rejected_without_fetch(self):
        self.assertEqual(parse('<!DOCTYPE testsuite SYSTEM "urn:no-resource-to-fetch">'+xml())['status'],'INVALID_EVIDENCE')
    def test_escaped_and_commented_dtd_text_not_a_declaration(self):
        data=xml().replace('</testsuite>','<!-- <!DOCTYPE example> --><system-out>&lt;!DOCTYPE example&gt;</system-out></testsuite>')
        self.assertEqual(parse(data)['status'],'PASS')
    def test_oversized_document_is_invalid(self):
        self.assertEqual(parse(b' '*(10_000_001))['status'],'INVALID_EVIDENCE')
    def test_multiple_failure_nodes_invalid(self):
        root=ET.fromstring(xml('baseline'));case=next(c for c in root if c.find('failure') is not None)
        ET.SubElement(case,'failure',message='second contradictory failure')
        self.assertEqual(parse(ET.tostring(root),1)['status'],'INVALID_EVIDENCE')
    def test_failure_preserves_type_message_and_file(self):
        data=parse(xml('baseline'),1)['failure_details'][C+'#runtimeFailureRollsBack']
        self.assertEqual(data['type'],'org.opentest4j.AssertionFailedError')
        self.assertEqual(data['message'],'EXPECTED_CONTROL_ASSERTION: runtimeFailureRollsBack')
        self.assertEqual(data['report_file'],'TEST-fixture.xml')
    def test_real_target_marker_is_accepted(self):
        parsed=parse(xml('baseline'),1)
        self.assertTrue(r.confirm_baseline(parsed,CONTRACT)['confirmed'])
    def test_wrong_failure_type_not_accepted(self):
        parsed=parse(xml('baseline',failure_type='org.opentest4j.MultipleFailuresError'),1)
        self.assertFalse(r.confirm_baseline(parsed,CONTRACT)['confirmed'])
    def test_marker_only_in_stack_not_accepted(self):
        root=ET.fromstring(xml('baseline'))
        for case in root:
            node=case.find('failure')
            if node is not None:
                node.text=node.get('message');node.set('message','fixture database never started')
        self.assertFalse(r.confirm_baseline(parse(ET.tostring(root),1),CONTRACT)['confirmed'])
    def test_marker_embedded_in_unrelated_message_not_accepted(self):
        self.assertFalse(r.confirm_baseline(parse(xml('baseline',message='unrelated EXPECTED_CONTROL_ASSERTION: runtimeFailureRollsBack'),1),CONTRACT)['confirmed'])
    def test_failure_under_wrong_method_not_accepted(self):
        root=ET.fromstring(xml('baseline'))
        for case in root:
            node=case.find('failure')
            if node is not None:node.set('message','EXPECTED_CONTROL_ASSERTION: someOtherMethod')
        self.assertFalse(r.confirm_baseline(parse(ET.tostring(root),1),CONTRACT)['confirmed'])
    def test_nonzero_required_for_negative_control(self):
        self.assertFalse(r.confirm_baseline(parse(xml('baseline'),0),CONTRACT)['confirmed'])
    def test_flaky_history_is_explicit(self):
        for tag in ['flakyFailure','flakyError']:
            with self.subTest(tag=tag):
                result=parse(xml(retry=tag));self.assertEqual(result['status'],'FLAKY_PASS')
                history=result['retries'][C+'#runtimeIdentity']
                self.assertEqual(history['rerun_count'],1);self.assertEqual(history['attempts'],2)
                self.assertEqual(history['failed_attempts'][0]['kind'],tag)
                self.assertNotIn(C+'#runtimeIdentity',result['first_attempt_passed'])
    def test_fail_after_retries_preserves_attempts_and_is_not_first_run_evidence(self):
        result=parse(xml('baseline',retry='rerunError'),1)
        self.assertEqual(result['status'],'TEST_FAIL')
        self.assertEqual(result['retries'][C+'#runtimeFailureRollsBack']['attempts'],2)
        self.assertFalse(r.confirm_baseline(result,CONTRACT)['confirmed'])
    def test_rerun_without_original_failure_invalid(self):
        self.assertEqual(parse(xml(retry='rerunFailure'))['status'],'INVALID_EVIDENCE')
    def test_flaky_mixed_with_terminal_failure_invalid(self):
        self.assertEqual(parse(xml('baseline',retry='flakyFailure'),1)['status'],'INVALID_EVIDENCE')
    def test_missing_or_damaged_identity_does_not_drop_next_result(self):
        for broken in [None,'{bad',[],{'fixtureMode':False}]:
            with self.subTest(broken=broken):
                code,s=run_simulation(mode_meta=lambda m,i:broken if m=='baseline' else i)
                self.assertEqual(code,2);self.assertEqual(len(s['integration_results']),2)
                self.assertEqual(s['integration_results'][0]['status'],'INVALID_EVIDENCE')
                self.assertTrue(s['integration_results'][1]['comparison_confirmed'])
    def test_mysql_identity_positive(self):
        code,s=run_simulation(engine='mysql');self.assertEqual(code,0)
        self.assertEqual(s['status'],'EXPECTED_OBSERVATIONS_REPRODUCED')
    def test_runtime_required_field_validation(self):
        for key in ['springBoot','imageTag','databaseVersion','databaseProduct','fixtureMode']:
            with self.subTest(key=key):
                def wrong(m,i):i[key]=' ';return i
                code,s=run_simulation(mode_meta=wrong);self.assertEqual(code,2)
                self.assertTrue(all(x['status']=='INVALID_EVIDENCE' for x in s['integration_results']))
    def test_duplicate_identity_keys_invalid(self):
        def bad(m,i):return json.dumps(i)[:-1]+',"fixtureMode":"'+m+'"}'
        code,s=run_simulation(mode_meta=bad);self.assertEqual(code,2)
        self.assertEqual(s['integration_results'][0]['status'],'INVALID_EVIDENCE')
    def test_runtime_version_or_image_mismatch_invalid(self):
        for key,value in [('springBoot','3.5.7'),('databaseVersion','15.4'),('imageTag','postgres:15.4')]:
            with self.subTest(key=key):
                def bad(m,i):i[key]=value;return i
                code,s=run_simulation(mode_meta=bad);self.assertEqual(code,2)
    def test_flaky_fixed_requires_explicit_allowance(self):
        code,s=run_simulation(retry='flakyFailure');self.assertEqual(code,2)
        self.assertEqual(s['integration_results'][1]['status'],'FLAKY_PASS')
        code,s=run_simulation(retry='flakyFailure',policy='allow-fixed');self.assertEqual(code,0)
        self.assertEqual(s['integration_results'][1]['status'],'FLAKY_PASS')
        self.assertEqual(s['retry_policy'],'allow-fixed')
    def test_compile_mode_does_not_require_docker(self):
        seen=[]
        def which(tool):seen.append(tool);return '/synthetic/'+tool
        def exec_stub(command,cwd,log,timeout):
            Path(log).write_text('openjdk version "21.0.11"\n' if 'java' in command[0] else 'Apache Maven test-double\n')
            return {'status':'FINISHED','exit_code':0}
        with tempfile.TemporaryDirectory() as d,patch.object(r.shutil,'which',side_effect=which),patch.object(r,'execute',side_effect=exec_stub):
            self.assertEqual(r.prerequisites(Path(d),require_docker=False)['status'],'READY_FOR_ATTEMPT')
        self.assertNotIn('docker',seen)
    def test_compile_mode_records_artifacts_without_claiming_tests(self):
        code,s=run_simulation(phase='compile');self.assertEqual(code,0)
        self.assertEqual(s['status'],'COMPILED');self.assertTrue(s['candidate_source_compiled'])
        self.assertTrue(all(i['observed_tests']==0 and i['status']=='NOT_RUN' for i in s['integration_results']))
    def test_compile_exit_zero_without_class_is_not_success(self):
        code,s=run_simulation(phase='compile',make_classes=False);self.assertEqual(code,2)
        self.assertEqual(s['build_result']['status'],'INVALID_EVIDENCE')
        self.assertFalse(s['candidate_source_compiled'])
    def test_failed_build_not_reported_as_compiled(self):
        code,s=run_simulation(phase='compile',exit_override=1);self.assertEqual(code,2)
        self.assertEqual(s['build_result']['status'],'BUILD_FAILED')
        self.assertFalse(s['candidate_source_compiled'])

if __name__=='__main__': unittest.main(verbosity=2)
