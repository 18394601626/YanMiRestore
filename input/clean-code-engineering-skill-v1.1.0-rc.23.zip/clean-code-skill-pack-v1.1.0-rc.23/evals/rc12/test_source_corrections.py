"""Regression assertions for three manually verified source details, not a semantic proof."""
import json
import os
from pathlib import Path
import unittest

ROOT = Path(os.environ.get("BOOK_PACK_ROOT", Path(__file__).resolve().parents[2]))
BOOK = ROOT / "clean-code-engineering/references/book"

class SourceCorrections(unittest.TestCase):
    def setUp(self):
        self.cards = {c["id"]: c for c in json.loads((BOOK / "cards.json").read_text(encoding="utf-8"))}

    def test_3_9_2_retains_try_position_and_end_boundary(self):
        text = self.cards["BK-3-9-2"]["principle"]
        self.assertIn("try", text)
        self.assertIn("第一个", text)
        self.assertIn("catch/finally", text)
        self.assertIn("之后不再", text)

    def test_6_3_enumerates_four_callable_object_categories(self):
        text = self.cards["BK-6-3"]["principle"]
        for phrase in ["C 本身", "f 创建的对象", "传给 f 的参数对象", "C 的实体变量持有的对象"]:
            self.assertIn(phrase, text)

    def test_index_calls_them_subsections_including_example(self):
        text = (BOOK / "INDEX.md").read_text(encoding="utf-8")
        self.assertNotRegex(text, r"19\s*类坏注释")
        self.assertIn("19个子小节", text)
        self.assertIn("4.4.19", text)
        self.assertIn("范例", text)

    def test_language_boundary_and_data_structure_distinction_retained(self):
        self.assertIn("语言", self.cards["BK-3-9-2"]["qualification"])
        for phrase in ["对象", "数据结构", "点号"]:
            self.assertIn(phrase, self.cards["BK-6-3"]["qualification"])

    def test_source_locations_and_card_identity_preserved(self):
        self.assertEqual(self.cards["BK-3-9-2"]["pdf_pages"], [60, 60])
        self.assertEqual(self.cards["BK-6-3"]["pdf_pages"], [107, 108])
        self.assertEqual(self.cards["BK-4-4-19"]["title"], "范例")
        coverage = json.loads((BOOK / "coverage.json").read_text(encoding="utf-8"))
        self.assertFalse(coverage["all_knowledge_points_complete"])
        self.assertFalse(coverage["agent_behavior_tested"])
        self.assertIsNone(coverage["semantic_coverage_percentage"])

if __name__ == "__main__":
    unittest.main(verbosity=2)
