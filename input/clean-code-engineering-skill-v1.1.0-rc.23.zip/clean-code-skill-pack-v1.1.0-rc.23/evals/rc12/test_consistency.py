"""Tests on actual corpus copies; deliberate mutations are not AI output."""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest

ROOT = Path(os.environ.get("BOOK_PACK_ROOT", Path(__file__).resolve().parents[2])).resolve()
CHECKER = Path(os.environ.get("BOOK_CHECKER", Path(__file__).resolve().parents[1] / "book/check_consistency.py"))
spec = importlib.util.spec_from_file_location("book_consistency_subject", CHECKER)
subject = importlib.util.module_from_spec(spec)
spec.loader.exec_module(subject)

class CorpusConsistency(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix="rc12-test-")
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.book = self.root / "clean-code-engineering/references/book"
        shutil.copytree(ROOT / "clean-code-engineering/references/book", self.book)
        self.cards = json.loads((self.book / "cards.json").read_text(encoding="utf-8"))
        self.cov = json.loads((self.book / "coverage.json").read_text(encoding="utf-8"))

    def card(self, ident="BK-9-4"):
        return next(c for c in self.cards if c["id"] == ident)

    def save(self):
        (self.book / "cards.json").write_text(json.dumps(self.cards, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (self.book / "coverage.json").write_text(json.dumps(self.cov, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    def change_markdown(self, old, new, card=None):
        card = card or self.card()
        path = self.book / card["target"].split("#")[0]
        text = path.read_text(encoding="utf-8")
        tag = '<a id="' + card["target"].split("#")[1] + '"></a>'
        start = text.index(tag)
        end = text.find('\n<a id=', start + len(tag))
        if end == -1:
            end = len(text)
        segment = text[start:end]
        self.assertEqual(segment.count(old), 1)
        path.write_text(text[:start] + segment.replace(old, new, 1) + text[end:], encoding="utf-8")

    def outcome(self):
        return subject.corpus_check(self.root)

    def rejected(self):
        result = self.outcome()
        self.assertFalse(result["ok"], "malformed or divergent corpus must not pass")
        self.assertTrue(result["errors"])

    def test_current_corpus_passes(self):
        self.assertTrue(self.outcome()["ok"])

    def test_principle_changed_in_markdown_is_rejected(self):
        self.change_markdown(self.card()["principle"], "【测试专用错误】正文不同步。")
        self.rejected()

    def test_qualification_changed_in_markdown_is_rejected(self):
        self.change_markdown(self.card()["qualification"], "【测试专用错误】每个测试只能有一个断言。")
        self.rejected()

    def test_execution_question_changed_in_markdown_is_rejected(self):
        self.change_markdown(self.card()["execution_question"], "【测试专用错误】无关的问题？")
        self.rejected()

    def test_appended_conflicting_text_is_not_hidden_by_substring_match(self):
        old = self.card()["qualification"]
        self.change_markdown(old, old + "【测试专用错误】但出现第二个断言必须判错。")
        self.rejected()

    def test_json_only_change_is_rejected(self):
        self.card()["principle"] = "【测试专用错误】JSON单方面改变。"
        self.save(); self.rejected()

    def test_wrong_existing_card_link_is_rejected(self):
        next(r for r in self.cov["toc"] if r["id"] == "7.7")["card_ids"] = ["BK-7-8"]
        self.save(); self.rejected()

    def test_card_side_missing_edge_is_rejected(self):
        self.card()["section_ids"] = ["9.3.2"]
        self.save(); self.rejected()

    def test_unknown_card_id_is_rejected(self):
        next(r for r in self.cov["toc"] if r["id"] == "7.7")["card_ids"] = ["BK-NOT-PRESENT"]
        self.save(); self.rejected()

    def test_unknown_section_id_is_rejected(self):
        self.card()["section_ids"].append("NOT-A-SECTION")
        self.save(); self.rejected()

    def test_duplicate_edge_is_rejected(self):
        row = next(r for r in self.cov["toc"] if r["id"] == "7.7")
        row["card_ids"].append(row["card_ids"][0])
        self.save(); self.rejected()

    def test_duplicate_card_identity_is_rejected(self):
        self.cards.append(dict(self.card()))
        self.cov["card_count"] = len(self.cards)
        self.save(); self.rejected()

    def test_duplicate_directory_identity_is_rejected(self):
        self.cov["toc"].append(dict(self.cov["toc"][0]))
        self.cov["toc_count"] += 1
        self.cov["toc_status_counts"]["CHAPTER_INDEX"] += 1
        self.save(); self.rejected()

    def test_missing_anchor_is_reported_not_crashed(self):
        tag = '<a id="' + self.card()["target"].split("#")[1] + '"></a>'
        self.change_markdown(tag, "<!-- removed for test -->")
        self.rejected()

    def test_duplicate_anchor_is_rejected(self):
        tag = '<a id="' + self.card()["target"].split("#")[1] + '"></a>'
        self.change_markdown(tag, tag + "\n" + tag)
        self.rejected()

    def test_metadata_count_mismatch_is_rejected(self):
        self.cov["card_count"] += 1
        self.save(); self.rejected()

    def test_markdown_title_drift_is_rejected(self):
        old = "## " + self.card()["id"] + "｜" + self.card()["title"]
        self.change_markdown(old, old + "【测试用错误标题】")
        self.rejected()

    def test_markdown_page_only_drift_is_rejected(self):
        card = self.card("BK-12-6")
        self.change_markdown("书内 162 页；PDF第 176 页", "书内 94 页；PDF第 110 页", card)
        self.rejected()

    def test_truncated_json_is_reported_not_crashed(self):
        (self.book / "cards.json").write_text("[", encoding="utf-8")
        self.rejected()

    def test_target_escape_is_rejected_before_file_access(self):
        self.card()["target"] = "../../../../outside.md#invalid"
        self.save(); self.rejected()

    def test_synchronized_wrong_meaning_remains_outside_mechanical_scope(self):
        card = self.card("BK-12-1")
        old = card["principle"]
        new = "【故意错误，不是可用知识】简单设计首先减少类和方法，测试可以让步。"
        self.change_markdown(old, new, card)
        card["principle"] = new
        self.save()
        self.assertTrue(self.outcome()["ok"], "consistency must not be described as source-truth proof")

    def test_synchronized_unrelated_page_remains_outside_mechanical_scope(self):
        card = self.card("BK-12-6")
        self.change_markdown("书内 162 页；PDF第 176 页", "书内 94 页；PDF第 110 页", card)
        card["book_pages"] = [94, 94]
        card["pdf_pages"] = [110, 110]
        self.save()
        self.assertTrue(self.outcome()["ok"], "valid matching page numbers need manual source review")

if __name__ == "__main__":
    unittest.main(verbosity=2)
