"""Run this release's owned document checks. No network, model or business execution."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    output = args.output.resolve()
    if output.exists() or output == root or root in output.parents:
        parser.error('output must be new and outside the package root')
    output.mkdir(parents=True)
    env = dict(os.environ, BOOK_PACK_ROOT=str(root), PYTHONDONTWRITEBYTECODE='1')
    env.pop('BOOK_CHECKER', None)
    stages = [
        ('package', 'evals/test_package.py', 8),
        ('book-index', 'evals/book/test_book_coverage.py', 12),
        ('source-corrections', 'evals/rc12/test_source_corrections.py', 5),
        ('consistency-regressions', 'evals/rc12/test_consistency.py', 22),
        ('corpus-inspection', 'evals/book/check_consistency.py', None),
    ]
    rows = []
    for label, script, expected_count in stages:
        command = [sys.executable, script]
        started = datetime.now(timezone.utc).isoformat()
        clock = time.monotonic()
        row = dict(label=label, command=command, cwd=str(root), started_utc=started)
        stdout, stderr = b'', b''
        try:
            proc = subprocess.run(command, cwd=root, env=env, capture_output=True, timeout=45)
            stdout, stderr = proc.stdout, proc.stderr
            row['exit_code'] = proc.returncode
            row['status'] = 'PASS' if proc.returncode == 0 else 'FAIL'
            if expected_count is not None:
                match = re.search(rb'^Ran (\d+) tests? in ', stderr, re.MULTILINE)
                count = int(match.group(1)) if match else 0
                row.update(expected_test_methods=expected_count, observed_test_methods=count)
                if count != expected_count:
                    row['status'] = 'INCOMPLETE'
            elif not json.loads(stdout)['ok']:
                row['status'] = 'FAIL'
        except subprocess.TimeoutExpired as exc:
            row.update(status='TIMEOUT', exit_code=None)
            stdout, stderr = exc.stdout or b'', exc.stderr or b''
        except (OSError, ValueError, KeyError) as exc:
            row.update(status='ERROR', exit_code=None)
            stderr += (str(exc) + '\n').encode('utf-8')
        row.update(seconds=time.monotonic() - clock,
                   stdout_sha256=digest(stdout), stderr_sha256=digest(stderr))
        (output / (label + '.stdout')).write_bytes(stdout)
        (output / (label + '.stderr')).write_bytes(stderr)
        rows.append(row)
        print(label, row['status'], flush=True)
    complete = all(r['status'] == 'PASS' for r in rows)
    result = dict(kind='document_consistency_not_semantic_or_agent_evaluation',
                  version=(root / 'VERSION').read_text().strip(), commands=rows,
                  observed_test_methods=sum(r.get('observed_test_methods', 0) for r in rows),
                  all_pass=complete,
                  note='Two sensitivity controls intentionally demonstrate semantic mistakes surviving mechanical checks. No full-book or agent-performance claim.')
    (output / 'summary.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return 0 if complete else 1


if __name__ == '__main__':
    raise SystemExit(main())
