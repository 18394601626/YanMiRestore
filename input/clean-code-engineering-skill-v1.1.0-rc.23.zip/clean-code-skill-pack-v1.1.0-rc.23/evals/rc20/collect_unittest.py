"""Collect exact per-test results, including skips. No language/tool spoofing."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import unittest

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('test_file',type=Path);parser.add_argument('report',type=Path)
    args=parser.parse_args()
    old=load('previous_result',Path(os.environ['RC20_TARGET_ROOT'])/'evals/rc19/run_python_suite.py')
    module=load('rc20_suite',args.test_file)
    suite=unittest.defaultTestLoader.loadTestsFromModule(module)
    result=unittest.TextTestRunner(verbosity=2,resultclass=old.RecordedResult).run(suite)
    report={'tests_run':result.testsRun,'success':result.wasSuccessful(),'failures':len(result.failures),
        'errors':len(result.errors),'skipped':len(result.skipped),'records':result.records}
    args.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    raise SystemExit(1 if not result.wasSuccessful() else (2 if result.skipped else 0))
