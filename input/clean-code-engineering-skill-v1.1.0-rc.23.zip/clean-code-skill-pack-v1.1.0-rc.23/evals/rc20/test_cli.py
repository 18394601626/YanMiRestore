import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
ENTRY=ROOT/'evals/rc20/reproduce.py'
class CLIContracts(unittest.TestCase):
    def test_help(self):
        p=subprocess.run([sys.executable,'-S',str(ENTRY),'--help'],capture_output=True,timeout=10)
        self.assertEqual(p.returncode,0);self.assertIn(b'--focused',p.stdout)
    def test_existing_output_is_not_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'existing';out.mkdir();(out/'sentinel').write_text('keep')
            p=subprocess.run([sys.executable,'-S',str(ENTRY),'--output',str(out)],capture_output=True,timeout=10)
            self.assertEqual(p.returncode,2);self.assertIn(b'new and outside',p.stderr)
            self.assertEqual((out/'sentinel').read_text(),'keep');self.assertEqual(len(list(out.iterdir())),1)
    def test_tools_only_and_focused_cannot_be_combined(self):
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'new'
            p=subprocess.run([sys.executable,'-S',str(ENTRY),'--output',str(out),'--tools-only','--focused'],capture_output=True,timeout=10)
            self.assertEqual(p.returncode,2);self.assertIn(b'not allowed',p.stderr);self.assertFalse(out.exists())
    def test_package_output_is_rejected(self):
        p=subprocess.run([sys.executable,'-S',str(ENTRY),'--output',str(ROOT)],capture_output=True,timeout=10)
        self.assertEqual(p.returncode,2);self.assertIn(b'new and outside',p.stderr)
if __name__=='__main__':unittest.main(verbosity=2)
