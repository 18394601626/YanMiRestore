"""Line-per-argument contract: zero arguments produce zero bytes, not a blank row.
This is not an invertible argv serialization for arguments containing newlines.
"""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
SOURCE=Path(os.environ['RC20_TARGET_ROOT'])/'evals/rc17/fixtures/bash/fixed/solution.sh'
class BashArgumentTests(unittest.TestCase):
    def invoke(self,script,*args,stdin=b''):
        with tempfile.TemporaryDirectory(prefix='rc20-shell-') as tmp:
            return subprocess.run(['bash','--noprofile','--norc','-c',
              'source "$1"; shift; '+script,'case',str(SOURCE),*args],
              cwd=tmp,input=stdin,capture_output=True,timeout=5,
              env={k:v for k,v in os.environ.items() if k not in ('BASH_ENV','ENV','SHELLOPTS','BASHOPTS')})
    def test_zero_arguments_produce_no_rows(self):
        r=self.invoke('emit_args');self.assertEqual(r.returncode,0);self.assertEqual(r.stdout,b'')
    def test_one_empty_argument_is_one_empty_row(self):
        r=self.invoke('emit_args "$@"','');self.assertEqual(r.returncode,0);self.assertEqual(r.stdout,b'\n')
    def test_multiple_empty_arguments(self):
        r=self.invoke('emit_args "$@"','','','');self.assertEqual(r.returncode,0);self.assertEqual(r.stdout,b'\n\n\n')
    def test_literal_format_and_special_values(self):
        r=self.invoke('emit_args "$@"','%s','-n','a b','*','中文','a\\b')
        self.assertEqual(r.returncode,0);self.assertEqual(r.stdout,'%s\n-n\na b\n*\n中文\na\\b\n'.encode())
    def test_output_failure_not_reported_as_success(self):
        if not Path('/dev/full').exists():self.skipTest('Linux /dev/full unavailable')
        r=self.invoke('emit_args content > /dev/full');self.assertNotEqual(r.returncode,0)
    def test_no_caller_option_change(self):
        r=self.invoke('set -u; set -o pipefail; a=$(set +o); emit_args x >/dev/null; b=$(set +o); [[ "$a" == "$b" ]]')
        self.assertEqual(r.returncode,0,r.stderr)
    def test_empty_batch_succeeds_under_errexit(self):
        r=self.invoke('set -eu; emit_args; printf DONE');self.assertEqual(r.returncode,0);self.assertEqual(r.stdout,b'DONE')
    def test_empty_line_is_success_not_eof(self):
        r=self.invoke('first_line',stdin=b'\nnext');self.assertEqual(r.returncode,0);self.assertEqual(r.stdout,b'')
if __name__=='__main__':unittest.main(verbosity=2)
