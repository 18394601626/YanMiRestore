"""Actual sqlite3 transaction-policy checks, not database mocks.

The adapter owns explicit BEGIN. A normal return must commit, and any failure
must end that owned transaction without changing a caller's autocommit policy.
Python 3.12+ is needed for the explicit autocommit parameter; older runtimes
must record these targets as skipped, not count them as passing.
"""
import importlib.util
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest

ROOT = Path(os.environ['RC20_TARGET_ROOT'])
spec = importlib.util.spec_from_file_location('sql_subject', ROOT/'evals/rc18/sql/fixed/solution.py')
solution = importlib.util.module_from_spec(spec)
spec.loader.exec_module(solution)

class SQLPolicyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='rc20-sql-')
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)/'data.sqlite'
        with sqlite3.connect(self.path) as db:
            db.executescript('''
            CREATE TABLE accounts(id INTEGER PRIMARY KEY, name TEXT,
              quantity INTEGER NOT NULL CHECK(quantity >= 0), deleted INTEGER NOT NULL DEFAULT 0);
            INSERT INTO accounts VALUES(1,'Ada',10,0),(2,'Bo',20,0);
            ''')
        db.close()

    def connection(self, policy='legacy'):
        if policy != 'legacy' and not hasattr(sqlite3.Connection, 'autocommit'):
            self.skipTest('autocommit parameter requires Python 3.12+')
        kwargs = {'isolation_level':None} if policy == 'legacy' else {'autocommit':policy}
        db = sqlite3.connect(self.path, timeout=0.0, **kwargs)
        self.addCleanup(db.close)
        db.execute('PRAGMA foreign_keys=ON')
        return db

    def committed(self):
        db = sqlite3.connect(self.path, timeout=0.0)
        try: return db.execute('SELECT id,quantity,typeof(quantity) FROM accounts ORDER BY id').fetchall()
        finally: db.close()

    def test_legacy_success(self):
        db=self.connection(); solution.replace_quantities(db,[(1,30)])
        self.assertFalse(db.in_transaction); self.assertEqual(self.committed()[0],(1,30,'integer'))

    def test_legacy_failure_rollback(self):
        db=self.connection(); before=self.committed()
        with self.assertRaises(ValueError):solution.replace_quantities(db,[(1,30),(2,'bad')])
        self.assertFalse(db.in_transaction); self.assertEqual(self.committed(),before)

    def test_autocommit_true_success_is_committed(self):
        db=self.connection(True); solution.replace_quantities(db,[(1,30),(2,40)])
        self.assertEqual(self.committed(),[(1,30,'integer'),(2,40,'integer')])
        self.assertFalse(db.in_transaction); self.assertIs(db.autocommit,True)

    def test_autocommit_true_failure_rolls_back_local_state(self):
        db=self.connection(True)
        with self.assertRaises(ValueError):solution.replace_quantities(db,[(1,30),(2,'bad')])
        self.assertEqual(db.execute('SELECT quantity FROM accounts ORDER BY id').fetchall(),[(10,),(20,)])
        self.assertFalse(db.in_transaction); self.assertEqual(self.committed()[0][1],10)

    def test_autocommit_true_empty_batch_closes_transaction(self):
        db=self.connection(True); solution.replace_quantities(db,[])
        self.assertFalse(db.in_transaction); self.assertEqual(self.committed()[0][1],10)

    def test_autocommit_true_iterator_error_identity_and_rollback(self):
        db=self.connection(True); original=LookupError('iterator failure')
        def rows():
            yield (1,80)
            raise original
        with self.assertRaises(LookupError) as caught:solution.replace_quantities(db,rows())
        self.assertIs(caught.exception,original); self.assertFalse(db.in_transaction)
        self.assertEqual(db.execute('SELECT quantity FROM accounts WHERE id=1').fetchone()[0],10)

    def test_autocommit_true_commit_failure_is_observed_and_rolled_back(self):
        db=self.connection(True)
        db.executescript('''
        CREATE TABLE allowed(n INTEGER PRIMARY KEY); INSERT INTO allowed VALUES(10),(20);
        CREATE TABLE audit(n INTEGER REFERENCES allowed(n) DEFERRABLE INITIALLY DEFERRED);
        CREATE TRIGGER log_update AFTER UPDATE ON accounts BEGIN INSERT INTO audit VALUES(new.quantity); END;
        ''')
        trace=[];db.set_trace_callback(trace.append)
        with self.assertRaises(sqlite3.IntegrityError):solution.replace_quantities(db,[(1,20),(2,99)])
        self.assertIn('COMMIT',[s.strip().upper() for s in trace]); self.assertFalse(db.in_transaction)
        self.assertEqual(self.committed(),[(1,10,'integer'),(2,20,'integer')])
        self.assertEqual(db.execute('SELECT count(*) FROM audit').fetchone()[0],0)

    def conflict_case(self,policy):
        db=self.connection(policy)
        db.executescript('''CREATE TRIGGER reject_quantity BEFORE UPDATE ON accounts
            WHEN new.quantity=99 BEGIN SELECT RAISE(ROLLBACK,'REJECT_99'); END;''')
        with self.assertRaises(sqlite3.IntegrityError) as caught:
            solution.replace_quantities(db,[(1,50),(2,99)])
        self.assertIn('REJECT_99',str(caught.exception));self.assertFalse(db.in_transaction)
        self.assertEqual(self.committed(),[(1,10,'integer'),(2,20,'integer')])

    def test_engine_rollback_legacy_keeps_original_error(self):self.conflict_case('legacy')
    def test_engine_rollback_autocommit_keeps_original_error(self):self.conflict_case(True)

    def test_autocommit_false_caller_transaction_not_taken_over(self):
        db=self.connection(False); used=[]
        def rows():
            used.append(True);yield (1,30)
        self.assertTrue(db.in_transaction)
        with self.assertRaises(RuntimeError):solution.replace_quantities(db,rows())
        self.assertEqual(used,[]);self.assertTrue(db.in_transaction);self.assertIs(db.autocommit,False)

    def test_true_mode_existing_transaction_not_taken_over(self):
        db=self.connection(True);db.execute('BEGIN');db.execute('UPDATE accounts SET quantity=50 WHERE id=1')
        with self.assertRaises(RuntimeError):solution.replace_quantities(db,[(2,60)])
        self.assertTrue(db.in_transaction);self.assertEqual(self.committed()[0][1],10)
        self.assertEqual(db.execute('SELECT quantity FROM accounts WHERE id=1').fetchone()[0],50)
        db.execute('ROLLBACK')

    def test_reuse_after_rejected_batch_autocommit(self):
        db=self.connection(True)
        with self.assertRaises(LookupError):solution.replace_quantities(db,[(1,80),(99,30)])
        self.assertFalse(db.in_transaction)
        solution.replace_quantities(db,[(1,60)])
        self.assertFalse(db.in_transaction);self.assertEqual(self.committed()[0][1],60)

    def test_commit_busy_rolls_back_without_losing_connection(self):
        db=self.connection(True); reader=self.connection()
        reader.execute('BEGIN');reader.execute('SELECT * FROM accounts').fetchall()
        trace=[];db.set_trace_callback(trace.append)
        try:
            with self.assertRaises(sqlite3.OperationalError):solution.replace_quantities(db,[(1,70)])
            self.assertIn('COMMIT',[s.strip().upper() for s in trace]);self.assertFalse(db.in_transaction)
        finally:reader.execute('ROLLBACK')
        self.assertEqual(self.committed()[0][1],10)
        solution.replace_quantities(db,[(1,70)]);self.assertEqual(self.committed()[0][1],70)

    def test_autocommit_configuration_not_changed(self):
        db=self.connection(True); before=(db.autocommit,db.isolation_level)
        solution.replace_quantities(db,[(1,15)])
        self.assertEqual((db.autocommit,db.isolation_level),before)
        self.assertFalse(db.in_transaction)

if __name__=='__main__':unittest.main(verbosity=2)
