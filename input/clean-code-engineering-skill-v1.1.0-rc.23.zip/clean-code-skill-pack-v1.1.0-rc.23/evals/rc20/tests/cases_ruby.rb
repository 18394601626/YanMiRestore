# Preserve Ruby's existing ensure exception precedence; do not impose JVM rules.
require ARGV.fetch(0)
class Resource
 attr_reader :count
 def initialize(error=nil,events=[],name='r');@error=error;@events=events;@name=name;@count=0;end
 def close;@count+=1;@events << @name;raise @error if @error;end
end
def check(value);raise 'CONTRACT_NOT_MET' unless value;end
cases = [
 -> {r=Resource.new;result=consume_owned(r){false};check(result==false && r.count==1)},
 -> {r=Resource.new;marker=RuntimeError.new('work');seen=nil;begin;consume_owned(r){raise marker};rescue => e;seen=e;end;check(seen.equal?(marker) && r.count==1)},
 -> {marker=IOError.new('close');r=Resource.new(marker);seen=nil;begin;consume_owned(r){7};rescue => e;seen=e;end;check(seen.equal?(marker) && r.count==1)},
 -> {work=RuntimeError.new('work');close=IOError.new('close');r=Resource.new(close);seen=nil;begin;consume_owned(r){raise work};rescue => e;seen=e;end;check(seen.equal?(close) && seen.cause.equal?(work) && r.count==1)},
 -> {events=[];a=Resource.new(nil,events,'outer');b=Resource.new(nil,events,'inner');begin;consume_owned(a){consume_owned(b){raise ArgumentError,'stop'}};rescue ArgumentError;end;check(events==['inner','outer'])},
 -> {source={tags:['a'.freeze,'b'.freeze].freeze}.freeze;copy=snapshot(source);copy[:tags][0]<<'x';copy[:tags]<<'c';check(source[:tags]==['a','b'])},
 -> {target=[9];result=replace_quantities(target,[]);check(result.equal?(target) && target.empty?)},
 -> {check(parse_quantity('0')==0);check(parse_quantity('9'*80)==10**80-1);['','+1','-1','1\n',"1\0",'1_0',' 1'].each{|text|rejected=false;begin;parse_quantity(text);rescue ArgumentError;rejected=true;end;check(rejected)}}
]
failed=0
cases.each_with_index do |test,index|
 id=format('RBEX%02d',index+1)
 begin;test.call;puts "CASE #{id} PASS";rescue StandardError=>e;failed+=1;puts "CASE #{id} FAIL";warn "#{id}: #{e.class}: #{e.message}";end
end
exit(failed.zero? ? 0 : 1)
