import java.io.Closeable
import java.io.IOException
import kotlin.system.exitProcess
class Counted(private val events: MutableList<String>, private val name: String,
              private val error: Throwable? = null): Closeable {
    var count = 0
    override fun close() { count++; events.add(name); if(error!=null) throw error }
}
fun requireTrue(v:Boolean){check(v){"CONTRACT_NOT_MET"}}
fun main() {
    val cases = listOf<Pair<String,()->Unit>>(
        "KTEX01" to {val r=Counted(mutableListOf(),"r");val marker=Any();requireTrue(consumeOwned(r){marker}===marker);requireTrue(r.count==1)},
        "KTEX02" to {val e=IOException("close");val r=Counted(mutableListOf(),"r",e);var seen:Throwable?=null;try{consumeOwned(r){3}}catch(t:Throwable){seen=t};requireTrue(seen===e);requireTrue(r.count==1)},
        "KTEX03" to {val work=IllegalStateException("work");val close=IOException("close");val r=Counted(mutableListOf(),"r",close);var seen:Throwable?=null;try{consumeOwned(r){throw work}}catch(t:Throwable){seen=t};requireTrue(seen===work);requireTrue(work.suppressed.size==1 && work.suppressed[0]===close);requireTrue(r.count==1)},
        "KTEX04" to {val order=mutableListOf<String>();val a=Counted(order,"outer");val b=Counted(order,"inner");val error=IllegalStateException("stop");var seen:Throwable?=null;try{consumeOwned(a){consumeOwned(b){throw error}}}catch(t:Throwable){seen=t};requireTrue(seen===error);requireTrue(order==listOf("inner","outer"))},
        "KTEX05" to {val a=Profile(mutableListOf("a"));val b=snapshot(a);b.tags.add("b");a.tags.add("c");requireTrue(a.tags==listOf("a","c"));requireTrue(b.tags==listOf("a","b"))},
        "KTEX06" to {requireTrue(checkedAdd(Int.MAX_VALUE,0)==Int.MAX_VALUE);requireTrue(checkedAdd(Int.MIN_VALUE,0)==Int.MIN_VALUE);for(pair in listOf(Int.MAX_VALUE to 1,Int.MIN_VALUE to -1)){var error=false;try{checkedAdd(pair.first,pair.second)}catch(e:ArithmeticException){error=true};requireTrue(error)}},
        "KTEX07" to {val old=mutableListOf(7);var error=false;try{replaceQuantities(old,listOf("1","2147483648"))}catch(e:IllegalArgumentException){error=true};requireTrue(error && old==listOf(7))},
        "KTEX08" to {val old=mutableListOf(7);replaceQuantities(old,emptyList());requireTrue(old.isEmpty())},
        "KTEX09" to {val error=IllegalStateException("source");val source=object:AbstractList<String>(){override val size:Int get()=2;override fun get(index:Int):String{if(index==1)throw error;return "1"}};val old=mutableListOf(7);var seen:Throwable?=null;try{replaceQuantities(old,source)}catch(t:Throwable){seen=t};requireTrue(seen===error && old==listOf(7))},
        "KTEX10" to {val parse:(String)->Int=::parseQuantity;val choose:(String?)->String=::defaultName;requireTrue(parse("2147483647")==Int.MAX_VALUE);requireTrue(choose("")=="");requireTrue(choose(null)=="default")}
    )
    var failures=0
    for((id,test) in cases){try{test();println("CASE $id PASS")}catch(t:Throwable){failures++;println("CASE $id FAIL");System.err.println("$id: $t")}}
    exitProcess(if(failures==0)0 else 1)
}
