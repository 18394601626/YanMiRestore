import Foundation
final class MarkerError: Error {}
func expect(_ value: Bool) throws {if !value {throw Problem.invalid}}
@main struct ExtendedCases {
 static func main() {
  let tests: [(String, () throws -> Void)] = [
   ("SWEX01", {let p=Probe();try consumeOwned(p){try expect(!p.closed)};try expect(p.closed)}),
   ("SWEX02", {let p=Probe();let marker=MarkerError();var caught=false;do{try consumeOwned(p){throw marker}}catch let error as MarkerError{caught=error===marker};try expect(caught && p.closed)}),
   ("SWEX03", {let outer=Probe();let inner=Probe();try consumeOwned(outer){try consumeOwned(inner){};try expect(inner.closed && !outer.closed)};try expect(outer.closed)}),
   ("SWEX04", {let s="👨‍👩‍👧‍👦e\u{301}\0";let bytes=s.utf8.count;try expect(fitsUTF8(s,maximum:bytes));try expect(!fitsUTF8(s,maximum:bytes-1));try expect(!fitsUTF8("",maximum:-1));try expect(fitsUTF8("",maximum:0))}),
   ("SWEX05", {try expect(checkedAdd(Int.max,0)==Int.max);try expect(checkedAdd(Int.min,0)==Int.min);for (a,b) in [(Int.max,1),(Int.min,-1)] {var refused=false;do{_ = try checkedAdd(a,b)}catch Problem.overflow{refused=true};try expect(refused)}}),
   ("SWEX06", {let shared=TagBox(["a"]);let original=Profile(box:shared);let view=Profile(box:shared);let cloned=snapshot(original);shared.tags.append("b");cloned.box.tags.append("c");try expect(view.box.tags==["a","b"]);try expect(cloned.box.tags==["a","c"])}),
   ("SWEX07", {var old=[9];var rejected=false;do{try replaceQuantities(&old,["1","2","bad"])}catch Problem.invalid{rejected=true};try expect(rejected && old==[9])}),
   ("SWEX08", {let replace:(inout [Int],[String])throws->Void=replaceQuantities;var old=[9];try replace(&old,[]);try expect(old.isEmpty);try replace(&old,[String(Int.max)]);try expect(old==[Int.max])})
  ]
  var failures=0
  for(id,test) in tests {do{try test();print("CASE \(id) PASS")}catch{failures+=1;print("CASE \(id) FAIL");fputs("\(id): \(error)\n",stderr)}}
  exit(failures==0 ? 0 : 1)
 }
}
