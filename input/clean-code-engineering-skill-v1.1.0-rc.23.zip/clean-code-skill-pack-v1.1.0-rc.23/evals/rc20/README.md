# rc.20：驱动事务策略、空参数与语言边界

## 验证范围

新增48项：真实SQLite14、Bash8、Kotlin/JVM10、Swift/Linux8、Ruby8。它们是已知输入的受控检查，不是独立代理盲测。只编辑两个旧样例：SQLite显式事务收尾、Bash零参数输出。其他三种语言不修改实现。Python3.12+才能执行新autocommit接口测试；旧运行时明确SKIP。

```bash
python -S evals/rc20/reproduce.py --output ../rc20-full --native
python -S evals/rc20/reproduce.py --output ../rc20-focused --focused
python -S evals/rc20/reproduce.py --output ../rc20-tools --tools-only
python -S evals/rc20/run_boundaries.py --languages sql,bash --output ../rc20-sql-bash
```

默认入口复用原十语言、TS、SQLite、C#/Dart尝试、原42项边界，追加本轮48项；`--native`追加原C/C++矩阵。`--focused`只运行工具/资料和本轮48项，不代表历史语言通过。`--tools-only`不执行语言行为。没有“全部30语言已运行”的选项。输出目录必须不存在且位于包外。无网络下载，无生产连接，无自动安装，不是恶意源码沙箱。

## 行为契约

### SQLite

函数原来自己执行BEGIN，却用Connection.commit/rollback收尾。新测试扩展到显式autocommit=True连接，要求正常返回可被独立连接看到、失败后回滚并结束自有事务。修改为SQL COMMIT/ROLLBACK，不切换调用者的配置。autocommit=False下自动开启的事务仍属于调用方，按原入口拒绝接管，不消耗输入迭代器。

SQLite RAISE(ROLLBACK)可以先结束事务，所以仅在in_transaction时回滚，避免覆盖原IntegrityError。真实延迟外键在COMMIT失败、读锁引发COMMIT busy、迭代器异常、原连接再次可用分别检查。SQLite是明确方言，不能代替PostgreSQL/MySQL/Spring。没有验证任意Connection子类、rollback本身失败、重入事务修改或同连接多线程。

### Bash

新增明确的逐参数文本输出契约：零个参数输出零字节；一个空字符串输出一行空行。旧实现printf的默认参数行为会多一行；只修改零参数分支。该行为变化不是纯重构。文本行输出不用于可逆表示内嵌换行的任意argv，也不承诺二进制协议。

### Kotlin / Swift / Ruby

三种实现原样接受追加测试。Kotlin检查双失败时主异常与suppressed、嵌套资源关闭顺序、迭代器异常、复制隔离、数值端点和函数引用。Ruby锁定原ensure语义：work与close均失败时外层为close错误，cause保留work错误；不能强行统一成Kotlin的suppressed策略。资源替身计数用于明确关闭次数，不冒充操作系统资源。Swift检查错误对象身份、defer时点、UTF8字节限制、值类型内引用隔离、溢出和批处理契约；不涉及Apple SDK或严格并发模式。

## 结果与口径

完整结果在包根VALIDATION。新消费者首次把Swift数组属性写成方法调用，编译失败而非旧实现失败；保留初版与日志，语法修正后冻结测试，再在旧实现观察红灯。最终冻结版本48项中38通过、10断言失败（8个SQLite政策路径、2个Bash空参数断言），不是10类独立缺陷。修正版48项通过。

原rc19整套240项先在原版、再在仅修改实现且版本仍rc19时运行。当前替换的仅是2个绑定rc19版本/全文件字节身份的发行断言；原文件留存，当前以6个发行保护检查替代，另加4个CLI检查，共248个资料/工具方法。缺依赖或工具时保持阻塞，不伪装成功。
