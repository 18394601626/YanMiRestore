"""Replay applicable historical tests plus 48 rc20 boundaries.

Default: old ten-language batch, TS, SQLite, C#/Dart attempts, rc19 boundaries,
plus SQL14/Bash8/Kotlin10/Swift8/Ruby8. --native adds previous native matrices.
--focused excludes old language behavior; --tools-only excludes all behavior.
No option means all 30 languages; missing tools remain BLOCKED.
"""
import argparse
import importlib.util
import json
from pathlib import Path
import sys
from datetime import datetime,timezone
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent

def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
    group=parser.add_mutually_exclusive_group();group.add_argument('--tools-only',action='store_true');group.add_argument('--focused',action='store_true')
    parser.add_argument('--native',action='store_true')
    args=parser.parse_args();out=args.output.resolve()
    if args.native and (args.tools_only or args.focused):parser.error('--native is only available with the default historical runtime scope')
    if out.exists() or out==ROOT or ROOT in out.parents:parser.error('output must be new and outside package')
    previous=load('rc20_previous',ROOT/'evals/rc19/reproduce.py')
    previous.STAGES=[(name,'evals/rc20/test_applicable_rc19.py',3) if name=='rc19-release' else (name,path,count) for name,path,count in previous.STAGES]
    previous.STAGES += [('rc20-release','evals/rc20/test_release.py',6),('rc20-cli','evals/rc20/test_cli.py',4)]
    argv=sys.argv[:]
    sys.argv=[str(ROOT/'evals/rc19/reproduce.py'),'--output',str(out)]
    if args.tools_only or args.focused:sys.argv.append('--tools-only')
    if args.native:sys.argv.append('--native')
    try:code=previous.main()
    finally:sys.argv=argv
    path=out/'summary.json';data=json.loads(path.read_text())
    data['entry']='evals/rc20/reproduce.py'
    data['scope_note']='Only explicitly listed runtimes; not 30-language, framework, IDE or independent AI validation.'
    if not args.tools_only and code!=130:
        data['requested_runtime'].append('rc20-boundaries-48');data['status']='RUNNING'
        previous.old.save(out,data)
        row=previous.old.launch(out,'rc20-boundaries',[sys.executable,'-S',str(HERE/'run_boundaries.py'),'--output',str(out/'rc20-boundaries')],180)
        child=out/'rc20-boundaries/summary.json'
        if row['status']=='FINISHED' and child.exists():
            detail=json.loads(child.read_text());row['details']=detail
            row['status']=detail['status'] if detail.get('exit_code')==row['exit_code'] else 'INVALID_EVIDENCE'
        data['runtime'].append(row)
    accepted={'PASS','CONTROL_OBSERVATIONS_MATCH','EXPECTED_OBSERVATIONS_REPRODUCED'}
    if code==130 or any(r['status']=='INTERRUPTED' for r in data['runtime']):code=130;data['status']='INTERRUPTED'
    elif any(r['status']!='PASS' for r in data['stages']) or any(r['status'] not in accepted|{'BLOCKED','PARTIAL_BLOCKED'} for r in data['runtime']):code=1;data['status']='FAIL'
    elif any(r['status'] in {'BLOCKED','PARTIAL_BLOCKED'} for r in data['runtime']):code=2;data['status']='PARTIAL_BLOCKED'
    else:code=0;data['status']='REQUESTED_SCOPE_PASSED'
    data['exit_code']=code;data['finished_utc']=datetime.now(timezone.utc).isoformat();previous.old.save(out,data)
    print('rc20 final:',data['status'],'tool_methods='+str(data['tool_methods']))
    return code
if __name__=='__main__':raise SystemExit(main())
