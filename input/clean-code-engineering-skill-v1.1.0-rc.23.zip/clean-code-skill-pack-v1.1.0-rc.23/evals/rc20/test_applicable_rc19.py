"""Keep rc19 assertions; two whole-release identity checks apply to rc19 only.
Both ran on the original archive and again after the code fix before rebasing.
Current identity and an exact edit-set hash check replace only those two.
"""
import importlib.util
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('rc19_release',ROOT/'evals/rc19/test_release.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
if __name__=='__main__':
    excluded={'test_version','test_old_files_protected_outside_declared_changes'}
    suite=unittest.TestSuite(old.ReleaseChecks(n) for n in unittest.defaultTestLoader.getTestCaseNames(old.ReleaseChecks) if n not in excluded)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
