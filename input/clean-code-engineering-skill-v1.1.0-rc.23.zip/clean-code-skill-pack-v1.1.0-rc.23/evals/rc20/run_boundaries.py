"""Run exactly SQL14 + Bash8 + Kotlin10 + Swift8 + Ruby8 controlled cases.

New SQL autocommit tests require Python 3.12+. Missing tools or skipped tests
are not passes. Uses only reviewed local fixtures, not an untrusted-code sandbox.
"""
import argparse
from datetime import datetime,timezone
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
COUNTS={'sql':14,'bash':8,'kotlin':10,'swift':8,'ruby':8}

def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def run(target,out,selected):
    support=load('process_support',target/'evals/rc8/run_integration.py')
    markers=load('marker_support',target/'evals/rc17/run_batch.py')
    data={'kind':'controlled_regression_not_AI_AB','target':str(target),
        'requested_languages':selected,'started_utc':datetime.now(timezone.utc).isoformat(),
        'status':'RUNNING','runs':[]}
    def save():
        tmp=out/'summary.json.tmp';tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n');tmp.replace(out/'summary.json')
    save();previous=os.environ.get('RC20_TARGET_ROOT');os.environ['RC20_TARGET_ROOT']=str(target)
    try:
        for name in selected:
            directory=out/name;directory.mkdir()
            row={'id':name,'status':'NOT_RUN','expected_count':COUNTS[name],'executed':0,'commands':[]}
            data['runs'].append(row);save()
            if name in ('sql','bash'):
                commands=[('test',[sys.executable,'-S',str(HERE/'collect_unittest.py'),str(HERE/'tests'/f'cases_{name}.py'),str(directory/'report.json')])]
            elif name in ('kotlin','swift'):
                suffix={'kotlin':'kt','swift':'swift'}[name]
                shutil.copy2(target/f'evals/rc17/fixtures/{name}/fixed/Solution.{suffix}',directory/f'Solution.{suffix}')
                shutil.copy2(HERE/'tests'/f'Cases.{suffix}',directory/f'Cases.{suffix}')
                if name=='kotlin':
                    commands=[('compile',['kotlinc','Solution.kt','Cases.kt','-jvm-target','1.8','-include-runtime','-d','cases.jar']),('test',['java','-jar','cases.jar'])]
                else:commands=[('compile',['swiftc','-swift-version','5','Solution.swift','Cases.swift','-o','cases']),('test',['./cases'])]
            else:
                commands=[('syntax',['ruby','-c',str(HERE/'tests/cases_ruby.rb')]),('test',['ruby',str(HERE/'tests/cases_ruby.rb'),str(target/'evals/rc17/fixtures/ruby/fixed/solution.rb')])]
            for index,(phase,cmd) in enumerate(commands):
                log=directory/f'{index:02d}-{phase}.log'
                record=support.execute(cmd,directory,log,90)
                row['commands'].append({'phase':phase,'log':str(log.relative_to(out)),**record})
                if record['status']!='FINISHED':row['status']=record['status'];break
                if phase!='test':
                    if record['exit_code']!=0:row['status']='COMPILE_FAIL';break
                    continue
                if name in ('sql','bash'):
                    if not (directory/'report.json').exists():row['status']='INVALID_EVIDENCE';break
                    report=json.loads((directory/'report.json').read_text());row['report']=report;row['executed']=report['tests_run']
                    # The fixed list is independent of how many methods a report claims ran.
                    expected=json.loads((HERE/'expected.json').read_text())[name]
                    ids=[r['test'] for r in report['records']]
                    if sorted(ids)!=sorted(expected) or len(ids)!=len(expected) or report['tests_run']!=len(expected):row['status']='INVALID_EVIDENCE'
                    elif report['skipped'] and report['success'] and record['exit_code']==2:row['status']='SKIPPED'
                    elif report['success'] and not report['skipped'] and record['exit_code']==0:row['status']='PASS'
                    elif not report['success'] and record['exit_code']==1:row['status']='TEST_FAIL'
                    else:row['status']='INVALID_EVIDENCE'
                else:
                    prefix={'kotlin':'KTEX','swift':'SWEX','ruby':'RBEX'}[name]
                    row.update(markers.inspect(log.read_text(errors='replace'),record['exit_code'],[f'{prefix}{n:02d}' for n in range(1,COUNTS[name]+1)]))
            save()
            if row['status']=='INTERRUPTED':raise KeyboardInterrupt
        states=[r['status'] for r in data['runs']]
        data['status']='FAIL' if any(s not in ('PASS','BLOCKED','SKIPPED') for s in states) else ('PARTIAL_BLOCKED' if any(s!='PASS' for s in states) else 'PASS')
    except KeyboardInterrupt:data['status']='INTERRUPTED'
    except Exception as exc:data.update(status='ERROR',reason=f'{type(exc).__name__}: {exc}')
    finally:
        if previous is None:os.environ.pop('RC20_TARGET_ROOT',None)
        else:os.environ['RC20_TARGET_ROOT']=previous
        data['exit_code']={'PASS':0,'PARTIAL_BLOCKED':2,'INTERRUPTED':130}.get(data['status'],1)
        data['finished_utc']=datetime.now(timezone.utc).isoformat();save()
    return data

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--target-root',type=Path,default=ROOT)
    p.add_argument('--languages',default=','.join(COUNTS))
    args=p.parse_args();out=args.output.resolve();target=args.target_root.resolve();selected=args.languages.split(',')
    if not selected or len(set(selected))!=len(selected) or any(n not in COUNTS for n in selected):p.error('use unique IDs from '+','.join(COUNTS))
    if not (target/'evals/rc18/sql/fixed/solution.py').is_file():p.error('target must be the reviewed fixture package')
    if out.exists() or out==ROOT or ROOT in out.parents or out==target or target in out.parents:p.error('output must be new and outside both source roots')
    out.mkdir(parents=True);data=run(target,out,selected)
    for r in data['runs']:print(r['id'],r['status'],r['executed'])
    print(data['status']);raise SystemExit(data['exit_code'])
