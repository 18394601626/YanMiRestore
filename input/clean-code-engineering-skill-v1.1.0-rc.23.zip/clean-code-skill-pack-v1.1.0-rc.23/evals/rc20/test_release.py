"""Identity/protection checks. Not a proof of source-book semantics or AI quality."""
import hashlib
import json
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2];SKILL=ROOT/'clean-code-engineering'
ALLOWED={
 'VERSION','README.md','CHANGELOG.md','VALIDATION.md','LANGUAGE_MATRIX.md','SHA256SUMS.txt','FIX_SUMMARY.json',
 'clean-code-engineering/VERSION','clean-code-engineering/assets/language-support.json',
 'clean-code-engineering/references/languages/sql.md','clean-code-engineering/references/languages/bash.md',
 'evals/rc18/sql/fixed/solution.py','evals/rc17/fixtures/bash/fixed/solution.sh'
}
class ReleaseContracts(unittest.TestCase):
    def test_identity(self):
        self.assertEqual((ROOT/'VERSION').read_text().strip(),'1.1.0-rc.20')
        self.assertEqual((SKILL/'VERSION').read_text().strip(),'1.1.0-rc.20')
        self.assertEqual(json.loads((SKILL/'assets/language-support.json').read_text())['version'],'1.1.0-rc.20')
    def test_prior_bytes_except_explicit_edits(self):
        manifest=json.loads((ROOT/'provenance/rc20/baseline-manifest.json').read_text())
        for name,digest in manifest.items():
            if name not in ALLOWED:
                with self.subTest(path=name):
                    self.assertTrue((ROOT/name).is_file())
                    self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest)
    def test_frozen_behavior_tests(self):
        files=json.loads((ROOT/'provenance/rc20/frozen-tests.json').read_text())['files']
        self.assertEqual(len(files),6)
        for name,digest in files.items():
            self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest)
    def test_exact_guide_additions(self):
        sql=(SKILL/'references/languages/sql.md').read_text();shell=(SKILL/'references/languages/bash.md').read_text()
        for term in ['rc.20','autocommit=True','COMMIT','ROLLBACK','调用方']:self.assertIn(term,sql)
        for term in ['rc.20','零个参数','空字符串','逐行','二进制']:self.assertIn(term,shell)
    def test_registry_has_unchanged_30_scopes(self):
        data=json.loads((SKILL/'assets/language-support.json').read_text());self.assertEqual(len(data['languages']),30);self.assertFalse(data['independent_agent_AB'])
        for name,count in [('sql',14),('bash',8),('kotlin',10),('swift',8),('ruby',8)]:
            self.assertEqual(data['languages'][name]['rc20_additional_cases']['cases'],count)
        self.assertEqual(data['languages']['sql']['dialects']['postgresql']['status'],'NOT_RUN')
        for name in ['csharp','dart']:self.assertNotEqual(data['languages'][name]['execution']['status'],'PASS')
    def test_current_reproducer_and_expected_count(self):
        data=json.loads((ROOT/'evals/rc20/expected.json').read_text())
        self.assertEqual(len(data['sql']),14);self.assertEqual(len(data['bash']),8)
        self.assertTrue((ROOT/'evals/rc20/run_boundaries.py').is_file())
        self.assertTrue((ROOT/'evals/rc20/reproduce.py').is_file())
if __name__=='__main__':unittest.main(verbosity=2)
