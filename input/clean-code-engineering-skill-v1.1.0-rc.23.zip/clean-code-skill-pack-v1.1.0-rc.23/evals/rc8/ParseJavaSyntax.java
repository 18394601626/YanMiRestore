import com.sun.source.util.JavacTask;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

/** Parse only: missing dependencies are NOT resolved and types are NOT checked. */
public class ParseJavaSyntax {
    public static void main(String[] args) throws Exception {
        if (args.length == 0) {
            throw new IllegalArgumentException("Pass Java source file paths");
        }
        var compiler = ToolProvider.getSystemJavaCompiler();
        if (compiler == null) { throw new IllegalStateException("JDK required"); }
        var diagnostics = new DiagnosticCollector<JavaFileObject>();
        try (StandardJavaFileManager files = compiler.getStandardFileManager(diagnostics, null, null)) {
            var inputs = files.getJavaFileObjectsFromPaths(Arrays.stream(args).map(Path::of).toList());
            var task = (JavacTask) compiler.getTask(null, files, diagnostics,
                    List.of("--release", "17", "-proc:none"), null, inputs);
            int units = 0;
            for (var ignored : task.parse()) { units++; }
            long errors = diagnostics.getDiagnostics().stream()
                    .filter(item -> item.getKind() == Diagnostic.Kind.ERROR).count();
            for (var diagnostic : diagnostics.getDiagnostics()) {
                System.out.println(diagnostic);
            }
            System.out.println("Parsed=" + units + ", syntax_errors=" + errors
                    + "; TYPE ANALYSIS / COMPILATION / FRAMEWORK EXECUTION NOT PERFORMED");
            if (errors != 0) { System.exit(1); }
        }
    }
}
