"""Run the bundled Spring/DB experiment with explicit evidence checks.

Python 3.9+. No tool installation, database substitution, or arbitrary-code
sandboxing. The rc8 path is retained for compatibility; see rc9 validation.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import time
import xml.etree.ElementTree as ET
from xml.parsers import expat

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
MAX_XML_BYTES = 10_000_000
MAX_IDENTITY_BYTES = 64_000
RETRY_POLICIES = ('reject', 'allow-fixed')


def reject_declaration(*args):
    # Called by the parser AFTER decoding, before DTD/entity expansion.
    raise ValueError('DTD and entity declarations are forbidden')


def read_report(path):
    with path.open('rb') as handle:
        raw = handle.read(MAX_XML_BYTES + 1)
    if len(raw) > MAX_XML_BYTES:
        raise ValueError('Oversized XML report')
    guard = expat.ParserCreate()
    guard.StartDoctypeDeclHandler = reject_declaration
    guard.EntityDeclHandler = reject_declaration
    guard.ExternalEntityRefHandler = reject_declaration
    guard.Parse(raw, True)
    return ET.fromstring(raw)


def diagnostic(node, report_file):
    # Output/log children are recorded separately, never treated as assertions.
    return {'kind': node.tag, 'type': node.get('type', ''),
            'message': node.get('message', ''),
            'stack_trace': node.findtext('stackTrace') or node.text or '',
            'report_file': report_file}


def record_case(case, report_file, result, seen):
    key = (case.get('classname'), case.get('name'))
    if not all(key) or key in seen:
        raise ValueError('Missing or repeated testcase identity')
    seen.add(key)
    name = '#'.join(key)
    terminal = [n for n in case if n.tag in ('failure', 'error', 'skipped')]
    if len(terminal) > 1:
        raise ValueError('Contradictory or repeated testcase outcome')
    flaky = [n for n in case if n.tag in ('flakyFailure', 'flakyError')]
    reruns = [n for n in case if n.tag in ('rerunFailure', 'rerunError')]
    outcome = terminal[0].tag if terminal else None
    if flaky and (terminal or reruns):
        raise ValueError('Flaky pass conflicts with terminal or rerun failure')
    if reruns and outcome not in ('failure', 'error'):
        raise ValueError('Rerun failure without original failure/error')
    bucket = {'failure': 'failed', 'error': 'errors', 'skipped': 'skipped'}.get(outcome, 'passed')
    result[bucket].append(name)
    if outcome in ('failure', 'error'):
        details_key = 'failure_details' if outcome == 'failure' else 'error_details'
        result[details_key][name] = diagnostic(terminal[0], report_file)
    if flaky or reruns:
        attempts = flaky if flaky else [terminal[0]] + reruns
        result['retries'][name] = {
            'failed_attempts': [diagnostic(n, report_file) for n in attempts],
            'rerun_count': len(flaky) if flaky else len(reruns),
            'attempts': len(flaky) + 1 if flaky else len(reruns) + 1,
            'final_outcome': 'passed' if flaky else bucket,
            'note': 'Surefire retains the first failure type for exhausted reruns.'}
        result['warnings'].append('RETRY_HISTORY: ' + name)
    if flaky:
        result['flaky'].append(name)
    elif bucket == 'passed':
        result['first_attempt_passed'].append(name)
    return outcome


def evaluate_reports(report_dir, exit_code, expected):
    """Parse actual testcase outcomes; retries remain visible under any policy."""
    result = {'status': 'NO_TESTS', 'executed': 0, 'passed': [], 'failed': [],
              'errors': [], 'skipped': [], 'missing': [], 'exit_code': exit_code,
              'failure_details': {}, 'error_details': {}, 'retries': {},
              'flaky': [], 'warnings': [], 'first_attempt_passed': []}
    seen = set()
    files = sorted(Path(report_dir).glob('TEST-*.xml'))
    if not files:
        result['status'] = 'NO_TESTS' if exit_code == 0 else 'PROCESS_ERROR'
        result['missing'] = ['#'.join(x) for x in sorted(expected)]
        return result
    try:
        for file in files:
            root = read_report(file)
            if root.tag not in ('testsuite', 'testsuites'):
                raise ValueError('Unexpected report root')
            suites = [root] if root.tag == 'testsuite' else list(root.findall('testsuite'))
            if not suites:
                raise ValueError('Missing testsuite root')
            for suite in suites:
                cases = list(suite.findall('testcase'))
                actual = {'tests': len(cases), 'failures': 0, 'errors': 0, 'skipped': 0}
                for case in cases:
                    kind = record_case(case, file.name, result, seen)
                    if kind:
                        actual[{'failure': 'failures', 'error': 'errors', 'skipped': 'skipped'}[kind]] += 1
                for label, value in actual.items():
                    if int(suite.attrib[label]) != value:
                        raise ValueError('Testcase records and aggregate counts disagree')
    except (OSError, ET.ParseError, expat.ExpatError, ValueError, KeyError) as exc:
        result.update(status='INVALID_EVIDENCE', reason=str(exc))
        return result
    result['executed'] = len(seen) - len(result['skipped'])
    result['missing'] = ['#'.join(x) for x in sorted(set(expected) - seen)]
    if result['errors']:
        result['status'] = 'TEST_ERROR'
    elif result['failed']:
        result['status'] = 'TEST_FAIL'
    elif exit_code != 0:
        result['status'] = 'PROCESS_ERROR'
    elif result['missing'] and seen:
        result['status'] = 'INCOMPLETE'
    elif result['skipped']:
        result['status'] = 'SKIP'
    elif not seen:
        result['status'] = 'NO_TESTS'
    elif result['flaky']:
        result['status'] = 'FLAKY_PASS'
    else:
        result['status'] = 'PASS'
    return result


def confirm_baseline(parsed, contract):
    """Confirm frozen contract failures, not just matching method names.

The exact prefix is emitted only at the target Java assertion. This detects
accidental attribution errors; it does NOT authenticate malicious test code.
"""
    reasons = []
    needed = {contract['class'] + '#' + n for n in contract['expected_baseline_failures']}
    if (parsed['status'] != 'TEST_FAIL' or set(parsed['failed']) != needed
            or parsed['errors'] or parsed['missing'] or parsed['skipped']
            or parsed['exit_code'] != 1):
        reasons.append('OUTCOME_OR_TARGET_SET_MISMATCH')
    if parsed.get('retries'):
        reasons.append('NEGATIVE_CONTROL_RETRIES_NOT_ACCEPTED')
    specs = contract.get('failure_expectations', {})
    for name in contract['expected_baseline_failures']:
        detail = parsed.get('failure_details', {}).get(contract['class'] + '#' + name, {})
        spec = specs.get(name, {})
        marker = spec.get('message_prefix')
        message = detail.get('message', '')
        if detail.get('type') not in spec.get('types', []):
            reasons.append(name + ': ASSERTION_TYPE_MISMATCH')
        if not marker or not re.match(re.escape(marker) + r'(?:$| \| | ==> )', message):
            reasons.append(name + ': ASSERTION_REASON_MISMATCH')
    return {'confirmed': not reasons, 'reasons': reasons,
            'scope': 'same testcase, terminal failure message and type; not stdout/stack/rerun text'}


def unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('Duplicate runtime identity key: ' + key)
        value[key] = item
    return value


def reject_constant(value):
    raise ValueError('Non-finite runtime identity value: ' + value)


def check_runtime_identity(path, engine, fixture, contract):
    """Validate consistency, not cryptographic authenticity of a test run."""
    result = {'status': 'INVALID_EVIDENCE', 'issues': [], 'runtime': None}
    try:
        with path.open('rb') as handle:
            raw = handle.read(MAX_IDENTITY_BYTES + 1)
        if len(raw) > MAX_IDENTITY_BYTES:
            raise ValueError('Oversized runtime identity')
        value = json.loads(raw.decode('utf-8'), object_pairs_hook=unique_object,
                           parse_constant=reject_constant)
        if not isinstance(value, dict):
            raise ValueError('Runtime identity must be an object')
        result['runtime'] = value
        for field in ('springBoot', 'databaseProduct', 'databaseVersion', 'imageTag', 'fixtureMode'):
            if not isinstance(value.get(field), str) or not value[field].strip():
                result['issues'].append('MISSING_OR_INVALID_' + field)
        spec = contract['runtime_expectations'][engine]
        for field, expected in [('fixtureMode', fixture), ('databaseProduct', spec['databaseProduct']),
                                ('springBoot', contract['springBoot'])]:
            if value.get(field) != expected:
                result['issues'].append(field + '_MISMATCH')
        image = value.get('imageTag', '')
        valid_images = {spec['imageTag'], 'library/' + spec['imageTag'],
                        'docker.io/' + spec['imageTag'], 'docker.io/library/' + spec['imageTag']}
        if not isinstance(image, str) or image not in valid_images:
            result['issues'].append('imageTag_MISMATCH')
        version = value.get('databaseVersion')
        if not isinstance(version, str) or not re.match(spec['version_pattern'], version):
            result['issues'].append('databaseVersion_MISMATCH')
    except (OSError, UnicodeError, ValueError, KeyError, TypeError) as exc:
        result['issues'].append(type(exc).__name__ + ': ' + str(exc))
    if not result['issues']:
        result['status'] = 'VALID'
    return result


TERMINATION_GRACE_SECONDS = 1.0
REAP_TIMEOUT_SECONDS = 5.0


def terminate_owned_process(process):
    """Stop only our process/session; never claim Docker or detached jobs died.

    On POSIX, keep the session leader unreaped until after the final group
    signal. Waiting only for that leader misses descendants ignoring SIGTERM.
    Windows fallback controls the direct child only, not a process tree.
    """
    result = {'scope': 'posix_process_group' if os.name == 'posix' else 'direct_child_only',
              'signals': [], 'errors': [], 'direct_child_reaped': False,
              'status': 'NOT_ATTEMPTED',
              'limit': 'Detached sessions, remote processes and Docker containers are not covered.'}

    def send(sig):
        try:
            if os.name == 'posix':
                os.killpg(process.pid, sig)
            elif sig == signal.SIGTERM:
                process.terminate()
            else:
                process.kill()
            result['signals'].append(sig.name)
        except ProcessLookupError:
            # The child/group may already have exited between observation and signal.
            pass
        except OSError as exc:
            result['errors'].append(type(exc).__name__ + ': ' + str(exc))

    if os.name == 'posix':
        send(signal.SIGTERM)
        try:
            # A bounded grace interval, NOT evidence that the descendants stopped.
            # Do not reap the leader yet: retain ownership of this group identifier.
            time.sleep(TERMINATION_GRACE_SECONDS)
        except KeyboardInterrupt:
            result['errors'].append('Additional interrupt shortened termination grace')
        finally:
            send(signal.SIGKILL)
    else:
        send(signal.SIGTERM)
        try:
            process.wait(timeout=TERMINATION_GRACE_SECONDS)
        except (subprocess.TimeoutExpired, KeyboardInterrupt):
            process.kill()
            result['signals'].append('KILL_DIRECT_CHILD')
    try:
        process.wait(timeout=REAP_TIMEOUT_SECONDS)
        result['direct_child_reaped'] = True
    except (subprocess.TimeoutExpired, OSError) as exc:
        result['errors'].append(type(exc).__name__ + ': ' + str(exc))
    result['status'] = ('SIGNALS_SENT_AND_CHILD_REAPED'
                        if result['direct_child_reaped'] and not result['errors'] else 'INCOMPLETE')
    return result


def execute(command, cwd, log, timeout):
    start = time.monotonic()
    state = {'command': command, 'cwd': str(cwd), 'status': 'NOT_RUN', 'exit_code': None}
    with Path(log).open('wb') as output:
        try:
            process = subprocess.Popen(command, cwd=cwd, stdout=output, stderr=subprocess.STDOUT,
                                       start_new_session=(os.name == 'posix'))
        except OSError as exc:
            state.update(status='BLOCKED', reason=str(exc))
            output.write(('Process launch failed: ' + str(exc) + '\n').encode('utf-8', errors='replace'))
        else:
            try:
                state['exit_code'] = process.wait(timeout=timeout)
                state['status'] = 'FINISHED'
            except (subprocess.TimeoutExpired, KeyboardInterrupt) as exc:
                state['status'] = 'TIMEOUT' if isinstance(exc, subprocess.TimeoutExpired) else 'INTERRUPTED'
                state['cleanup'] = terminate_owned_process(process)
                state['exit_code'] = process.returncode
    state['elapsed_seconds'] = round(time.monotonic() - start, 3)
    state['log_sha256'] = hashlib.sha256(Path(log).read_bytes()).hexdigest()
    return state


def prerequisites(output, require_docker=True):
    issues, commands = [], []
    tools = [('java', ['-version']), ('mvn', ['-version'])]
    if require_docker:
        tools.append(('docker', ['info', '--format', '{{.ServerVersion}}']))
    for name, args in tools:
        exe = shutil.which(name)
        if exe is None:
            issues.append(name.upper() + '_NOT_FOUND')
            continue
        log = output / (name + '-preflight.log')
        step = execute([exe] + args, HERE, log, 20)
        commands.append(step)
        if step['status'] == 'INTERRUPTED':
            return {'status': 'INTERRUPTED', 'issues': [name.upper() + '_PREFLIGHT_INTERRUPTED'],
                    'commands': commands, 'require_docker': require_docker}
        if step['status'] != 'FINISHED' or step['exit_code'] != 0:
            issues.append(name.upper() + '_NOT_READY')
        elif name == 'java':
            text = log.read_text(encoding='utf-8', errors='replace')
            match = re.search(r'version\s+"(\d+)', text)
            if not match or int(match.group(1)) < 17:
                issues.append('JAVA_17_OR_NEWER_REQUIRED_BY_THIS_FIXTURE')
    return {'status': 'BLOCKED' if issues else 'READY_FOR_ATTEMPT',
            'issues': issues, 'commands': commands, 'require_docker': require_docker,
            'note': 'READY is not dependency resolution, compilation or integration success.'}


def write_summary(output, summary):
    temp = output / 'summary.json.tmp'
    temp.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    temp.replace(output / 'summary.json')


def copy_lab(dest):
    shutil.copytree(HERE / 'integration-lab', dest,
                    ignore=shutil.ignore_patterns('target', '.idea'))


def compile_only(output):
    dest = output / 'compile'
    copy_lab(dest)
    # test-compile precedes test in Maven's lifecycle; no Docker is necessary.
    command = [shutil.which('mvn'), '--batch-mode', '-Dstyle.color=never', 'clean', 'test-compile']
    proc = execute(command, dest, dest / 'maven.log', 900)
    item = {'process': proc, 'status': proc['status'], 'class_artifacts': [],
            'note': 'Dependency resolution and compilation only; no tests executed.'}
    if proc['status'] != 'FINISHED':
        return item
    if proc['exit_code'] != 0:
        item['status'] = 'BUILD_FAILED'
        item['note'] = 'Dependency/plugin resolution or compilation failed; inspect Maven log.'
        return item
    required = ('classes/example/rc8/LabApplication.class',
                'test-classes/example/rc8/IntegrationContractTest.class')
    for rel in required:
        file = dest / 'target' / rel
        if not file.is_file() or file.stat().st_size == 0:
            item.update(status='INVALID_EVIDENCE', reason='Missing compiled artifact: ' + rel)
            return item
        item['class_artifacts'].append({'path': rel, 'sha256': hashlib.sha256(file.read_bytes()).hexdigest()})
    item['status'] = 'COMPILED'
    return item


def run_item(item, output, expected, contract, retry_policy):
    dest = output / (item['engine'] + '-' + item['fixture'])
    copy_lab(dest)
    command = [shutil.which('mvn'), '--batch-mode', '-Dstyle.color=never',
               'clean', 'test', '-Dfixture.mode=' + item['fixture'], '-Dlab.engine=' + item['engine']]
    proc = execute(command, dest, dest / 'maven.log', 900)
    item['process'] = proc
    if proc['status'] != 'FINISHED':
        item['status'] = proc['status']
        return
    parsed = evaluate_reports(dest / 'target/surefire-reports', proc['exit_code'], expected)
    item.update(status=parsed['status'], observed_tests=parsed['executed'], reports=parsed,
                comparison_confirmed=False)
    # No successful test run is inferred from missing/corrupt metadata.
    identity = check_runtime_identity(dest / 'target/rc8-runtime.json', item['engine'], item['fixture'], contract)
    item['identity_check'] = identity
    item['runtime'] = identity['runtime']
    if identity['status'] != 'VALID':
        item['reported_test_status'] = parsed['status']
        # Retain real build/no-test status when no testcase was ever observed.
        if parsed['executed']:
            item['status'] = 'INVALID_EVIDENCE'
        return
    if item['fixture'] == 'baseline':
        item['failure_confirmation'] = confirm_baseline(parsed, contract)
        item['comparison_confirmed'] = item['failure_confirmation']['confirmed']
    else:
        item['comparison_confirmed'] = (parsed['status'] == 'PASS' or
            parsed['status'] == 'FLAKY_PASS' and retry_policy == 'allow-fixed')


def run(output, engines, should_run, *, phase='integration', retry_policy='reject'):
    if phase not in ('compile', 'integration') or retry_policy not in RETRY_POLICIES:
        raise ValueError('Unsupported phase or retry policy')
    if not engines or len(set(engines)) != len(engines) or any(x not in ('postgres', 'mysql') for x in engines):
        raise ValueError('Specify unique supported engines')
    output = Path(output).resolve()
    if output.exists() or output.is_relative_to(ROOT.resolve()):
        raise ValueError('Output must be a NEW directory outside the package')
    output.mkdir(parents=True)
    contract = json.loads((HERE / 'contract.json').read_text(encoding='utf-8'))
    expected = {(contract['class'], name) for name in contract['tests']}
    summary = {'kind': contract['kind'], 'created_at': datetime.now(timezone.utc).isoformat(),
               'phase': phase, 'retry_policy': retry_policy, 'candidate_source_compiled': False,
               'build_result': {'status': 'NOT_RUN'}, 'integration_results': [],
               'independent_agent_ab': 'NOT_RUN',
               'prerequisites': prerequisites(output, require_docker=(phase == 'integration')),
               'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
               'contract_sha256': hashlib.sha256((HERE / 'contract.json').read_bytes()).hexdigest()}
    blocked = summary['prerequisites']['status'] == 'BLOCKED'
    interrupted = summary['prerequisites']['status'] == 'INTERRUPTED'
    for engine in engines:
        for mode in ('baseline', 'fixed'):
            summary['integration_results'].append({'engine': engine, 'fixture': mode,
                'status': 'BLOCKED' if blocked and phase == 'integration' else 'NOT_RUN',
                'observed_tests': 0, 'comparison_confirmed': None})
    # Checkpoint before starting: a corrupt single result must not erase the run.
    summary['status'] = 'INTERRUPTED' if interrupted else ('BLOCKED' if blocked else 'NOT_RUN')
    write_summary(output, summary)
    if interrupted:
        write_summary(output, summary)
        print(json.dumps({'status': 'INTERRUPTED', 'output': str(output)}, ensure_ascii=False))
        return 2
    if blocked:
        if phase == 'compile':
            summary['build_result']['status'] = 'BLOCKED'
    elif should_run and phase == 'compile':
        try:
            summary['build_result'] = compile_only(output)
        except (OSError, ValueError) as exc:
            summary['build_result'] = {'status': 'PROCESS_ERROR', 'reason': str(exc)}
        summary['status'] = summary['build_result']['status']
        summary['candidate_source_compiled'] = summary['status'] == 'COMPILED'
    elif should_run:
        for item in summary['integration_results']:
            try:
                run_item(item, output, expected, contract, retry_policy)
            except KeyboardInterrupt:
                item.update(status='INTERRUPTED', comparison_confirmed=False)
            except (OSError, ValueError) as exc:
                item.update(status='INVALID_EVIDENCE', reason=str(exc), comparison_confirmed=False)
            if item['observed_tests']:
                summary['candidate_source_compiled'] = True
            if item['status'] == 'INTERRUPTED':
                summary['status'] = 'INTERRUPTED'
                write_summary(output, summary)
                break
            summary['status'] = 'RUNNING'
            write_summary(output, summary)
        if summary['status'] == 'INTERRUPTED':
            pass  # Pending items retain NOT_RUN; no further build/container is started.
        elif any(x['status'] == 'BLOCKED' for x in summary['integration_results']):
            summary['status'] = 'BLOCKED'
        elif all(x['comparison_confirmed'] is True for x in summary['integration_results']):
            summary['status'] = 'EXPECTED_OBSERVATIONS_REPRODUCED'
        else:
            summary['status'] = 'UNCONFIRMED'
    write_summary(output, summary)
    print(json.dumps({'status': summary['status'], 'output': str(output)}, ensure_ascii=False))
    return 0 if summary['status'] in ('EXPECTED_OBSERVATIONS_REPRODUCED', 'COMPILED') else 2


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--engine', choices=['postgres', 'mysql', 'all'], default='all')
    parser.add_argument('--phase', choices=['compile', 'integration'], default='integration')
    parser.add_argument('--retry-policy', choices=RETRY_POLICIES, default='reject')
    parser.add_argument('--output', required=True, help='New directory OUTSIDE package')
    parser.add_argument('--run', action='store_true', help='Authorize dependency resolution; integration also starts ephemeral containers')
    args = parser.parse_args()
    try:
        raise SystemExit(run(args.output, ['postgres', 'mysql'] if args.engine == 'all' else [args.engine],
                             args.run, phase=args.phase, retry_policy=args.retry_policy))
    except (ValueError, OSError) as exc:
        parser.error(str(exc))
