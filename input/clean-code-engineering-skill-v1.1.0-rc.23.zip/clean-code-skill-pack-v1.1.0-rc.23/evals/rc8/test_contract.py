"""Static packaging/source contracts. These DO NOT compile the Java project."""
from pathlib import Path
import importlib.util
import json
import re
import unittest
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[2]
SKILL=ROOT/'clean-code-engineering'
LAB=ROOT/'evals/rc8/integration-lab'
class RC8Contract(unittest.TestCase):
    def test_version(self):
        self.assertEqual((ROOT/'VERSION').read_text().strip(),'1.1.0-rc.8')
        self.assertEqual((SKILL/'VERSION').read_text().strip(),'1.1.0-rc.8')
    def test_reference_routed(self):
        self.assertIn('references/16-real-integration.md',(SKILL/'SKILL.md').read_text())
    def test_source_boundary_and_blocked_status(self):
        text=(SKILL/'references/16-real-integration.md').read_text()
        for term in ['执行适配','BLOCKED','ObjectMapper','测试托管事务','SQL','未编译']:
            self.assertIn(term,text)
    def test_pom_has_real_dependencies_and_no_embedded_fallback(self):
        root=ET.parse(LAB/'pom.xml').getroot();ns={'m':'http://maven.apache.org/POM/4.0.0'}
        artifacts={e.text for e in root.findall('.//m:dependency/m:artifactId',ns)}
        self.assertTrue({'spring-boot-starter-web','mybatis-plus-spring-boot3-starter','postgresql','mysql-connector-j','junit-jupiter','mysql'}.issubset(artifacts))
        self.assertFalse({'h2','hsqldb','mockito-core'} & artifacts)
        self.assertEqual(root.find('.//m:failIfNoTests',ns).text,'true')
    def test_exact_java_case_inventory(self):
        source=(LAB/'src/test/java/example/rc8/IntegrationContractTest.java').read_text()
        names=re.findall(r'@Test\s+void\s+(\w+)\(',source)
        declared=json.loads((ROOT/'evals/rc8/contract.json').read_text())['tests']
        self.assertEqual(sorted(names),sorted(declared));self.assertEqual(len(names),13)
    def test_tests_do_not_supply_transaction_or_skip_missing_docker(self):
        source=(LAB/'src/test/java/example/rc8/IntegrationContractTest.java').read_text()
        self.assertNotRegex(source,r'(?m)^\s*@Transactional')
        for bad in ['disabledWithoutDocker', '@MockBean','Mockito.mock','Assumptions.assume']:
            self.assertNotIn(bad,source)
        self.assertIn('dataSource.getConnection()',source)
        self.assertIn('getDatabaseProductName()',source)
    def test_results_are_explicitly_not_run(self):
        data=json.loads((ROOT/'evals/rc8/contract.json').read_text())
        self.assertEqual(data['status'],'NOT_RUN_INTEGRATION')
        self.assertIsNone(data['observed_postgres']);self.assertIsNone(data['observed_mysql'])
    def test_java_uses_real_framework_annotations(self):
        src='\n'.join(p.read_text() for p in (LAB/'src/main').rglob('*.java'))
        for value in ['@SpringBootApplication','@TableLogic','@Mapper','@Transactional(rollbackFor = IOException.class)','@JsonProperty']:
            self.assertIn(value,src)
        self.assertNotIn('interface Transactional',src)

def suite():
    spec=importlib.util.spec_from_file_location('rc7_docs',ROOT/'evals/rc7/test_contract.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    result=unittest.TestSuite()
    def add(items):
        for t in items:
            if isinstance(t,unittest.TestSuite): add(t)
            elif getattr(t,'_testMethodName','')!='test_version':result.addTest(t)
    add(module.suite())
    result.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(RC8Contract))
    return result
if __name__=='__main__':
    r=unittest.TextTestRunner(verbosity=2).run(suite());raise SystemExit(0 if r.wasSuccessful() else 1)
