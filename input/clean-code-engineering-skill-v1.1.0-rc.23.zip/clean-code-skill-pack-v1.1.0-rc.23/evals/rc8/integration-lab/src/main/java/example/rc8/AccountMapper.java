package example.rc8;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface AccountMapper extends BaseMapper<Account> {
    // Intentionally unfiltered SQL for the known-bad control. Not production guidance.
    @Select("SELECT id, display_name, status, deleted FROM rc8_accounts WHERE id=#{id}")
    Account rawById(@Param("id") long id);
}
