package example.rc8;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record ProfilePayload(long id,
        @JsonProperty("name") String legacyName,
        @JsonProperty("display_name") String displayName) { }
