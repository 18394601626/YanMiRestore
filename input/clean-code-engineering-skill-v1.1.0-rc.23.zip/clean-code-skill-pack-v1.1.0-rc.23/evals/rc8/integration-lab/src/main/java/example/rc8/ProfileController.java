package example.rc8;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

@RestController
public class ProfileController {
    private final AccountOperations operations;
    public ProfileController(AccountOperations operations) { this.operations = operations; }

    @GetMapping("/profiles/{id}")
    public ProfilePayload profile(@PathVariable long id) {
        ProfilePayload payload = operations.profile(id);
        if (payload == null) { throw new ResponseStatusException(HttpStatus.NOT_FOUND); }
        return payload;
    }
}
