package example.rc8;

import java.io.IOException;
import java.util.List;

public interface AccountOperations {
    void create(long id, String name);
    void createAndFail(long id);
    void createAndFailChecked(long id) throws IOException;
    List<Account> findMany(List<Long> ids);
    void clearDisplayName(long id);
    void renameMany(List<Long> ids, String name);
    Account find(long id);
    ProfilePayload profile(long id);
}
