package example.rc8;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableLogic;
import com.baomidou.mybatisplus.annotation.TableName;

@TableName("rc8_accounts")
public class Account {
    @TableId(type = IdType.INPUT)
    private Long id;
    private String displayName;
    private String status;
    @TableLogic
    private Integer deleted;

    public Account() { }
    public Account(Long id, String displayName) {
        this.id = id;
        this.displayName = displayName;
        this.status = "active";
        this.deleted = 0;
    }
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String value) { displayName = value; }
    public String getStatus() { return status; }
    public void setStatus(String value) { status = value; }
    public Integer getDeleted() { return deleted; }
    public void setDeleted(Integer value) { deleted = value; }
}
