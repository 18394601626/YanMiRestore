package example.rc8;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/** Deliberately faulty fixture. This is NOT an AI-generated control sample. */
@Service
@ConditionalOnProperty(name = "fixture.mode", havingValue = "baseline")
public class BaselineOperations implements AccountOperations {
    private final AccountMapper mapper;
    public BaselineOperations(AccountMapper mapper) { this.mapper = mapper; }

    public void create(long id, String name) { mapper.insert(new Account(id, name)); }

    public void createAndFail(long id) { this.insertThenReject(id); }

    @Transactional
    public void insertThenReject(long id) {
        mapper.insert(new Account(id, "runtime-failure"));
        throw new Rejected();
    }

    @Transactional
    public void createAndFailChecked(long id) throws IOException {
        mapper.insert(new Account(id, "checked-failure"));
        throw new IOException("controlled checked rejection");
    }

    public List<Account> findMany(List<Long> ids) {
        if (ids.isEmpty()) {
            return mapper.selectList(Wrappers.<Account>lambdaQuery()
                    .in(!ids.isEmpty(), Account::getId, ids));
        }
        List<Account> result = new ArrayList<>();
        for (Long id : ids) { result.add(mapper.selectById(id)); }
        return result;
    }

    public void clearDisplayName(long id) {
        Account patch = new Account();
        patch.setId(id);
        patch.setStatus("updated");
        patch.setDisplayName(null);
        mapper.updateById(patch);
    }

    public void renameMany(List<Long> ids, String name) {
        mapper.update(null, Wrappers.<Account>lambdaUpdate()
                .in(!ids.isEmpty(), Account::getId, ids).set(Account::getDisplayName, name));
    }

    public Account find(long id) { return mapper.rawById(id); }

    public ProfilePayload profile(long id) {
        Account account = mapper.selectById(id);
        return account == null ? null : new ProfilePayload(id, null, account.getDisplayName());
    }
}
