package example.rc8;

public final class Rejected extends RuntimeException {
    public Rejected() { super("controlled business rejection after insert"); }
}
