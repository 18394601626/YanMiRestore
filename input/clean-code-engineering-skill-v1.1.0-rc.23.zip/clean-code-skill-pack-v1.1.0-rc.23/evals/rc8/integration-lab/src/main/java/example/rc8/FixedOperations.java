package example.rc8;

import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.io.IOException;
import java.util.List;

/** Candidate implementation. Framework compilation and integration remain unverified here. */
@Service
@ConditionalOnProperty(name = "fixture.mode", havingValue = "fixed", matchIfMissing = true)
public class FixedOperations implements AccountOperations {
    private final AccountMapper mapper;
    public FixedOperations(AccountMapper mapper) { this.mapper = mapper; }

    @Transactional
    public void create(long id, String name) { mapper.insert(new Account(id, name)); }

    @Transactional
    public void createAndFail(long id) {
        mapper.insert(new Account(id, "runtime-failure"));
        throw new Rejected();
    }

    @Transactional(rollbackFor = IOException.class)
    public void createAndFailChecked(long id) throws IOException {
        mapper.insert(new Account(id, "checked-failure"));
        throw new IOException("controlled checked rejection");
    }

    public List<Account> findMany(List<Long> ids) {
        if (ids.isEmpty()) { return List.of(); }
        return mapper.selectList(Wrappers.<Account>lambdaQuery()
                .in(Account::getId, ids).orderByAsc(Account::getId));
    }

    public void clearDisplayName(long id) {
        // This command explicitly means SQL NULL, not an omitted patch field.
        mapper.update(null, Wrappers.<Account>lambdaUpdate().eq(Account::getId, id)
                .set(Account::getDisplayName, null).set(Account::getStatus, "updated"));
    }

    public void renameMany(List<Long> ids, String name) {
        if (ids.isEmpty()) { throw new IllegalArgumentException("At least one account ID is required"); }
        mapper.update(null, Wrappers.<Account>lambdaUpdate().in(Account::getId, ids)
                .set(Account::getDisplayName, name));
    }

    public Account find(long id) { return mapper.selectById(id); }

    public ProfilePayload profile(long id) {
        Account account = mapper.selectById(id);
        return account == null ? null
                : new ProfilePayload(id, account.getDisplayName(), account.getDisplayName());
    }
}
