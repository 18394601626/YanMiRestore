package example.rc8;

import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Signature;
import org.apache.ibatis.session.ResultHandler;
import org.springframework.stereotype.Component;
import java.sql.Statement;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Counts completed MyBatis statement queries, not mapper calls or pool acquisition. */
@Component
@Intercepts(@Signature(type = StatementHandler.class, method = "query",
        args = {Statement.class, ResultHandler.class}))
public class SqlProbe implements Interceptor {
    private final ConcurrentLinkedQueue<String> queries = new ConcurrentLinkedQueue<>();

    public Object intercept(Invocation invocation) throws Throwable {
        String sql = ((StatementHandler) invocation.getTarget()).getBoundSql().getSql();
        Object result = invocation.proceed();
        queries.add(sql.replaceAll("\\s+", " ").trim());
        return result;
    }
    public void reset() { queries.clear(); }
    public int count() { return queries.size(); }
    public List<String> statements() { return List.copyOf(queries); }
}
