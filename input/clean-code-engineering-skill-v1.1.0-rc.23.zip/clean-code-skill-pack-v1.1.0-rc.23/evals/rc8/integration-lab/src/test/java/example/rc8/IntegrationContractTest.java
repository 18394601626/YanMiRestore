package example.rc8;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootVersion;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.SpringVersion;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.testcontainers.containers.JdbcDatabaseContainer;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

import javax.sql.DataSource;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

// Intentionally NO @Transactional: a test-owned transaction can mask missing
// service transactions. Database state is checked after the proxy returns.
@SpringBootTest(classes = LabApplication.class, webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
@Testcontainers
@TestMethodOrder(MethodOrderer.MethodName.class)
class IntegrationContractTest {
    @Container
    static final JdbcDatabaseContainer<?> DATABASE = database();

    static JdbcDatabaseContainer<?> database() {
        String engine = System.getProperty("lab.engine", "postgres");
        return switch (engine) {
            case "postgres" -> new PostgreSQLContainer<>("postgres:16.4")
                    .withDatabaseName("rc8_lab").withUsername("rc8_lab").withPassword("ephemeral-test-only");
            case "mysql" -> new MySQLContainer<>("mysql:8.4.0")
                    .withDatabaseName("rc8_lab").withUsername("rc8_lab").withPassword("ephemeral-test-only");
            default -> throw new IllegalArgumentException("Unsupported engine: " + engine);
        };
    }

    @DynamicPropertySource
    static void datasource(DynamicPropertyRegistry registry) {
        registry.add("spring.datasource.url", DATABASE::getJdbcUrl);
        registry.add("spring.datasource.username", DATABASE::getUsername);
        registry.add("spring.datasource.password", DATABASE::getPassword);
        registry.add("spring.datasource.driver-class-name", DATABASE::getDriverClassName);
    }

    @Autowired AccountOperations operations;
    @Autowired AccountMapper mapper;
    @Autowired SqlProbe probe;
    @Autowired DataSource dataSource;
    @Autowired JdbcTemplate jdbc;
    @Autowired ObjectMapper json;
    @Autowired MockMvc mvc;
    @Autowired SqlSessionFactory sessions;

    @BeforeEach
    void seedIsolatedDatabase() {
        assertFalse(TransactionSynchronizationManager.isActualTransactionActive(),
                "Test must not supply a transaction to the service");
        jdbc.update("DELETE FROM rc8_accounts");
        for (long id = 1; id <= 3; id++) {
            jdbc.update("INSERT INTO rc8_accounts(id,display_name,status,deleted) VALUES(?,?,?,?)",
                    id, "user-" + id, "active", 0);
        }
        probe.reset();
    }

    @Test
    void runtimeIdentity() throws Exception {
        assertNotNull(sessions);
        assertEquals("3.5.6", SpringBootVersion.getVersion());
        try (Connection connection = dataSource.getConnection()) {
            String actual = connection.getMetaData().getDatabaseProductName();
            String expected = System.getProperty("lab.engine", "postgres").equals("postgres")
                    ? "PostgreSQL" : "MySQL";
            assertEquals(expected, actual, "H2/MariaDB are not evidence for this engine");
            Map<String, Object> identity = new LinkedHashMap<>();
            identity.put("springBoot", SpringBootVersion.getVersion());
            identity.put("springFramework", SpringVersion.getVersion());
            identity.put("jackson", json.version().toString());
            identity.put("java", System.getProperty("java.version"));
            identity.put("databaseProduct", actual);
            identity.put("databaseVersion", connection.getMetaData().getDatabaseProductVersion());
            identity.put("driverVersion", connection.getMetaData().getDriverVersion());
            identity.put("imageTag", DATABASE.getDockerImageName());
            identity.put("fixtureMode", System.getProperty("fixture.mode", "fixed"));
            Files.createDirectories(Path.of("target"));
            json.writerWithDefaultPrettyPrinter().writeValue(Path.of("target/rc8-runtime.json").toFile(), identity);
        }
    }

    @Test
    void realProxyAndNoAmbientTransaction() {
        assertTrue(AopUtils.isAopProxy(operations), "Obtain the bean from Spring, not new Service()");
        assertFalse(TransactionSynchronizationManager.isActualTransactionActive());
    }

    @Test
    void successfulWriteCommits() throws Exception {
        operations.create(10L, "Ada");
        assertEquals(1, committedCount(10L));
    }

    @Test
    void runtimeFailureRollsBack() throws Exception {
        assertThrows(Rejected.class, () -> operations.createAndFail(10L));
        assertEquals(0, committedCount(10L), "EXPECTED_CONTROL_ASSERTION: runtimeFailureRollsBack | RC8_RUNTIME_ROLLBACK: write leaked outside rollback");
    }

    @Test
    void checkedFailureRollsBack() throws Exception {
        assertThrows(IOException.class, () -> operations.createAndFailChecked(11L));
        assertEquals(0, committedCount(11L), "EXPECTED_CONTROL_ASSERTION: checkedFailureRollsBack | RC8_CHECKED_ROLLBACK: checked failure committed");
    }

    @Test
    void batchQueryUsesOneSql() {
        List<Account> result = operations.findMany(List.of(1L, 2L, 3L));
        assertEquals(3, result.size());
        assertEquals(1, probe.count(), "EXPECTED_CONTROL_ASSERTION: batchQueryUsesOneSql | RC8_QUERY_COUNT: " + probe.statements());
    }

    @Test
    void emptyQueryRunsNoSql() {
        assertTrue(operations.findMany(List.of()).isEmpty(), "EXPECTED_CONTROL_ASSERTION: emptyQueryRunsNoSql | RC8_EMPTY_QUERY: returned all rows");
        assertEquals(0, probe.count(), "An empty ID set has no database work");
    }

    @Test
    void explicitNullClearsField() {
        operations.clearDisplayName(1L);
        assertNull(jdbc.queryForObject("SELECT display_name FROM rc8_accounts WHERE id=1", String.class),
                "EXPECTED_CONTROL_ASSERTION: explicitNullClearsField | RC8_NULL_UPDATE: NOT_NULL silently skipped requested clear");
        assertEquals("user-2", jdbc.queryForObject("SELECT display_name FROM rc8_accounts WHERE id=2", String.class));
    }

    @Test
    void emptyUpdateRejected() {
        assertThrows(IllegalArgumentException.class, () -> operations.renameMany(List.of(), "changed"),
                "EXPECTED_CONTROL_ASSERTION: emptyUpdateRejected | RC8_EMPTY_UPDATE: missing IDs must not become full-table update");
        assertEquals(0, jdbc.queryForObject("SELECT count(*) FROM rc8_accounts WHERE display_name='changed'", Integer.class));
    }

    @Test
    void logicalDeleteRespected() {
        assertEquals(1, mapper.deleteById(1L));
        assertEquals(1, jdbc.queryForObject("SELECT deleted FROM rc8_accounts WHERE id=1", Integer.class));
        assertNull(operations.find(1L), "EXPECTED_CONTROL_ASSERTION: logicalDeleteRespected | RC8_LOGICAL_DELETE: custom SQL exposed logically deleted row");
        assertNotNull(operations.find(2L));
    }

    @Test
    void newJsonField() throws Exception {
        mvc.perform(get("/profiles/1")).andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.display_name").value("user-1"));
    }

    @Test
    void oldJsonNamePreserved() throws Exception {
        mvc.perform(get("/profiles/1")).andExpect(status().isOk())
                .andExpect(result -> assertEquals("user-1",
                        json.readTree(result.getResponse().getContentAsString()).path("name").asText(null),
                        "EXPECTED_CONTROL_ASSERTION: oldJsonNamePreserved | old JSON name must be preserved"));
    }

    @Test
    void configuredJacksonPreservesNullAndEmpty() throws Exception {
        Map<String, Object> input = new LinkedHashMap<>();
        input.put("missingValue", null);
        input.put("emptyList", List.of());
        var decoded = json.readTree(json.writeValueAsBytes(input));
        assertTrue(decoded.get("missingValue").isNull());
        assertTrue(decoded.get("emptyList").isArray());
        assertEquals(0, decoded.get("emptyList").size());
    }

    private int committedCount(long id) throws Exception {
        // A fresh, independently acquired connection outside any test transaction.
        try (Connection connection = dataSource.getConnection();
             Statement statement = connection.createStatement();
             ResultSet rows = statement.executeQuery("SELECT count(*) FROM rc8_accounts WHERE id=" + id)) {
            assertTrue(connection.getAutoCommit());
            assertTrue(rows.next());
            return rows.getInt(1);
        }
    }
}
