# rc.9 验收器修复版（保留 evals/rc8 入口）

此目录沿用 rc.8 Java 项目与入口路径，运行器在 rc.9 修复四类已复现问题。
**当前环境没有实际编译 Java，也没有运行 Spring/PostgreSQL/MySQL；仍是 BLOCKED。**
仅依赖真实 Spring Boot/MyBatis-Plus/Jackson/Testcontainers，不降级 H2。

## 先单独构建，再运行数据库

在完整包根目录运行，下列输出目录都必须是包外的新目录。

```text
python evals/rc8/run_integration.py --run --phase compile --output ../rc9-compile
python evals/rc8/run_integration.py --run --phase integration --engine all --output ../rc9-integration
```

compile 需要 JDK17+、Maven、可访问依赖或完整离线缓存；**不检查 Docker**。
它执行 clean test-compile，检查主类与测试类产物；COMPILED 不代表运行了任何测试。
BUILD_FAILED 包括依赖/插件解析或编译失败，日志保留，不能猜测是哪一类业务缺陷。

integration 还要求可用 Docker daemon 和镜像。每种数据库的 baseline/fixed 使用独立新工作目录，执行 clean test。
默认省略 --run 时仅探测当前 phase 的前置环境。不会安装工具、修改宿主网络、访问生产数据库。

## 四项证据修复

1. 坏候选需恰好出现原约定的8个失败方法，且每个 failure 类型与固定原因标识匹配。退出1与目标集合还要一致。不能借日志、堆栈或重试消息完成归属。
2. 身份文件中的数据库、版本系列、镜像、Spring Boot 和 fixture 身份必须一致；损坏/缺失/矛盾标 INVALID_EVIDENCE，并继续下一项、保存总表。
3. flakyFailure/flakyError 保留为 FLAKY_PASS，rerunFailure/rerunError 保留失败尝试。默认 retry-policy=reject。显式 --retry-policy allow-fixed 只允许 fixed 的 FLAKY_PASS 完成验收，输出仍标重试；baseline 重试一律不确认。
4. XML通过解析器声明回调禁止DTD，支持经过本轮测试的UTF-8/UTF-16。单XML上限10,000,000字节，身份上限64,000字节。

这些检查只验证受控证据一致性，不是安全沙箱或恶意代码防伪系统。

## 测试修订说明

原13个Java测试名字、两种候选业务实现和POM不变；仅为8个目标断言加入固定诊断前缀。
JSON旧字段断言从jsonPath matcher改为同一MockMvc响应中用真实ObjectMapper读取name并断言user-1，以得到稳定原因。
原Java测试在 provenance/rc9/before 保留，差异单独记录；这两种写法的真实框架编译/运行仍未验证，不宣称等价集成已过。
expected_baseline_failures本身仍是假定的坏控制结果，尚无真实数据库实测。

## 本地工具测试

```text
python evals/rc8/test_runner.py
python evals/rc9/test_hardening.py
python evals/rc9/test_contract.py
python evals/rc9/reproduce.py --output ../rc9-verification
```

这些是Python文档/报告/流程测试。保留的rc8/test_contract.py版本断言仍应在rc8运行；rc9入口复用其84项非版本检查加8项本版检查。
reproduce将上一轮原始16项测试原字节复制到临时目录执行，没有改断言。

需要真实SQL、事务、ObjectMapper、框架代理验证时，使用上面的integration入口；MockMvc不等于真实TCP端到端。
