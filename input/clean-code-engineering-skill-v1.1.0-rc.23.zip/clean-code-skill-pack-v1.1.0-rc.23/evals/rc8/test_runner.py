"""Tests for the runner, not Spring/DB integration or agent behavior."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('rc8_runner', HERE / 'run_integration.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
C = 'example.rc8.IntegrationContractTest'

class ReportChecks(unittest.TestCase):
    def evaluate(self, body, code=0, expected=None):
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp)
            if body is not None:
                (path / 'TEST-contract.xml').write_text(body, encoding='utf-8')
            return runner.evaluate_reports(path, code, expected or {(C, 'works')})
    def suite(self, case='', **kwargs):
        attrs = {'tests':'1','failures':'0','errors':'0','skipped':'0'}
        attrs.update(kwargs)
        return '<testsuite '+ ' '.join(f'{k}="{v}"' for k,v in attrs.items())+'>'+case+'</testsuite>'
    def case(self, content='', name='works'):
        return f'<testcase classname="{C}" name="{name}">{content}</testcase>'
    def test_success_requires_actual_case(self):
        self.assertEqual(self.evaluate(self.suite(self.case()))['status'], 'PASS')
    def test_no_reports_is_not_success(self):
        self.assertEqual(self.evaluate(None)['status'], 'NO_TESTS')
    def test_empty_suite_is_not_success(self):
        self.assertEqual(self.evaluate(self.suite(tests='0'))['status'], 'NO_TESTS')
    def test_skipped_is_not_pass(self):
        self.assertEqual(self.evaluate(self.suite(self.case('<skipped/>'), skipped='1'))['status'], 'SKIP')
    def test_failure_even_when_exit_zero(self):
        self.assertEqual(self.evaluate(self.suite(self.case('<failure message="bad"/>'), failures='1'))['status'], 'TEST_FAIL')
    def test_context_error_is_not_expected_assertion_failure(self):
        result = self.evaluate(self.suite(self.case('<error message="cannot start database"/>'), errors='1'),1)
        self.assertEqual(result['status'], 'TEST_ERROR')
        self.assertEqual(result['failed'], [])
    def test_exit_failure_even_when_xml_passes(self):
        self.assertEqual(self.evaluate(self.suite(self.case()),1)['status'], 'PROCESS_ERROR')
    def test_required_case_missing(self):
        self.assertEqual(self.evaluate(self.suite(self.case(name='other')))['status'], 'INCOMPLETE')
    def test_log_text_cannot_impersonate_test(self):
        xml=self.suite(self.case(name='other')+'<system-out>works PASS</system-out>')
        self.assertEqual(self.evaluate(xml)['status'], 'INCOMPLETE')
    def test_wrong_class_not_matched(self):
        xml=self.suite(self.case()).replace(C,'different.Test')
        self.assertEqual(self.evaluate(xml)['status'], 'INCOMPLETE')
    def test_duplicate_case_invalid(self):
        xml=self.suite(self.case()+self.case(),tests='2')
        self.assertEqual(self.evaluate(xml)['status'], 'INVALID_EVIDENCE')
    def test_malformed_xml_invalid(self):
        self.assertEqual(self.evaluate('<testsuite>')['status'], 'INVALID_EVIDENCE')
    def test_aggregate_count_mismatch_invalid(self):
        self.assertEqual(self.evaluate(self.suite(self.case(),tests='3'))['status'], 'INVALID_EVIDENCE')
    def test_missing_class_invalid(self):
        self.assertEqual(self.evaluate(self.suite('<testcase name="works"/>'))['status'], 'INVALID_EVIDENCE')
    def test_failure_counts_mismatch_invalid(self):
        xml=self.suite(self.case('<failure/>'),failures='0')
        self.assertEqual(self.evaluate(xml)['status'], 'INVALID_EVIDENCE')
    def test_extra_failure_cannot_hide_behind_passed_target(self):
        xml=self.suite(self.case()+self.case('<failure/>',name='other'),tests='2',failures='1')
        self.assertEqual(self.evaluate(xml,1)['status'],'TEST_FAIL')
    def test_doctype_rejected(self):
        xml='<!DOCTYPE a [<!ENTITY x "ok">]>'+self.suite(self.case())
        self.assertEqual(self.evaluate(xml)['status'],'INVALID_EVIDENCE')
    def test_none_exit_is_incomplete_process(self):
        self.assertEqual(self.evaluate(self.suite(self.case()),None)['status'],'PROCESS_ERROR')

if __name__ == '__main__':
    unittest.main(verbosity=2)
