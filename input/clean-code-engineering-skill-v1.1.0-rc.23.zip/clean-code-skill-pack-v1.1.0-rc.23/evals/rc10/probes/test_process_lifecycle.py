"""Real owned-process tests plus two explicitly mocked orchestration tests.

These are NOT Maven, database, or agent A/B tests. Use the RUNNER_PATH env
variable to run the identical assertions against the original or repaired runner.
All processes created here are killed in finally, including on baseline failure.
"""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

DEFAULT = Path(__file__).resolve().parents[2] / 'rc8' / 'run_integration.py'
spec = importlib.util.spec_from_file_location('lifecycle_target', os.environ.get('RUNNER_PATH', DEFAULT))
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


def live(pid):
    try:
        stat = Path('/proc/%d/stat' % pid).read_text()
        return stat[stat.rfind(')') + 2:].split()[0] not in ('Z', 'X')
    except FileNotFoundError:
        return False


def wait_for(predicate, timeout=2):
    end = time.monotonic() + timeout
    while time.monotonic() < end:
        if predicate():
            return True
        time.sleep(.01)
    return bool(predicate())


CHILD = '''import os, signal, time
signal.signal(signal.SIGTERM, signal.SIG_IGN)
print(os.getpid(), flush=True)
time.sleep(60)
'''
PARENT = '''import json, os, pathlib, subprocess, sys, time
child = subprocess.Popen([sys.executable, '-c', %r], stdout=subprocess.PIPE, text=True)
child_pid = int(child.stdout.readline())
child.stdout.close()
pathlib.Path(sys.argv[1]).write_text(json.dumps({'parent':os.getpid(), 'child':child_pid, 'group':os.getpgrp()}))
print('parent-and-child-ready', flush=True)
time.sleep(60)
''' % CHILD
SLEEPER = '''import os, pathlib, sys, time
pathlib.Path(sys.argv[1]).write_text(str(os.getpid()))
print('ready', flush=True)
time.sleep(60)
'''


@unittest.skipUnless(sys.platform.startswith('linux'), 'Live lifecycle probes use Linux /proc')
class ProcessLifecycle(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.grace = patch.object(runner, 'TERMINATION_GRACE_SECONDS', .15, create=True)
        self.grace.start()

    def tearDown(self):
        self.grace.stop()
        self.temp.cleanup()

    def execute(self, code, timeout=3, args=()):
        return runner.execute([sys.executable, '-c', code, *map(str,args)], self.root,
                              self.root/'command.log', timeout)

    def clean_group(self, pid, proc=None):
        if pid:
            self.assertNotEqual(pid, os.getpgrp(), 'Never target the test runner group')
            try:
                os.killpg(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        if proc:
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                pass

    def test_success_preserves_result_and_log_digest(self):
        result = self.execute("print('contract-ok')")
        self.assertEqual(result['status'], 'FINISHED')
        self.assertEqual(result['exit_code'], 0)
        self.assertIn('contract-ok', (self.root/'command.log').read_text())
        self.assertEqual(result['log_sha256'], hashlib.sha256((self.root/'command.log').read_bytes()).hexdigest())
        self.assertGreaterEqual(result['elapsed_seconds'], 0)

    def test_nonzero_is_not_reported_as_exit_zero(self):
        result = self.execute('import sys; print("controlled-failure"); sys.exit(7)')
        self.assertEqual(result['status'], 'FINISHED')
        self.assertEqual(result['exit_code'], 7)

    def test_launch_failure_keeps_elapsed_log_and_reason(self):
        result = runner.execute([str(self.root/'not-an-executable')], self.root,
                                self.root/'command.log', 1)
        self.assertEqual(result['status'], 'BLOCKED')
        self.assertIsNone(result['exit_code'])
        self.assertIn('elapsed_seconds', result)
        self.assertIn('log_sha256', result)
        self.assertIn('not-an-executable', (self.root/'command.log').read_text())

    def test_timeout_terminates_direct_child(self):
        marker=self.root/'pid'; pid=None
        try:
            result = self.execute(SLEEPER, 1, [marker])
            self.assertTrue(marker.exists(), 'controlled child must start before timeout')
            pid=int(marker.read_text())
            self.assertEqual(result['status'], 'TIMEOUT')
            self.assertTrue(wait_for(lambda:not live(pid)), 'direct child still running')
        finally:
            if marker.exists(): pid=int(marker.read_text())
            self.clean_group(pid)

    def test_timeout_terminates_descendant_even_when_parent_exits_on_term(self):
        marker=self.root/'tree.json'; group=None
        try:
            result = self.execute(PARENT, 1, [marker])
            self.assertTrue(marker.exists(), 'process tree readiness handshake missing')
            tree=json.loads(marker.read_text());group=tree['group']
            self.assertEqual(group,tree['parent'])
            self.assertEqual(result['status'], 'TIMEOUT')
            self.assertTrue(wait_for(lambda:not live(tree['child']), .5),
                            'grandchild ignores SIGTERM and survives after parent exits')
        finally:
            if marker.exists(): group=json.loads(marker.read_text())['group']
            self.clean_group(group)

    def test_keyboard_interrupt_terminates_started_process_and_returns_state(self):
        marker=self.root/'pid'; started=[]; real_popen=subprocess.Popen
        def create(*a, **kw):
            process=real_popen(*a, **kw);started.append(process)
            real_wait=process.wait; first=[True]
            def wait(timeout=None):
                if first[0]:
                    first[0]=False
                    if not wait_for(marker.exists):
                        raise AssertionError('child did not signal ready')
                    raise KeyboardInterrupt('controlled interruption')
                return real_wait(timeout=timeout)
            process.wait=wait
            return process
        try:
            with patch.object(runner.subprocess,'Popen',side_effect=create):
                try:
                    result=self.execute(SLEEPER,10,[marker])
                except KeyboardInterrupt:
                    self.fail('interrupt escaped without cleanup result')
            self.assertEqual(result['status'],'INTERRUPTED')
            self.assertTrue(wait_for(lambda:not live(int(marker.read_text()))), 'interrupted child still running')
            self.assertIn('log_sha256',result)
        finally:
            for p in started:self.clean_group(p.pid,p)

    def test_timeout_does_not_terminate_unrelated_process_group(self):
        unrelated=subprocess.Popen([sys.executable,'-c','import time;time.sleep(60)'],start_new_session=True)
        marker=self.root/'pid'
        try:
            result=self.execute(SLEEPER,1,[marker])
            self.assertEqual(result['status'],'TIMEOUT')
            self.assertIsNone(unrelated.poll(), 'runner killed an unrelated process group')
        finally:
            self.clean_group(unrelated.pid,unrelated)
            if marker.exists():self.clean_group(int(marker.read_text()))

    def test_batch_interrupt_stops_pending_cases_but_keeps_summary(self):
        calls=[];out=self.root/'batch'
        def item(target,*args):
            calls.append((target['engine'],target['fixture']))
            target.update(status='INTERRUPTED',comparison_confirmed=False)
        with patch.object(runner,'prerequisites',return_value={'status':'READY_FOR_ATTEMPT','issues':[]}),\
             patch.object(runner,'run_item',side_effect=item):
            exit_code=runner.run(out,['postgres','mysql'],True)
        summary=json.loads((out/'summary.json').read_text())
        self.assertEqual(calls,[('postgres','baseline')], 'remaining jobs launched after interruption')
        self.assertEqual(summary['status'],'INTERRUPTED')
        self.assertEqual(exit_code,2)
        self.assertEqual([x['status'] for x in summary['integration_results']],
                         ['INTERRUPTED','NOT_RUN','NOT_RUN','NOT_RUN'])
        self.assertFalse(summary['candidate_source_compiled'])

    def test_compile_interrupt_is_not_marked_compiled(self):
        out=self.root/'compile'
        with patch.object(runner,'prerequisites',return_value={'status':'READY_FOR_ATTEMPT','issues':[]}),\
             patch.object(runner,'compile_only',return_value={'status':'INTERRUPTED'}):
            code=runner.run(out,['postgres'],True,phase='compile')
        summary=json.loads((out/'summary.json').read_text())
        self.assertEqual(summary['status'],'INTERRUPTED')
        self.assertFalse(summary['candidate_source_compiled'])
        self.assertEqual(code,2)


if __name__=='__main__':
    unittest.main(verbosity=2)
