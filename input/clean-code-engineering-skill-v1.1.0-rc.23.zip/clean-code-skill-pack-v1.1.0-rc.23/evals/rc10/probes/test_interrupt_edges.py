"""Additional tests frozen before repair. One real SIGINT, one mocked preflight."""
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_process_lifecycle import runner, wait_for, live, PARENT

@unittest.skipUnless(sys.platform.startswith('linux'), 'POSIX/Linux process tests')
class InterruptEdges(unittest.TestCase):
    def test_real_sigint_cleans_owned_tree_and_keeps_result(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);treefile=root/'tree.json';resultfile=root/'result.json'
            launcher = '''import importlib.util,json,sys
from pathlib import Path
spec=importlib.util.spec_from_file_location('runner',sys.argv[1]);r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
r.TERMINATION_GRACE_SECONDS=.15
try:
    result=r.execute([sys.executable,'-c',%r,sys.argv[2]],Path(sys.argv[3]),Path(sys.argv[3])/'work.log',30)
except BaseException as e:
    result={'escaped':type(e).__name__}
Path(sys.argv[4]).write_text(json.dumps(result))
''' % PARENT
            process=subprocess.Popen([sys.executable,'-c',launcher,runner.__file__,str(treefile),str(root),str(resultfile)],start_new_session=True)
            try:
                self.assertTrue(wait_for(treefile.exists), 'process-tree handshake not observed')
                tree=json.loads(treefile.read_text())
                os.kill(process.pid, signal.SIGINT)
                process.wait(timeout=4)
                result=json.loads(resultfile.read_text())
                self.assertEqual(result.get('status'),'INTERRUPTED',result)
                self.assertTrue(wait_for(lambda:not live(tree['child']), .6), 'descendant survived SIGINT cleanup')
                self.assertIn('log_sha256',result)
            finally:
                if treefile.exists():
                    group=json.loads(treefile.read_text())['group']
                    self.assertNotEqual(group,os.getpgrp())
                    try:os.killpg(group,signal.SIGKILL)
                    except ProcessLookupError:pass
                if process.poll() is None:
                    os.killpg(process.pid,signal.SIGKILL)
                process.wait(timeout=2)

    def test_interrupted_preflight_never_launches_build_or_database(self):
        with tempfile.TemporaryDirectory() as temp:
            out=Path(temp)/'out'
            with patch.object(runner,'prerequisites',return_value={'status':'INTERRUPTED','issues':[]}),\
                 patch.object(runner,'run_item') as item:
                code=runner.run(out,['postgres'],True)
            summary=json.loads((out/'summary.json').read_text())
            self.assertEqual(item.call_count,0,'run launched after interrupted preflight')
            self.assertEqual(summary['status'],'INTERRUPTED')
            self.assertEqual(code,2)
            self.assertTrue(all(x['status']=='NOT_RUN' for x in summary['integration_results']))

if __name__=='__main__':unittest.main(verbosity=2)
