"""Repeat rc10 document and Python checks, not Java/DB/agent experiments.

Only controlled local subprocess fixtures are executed. Output is a NEW
folder outside the package. Linux lifecycle tests need /proc; other platforms
are explicitly UNSUPPORTED rather than treated as successful validation.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    output=Path(args.output).resolve()
    if output.exists() or output.is_relative_to(ROOT):
        parser.error('Output must be a NEW directory outside the package')
    output.mkdir(parents=True)
    spec=importlib.util.spec_from_file_location('exec_runner',ROOT/'evals/rc8/run_integration.py')
    runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
    os.environ['PYTHONDONTWRITEBYTECODE']='1'
    os.environ['RC8_RELEASE_ROOT']=str(ROOT)
    os.environ['RUNNER_PATH']=str(ROOT/'evals/rc8/run_integration.py')
    checks=['evals/test_package.py','evals/rc10/test_contract.py',
            'evals/rc8/test_runner.py','evals/rc9/test_hardening.py',
            'evals/rc3/test_evidence.py','evals/rc3/test_failure_attribution.py',
            'evals/rc6/test_change_control.py']
    work=output/'frozen-work';(work/'probes').mkdir(parents=True);(work/'evidence').mkdir()
    source=ROOT/'provenance/rc9/test_new_probes.py.txt'
    target=work/'probes/test_new_probes.py';shutil.copy2(source,target)
    checks.append(str(target))
    checks+=['evals/rc10/probes/test_process_lifecycle.py','evals/rc10/probes/test_interrupt_edges.py']
    summary={'kind':'document_and_python_process_tests_NOT_framework_or_agent_AB',
             'version':(ROOT/'VERSION').read_text().strip(),'at':datetime.now(timezone.utc).isoformat(),
             'runs':[],'real_java_compile':'NOT_RUN','real_database_integration':'NOT_RUN',
             'frozen_original_probe_identical':source.read_bytes()==target.read_bytes()}
    path=output/'summary.json'
    def save():
        temp=path.with_suffix('.json.tmp');temp.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n');temp.replace(path)
    save()
    for index,rel in enumerate(checks,1):
        case=output/('%02d'%index);case.mkdir()
        if 'rc10/probes/' in rel and not sys.platform.startswith('linux'):
            result={'status':'UNSUPPORTED','exit_code':None,'command':[rel],'reason':'Linux /proc required'}
        else:
            result=runner.execute([sys.executable,str(ROOT/rel)],work if rel==str(target) else ROOT,case/'output.log',40)
        result['check']=rel;summary['runs'].append(result);save()
        if result['status']=='INTERRUPTED':break
    summary['all_checks_executed_and_passed']=(len(summary['runs'])==len(checks) and
        all(x['status']=='FINISHED' and x['exit_code']==0 for x in summary['runs']))
    save()
    print(json.dumps({'all_checks_executed_and_passed':summary['all_checks_executed_and_passed'],'output':str(output)}))
    return 0 if summary['all_checks_executed_and_passed'] else 1

if __name__=='__main__':raise SystemExit(main())
