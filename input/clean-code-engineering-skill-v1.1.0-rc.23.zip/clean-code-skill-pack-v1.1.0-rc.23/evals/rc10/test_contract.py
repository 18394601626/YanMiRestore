"""Current document/manifest checks, not framework or model verification."""
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest

ROOT=Path(__file__).resolve().parents[2]
OLD=json.loads((ROOT/'provenance/rc10/baseline-files.json').read_text())

class RC10Contract(unittest.TestCase):
    def test_version(self):
        for name in ['VERSION','clean-code-engineering/VERSION']:
            self.assertEqual((ROOT/name).read_text().strip(),'1.1.0-rc.10')

    def test_runtime_except_version_and_integration_note_unchanged(self):
        for rel,digest in OLD.items():
            if rel.startswith('clean-code-engineering/') and rel not in (
                    'clean-code-engineering/VERSION',
                    'clean-code-engineering/references/16-real-integration.md'):
                self.assertEqual(hashlib.sha256((ROOT/rel).read_bytes()).hexdigest(),digest,rel)

    def test_new_process_tests_are_frozen_bytes(self):
        for filename,digest in json.loads((ROOT/'provenance/rc10/test-input-hashes.json').read_text()).items():
            self.assertEqual(hashlib.sha256((ROOT/'evals/rc10/probes'/filename).read_bytes()).hexdigest(),digest)

    def test_cleanup_scope_and_unrun_cases_disclosed(self):
        text=(ROOT/'clean-code-engineering/references/16-real-integration.md').read_text()
        for term in ['rc.10','INTERRUPTED','NOT_RUN','POSIX','脱离','Docker 容器','并不证明']:
            self.assertIn(term,text)

def suite():
    spec=importlib.util.spec_from_file_location('old_contract',ROOT/'evals/rc9/test_contract.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    result=unittest.TestSuite()
    def add(items):
        for test in items:
            if isinstance(test,unittest.TestSuite):add(test)
            elif test._testMethodName!='test_version':result.addTest(test)
    add(module.suite())
    result.addTests(unittest.defaultTestLoader.loadTestsFromTestCase(RC10Contract))
    return result
if __name__=='__main__':
    res=unittest.TextTestRunner(verbosity=2).run(suite())
    raise SystemExit(0 if res.wasSuccessful() else 1)
