#include "bytes.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define CHECK(x) do { if(!(x)){fprintf(stderr,"EXTRA_FAIL %s:%d: %s\n",__func__,__LINE__,#x);return 1;} } while(0)
static int attempts;
static void *counted_failure(size_t n){(void)n;++attempts;return NULL;}
static int EC01(void){char dst[2]={'x','y'};size_t n=99;CHECK(copy_label(dst,1,"",&n)==BUFFER_OK);CHECK(n==0 && dst[0]=='\0' && dst[1]=='y');return 0;}
static int EC02(void){char dst[1]={'x'};size_t n=99;CHECK(copy_label(dst,0,"",&n)==BUFFER_SPACE);CHECK(n==99 && dst[0]=='x');return 0;}
static int EC03(void){char b[12]="abcdef";size_t n=0;CHECK(copy_label(b,sizeof b,b+2,&n)==BUFFER_OK);CHECK(n==4 && !strcmp(b,"cdef"));return 0;}
static int EC04(void){size_t n=1;CHECK(checked_product(SIZE_MAX,1,&n));CHECK(n==SIZE_MAX);CHECK(!checked_product(SIZE_MAX/2+1,2,&n));CHECK(n==SIZE_MAX);return 0;}
static int EC05(void){struct blob b={NULL,0};CHECK(replace_blob(&b,"a\0b",3,malloc)==BUFFER_OK);int ok=replace_blob(&b,b.data,b.size,malloc)==BUFFER_OK && b.size==3 && !memcmp(b.data,"a\0b",3);release_blob(&b);CHECK(ok);return 0;}
static int EC06(void){struct blob b={NULL,0};CHECK(replace_blob(&b,"abcd",4,malloc)==BUFFER_OK);unsigned char *before=b.data;attempts=0;enum buffer_status s=replace_blob(&b,b.data+1,2,counted_failure);int ok=s==BUFFER_NOMEM && attempts==1 && b.data==before && b.size==4 && !memcmp(b.data,"abcd",4);release_blob(&b);CHECK(ok);return 0;}
static int EC07(void){struct blob b={NULL,0};CHECK(replace_blob(&b,"abcd",4,malloc)==BUFFER_OK);unsigned char *before=b.data;attempts=0;enum buffer_status s=replace_blob(&b,NULL,1,counted_failure);int ok=s==BUFFER_INVALID && attempts==0 && b.data==before && b.size==4 && !memcmp(b.data,"abcd",4);release_blob(&b);CHECK(ok);return 0;}
static int EC08(void){struct blob b={NULL,0};unsigned char input[256];for(size_t n=0;n<=sizeof input;++n){for(size_t i=0;i<n;++i)input[i]=(unsigned char)(i*37U+n);enum buffer_status s=replace_blob(&b,input,n,malloc);int ok=s==BUFFER_OK && b.size==n && (n==0 ? b.data==NULL : memcmp(b.data,input,n)==0);if(n>0 && ok){unsigned char old=b.data[n-1];input[n-1]^=255U;ok=b.data[n-1]==old;}if(!ok){release_blob(&b);CHECK(ok);}}release_blob(&b);return 0;}
struct entry{const char *name;int(*run)(void);};
int main(int argc,char **argv){const struct entry tests[]={{"EC01",EC01},{"EC02",EC02},{"EC03",EC03},{"EC04",EC04},{"EC05",EC05},{"EC06",EC06},{"EC07",EC07},{"EC08",EC08}};if(argc!=2)return 2;for(size_t i=0;i<sizeof tests/sizeof tests[0];++i){if(!strcmp(argv[1],tests[i].name)){int c=tests[i].run();if(c==0)printf("CASE_OK %s\n",argv[1]);return c;}}return 2;}
