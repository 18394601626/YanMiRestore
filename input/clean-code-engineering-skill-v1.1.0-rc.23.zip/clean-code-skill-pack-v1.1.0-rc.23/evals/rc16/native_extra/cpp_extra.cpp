#include "work.hpp"
#include <climits>
#include <iostream>
#include <stdexcept>
#define CHECK(x) do{if(!(x))throw std::logic_error(std::string("EXTRA_FAIL ")+__func__+": "+#x);}while(false)
using namespace rc14;
static void ECPP01(){std::vector<int> out{99};bool caught=false;try{replace_numbers(out,{"1",std::string("2\0x",3)});}catch(const std::invalid_argument&){caught=true;}CHECK(caught);CHECK(out==std::vector<int>{99});}
static void ECPP02(){std::vector<int> out{99};bool caught=false;try{replace_numbers(out,{"1","9999999999999999999999999999999"});}catch(const std::out_of_range&){caught=true;}CHECK(caught);CHECK(out==std::vector<int>{99});}
static void ECPP03(){std::vector<int> out{99};replace_numbers(out,{});CHECK(out.empty());}
static void ECPP04(){auto r=std::make_shared<Record>(Record{{"old", ""}});Records source{r,r,nullptr};auto result=snapshot(source);CHECK(result.size()==3 && result[2]==nullptr);r->tags[0]="new";CHECK(result[0]->tags[0]=="old" && result[1]->tags[0]=="old");result[0]->tags[1]="changed";CHECK(r->tags[1].empty());}
static void ECPP05(){ResourceCounts counts;bool caught=false;try{with_resource(counts,[&]{CHECK(counts.live==1);with_resource(counts,[&]{CHECK(counts.live==2);throw 42;});});}catch(int value){caught=value==42;}CHECK(caught);CHECK(counts.live==0 && counts.closed==2);}
static void ECPP06(){ResourceCounts counts;bool caught=false;try{with_resource(counts,{});}catch(const std::bad_function_call&){caught=true;}CHECK(caught);CHECK(counts.live==0 && counts.closed==1);}
static void ECPP07(){std::string input("a\0b",3);auto result=owned_name(input);input.assign("other");CHECK(result.size()==3 && result[0]=='a' && result[1]=='\0' && result[2]=='b');}
static void ECPP08(){std::vector<int> expected{INT_MIN,INT_MAX,0};for(int i=-256;i<=256;++i)expected.push_back(i);std::vector<std::string> strings;for(int i:expected)strings.push_back(std::to_string(i));std::vector<int> output{99};replace_numbers(output,strings);CHECK(output==expected);}
struct Test{const char *name;void(*run)();};
int main(int argc,char **argv){const Test tests[]={{"ECPP01",ECPP01},{"ECPP02",ECPP02},{"ECPP03",ECPP03},{"ECPP04",ECPP04},{"ECPP05",ECPP05},{"ECPP06",ECPP06},{"ECPP07",ECPP07},{"ECPP08",ECPP08}};if(argc!=2)return 2;for(const auto& t:tests)if(std::string(argv[1])==t.name){try{t.run();std::cout<<"CASE_OK "<<t.name<<'\n';return 0;}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}return 2;}
