"""Replay rc16 checks and optional languages in fresh directories; no downloads."""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import importlib.util
import json
import os
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('old_replay_helpers',ROOT/'evals/rc15/reproduce.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--language',choices=('none','native','rust','all'),default='all')
    a=p.parse_args();out=a.output.resolve()
    if out.exists() or out==ROOT or ROOT in out.parents:p.error('output must be new and outside the package root')
    out.mkdir(parents=True);os.environ.update(PACK_ROOT=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
    result={'version':(ROOT/'VERSION').read_text().strip(),'kind':'controlled_tools_and_fixtures_not_AI_AB',
            'started_utc':datetime.now(timezone.utc).isoformat(),'status':'RUNNING','stages':[],
            'language_request':a.language,'languages':{'status':'NOT_REQUESTED' if a.language=='none' else 'NOT_RUN'},
            'extra_native':{'status':'NOT_REQUESTED'},'real_ctest':{'status':'NOT_REQUESTED'}}
    def save():old.save(out,result)
    def launch(name,cmd,timeout=90):
        row=old.launch(out,name,cmd,timeout)
        if row['status']=='INTERRUPTED':
            result['stages'].append(row);save();raise KeyboardInterrupt
        return row
    save();code=1
    try:
        row=launch('book',[sys.executable,'-S','evals/rc13/reproduce.py','--output',str(out/'book-details')],120)
        if row['status']=='FINISHED':
            d=json.loads((out/'book-details/summary.json').read_text());row['observed_methods']=d['observed_test_methods']
            row['status']='PASS' if row['exit_code']==0 and d['all_pass'] is True and row['observed_methods']==90 else 'FAIL'
        result['stages'].append(row);save()
        for name,path,count in [('current-release','evals/rc16/test_current_release.py',14),('old-native-parser','evals/rc14/test_runner.py',10),
                ('old-stop','evals/rc6/test_change_control.py',7),('strict-stop','evals/rc15/test_stop_contract.py',38),
                ('old-cli','evals/rc15/test_reproduce_cli.py',4),('native-evidence','evals/rc16/test_native_evidence.py',26),
                ('current-cli','evals/rc16/test_reproduce_cli.py',4)]:
            row=launch(name,[sys.executable,'-S',path],60);old.check_unittest(row,out,count)
            result['stages'].append(row);save()
        row=old.replay_original(out);result['stages'].append(row);save()
        if row['status']=='INTERRUPTED':raise KeyboardInterrupt
        if a.language!='none':
            row=launch('languages',[sys.executable,'-S','evals/rc14/run_checks.py','--language',a.language,'--output',str(out/'language-details')],240)
            result['language_process']=row
            if row['status']=='FINISHED' and (out/'language-details/summary.json').is_file():
                result['languages']=json.loads((out/'language-details/summary.json').read_text())
                if result['languages'].get('exit_code')!=row['exit_code']:result['languages']={'status':'INVALID_EVIDENCE'}
            else:result['languages']={'status':row['status']}
            save()
        if a.language in ('native','all'):
            for name,script,args in [('extra_native','evals/rc16/run_extra.py',[]),('real_ctest','evals/rc16/run_real_ctest.py',['--root',str(ROOT)])]:
                target=out/(name+'-details');row=launch(name,[sys.executable,'-S',script,*args,'--output',str(target)],180)
                d=json.loads((target/'summary.json').read_text()) if (target/'summary.json').is_file() else {}
                ok=(d.get('status')=='PASS' if name=='extra_native' else d.get('all_expected') is True)
                state='PASS' if row['status']=='FINISHED' and row['exit_code']==0 and ok else ('BLOCKED' if row['exit_code']==2 else 'FAIL')
                result[name]={'status':state,'process':row,'details':d};save()
        tools_ok=all(r['status']=='PASS' for r in result['stages'])
        states=[result[k]['status'] for k in ('languages','extra_native','real_ctest')]
        if not tools_ok or any(s not in ('NOT_REQUESTED','EXPECTED_OBSERVATIONS_REPRODUCED','PARTIAL_BLOCKED','PASS','BLOCKED') for s in states):
            result['status']='FAIL';code=1
        elif any(s in ('BLOCKED','PARTIAL_BLOCKED') for s in states):result['status']='PARTIAL_BLOCKED';code=2
        else:result['status']='CHECKS_PASSED';code=0
    except KeyboardInterrupt:result['status']='INTERRUPTED';code=130
    except Exception as e:result.update(status='ERROR',reason=type(e).__name__+': '+str(e));code=1
    finally:
        result['exit_code']=code;result['observed_test_methods']=sum(r['observed_methods'] for r in result['stages'])
        result['finished_utc']=datetime.now(timezone.utc).isoformat();save()
    print(result['status'],'tool_methods='+str(result['observed_test_methods']))
    for r in result['stages']:print(r['id'],r['status'],r['observed_methods'])
    return code
if __name__=='__main__':raise SystemExit(main())
