# rc.16：CTest 证据归属与 C/C++ 边界回归

这是受控 fixture 验证，不是独立模型A/B，不是原书内容补全。

## 修复范围

只修 `evals/rc14/run_checks.py` 中本包 CTest XML 的判定。`CASE_OK`/`CASE_FAIL` 必须是整行且单一终态；失败原因只能来自该用例唯一的 `CONTRACT_FAIL` 行，C的可选源代码行号保留。旧REASONS中的片段允许匹配该行表达式，不能从其他行借词。已确认行添加到 `confirmed_failure_causes`，既有输出字段不删除。

元数据 `status` 和 tests/failures/errors/skipped/disabled 计数若出现，必须与case节点一致；原简化报告可以不提供这些可选属性。重复system-out或矛盾标记不能判PASS。它不是通用JUnit解析器，不是恶意报告鉴真器；一个不诚实的程序仍能伪造一致的标记，需可信执行来源。

## 新增测试

26个Python检查：6个原本已能通过，20个在rc15不满足本次证据要求；这是受控输入，不是20处生产事故。原10项解析器测试保持不变。

`run_real_ctest.py` 先真正compile一个短C程序，再调用本机CTest产生3份XML：匹配的失败、从无关日志借词的失败、打印失败但退出0的矛盾成功。不是模拟解析XML生成器，也不是实际业务故障。

16个新增C/C++运行测试在原修正版上执行，未改变旧实现：8个C检查零容量、重叠、边界乘法、原地替换、分配失败与非法输入；8个C++检查内嵌NUL、溢出、空批次、共享源快照、嵌套资源和非std异常等。EC08为257种长度、ECPP08为516个整数的确定性组合测试，不称为模糊测试或独立样本。结果由真实编译运行确认。

## 复现

在完整包根目录运行 `python -S evals/rc16/reproduce.py --output ../new-run --language all`。
只跑资料与工具用 `--language none`；只跑C/C++用 `--language native`。新目录必须在包外。脚本不下载依赖，不改工具链，不连接生产。

当前Rust仍为BLOCKED，不能用C/C++通过代替Rust编译；没有运行Spring或数据库。--language all 返回2是请求范围未全部完成；--language native通过不包含Rust。

原书资料、STOP工具、旧业务源码及测试未改。精确版本/全文件哈希绑定rc15的旧发布测试保留给rc15；本版使用其8个非版本适配检查、2个通用契约检查，并新增4个本版保护检查，明确不宣称原完整172项在新版本逐字重跑。
