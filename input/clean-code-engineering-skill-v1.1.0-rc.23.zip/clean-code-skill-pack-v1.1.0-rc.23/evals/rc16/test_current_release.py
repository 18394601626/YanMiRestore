"""Current identity and preservation; old exact-version assertions stay archived."""
import hashlib
import importlib.util
import json
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2]
def load(name,path):
    s=importlib.util.spec_from_file_location(name,ROOT/path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
adapters=load('historical_adapters','evals/rc14/test_adapters.py')
previous=load('previous_release_checks','evals/rc15/test_current_release.py')
ALLOWED={'README.md','CHANGELOG.md','VALIDATION.md','VERSION','SHA256SUMS.txt','FIX_SUMMARY.json',
         'clean-code-engineering/VERSION','clean-code-engineering/assets/language-support.json','evals/rc14/run_checks.py'}
class CurrentRelease(unittest.TestCase):
    def test_identity(self):
        for n in ('VERSION','clean-code-engineering/VERSION'):
            self.assertEqual((ROOT/n).read_text().strip(),'1.1.0-rc.16')
        self.assertEqual(json.loads((ROOT/'clean-code-engineering/assets/language-support.json').read_text())['version'],'1.1.0-rc.16')
    def test_prior_content_preserved_outside_explicit_patch(self):
        hashes=json.loads((ROOT/'provenance/rc16/baseline-hashes.json').read_text())
        for n,h in hashes.items():
            if n not in ALLOWED:
                with self.subTest(file=n):self.assertEqual(hashlib.sha256((ROOT/n).read_bytes()).hexdigest(),h)
    def test_new_tests_unchanged(self):
        hashes=json.loads((ROOT/'provenance/rc16/frozen-tests.json').read_text())
        self.assertGreaterEqual(len(hashes),6)
        for n,h in hashes.items():self.assertEqual(hashlib.sha256((ROOT/n).read_bytes()).hexdigest(),h,n)
    def test_scope_and_evidence_boundaries_documented(self):
        text=(ROOT/'evals/rc16/README.md').read_text()
        for t in ('26','16','CTest','Rust','BLOCKED','不是','原书','compile','fixture'):
            self.assertIn(t,text)
if __name__=='__main__':
    l=unittest.defaultTestLoader;s=unittest.TestSuite()
    for name in l.getTestCaseNames(adapters.AdapterContracts):
        if name not in previous.OLD_EXCLUSIONS:s.addTest(adapters.AdapterContracts(name))
    for name in ('test_stop_input_contract_documented','test_frozen_regressions'):
        s.addTest(previous.CurrentReleaseTests(name))
    s.addTests(l.loadTestsFromTestCase(CurrentRelease))
    r=unittest.TextTestRunner(verbosity=2).run(s);raise SystemExit(0 if r.wasSuccessful() else 1)
