"""Run 16 new behavior tests against the unchanged, bundled C/C++ sources."""
from __future__ import annotations
import argparse
import importlib.util
import json
from pathlib import Path
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('native_extra_support',ROOT/'evals/rc14/run_checks.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
EXPECTED=['EC%02d'%i for i in range(1,9)]+['ECPP%02d'%i for i in range(1,9)]

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();out=a.output.resolve()
    if out.exists() or out==ROOT or ROOT in out.parents:p.error('output must be new and outside the package')
    out.mkdir(parents=True);result={'status':'RUNNING','commands':[],'runs':[], 'unique_contracts':16,'implementation_unchanged':True}
    def save():
        t=out/'summary.tmp';t.write_text(json.dumps(result,indent=2)+'\n');t.replace(out/'summary.json')
    save()
    def cmd(label,args):
        r=runner.support.execute(args,ROOT,out/(label+'.log'),45);r.update(id=label,log=label+'.log');result['commands'].append(r);save()
        if r['status']=='INTERRUPTED':raise KeyboardInterrupt
        return r
    code=1
    try:
        missing=[x for x in ('cmake','ctest','gcc','g++','clang','clang++') if not shutil.which(x)]
        if missing:
            result.update(status='BLOCKED',missing=missing);code=2
        else:
            for name,cc,cxx,cs,cpps,san in [('gcc-c11-cpp17','gcc','g++',11,17,False),('clang-c17-cpp20','clang','clang++',17,20,False),('clang-sanitized','clang','clang++',11,17,True)]:
                build=out/(name+'-build');report=out/(name+'.xml');row={'id':name,'status':'NOT_RUN'};result['runs'].append(row)
                r=cmd(name+'-configure',['cmake','-S',str(HERE/'native_extra'),'-B',str(build),'-DORIGINAL_NATIVE='+str(ROOT/'evals/rc14/native'),'-DCMAKE_C_COMPILER='+shutil.which(cc),'-DCMAKE_CXX_COMPILER='+shutil.which(cxx),'-DCMAKE_C_STANDARD='+str(cs),'-DCMAKE_CXX_STANDARD='+str(cpps),'-DSANITIZE='+('ON' if san else 'OFF')])
                if r['status']!='FINISHED' or r['exit_code']!=0:row['status']='CONFIGURE_FAILED';save();continue
                r=cmd(name+'-build',['cmake','--build',str(build),'-j2'])
                if r['status']!='FINISHED' or r['exit_code']!=0:row['status']='COMPILE_FAILED';save();continue
                r=cmd(name+'-test',['ctest','--test-dir',str(build),'--output-on-failure','--no-tests=error','--output-junit',str(report)])
                row.update(runner.inspect_ctest(report,r['exit_code'],EXPECTED,{}) if r['status']=='FINISHED' else {'status':r['status']});save()
            result['status']='PASS' if len(result['runs'])==3 and all(r['status']=='PASS' for r in result['runs']) else 'FAIL'
            code=0 if result['status']=='PASS' else 1
    except KeyboardInterrupt:result['status']='INTERRUPTED';code=130
    except Exception as e:result.update(status='ERROR',reason=type(e).__name__+': '+str(e));code=1
    finally:result['exit_code']=code;save()
    print(result['status']);return code
if __name__=='__main__':raise SystemExit(main())
