"""CTest evidence regressions for this package's protocol, not universal JUnit."""
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(os.environ['PACK_ROOT']).resolve()
spec = importlib.util.spec_from_file_location('tested_native_runner', ROOT/'evals/rc14/run_checks.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


def report(output='CASE_OK T1\n', terminal=None, status=None, **attributes):
    suite = ET.Element('testsuite', tests='1', **attributes)
    tc = ET.SubElement(suite, 'testcase', name='T1')
    if status is not None: tc.set('status', status)
    if terminal: ET.SubElement(tc, terminal)
    ET.SubElement(tc, 'system-out').text = output
    return suite


class NativeEvidence(unittest.TestCase):
    def parse(self, tree, failures=None):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'result.xml'
            path.write_bytes(ET.tostring(tree, encoding='utf-8', xml_declaration=True))
            return runner.inspect_ctest(path, 8 if failures else 0, ['T1'], failures or {})

    def reject(self, tree, failures=None):
        observed = self.parse(tree, failures)
        self.assertNotIn(observed['status'], ('PASS','EXPECTED_FAILURES'), observed)

    def test_plain_success(self):
        self.assertEqual(self.parse(report())['status'], 'PASS')

    def test_ctest_status_run(self):
        self.assertEqual(self.parse(report(status='run', failures='0', skipped='0', disabled='0'))['status'],'PASS')

    def test_cpp_failure_exact(self):
        self.assertEqual(self.parse(report('CONTRACT_FAIL T1: expected reason\nCASE_FAIL T1\n','failure','fail', failures='1'), {'T1':'expected reason'})['status'], 'EXPECTED_FAILURES')

    def test_c_failure_line_number(self):
        self.assertEqual(self.parse(report('CONTRACT_FAIL T1:47: expected reason\nCASE_FAIL T1\n','failure','fail'), {'T1':'expected reason'})['status'], 'EXPECTED_FAILURES')

    def test_expected_expression_is_fragment_of_actual_expression(self):
        self.assertEqual(self.parse(report('CONTRACT_FAIL T1:47: copy_label(out,3,"Ada",&n)==BUFFER_SPACE\nCASE_FAIL T1\n','failure','fail'), {'T1':'==BUFFER_SPACE'})['status'], 'EXPECTED_FAILURES')

    def test_unrelated_line_cannot_supply_failure_reason(self):
        self.reject(report('note: expected reason\nCONTRACT_FAIL T1: unrelated precondition\nCASE_FAIL T1\n','failure','fail'), {'T1':'expected reason'})

    def test_another_contract_cannot_supply_reason(self):
        self.reject(report('CONTRACT_FAIL Other: expected reason\nCONTRACT_FAIL T1: unrelated\nCASE_FAIL T1\n','failure'), {'T1':'expected reason'})

    def test_quoted_diagnostic_is_not_live_failure(self):
        self.reject(report('documentation: CONTRACT_FAIL T1: expected reason\nCASE_FAIL T1\n','failure'), {'T1':'expected reason'})

    def test_fail_marker_must_be_whole_line(self):
        self.reject(report('CONTRACT_FAIL T1: expected reason\nexample CASE_FAIL T1\n','failure'), {'T1':'expected reason'})

    def test_contradictory_pass_and_fail_markers(self):
        self.reject(report('CONTRACT_FAIL T1: expected reason\nCASE_OK T1\nCASE_FAIL T1\n','failure'), {'T1':'expected reason'})

    def test_success_cannot_contain_failed_contract(self):
        self.reject(report('CONTRACT_FAIL T1: actual failure\nCASE_OK T1\n'))

    def test_multiple_contract_outcomes_ambiguous(self):
        self.reject(report('CONTRACT_FAIL T1: expected reason\nCONTRACT_FAIL T1: unrelated\nCASE_FAIL T1\n','failure'), {'T1':'expected reason'})

    def test_suite_failure_count_must_match(self):
        self.reject(report(failures='1'))

    def test_suite_error_count_must_match(self):
        self.reject(report(errors='1'))

    def test_suite_skip_count_must_match(self):
        self.reject(report(skipped='1'))

    def test_suite_disabled_count_must_match(self):
        self.reject(report(disabled='1'))

    def test_counts_cannot_be_negative(self):
        self.reject(report(failures='-1'))

    def test_counts_cannot_be_nonnumeric(self):
        self.reject(report(errors='nan'))

    def test_notrun_with_success_marker_rejected(self):
        self.reject(report(status='notrun'))

    def test_fail_status_without_failure_node_rejected(self):
        self.reject(report(status='fail'))

    def test_run_status_with_failure_node_rejected(self):
        self.reject(report('CONTRACT_FAIL T1: expected reason\nCASE_FAIL T1\n','failure','run'), {'T1':'expected reason'})

    def test_unknown_status_rejected(self):
        self.reject(report(status='finished-ish'))

    def test_duplicate_output_blocks_rejected(self):
        tree=report();ET.SubElement(tree.find('testcase'),'system-out').text='CASE_FAIL T1'
        self.reject(tree)

    def test_duplicate_terminal_markers_rejected(self):
        self.reject(report('CASE_OK T1\nCASE_OK T1\n'))

    def test_report_output_preserves_case_local_diagnostic(self):
        observed=self.parse(report('CONTRACT_FAIL T1:25: expected reason\nCASE_FAIL T1\n','failure'), {'T1':'expected reason'})
        self.assertEqual(observed.get('confirmed_failure_causes',{}).get('T1'), 'CONTRACT_FAIL T1:25: expected reason')

    def test_ordinary_logging_is_allowed(self):
        self.assertEqual(self.parse(report('starting work\nCASE_OK T1\nresource cleanup complete\n'))['status'],'PASS')

if __name__=='__main__':unittest.main(verbosity=2)
