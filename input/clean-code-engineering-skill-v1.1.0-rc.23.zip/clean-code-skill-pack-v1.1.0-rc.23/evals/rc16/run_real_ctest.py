"""Actual gcc/CTest probe. Controlled outputs, not real business failures."""
import argparse,importlib.util,json,os,shutil,subprocess,sys,time
from pathlib import Path

C_SOURCE=r'''#include <stdio.h>
#include <string.h>
int main(int argc,char **argv) {
    if(argc!=2) return 2;
    if(strcmp(argv[1],"matching")==0) {
        puts("CONTRACT_FAIL T1:42: expected reason");
        puts("CASE_FAIL T1");
        return 1;
    }
    if(strcmp(argv[1],"borrowed")==0) {
        puts("note: this suite also checks expected reason");
        puts("CONTRACT_FAIL T1:42: unrelated precondition");
        puts("CASE_FAIL T1");
        return 1;
    }
    if(strcmp(argv[1],"false-success")==0) {
        puts("CONTRACT_FAIL T1:42: actual failed assertion");
        puts("CASE_OK T1");
        return 0;
    }
    return 2;
}
'''

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
    a=p.parse_args();root=a.root.resolve();out=a.output.resolve()
    if out.exists() or out==root or root in out.parents:p.error('output must be new and outside root')
    out.mkdir(parents=True);rows=[];commands=[]
    spec=importlib.util.spec_from_file_location('probe_runner',root/'evals/rc14/run_checks.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    def cmd(label,args):
        start=time.monotonic();r=subprocess.run(args,cwd=out,capture_output=True,timeout=30)
        (out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr)
        commands.append({'id':label,'command':args,'exit_code':r.returncode,'seconds':time.monotonic()-start});return r.returncode
    missing=[x for x in ('gcc','ctest') if not shutil.which(x)]
    if missing:
        (out/'summary.json').write_text(json.dumps({'status':'BLOCKED','missing':missing,'actual_tests':0}));return 2
    source=out/'probe.c';source.write_text(C_SOURCE)
    if cmd('compile',['gcc','-std=c11','-Wall','-Wextra','-Werror',str(source),'-o',str(out/'probe')])!=0:return 1
    for name in ('matching','borrowed','false-success'):
        d=out/name;d.mkdir();(d/'CTestTestfile.cmake').write_text('add_test(T1 "'+str(out/'probe')+'" "'+name+'")\n')
        report=d/'report.xml';code=cmd(name,['ctest','--test-dir',str(d),'--output-on-failure','--no-tests=error','--output-junit',str(report)])
        obs=m.inspect_ctest(report,code,['T1'],{} if name=='false-success' else {'T1':'expected reason'})
        confirmed=obs['status'] in ('PASS','EXPECTED_FAILURES');wanted=name=='matching'
        rows.append({'case':name,'ctest_exit':code,'expected_confirmation':wanted,'observed':obs,'matches':confirmed==wanted})
    result={'kind':'actual_CTest_controlled_output_not_business_or_AI_AB','all_expected':all(r['matches'] for r in rows),'observations':rows,'commands':commands}
    (out/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));return 0 if result['all_expected'] else 1
if __name__=='__main__':raise SystemExit(main())
