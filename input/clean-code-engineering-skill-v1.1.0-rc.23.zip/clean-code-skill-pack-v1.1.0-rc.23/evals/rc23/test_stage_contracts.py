"""Frozen contract probes. JSON mutations are controlled inputs, not AI trials.

Tests marked flow start real Python child processes; they do NOT start Go/JDK,
Maven, databases, or models. Archived reports are shape-positive fixtures only.
"""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(os.environ.get('RC23_TARGET_ROOT', Path(__file__).resolve().parents[2])).resolve()

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

m = load('rc23_target_verify', ROOT / 'evals/rc22/reproduce.py')
support = load('rc23_target_process', ROOT / 'evals/rc8/run_integration.py')
ARCHIVE = ROOT / 'evidence/rc22/system-full'

def report(name):
    return json.loads((ARCHIVE / name / 'summary.json').read_text())

class StageContracts(unittest.TestCase):
    def test_01_archived_positive_shapes_remain_accepted(self):
        # Reading old reports is not fresh language execution; run verify.py for that.
        for name, kind, code, expected in (
            ('java-jdk', 'jdk', 0, 'PASS'),
            ('go-resources', 'go-resources', 0, 'PASS'),
            ('go-modules', 'go-modules', 0, 'PASS'),
            ('core-languages', 'core', 2, 'PARTIAL_BLOCKED'),
            ('framework-compile', 'framework-compile', 2, 'BLOCKED'),
            ('framework-integration', 'framework-integration', 2, 'BLOCKED'),
        ):
            with self.subTest(stage=name):
                self.assertEqual(m.normalized(report(name), code, kind), expected)

    def test_02_nonobject_root_is_invalid_not_exception(self):
        for kind in ('jdk','go-resources','go-modules','core','standard','unittest','framework-compile'):
            for value in (None, [], 'PASS', 1, True):
                with self.subTest(kind=kind,value=value):
                    self.assertEqual(m.normalized(value, 0, kind), 'INVALID_EVIDENCE')

    def test_03_exit_code_must_be_integer_not_boolean(self):
        for code in (False, True, 0.0, '0', None):
            with self.subTest(code=code):
                self.assertEqual(m.normalized({'status':'PASS','exit_code':code}, code, 'standard'), 'INVALID_EVIDENCE')

    def test_04_unknown_adapter_cannot_default_to_standard(self):
        self.assertEqual(m.normalized({'status':'PASS','exit_code':0},0,'jkd'), 'INVALID_EVIDENCE')

    def test_05_jdk_names_without_outcomes_cannot_pass(self):
        data=report('java-jdk')
        data['cases']=[{'case':x['case']} for x in data['cases']]
        self.assertEqual(m.normalized(data,0,'jdk'),'INVALID_EVIDENCE')

    def test_06_jdk_duplicate_identity_cannot_replace_missing_case(self):
        data=report('java-jdk'); data['cases'][-1]=copy.deepcopy(data['cases'][0])
        self.assertEqual(m.normalized(data,0,'jdk'),'INVALID_EVIDENCE')

    def test_07_jdk_missing_required_boolean_rejected(self):
        data=report('java-jdk'); del data['cases'][0]['good_hidden_pass']
        self.assertEqual(m.normalized(data,0,'jdk'),'INVALID_EVIDENCE')

    def test_08_jdk_unknown_case_rejected(self):
        data=report('java-jdk');data['cases'][0]['case']='unrelated_case'
        self.assertEqual(m.normalized(data,0,'jdk'),'INVALID_EVIDENCE')

    def test_09_jdk_false_boolean_is_failure_not_schema_error(self):
        data=report('java-jdk');data['cases'][0]['good_hidden_pass']=False
        self.assertEqual(m.normalized(data,0,'jdk'),'FAIL')

    def test_10_jdk_additional_metadata_does_not_change_boolean_contract(self):
        data=report('java-jdk');data['cases'][0]['note']='diagnostic metadata'
        self.assertEqual(m.normalized(data,0,'jdk'),'PASS')

    def test_11_go_empty_observation_placeholders_cannot_pass(self):
        data=report('go-resources');data['observations']=[{} for _ in range(11)]
        self.assertEqual(m.normalized(data,0,'go-resources'),'INVALID_EVIDENCE')

    def test_12_go_child_disagreement_overrides_parent_success(self):
        data=report('go-resources');data['observations'][3]['matches_expected_observation']=False
        self.assertEqual(m.normalized(data,0,'go-resources'),'FAIL')

    def test_13_go_observed_state_must_equal_known_expectation(self):
        data=report('go-resources');row=data['observations'][3]
        row.update(observed='BLOCKED', expected='BLOCKED', matches_expected_observation=True)
        self.assertEqual(m.normalized(data,0,'go-resources'),'INVALID_EVIDENCE')

    def test_14_go_duplicate_identity_rejected(self):
        data=report('go-resources');data['observations'][-1]=copy.deepcopy(data['observations'][0])
        self.assertEqual(m.normalized(data,0,'go-resources'),'INVALID_EVIDENCE')

    def test_15_go_module_count_alone_is_not_identity(self):
        data=report('go-modules');data['assertions']={str(n):True for n in range(11)}
        self.assertEqual(m.normalized(data,0,'go-modules'),'INVALID_EVIDENCE')

    def test_16_nested_wrong_types_are_invalid_not_exception(self):
        for name,kind,key,bad in (
            ('java-jdk','jdk','cases',[None]),
            ('go-resources','go-resources','observations',None),
            ('go-modules','go-modules','assertions',[]),
            ('core-languages','core','runtime',[None]),
            ('core-languages','core','runtime',{}),
            ('framework-compile','framework-compile','prerequisites',[]),
            ('framework-integration','framework-integration','integration_results',[None]),
        ):
            data=report(name);data[key]=bad
            with self.subTest(stage=name,key=key,bad=bad):
                self.assertEqual(m.normalized(data,2 if name.startswith(('core','framework')) else 0,kind),'INVALID_EVIDENCE')

    def test_17_framework_blocked_candidate_pairs_are_unique(self):
        data=report('framework-compile');data['integration_results'][-1]=copy.deepcopy(data['integration_results'][0])
        self.assertEqual(m.normalized(data,2,'framework-compile'),'INVALID_EVIDENCE')

    def test_18_core_missing_named_stage_cannot_be_success(self):
        data=report('core-languages');data['runtime'].pop(1)
        self.assertEqual(m.normalized(data,2,'core'),'INVALID_EVIDENCE')

    def test_19_core_nested_run_list_cannot_be_string(self):
        data=report('core-languages');data['runtime'][0]['details']['runs']='PASS'
        self.assertEqual(m.normalized(data,2,'core'),'INVALID_EVIDENCE')

    def test_20_order_changes_are_not_failures(self):
        for name,kind,key in [('java-jdk','jdk','cases'),('go-resources','go-resources','observations')]:
            data=report(name);data[key].reverse()
            with self.subTest(stage=name):self.assertEqual(m.normalized(data,0,kind),'PASS')

    def test_21_invalid_stage_payload_does_not_break_inventory(self):
        rows=[{'id':'core-languages','status':'INVALID_EVIDENCE','data':{'runtime':[None]}}]
        self.assertIsInstance(m.collect_observed(rows),dict)

    def test_22_rejected_core_payload_cannot_promote_embedded_pass(self):
        data=report('core-languages')
        observed=m.collect_observed([{'id':'core-languages','status':'INVALID_EVIDENCE','data':data}])
        self.assertNotEqual(observed.get('typescript',{}).get('status'), 'PASS')

    def test_23_planned_missing_supplement_is_incomplete_not_pass(self):
        rows=[{'id':'go-modules','status':'PASS'}]
        observed=m.collect_observed(rows, requested_stages=['go-modules','go-resources'])
        self.assertEqual(observed['go']['status'],'INCOMPLETE')
        reg={'languages':{'go':{'guide':'references/08-go.md','status':'HISTORICAL_CONTROLLED_TESTS'}}}
        inventory=m.checks.inventory(reg,observed)[0]
        self.assertEqual(inventory['current_status'],'INCOMPLETE')
        self.assertTrue(inventory['runtime_executed'])

    def test_24_unrequested_supplement_does_not_block_partial_profile(self):
        observed=m.collect_observed([{'id':'go-modules','status':'PASS'}],requested_stages=['go-modules'])
        self.assertEqual(observed['go']['status'],'PASS')

    def test_25_absent_core_leaves_language_not_run(self):
        reg={'languages':{'go':{'guide':'references/08-go.md','status':'HISTORICAL_CONTROLLED_TESTS'}}}
        inv=m.checks.inventory(reg,m.collect_observed([],requested_stages=['go-modules','go-resources']))
        self.assertEqual(inv[0]['current_status'],'NOT_RUN')

    def _flow(self, raw, kind='core', projection_error=False):
        # Actual Python children write the controlled report. No compiler/database.
        with tempfile.TemporaryDirectory() as tmp:
            folder=Path(tmp);root=folder/'package';root.mkdir();out=folder/'out'
            (root/'VERSION').write_text('probe-version')
            (root/'RELEASE.json').write_text(json.dumps({'parent_sha256':'0'*64}))
            assets=root/'clean-code-engineering/assets';assets.mkdir(parents=True)
            (assets/'language-support.json').write_text(json.dumps({'languages':{}}))
            (root/'payload.txt').write_text(raw)
            (root/'probe.py').write_text('import argparse,json\nfrom pathlib import Path\np=argparse.ArgumentParser();p.add_argument("--output");a=p.parse_args();o=Path(a.output);o.mkdir();(o/"summary.json").write_text(Path("payload.txt").read_text())\n')
            (root/'after.py').write_text('import argparse,json\nfrom pathlib import Path\np=argparse.ArgumentParser();p.add_argument("--output");a=p.parse_args();o=Path(a.output);o.mkdir();(o/"summary.json").write_text(json.dumps({"status":"PASS","exit_code":0}))\n')
            rewritten=root/'evals/rc22/run_core.py'
            rewritten.parent.mkdir(parents=True)
            rewritten.write_bytes((root/'probe.py').read_bytes())
            manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(root).as_posix()+'\n' for p in sorted(root.rglob('*')) if p.is_file())
            (root/'SHA256SUMS.txt').write_text(manifest)
            tasks=[('core-languages','probe.py',[],10,kind),('after','after.py',[],10,'standard')]
            keys=('PACK_ROOT','RC18_ROOT','RC20_TARGET_ROOT','RC21_TARGET_ROOT','RC22_TARGET_ROOT','PYTHONDONTWRITEBYTECODE')
            with patch.dict(os.environ,{}):
                before={k:os.environ.get(k) for k in keys}
                with patch.object(m,'ROOT',root),patch.object(m,'plan',return_value=tasks),patch.object(m,'load',return_value=support),patch.object(sys,'argv',['verify.py','--output',str(out)]),contextlib.redirect_stdout(io.StringIO()):
                    if projection_error:
                        with patch.object(m,'collect_observed',side_effect=ValueError('controlled inventory failure')):
                            code=m.main()
                    else:code=m.main()
                self.assertEqual({k:os.environ.get(k) for k in keys},before,'environment must be restored')
            result=json.loads((out/'summary.json').read_text())
            self.assertEqual(result['rows'][0]['process']['exit_code'],0,'probe process must actually execute')
            self.assertEqual((out/'core-languages/summary.json').read_text(),raw,'same controlled payload must reach parser')
            self.assertEqual(code,1);self.assertEqual(result['status'],'FAIL')
            self.assertIn('finished_utc',result)
            self.assertEqual(result['rows'][-1]['id'],'after')
            self.assertEqual(result['rows'][-1]['status'],'PASS')
            if not projection_error:
                self.assertEqual(result['rows'][0]['status'],'INVALID_EVIDENCE')
            else:self.assertIn('inventory_error',result)
            return result

    def test_26_flow_json_null_finalizes_and_runs_later_stage(self):
        self._flow('null')

    def test_27_flow_nested_null_finalizes_and_restores_environment(self):
        self._flow(json.dumps({'status':'PASS','exit_code':0,'runtime':[None]}))

    def test_28_flow_truncated_json_records_invalid_evidence(self):
        self._flow('{broken')

    def test_29_flow_projection_failure_still_saves_and_restores(self):
        self._flow(json.dumps({'status':'PASS','exit_code':0}),kind='standard',projection_error=True)

if __name__ == '__main__':
    unittest.main(verbosity=2)
