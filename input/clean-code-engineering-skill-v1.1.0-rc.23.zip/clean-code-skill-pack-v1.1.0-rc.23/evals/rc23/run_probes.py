"""Record the 36 regression methods including subtest failures without inflating counts."""
import argparse
import contextlib
import importlib.util
import json
import os
from pathlib import Path
import sys
import unittest

class Recorder(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs);self.methods={}
    def startTest(self,test):
        self.methods[test.id()]={'status':'PASS','failure_subtests':0,'error_subtests':0}
        super().startTest(test)
    def addFailure(self,test,error):
        self.methods[test.id()]['status']='FAIL';super().addFailure(test,error)
    def addError(self,test,error):
        self.methods[test.id()]['status']='ERROR';super().addError(test,error)
    def addSubTest(self,test,subtest,error):
        if error:
            kind='failure_subtests' if issubclass(error[0],test.failureException) else 'error_subtests'
            row=self.methods[test.id()];row[kind]+=1;row['status']='FAIL' if kind=='failure_subtests' and row['status']!='ERROR' else 'ERROR'
        super().addSubTest(test,subtest,error)

def main():
    p=argparse.ArgumentParser();p.add_argument('--target-root',type=Path,default=Path(__file__).resolve().parents[2]);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    out=args.output.resolve();root=args.target_root.resolve()
    if out.exists() or root==out or root in out.parents:p.error('output must be new and outside target root')
    out.mkdir(parents=True)
    os.environ['RC23_TARGET_ROOT']=str(root);os.environ['PYTHONDONTWRITEBYTECODE']='1'
    suite=unittest.TestSuite()
    for name in ('test_stage_contracts','test_core_reports'):
        spec=importlib.util.spec_from_file_location(name,Path(__file__).with_name(name+'.py'))
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        suite.addTests(unittest.defaultTestLoader.loadTestsFromModule(module))
    with (out/'unittest.log').open('w') as log,contextlib.redirect_stdout(log):
        result=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Recorder).run(suite)
    data={'target_root':str(root),'kind':'controlled_report_and_process_probes_not_AI_trials',
          'methods':result.testsRun,'success':result.wasSuccessful(),'results':result.methods,
          'failure_records':len(result.failures),'error_records':len(result.errors)}
    data['method_counts']={state:sum(row['status']==state for row in result.methods.values()) for state in ('PASS','FAIL','ERROR')}
    (out/'summary.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(data['method_counts']));return 0 if result.wasSuccessful() else 1
if __name__=='__main__':raise SystemExit(main())
