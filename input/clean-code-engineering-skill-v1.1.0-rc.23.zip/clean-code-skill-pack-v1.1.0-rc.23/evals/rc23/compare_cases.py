"""Collect before/after outputs of the frozen probes, without changing inputs."""
import argparse, contextlib, hashlib, importlib.util, io, json, os, sys
from pathlib import Path
from unittest.mock import patch

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    p=argparse.ArgumentParser();p.add_argument('--baseline',required=True,type=Path);p.add_argument('--current',required=True,type=Path);p.add_argument('--output',required=True,type=Path);a=p.parse_args();a.output.mkdir()
    result={'kind':'controlled_report_inputs_not_model_AB','observations':[]}
    for label,root in [('before',a.baseline),('after',a.current)]:
        m=load('compare_'+label,root/'evals/rc22/reproduce.py')
        support=load('support_'+label,root/'evals/rc8/run_integration.py')
        fixtures=root/'evidence/rc22/system-full'
        j=json.loads((fixtures/'java-jdk/summary.json').read_text());j['cases']=[{'case':r['case']} for r in j['cases']]
        g=json.loads((fixtures/'go-resources/summary.json').read_text());g['observations']=[{} for _ in range(11)]
        for case,value,kind in [('jdk-count-without-outcomes',j,'jdk'),('go-empty-placeholders',g,'go-resources')]:
            entry={'version':label,'case':case,'input':value,'actual':m.normalized(value,0,kind)}
            result['observations'].append(entry)
        for case,payload in [('json-null','null'),('nested-null',json.dumps({'status':'PASS','exit_code':0,'runtime':[None]}))]:
            work=a.output/(label+'-'+case);work.mkdir();mini=work/'package';mini.mkdir();out=work/'run'
            (mini/'VERSION').write_text('controlled-report-probe');(mini/'RELEASE.json').write_text(json.dumps({'parent_sha256':'0'*64}))
            reg=mini/'clean-code-engineering/assets';reg.mkdir(parents=True);(reg/'language-support.json').write_text('{"languages":{}}')
            (mini/'payload.txt').write_text(payload)
            prefix='import argparse,json\nfrom pathlib import Path\np=argparse.ArgumentParser();p.add_argument("--output");a=p.parse_args();o=Path(a.output);o.mkdir();'
            (mini/'probe.py').write_text(prefix+'(o/"summary.json").write_text(Path("payload.txt").read_text())\n')
            (mini/'after.py').write_text(prefix+'(o/"summary.json").write_text(json.dumps({"status":"PASS","exit_code":0}))\n')
            rewired=mini/'evals/rc22/run_core.py';rewired.parent.mkdir(parents=True);rewired.write_bytes((mini/'probe.py').read_bytes())
            (mini/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.relative_to(mini).as_posix()+'\n' for f in sorted(mini.rglob('*')) if f.is_file()))
            keys=('PACK_ROOT','RC18_ROOT','RC20_TARGET_ROOT','RC21_TARGET_ROOT','RC22_TARGET_ROOT','PYTHONDONTWRITEBYTECODE')
            saved={key:os.environ.get(key) for key in keys};log=io.StringIO();entry={'version':label,'case':case,'input':json.loads(payload),'error':None}
            with patch.object(m,'ROOT',mini),patch.object(m,'plan',return_value=[('core-languages','probe.py',[],10,'core'),('after','after.py',[],10,'standard')]),patch.object(m,'load',return_value=support),patch.object(sys,'argv',['verify.py','--output',str(out)]),contextlib.redirect_stdout(log):
                try:entry['returncode']=m.main()
                except Exception as error:entry['error']=repr(error)
            entry['environment_restored']={key:os.environ.get(key) for key in keys}==saved
            for key,value in saved.items():
                if value is None:os.environ.pop(key,None)
                else:os.environ[key]=value
            (work/'stdout.log').write_text(log.getvalue());entry['summary']=json.loads((out/'summary.json').read_text())
            result['observations'].append(entry)
    (a.output/'observations.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    for row in result['observations']:
        print(row['version'],row['case'],row.get('actual',row.get('summary',{}).get('status')),row.get('environment_restored'),row.get('error'))
if __name__=='__main__':main()
