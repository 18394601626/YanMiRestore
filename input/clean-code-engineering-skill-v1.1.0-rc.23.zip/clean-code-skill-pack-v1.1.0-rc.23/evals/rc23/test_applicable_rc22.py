"""Retain original non-identity checks; old rc22 identity tests stay unchanged."""
import importlib.util
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('rc22_release_original',ROOT/'evals/rc22/test_release.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
if __name__=='__main__':
    excluded={'test_01_version','test_02_parent_identity'}
    names=unittest.defaultTestLoader.getTestCaseNames(m.Release)
    suite=unittest.TestSuite(m.Release(name) for name in names if name not in excluded)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
