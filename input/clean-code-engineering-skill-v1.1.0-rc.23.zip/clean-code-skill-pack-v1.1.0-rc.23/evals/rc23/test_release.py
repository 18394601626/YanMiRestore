"""Release identity, preservation and entry registration; not AI behavior."""
import hashlib
import json
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2]
ALLOWED={'VERSION','README.md','VALIDATION.md','CHANGELOG.md','START_HERE.md',
         'LANGUAGE_MATRIX.md','FIX_SUMMARY.json','SHA256SUMS.txt','RELEASE.json','verify.py',
         'clean-code-engineering/VERSION','clean-code-engineering/assets/language-support.json',
         'evals/rc22/reproduce.py','evals/rc22/delivery_checks.py'}
class Release(unittest.TestCase):
    def test_version(self):
        for path in ('VERSION','clean-code-engineering/VERSION'):
            self.assertEqual((ROOT/path).read_text().strip(),'1.1.0-rc.23')
    def test_parent_identity(self):
        data=json.loads((ROOT/'RELEASE.json').read_text())
        self.assertEqual(data['version'],'1.1.0-rc.23')
        self.assertEqual(data['parent_sha256'],'b5f17596721e0f804da7b726f8ee1d7a1094c14c77f8448df602446d94229267')
        self.assertFalse(data['independent_model_ab'])
    def test_all_undeclared_parent_files_unchanged(self):
        old=json.loads((ROOT/'provenance/rc23/baseline-manifest.json').read_text())
        for name,digest in old.items():
            if name not in ALLOWED:
                with self.subTest(file=name):
                    self.assertTrue((ROOT/name).is_file())
                    self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest)
    def test_frozen_new_consumers(self):
        frozen=json.loads((ROOT/'provenance/rc23/frozen-tests.json').read_text())
        self.assertGreaterEqual(len(frozen),2)
        for name,digest in frozen.items():
            self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)
    def test_30_guides_are_not_30_runtime_claims(self):
        data=json.loads((ROOT/'clean-code-engineering/assets/language-support.json').read_text())
        self.assertEqual(len(data['languages']),30)
        self.assertEqual(sum(v['status']=='GUIDE_ONLY' for v in data['languages'].values()),12)
        self.assertFalse(data['independent_agent_AB'])
        for info in data['languages'].values():self.assertTrue((ROOT/'clean-code-engineering'/info['guide']).is_file())
    def test_current_entry_exists_and_is_routed(self):
        self.assertTrue((ROOT/'evals/rc23/reproduce.py').is_file())
        self.assertTrue((ROOT/'evals/rc23/run_tools.py').is_file())
        self.assertIn('evals/rc23/reproduce.py',(ROOT/'verify.py').read_text())
if __name__=='__main__':unittest.main(verbosity=2)
