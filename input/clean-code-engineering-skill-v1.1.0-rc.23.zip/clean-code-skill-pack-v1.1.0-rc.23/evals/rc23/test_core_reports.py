"""Second-round scoped probes; same prior report used as positive fixture."""
import copy
import importlib.util
import json
import os
from pathlib import Path
import unittest
ROOT=Path(os.environ.get('RC23_TARGET_ROOT',Path(__file__).resolve().parents[2]))
spec=importlib.util.spec_from_file_location('rc23_core_target',ROOT/'evals/rc22/reproduce.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def data():return json.loads((ROOT/'evidence/rc22/system-full/core-languages/summary.json').read_text())
class CoreReports(unittest.TestCase):
    def test_complete_partial_blocked_report_remains_blocked(self):
        self.assertEqual(m.normalized(data(),2,'core'),'PARTIAL_BLOCKED')
    def test_child_failure_not_hidden_by_parent_blocked(self):
        d=data();d['runtime'][-1]['status']='FAIL'
        self.assertEqual(m.normalized(d,2,'core'),'FAIL')
    def test_batch_duplicate_pair_rejected(self):
        d=data();rows=d['runtime'][0]['details']['runs'];rows[-1]=copy.deepcopy(rows[0])
        self.assertEqual(m.normalized(d,2,'core'),'INVALID_EVIDENCE')
    def test_batch_missing_pair_rejected(self):
        d=data();d['runtime'][0]['details']['runs'].pop()
        self.assertEqual(m.normalized(d,2,'core'),'INVALID_EVIDENCE')
    def test_batch_empty_records_rejected(self):
        d=data();d['runtime'][0]['details']['runs']=[]
        self.assertEqual(m.normalized(d,2,'core'),'INVALID_EVIDENCE')
    def test_bad_expected_observation_not_accepted(self):
        d=data();d['runtime'][0]['details']['runs'][0]['expected_observation']=False
        self.assertEqual(m.normalized(d,2,'core'),'FAIL')
    def test_order_and_extra_metadata_permitted(self):
        d=data();d['runtime'][0]['details']['runs'].reverse();d['runtime'].reverse();d['extra']={'diagnostic':1}
        self.assertEqual(m.normalized(d,2,'core'),'PARTIAL_BLOCKED')
if __name__=='__main__':unittest.main(verbosity=2)
