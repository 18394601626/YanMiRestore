"""Current release entry; same explicit 14 stages, current tool contracts."""
import importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('rc23_verify',ROOT/'evals/rc22/reproduce.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
original_plan=runner.plan

def plan(profile):
    return [(name,'evals/rc23/run_tools.py' if name=='tools' else script,args,timeout,kind)
            for name,script,args,timeout,kind in original_plan(profile)]

if __name__=='__main__':
    runner.plan=plan
    raise SystemExit(runner.main())
