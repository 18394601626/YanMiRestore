"""Focused fault injection with a real SQLite file; not a model or framework trial.

RC22_TARGET_ROOT lets the identical test bytes exercise the frozen parent release.
Custom exceptions/log handlers below are intentional reporting-failure controls.
"""
import importlib.util
import logging
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest

ROOT = Path(os.environ.get('RC22_TARGET_ROOT', Path(__file__).resolve().parents[2]))
spec = importlib.util.spec_from_file_location('rc22_sql_subject', ROOT/'evals/rc18/sql/fixed/solution.py')
subject = importlib.util.module_from_spec(spec)
spec.loader.exec_module(subject)

class BrokenNote(ValueError):
    def add_note(self, note):
        raise RuntimeError('note transport failed')

class MissingNote(ValueError):
    add_note = None

class RecordingHandler(logging.Handler):
    def __init__(self, failure=None):
        super().__init__(); self.failure = failure; self.records = []
    def emit(self, record):
        self.records.append(record)
        if self.failure is not None:
            raise self.failure

class DiagnosticResilience(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='rc22-diagnostic-')
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)/'data.sqlite'
        self.db = sqlite3.connect(self.path, isolation_level=None)
        self.db.executescript('CREATE TABLE accounts(id INTEGER PRIMARY KEY, quantity INTEGER CHECK(quantity>=0));'
            'INSERT INTO accounts VALUES(1,10),(2,20);')
        self.addCleanup(self.db.close)
        self.events = []
        self.denied = {'ROLLBACK'}
        def authorizer(action, first, *rest):
            if action == sqlite3.SQLITE_TRANSACTION:
                self.events.append(first)
                if first in self.denied:
                    return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK
        self.db.set_authorizer(authorizer)
        self.log = logging.getLogger(subject.__name__)
        self.old = (list(self.log.handlers), list(self.log.filters), self.log.level, self.log.disabled, self.log.propagate)
        self.log.handlers = []; self.log.filters = []; self.log.disabled = False
        self.log.propagate = False; self.log.setLevel(logging.ERROR)
        self.addCleanup(self.restore_logger)
        self.handler = RecordingHandler(); self.log.addHandler(self.handler)
    def restore_logger(self):
        handlers, filters, level, disabled, propagate = self.old
        self.log.handlers=handlers; self.log.filters=filters; self.log.setLevel(level)
        self.log.disabled=disabled; self.log.propagate=propagate
    def committed(self):
        other=sqlite3.connect(self.path)
        try: return other.execute('SELECT id,quantity FROM accounts ORDER BY id').fetchall()
        finally: other.close()
    def invoke(self, error):
        def rows():
            yield (1,80)
            raise error
        try:
            subject.replace_quantities(self.db,rows())
        except BaseException as caught:
            return caught
        self.fail('failing rows must not be accepted')
    def assert_original(self, error):
        self.assertIs(self.invoke(error),error)
        self.assertTrue(self.db.in_transaction)
        self.assertEqual(self.committed(),[(1,10),(2,20)])
    def assert_reported(self):
        self.assertEqual(len(self.handler.records),1)
        self.assertIn('rollback',self.handler.records[0].getMessage().lower())
        self.assertIn('unverified',self.handler.records[0].getMessage().lower())

    def test_01_raising_note_method_falls_back_to_log(self):
        self.assert_original(BrokenNote('business error')); self.assert_reported()
    def test_02_raising_note_descriptor_falls_back_to_log(self):
        class DescriptorError(ValueError):
            @property
            def add_note(self): raise RuntimeError('descriptor unavailable')
        self.assert_original(DescriptorError('business error')); self.assert_reported()
    def test_03_missing_note_logs_once(self):
        self.assert_original(MissingNote('business error')); self.assert_reported()
    def test_04_noncallable_note_uses_log(self):
        class Noncallable(ValueError): add_note=42
        self.assert_original(Noncallable('business error')); self.assert_reported()
    def test_05_corrupt_notes_container_preserved_with_fallback(self):
        error=ValueError('business error'); error.__notes__='caller-corrupted-notes'
        self.assert_original(error)
        self.assertEqual(error.__notes__,'caller-corrupted-notes'); self.assert_reported()
    def test_06_logger_io_error_cannot_replace_primary(self):
        self.handler.failure=OSError('log sink failed')
        self.assert_original(MissingNote('business error')); self.assert_reported()
    def test_07_both_reporting_paths_fail_without_replacing_primary(self):
        self.handler.failure=RuntimeError('log sink failed')
        self.assert_original(BrokenNote('business error')); self.assert_reported()
    def test_08_logging_filter_failure_does_not_escape(self):
        def bad_filter(record): raise ValueError('filter failed')
        self.log.addFilter(bad_filter)
        self.assert_original(MissingNote('business error'))
        self.assertEqual(self.handler.records,[])
    def test_09_original_cancel_with_bad_notes_is_preserved(self):
        class Cancel(KeyboardInterrupt):
            def add_note(self,note): raise TypeError('note failed')
        self.assert_original(Cancel('original cancel')); self.assert_reported()
    def test_10_original_exit_with_bad_logger_is_preserved(self):
        class Exit(SystemExit): add_note=None
        error=Exit(17); self.handler.failure=OSError('log failed')
        self.assert_original(error); self.assertEqual(error.code,17)
    def test_11_original_cause_and_existing_note_are_preserved(self):
        cause=LookupError('cause'); error=ValueError('primary'); error.__cause__=cause
        error.add_note('existing note')
        self.assert_original(error)
        self.assertIs(error.__cause__,cause); self.assertEqual(error.__notes__[0],'existing note')
        self.assertIn('rollback',error.__notes__[-1].lower()); self.assertEqual(self.handler.records,[])
    def test_12_successful_note_does_not_call_broken_logger(self):
        self.handler.failure=RuntimeError('must not log when noted')
        error=ValueError('primary'); self.assert_original(error)
        self.assertEqual(self.handler.records,[])
    def test_13_new_cancel_during_note_is_not_swallowed(self):
        cancel=KeyboardInterrupt('new cancellation')
        class InterruptedNote(ValueError):
            def add_note(self,note): raise cancel
        self.assertIs(self.invoke(InterruptedNote('original')),cancel)
        self.assertTrue(self.db.in_transaction)
    def test_14_new_exit_during_log_is_not_swallowed(self):
        new_exit=SystemExit(19); self.handler.failure=new_exit
        self.assertIs(self.invoke(MissingNote('original')),new_exit)
    def test_15_clean_rollback_needs_no_reporting(self):
        self.denied.clear(); self.handler.failure=RuntimeError('must not log')
        error=BrokenNote('primary'); self.assertIs(self.invoke(error),error)
        self.assertFalse(self.db.in_transaction); self.assertEqual(self.handler.records,[])
        self.assertEqual(self.committed(),[(1,10),(2,20)])
    def test_16_successful_commit_is_unchanged(self):
        self.handler.failure=RuntimeError('must not log')
        subject.replace_quantities(self.db,[(1,30),(2,40)])
        self.assertEqual(self.committed(),[(1,30),(2,40)])
        self.assertFalse(self.db.in_transaction); self.assertEqual(self.events,['BEGIN','COMMIT'])
    def test_17_owner_can_recover_after_reporting_failure(self):
        self.handler.failure=OSError('log failed')
        self.assert_original(MissingNote('primary')); self.denied.clear()
        self.db.execute('ROLLBACK')
        subject.replace_quantities(self.db,[(2,99)])
        self.assertEqual(self.committed(),[(1,10),(2,99)])
    def test_18_logger_configuration_untouched(self):
        self.handler.failure=OSError('log failed')
        before=(self.log.level,self.log.disabled,self.log.propagate,list(self.log.handlers),list(self.log.filters),logging.raiseExceptions)
        self.assert_original(MissingNote('primary'))
        after=(self.log.level,self.log.disabled,self.log.propagate,list(self.log.handlers),list(self.log.filters),logging.raiseExceptions)
        self.assertEqual(before,after)

if __name__=='__main__': unittest.main(verbosity=2)
