"""Shape contracts for the explicitly registered, trusted local report adapters.

These checks do not authenticate reports or prove test behavior. Identities are
from the bundled runners; changing those runners requires versioning this table.
"""
JDK_CASES = frozenset((
    'completable_executor', 'interrupt_restore', 'json_compat', 'method_reference',
    'n_plus_one', 'resources_suppressed', 'rollback_checked', 'singleton_state',
    'threadlocal', 'tx_proxy',
))
JDK_OUTCOMES = ('bad_visible_pass', 'bad_hidden_rejected', 'good_visible_pass', 'good_hidden_pass')
GO_EXPECTED = {
    'R01-baseline-v1': 'TEST_FAIL', 'R02-corrected-with-v1-double': 'TEST_FAIL',
    'R03-baseline-v2': 'TEST_FAIL', 'R04-corrected-v2': 'PASS',
    'R05-repaired-formatted': 'PASS', 'R06-double-capabilities': 'PASS',
    'R07-repaired-race': 'PASS', 'R08-forward-race-20': 'PASS',
    'R09-vet': 'PASS', 'R10-build': 'PASS', 'R11-format': 'PASS',
}
GO_ASSERTIONS = frozenset((
    'baseline_service_pass', 'bad_local_service_pass', 'bad_not_full_pass',
    'bad_scope_detected', 'bad_generated_detected', 'bad_schema_detected',
    'bad_migration_detected', 'bad_perf_detected', 'bad_consumer_detected',
    'bad_enterprise_detected', 'good_full_pass',
))
CORE_IDS = frozenset((
    'rc17-ten-language-batch', 'typescript-extra', 'sql-sqlite-baseline',
    'sql-sqlite-fixed', 'csharp', 'dart', 'new-42',
))
CORE_LANGUAGES = frozenset(('python','javascript','typescript','php','ruby','kotlin','swift','perl','bash','fortran'))
KINDS = frozenset(('jdk', 'go-resources', 'go-modules', 'core', 'standard',
                   'unittest', 'ctest', 'framework-compile', 'framework-integration'))


def object_rows(value):
    return type(value) is list and all(type(row) is dict for row in value)


def named_rows(value, field, expected):
    if not object_rows(value):
        return False
    names = [row.get(field) for row in value]
    return (all(type(name) is str for name in names)
            and len(names) == len(expected) and set(names) == set(expected))


def shape_issue(data, exit_code, kind):
    """Return a path-oriented schema diagnostic, or None for the known shape."""
    if type(kind) is not str or kind not in KINDS:
        return 'adapter: unknown kind'
    if type(data) is not dict:
        return 'report: expected JSON object'
    if type(exit_code) is not int:
        return 'process.exit_code: expected integer, not bool/coercible value'
    if kind in ('standard', 'core'):
        if type(data.get('exit_code')) is not int:
            return 'report.exit_code: expected integer'
        if type(data.get('status')) is not str:
            return 'report.status: expected string'
    if kind == 'jdk':
        if not named_rows(data.get('cases'), 'case', JDK_CASES):
            return 'cases: missing/duplicate/unknown identity or non-object row'
        if type(data.get('all_expected')) is not bool:
            return 'all_expected: expected boolean'
        for row in data['cases']:
            for field in JDK_OUTCOMES:
                if type(row.get(field)) is not bool:
                    return f'cases.{row["case"]}.{field}: required boolean'
    elif kind == 'go-resources':
        if not named_rows(data.get('observations'), 'id', GO_EXPECTED):
            return 'observations: missing/duplicate/unknown identity or non-object row'
        if type(data.get('all_expected_observations_reproduced')) is not bool:
            return 'all_expected_observations_reproduced: expected boolean'
        for row in data['observations']:
            if row.get('expected') != GO_EXPECTED[row['id']]:
                return f'observations.{row["id"]}.expected: not the registered contract'
            if type(row.get('observed')) is not str or type(row.get('matches_expected_observation')) is not bool:
                return f'observations.{row["id"]}: explicit observed state and boolean required'
    elif kind == 'go-modules':
        flags = data.get('assertions')
        if type(flags) is not dict or set(flags) != GO_ASSERTIONS:
            return 'assertions: expected the registered eleven names'
        if any(type(value) is not bool for value in flags.values()):
            return 'assertions: all values must be booleans'
    elif kind == 'core':
        if not named_rows(data.get('runtime'), 'id', CORE_IDS):
            return 'runtime: missing/duplicate/unknown identity or non-object row'
        for row in data['runtime']:
            if type(row.get('status')) is not str:
                return f'runtime.{row["id"]}.status: required string'
            if row['id'] == 'rc17-ten-language-batch':
                details = row.get('details')
                if type(details) is not dict or not object_rows(details.get('runs')):
                    return 'runtime.batch.details.runs: required array of objects'
                pairs=[(run.get('language'),run.get('variant')) for run in details['runs']]
                wanted={(lang,variant) for lang in CORE_LANGUAGES for variant in ('baseline','fixed')}
                if (any(type(lang) is not str or type(variant) is not str for lang,variant in pairs)
                        or len(pairs)!=len(wanted) or set(pairs)!=wanted):
                    return 'runtime.batch.details.runs: missing/duplicate/unknown language and variant'
                for run in details['runs']:
                    if any(type(run.get(key)) is not str for key in ('language', 'variant', 'status')):
                        return 'runtime.batch.details.runs: language/variant/status strings required'
                    if type(run.get('executed')) is not int or run['executed'] < 0:
                        return 'runtime.batch.details.runs.executed: nonnegative integer required'
    elif kind.startswith('framework-'):
        for key in ('prerequisites', 'build_result'):
            if key in data and type(data[key]) is not dict:
                return f'{key}: expected object'
        if 'integration_results' in data:
            rows = data['integration_results']
            if not object_rows(rows):
                return 'integration_results: expected array of objects'
            pairs = [(row.get('engine'), row.get('fixture')) for row in rows]
            expected = {(engine, fixture) for engine in ('postgres', 'mysql') for fixture in ('baseline', 'fixed')}
            if any(type(e) is not str or type(f) is not str for e, f in pairs) or len(pairs) != 4 or set(pairs) != expected:
                return 'integration_results: missing/duplicate/unknown engine and fixture pair'
            if any(type(row.get('observed_tests')) is not int or row['observed_tests'] < 0 for row in rows):
                return 'integration_results.observed_tests: nonnegative integer required'
    elif kind in ('unittest', 'ctest'):
        field = 'records' if kind == 'unittest' else 'observations'
        if not object_rows(data.get(field)):
            return f'{field}: required array of objects'
        identity = 'test' if kind == 'unittest' else 'case'
        if any(type(row.get(identity)) is not str for row in data[field]):
            return f'{field}.{identity}: required string'
    return None
