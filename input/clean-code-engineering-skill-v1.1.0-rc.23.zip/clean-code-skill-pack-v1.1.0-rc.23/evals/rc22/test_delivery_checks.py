"""Test release/inventory plumbing, not agent quality or source-book semantics."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('delivery_checks',HERE/'delivery_checks.py')
subject=importlib.util.module_from_spec(spec);spec.loader.exec_module(subject)

class DeliveryChecks(unittest.TestCase):
    def test_01_complete_pass(self):
        self.assertEqual(subject.rollup([{'id':'a','status':'PASS'}],['a'])['status'],'REQUESTED_SCOPE_PASSED')
    def test_02_missing_stage_is_not_pass(self):
        r=subject.rollup([{'id':'a','status':'PASS'}],['a','b'])
        self.assertEqual(r['exit_code'],1);self.assertEqual(r['missing'],['b'])
    def test_03_duplicate_stage_rejected(self):
        self.assertEqual(subject.rollup([{'id':'a','status':'PASS'}]*2,['a'])['exit_code'],1)
    def test_04_unrequested_stage_rejected(self):
        self.assertEqual(subject.rollup([{'id':'a','status':'PASS'},{'id':'b','status':'PASS'}],['a'])['exit_code'],1)
    def test_05_blocked_not_pass(self):
        r=subject.rollup([{'id':'a','status':'BLOCKED'}],['a'])
        self.assertEqual((r['status'],r['exit_code']),('PARTIAL_BLOCKED',2))
    def test_06_failure_not_hidden_by_blocked(self):
        r=subject.rollup([{'id':'a','status':'BLOCKED'},{'id':'b','status':'FAIL'}],['a','b'])
        self.assertEqual(r['exit_code'],1)
    def test_07_interrupt_retains_pending(self):
        r=subject.rollup([{'id':'a','status':'INTERRUPTED'}],['a','b'])
        self.assertEqual(r['exit_code'],130);self.assertEqual(r['missing'],['b'])
    def test_08_unknown_status_rejected(self):
        for value in ['true',True,'PASSED',None,0,'RUNNING']:
            with self.subTest(value=value):self.assertEqual(subject.rollup([{'id':'a','status':value}],['a'])['exit_code'],1)
    def test_09_empty_plan_not_green(self):
        self.assertEqual(subject.rollup([],[])['exit_code'],1)
    def test_10_valid_manifest(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'a.txt').write_text('hello')
            digest=hashlib.sha256(b'hello').hexdigest()
            (root/'SHA256SUMS.txt').write_text(digest+'  a.txt\n')
            r=subject.check_manifest(root)
            self.assertTrue(r['ok']);self.assertEqual(r['checked'],1)
    def test_11_changed_file_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'a.txt').write_text('changed')
            (root/'SHA256SUMS.txt').write_text(hashlib.sha256(b'old').hexdigest()+'  a.txt\n')
            self.assertFalse(subject.check_manifest(root)['ok'])
    def test_12_missing_extra_and_escaping_paths_rejected(self):
        for path in ['missing.txt','../outside.txt','/tmp/outside.txt']:
            with self.subTest(path=path), tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);(root/'extra.txt').write_text('extra')
                (root/'SHA256SUMS.txt').write_text('0'*64+'  '+path+'\n')
                self.assertFalse(subject.check_manifest(root)['ok'])
    def test_13_malformed_manifest_rejected(self):
        for text in ['', 'not a hash  a.txt\n', '0'*64+'  a.txt\n'+'0'*64+'  a.txt\n']:
            with self.subTest(text=text),tempfile.TemporaryDirectory() as tmp:
                root=Path(tmp);(root/'a.txt').write_text('x');(root/'SHA256SUMS.txt').write_text(text)
                self.assertFalse(subject.check_manifest(root)['ok'])
    def test_14_guide_only_never_marked_executed(self):
        registry={'languages':{'x':{'guide':'references/x.md','status':'GUIDE_ONLY'}}}
        row=subject.inventory(registry,{})[0]
        self.assertEqual(row['current_status'],'GUIDE_ONLY');self.assertFalse(row['runtime_executed'])
    def test_15_historical_pass_is_not_current_pass(self):
        registry={'languages':{'x':{'guide':'x','status':'CONTROLLED_LANGUAGE_TESTS','execution':{'status':'PASS'}}}}
        row=subject.inventory(registry,{})[0]
        self.assertEqual(row['current_status'],'NOT_RUN');self.assertFalse(row['runtime_executed'])
    def test_16_blocked_records_zero_current_execution(self):
        registry={'languages':{'rust':{'guide':'rust.md','status':'SOURCE_BLOCKED'}}}
        row=subject.inventory(registry,{'rust':{'status':'BLOCKED','executed':0}})[0]
        self.assertEqual(row['current_status'],'BLOCKED');self.assertFalse(row['runtime_executed'])
    def test_17_pass_requires_positive_execution_count(self):
        registry={'languages':{'python':{'guide':'py.md','status':'CONTROLLED_LANGUAGE_TESTS'}}}
        for count in [0,True,-1,'6',None]:
            with self.subTest(count=count):
                row=subject.inventory(registry,{'python':{'status':'PASS','executed':count}})[0]
                self.assertEqual(row['current_status'],'INVALID_EVIDENCE');self.assertFalse(row['runtime_executed'])
    def test_18_current_pass_does_not_certify_framework(self):
        registry={'languages':{'python':{'guide':'py.md','status':'CONTROLLED_LANGUAGE_TESTS'}}}
        row=subject.inventory(registry,{'python':{'status':'PASS','executed':6,'evidence':'batch.json'}})[0]
        self.assertEqual(row['current_status'],'CONTROLLED_PASS');self.assertTrue(row['runtime_executed'])
        self.assertEqual(row['framework_status'],'NOT_RUN');self.assertFalse(row['agent_behavior_tested'])
    def test_19_registry_identity_is_not_recounted_from_guides(self):
        registry={'languages':{'python':{'guide':'shared.md','status':'GUIDE_ONLY'},'ruby':{'guide':'shared.md','status':'GUIDE_ONLY'}}}
        self.assertEqual([r['language'] for r in subject.inventory(registry,{})],['python','ruby'])
    def test_20_expected_plan_duplicate_rejected(self):
        self.assertEqual(subject.rollup([{'id':'a','status':'PASS'}],['a','a'])['exit_code'],1)

    def test_21_unlisted_nested_manifest_is_not_ignored(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'a.txt').write_text('hello')
            digest=hashlib.sha256(b'hello').hexdigest()
            (root/'SHA256SUMS.txt').write_text(digest+'  a.txt\n')
            (root/'nested').mkdir();(root/'nested/SHA256SUMS.txt').write_text('unlisted data')
            self.assertFalse(subject.check_manifest(root)['ok'])

if __name__=='__main__':unittest.main(verbosity=2)
