"""Current release identity and preservation; not independent content review."""
import hashlib
import json
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2]
ALLOWED={'VERSION','README.md','VALIDATION.md','CHANGELOG.md','LANGUAGE_MATRIX.md','FIX_SUMMARY.json','SHA256SUMS.txt',
         'clean-code-engineering/VERSION','clean-code-engineering/assets/language-support.json',
         'clean-code-engineering/references/languages/sql.md','evals/rc18/sql/fixed/solution.py'}
class Release(unittest.TestCase):
    def test_01_version(self):
        for rel in ('VERSION','clean-code-engineering/VERSION'):
            self.assertEqual((ROOT/rel).read_text().strip(),'1.1.0-rc.22')
    def test_02_parent_identity(self):
        meta=json.loads((ROOT/'RELEASE.json').read_text())
        self.assertEqual(meta['version'],'1.1.0-rc.22')
        self.assertEqual(meta['parent_sha256'],'34229a1ec2800863828179de4a499f32d1b860e99eaa9d14fb56383535c80102')
        self.assertFalse(meta['independent_model_ab'])
    def test_03_all_undeclared_prior_files_preserved(self):
        baseline=json.loads((ROOT/'provenance/rc22/baseline-manifest.json').read_text())
        for name,digest in baseline.items():
            if name not in ALLOWED:
                with self.subTest(path=name):
                    self.assertTrue((ROOT/name).is_file())
                    self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest)
    def test_04_original_knowledge_and_main_unchanged(self):
        baseline=json.loads((ROOT/'provenance/rc22/baseline-manifest.json').read_text())
        for name,digest in baseline.items():
            if name.startswith('clean-code-engineering/references/book/') or name=='clean-code-engineering/SKILL.md':
                self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)
    def test_05_new_frozen_tests_unchanged(self):
        frozen=json.loads((ROOT/'provenance/rc22/frozen-tests.json').read_text())
        self.assertGreaterEqual(len(frozen),3)
        for name,digest in frozen.items():self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)
    def test_06_30_guides_without_runtime_overclaim(self):
        data=json.loads((ROOT/'clean-code-engineering/assets/language-support.json').read_text())
        self.assertEqual(len(data['languages']),30);self.assertFalse(data['independent_agent_AB'])
        for info in data['languages'].values():
            self.assertTrue((ROOT/'clean-code-engineering'/info['guide']).is_file())
        self.assertEqual(sum(v['status']=='GUIDE_ONLY' for v in data['languages'].values()),12)
    def test_07_original_consumers_preserved(self):
        baseline=json.loads((ROOT/'provenance/rc22/baseline-manifest.json').read_text())
        for name,digest in baseline.items():
            if name.startswith('evals/') and (Path(name).name.startswith(('test_','cases','Cases','contracts'))):
                self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest,name)
    def test_08_single_entry_and_scope_boundary(self):
        self.assertTrue((ROOT/'verify.py').is_file())
        doc=(ROOT/'START_HERE.md').read_text()
        for phrase in ('--profile full','--profile tools','GUIDE_ONLY','54','独立模型'):
            self.assertIn(phrase,doc)
if __name__=='__main__':unittest.main(verbosity=2)
