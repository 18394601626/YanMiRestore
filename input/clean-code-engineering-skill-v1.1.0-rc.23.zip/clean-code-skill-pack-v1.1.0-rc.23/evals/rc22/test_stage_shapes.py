"""Legacy framework summaries intentionally omit a top-level exit_code.
Accept their documented blocked shape, never turn BLOCKED into PASS."""
import copy
import importlib.util
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('current_verify',ROOT/'evals/rc22/reproduce.py')
m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
def blocked(phase):
    return {'kind':'controlled_integration_fixture_not_agent_ab','phase':phase,'status':'BLOCKED',
        'candidate_source_compiled':False,'prerequisites':{'status':'BLOCKED','issues':['MVN_NOT_FOUND']},
        'integration_results':[{'engine':engine,'fixture':fixture,'status':'BLOCKED' if phase=='integration' else 'NOT_RUN','observed_tests':0,'comparison_confirmed':None}
                               for engine in ('postgres','mysql') for fixture in ('baseline','fixed')]}
class StageShapes(unittest.TestCase):
    def test_01_compile_blocked_without_synthetic_exit_field(self):
        self.assertEqual(m.normalized(blocked('compile'),2,'framework-compile'),'BLOCKED')
    def test_02_integration_blocked_without_synthetic_exit_field(self):
        self.assertEqual(m.normalized(blocked('integration'),2,'framework-integration'),'BLOCKED')
    def test_03_wrong_phase_rejected(self):
        self.assertEqual(m.normalized(blocked('compile'),2,'framework-integration'),'INVALID_EVIDENCE')
    def test_04_blocked_but_claims_compiled_rejected(self):
        d=blocked('compile');d['candidate_source_compiled']=True
        self.assertEqual(m.normalized(d,2,'framework-compile'),'INVALID_EVIDENCE')
    def test_05_blocked_exit_zero_rejected(self):
        self.assertEqual(m.normalized(blocked('compile'),0,'framework-compile'),'INVALID_EVIDENCE')
    def test_06_empty_success_not_accepted(self):
        d={'kind':'controlled_integration_fixture_not_agent_ab','phase':'integration','status':'EXPECTED_OBSERVATIONS_REPRODUCED','candidate_source_compiled':True,'integration_results':[]}
        self.assertEqual(m.normalized(d,0,'framework-integration'),'INVALID_EVIDENCE')
    def test_07_standard_exit_code_mismatch_rejected(self):
        self.assertEqual(m.normalized({'status':'PASS','exit_code':0},1,'standard'),'INVALID_EVIDENCE')
    def test_08_blocked_with_observed_business_tests_rejected(self):
        d=blocked('integration');d['integration_results'][0]['observed_tests']=13
        self.assertEqual(m.normalized(d,2,'framework-integration'),'INVALID_EVIDENCE')
    def test_09_new_sql_failure_overrides_core_pass(self):
        core={'id':'core-languages','status':'PASS','data':{'runtime':[{'id':'sql-sqlite-fixed','status':'PASS','executed':12}]}}
        observed=m.collect_observed([core,{'id':'new-diagnostics','status':'FAIL'}])
        self.assertEqual(observed['sql']['status'],'FAIL')
    def test_10_go_resource_failure_overrides_module_pass(self):
        observed=m.collect_observed([{'id':'go-modules','status':'PASS'},{'id':'go-resources','status':'FAIL'}])
        self.assertEqual(observed['go']['status'],'FAIL')
    def test_11_native_extra_failure_overrides_core_pass(self):
        observed=m.collect_observed([{'id':'native','status':'PASS'},{'id':'native-extra','status':'FAIL'}])
        self.assertEqual(observed['cpp']['status'],'FAIL')
if __name__=='__main__' :unittest.main(verbosity=2)
