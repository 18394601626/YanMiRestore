"""Keep the four rc21 behavior/document checks unchanged; exact identity and
parent-byte preservation have new rc22 checks. Old file remains unmodified."""
import importlib.util
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2]
s=importlib.util.spec_from_file_location('rc21_release',ROOT/'evals/rc21/test_release.py')
old=importlib.util.module_from_spec(s);s.loader.exec_module(old)
if __name__=='__main__':
    excluded={'test_identity','test_all_prior_files_except_declared_changes_preserved'}
    suite=unittest.TestSuite(old.ReleaseContracts(n) for n in unittest.defaultTestLoader.getTestCaseNames(old.ReleaseContracts) if n not in excluded)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
