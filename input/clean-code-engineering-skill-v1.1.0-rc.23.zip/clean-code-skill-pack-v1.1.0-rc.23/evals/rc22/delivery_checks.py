"""Small release checks for this package's manifest and execution inventory.

Consistency is not authenticity: self-consistent untrusted reports can still lie.
This module does not install tools, execute builds, or evaluate book semantics.
"""
import hashlib
from pathlib import Path
import re


def check_manifest(root):
    root=Path(root).resolve()
    errors=[]; entries={}; checked=0
    try:
        lines=(root/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines()
    except (OSError,UnicodeError) as error:
        return {'ok':False,'checked':0,'errors':['manifest unreadable: '+str(error)]}
    for number,line in enumerate(lines,1):
        match=re.fullmatch(r'([0-9a-f]{64})  (.+)',line)
        if not match:
            errors.append(f'malformed manifest line {number}');continue
        digest,name=match.groups(); path=Path(name)
        if path.is_absolute() or '..' in path.parts or name=='SHA256SUMS.txt':
            errors.append('invalid path: '+name);continue
        if name in entries:
            errors.append('duplicate path: '+name);continue
        entries[name]=digest
        target=root/path
        try:
            if not target.resolve().is_relative_to(root) or target.is_symlink():
                errors.append('symlink/escaping path: '+name);continue
            observed=hashlib.sha256(target.read_bytes()).hexdigest(); checked+=1
            if observed!=digest:errors.append('changed: '+name)
        except OSError as error:errors.append('missing/unreadable: '+name+': '+str(error))
    if not entries:errors.append('empty manifest')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p!=root/'SHA256SUMS.txt'
            and '__pycache__' not in p.parts and p.suffix!='.pyc'}
    errors.extend('unlisted: '+name for name in sorted(actual-set(entries)))
    return {'ok':not errors,'checked':checked,'listed':len(entries),'errors':errors}


def rollup(rows,expected):
    """Aggregate normalized child states. Missing/unknown outcomes never pass."""
    ids=[row.get('id') for row in rows]
    missing=[name for name in expected if name not in ids]
    issues=[]
    if not expected or len(expected)!=len(set(expected)):issues.append('empty/duplicate plan')
    if len(ids)!=len(set(ids)):issues.append('duplicate stage')
    if any(name not in expected for name in ids):issues.append('unexpected stage')
    states=[row.get('status') for row in rows]
    valid={'PASS','BLOCKED','PARTIAL_BLOCKED','FAIL','INVALID_EVIDENCE','INTERRUPTED','NOT_RUN'}
    if any(not isinstance(s,str) or s not in valid for s in states):issues.append('unknown state')
    if 'INTERRUPTED' in states:
        status,code='INTERRUPTED',130
    elif issues or missing or any(s in ('FAIL','INVALID_EVIDENCE','NOT_RUN') for s in states):
        status,code='FAIL',1
    elif any(s in ('BLOCKED','PARTIAL_BLOCKED') for s in states):
        status,code='PARTIAL_BLOCKED',2
    else:status,code='REQUESTED_SCOPE_PASSED',0
    return {'status':status,'exit_code':code,'missing':missing,'issues':issues}


def inventory(registry,observed):
    """Separate current execution from historical assertions and guide existence."""
    result=[]
    for key,item in registry['languages'].items():
        row={'language':key,'guide':item.get('guide'),'historical_status':item.get('status'),
             'current_status':'GUIDE_ONLY' if item.get('status')=='GUIDE_ONLY' else 'NOT_RUN',
             'runtime_executed':False,'executed_contracts':0,'framework_status':'NOT_RUN',
             'agent_behavior_tested':False}
        observation=observed.get(key)
        if observation is not None:
            state=observation.get('status'); count=observation.get('executed',0)
            row['evidence']=observation.get('evidence')
            row['scope']=observation.get('scope','controlled packaged fixture')
            if state=='PASS':
                if type(count) is int and count>0:
                    row.update(current_status='CONTROLLED_PASS',runtime_executed=True,executed_contracts=count)
                else:row['current_status']='INVALID_EVIDENCE'
            elif state=='INCOMPLETE':
                row.update(current_status='INCOMPLETE',
                           runtime_executed=type(count) is int and count>0,
                           executed_contracts=count if type(count) is int and count>0 else 0,
                           reason='requested supplementary verification is incomplete')
            elif state in ('BLOCKED','NOT_RUN'):
                row.update(current_status=state,reason=observation.get('reason'))
            else:row['current_status']='FAIL'
        result.append(row)
    return result
