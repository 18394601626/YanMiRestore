import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[2]
class CLI(unittest.TestCase):
    def run_cli(self,*args):
        return subprocess.run([sys.executable,'-S',str(ROOT/'verify.py'),*args],text=True,capture_output=True,timeout=15)
    def test_existing_output_is_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp);(path/'sentinel').write_text('keep')
            r=self.run_cli('--output',str(path),'--profile','tools')
            self.assertEqual(r.returncode,2);self.assertIn('output must be new',r.stderr);self.assertEqual((path/'sentinel').read_text(),'keep')
    def test_source_output_refused_without_creating(self):
        path=ROOT/'rc22-should-not-exist'
        self.assertFalse(path.exists())
        r=self.run_cli('--output',str(path));self.assertEqual(r.returncode,2);self.assertIn('output must be new',r.stderr);self.assertFalse(path.exists())
    def test_unknown_profile_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'absent'
            r=self.run_cli('--profile','all-languages-certified','--output',str(path))
            self.assertEqual(r.returncode,2);self.assertIn('invalid choice',r.stderr);self.assertFalse(path.exists())
    def test_plan_is_read_only_and_explicit(self):
        r=self.run_cli('--plan');self.assertEqual(r.returncode,0,r.stderr)
        plan=json.loads(r.stdout)
        self.assertEqual(plan['guide_count'],30);self.assertEqual(plan['model_ab'],'NOT_RUN')
        for key in ('go-resources','go-modules','java-jdk','rust','framework-compile','framework-integration','new-diagnostics'):
            self.assertIn(key,plan['stages'])
        self.assertEqual(len(plan['guide_only_languages']),12)
if __name__=='__main__':unittest.main(verbosity=2)
