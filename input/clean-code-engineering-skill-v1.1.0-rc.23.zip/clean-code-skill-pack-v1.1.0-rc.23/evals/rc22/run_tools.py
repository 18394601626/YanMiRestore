"""Run current applicable tool checks; immutable old release identities are not
silently rewritten. Individual exact-version tests remain with their releases."""
import argparse
import importlib.util
import os
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True)
    args=parser.parse_args()
    prior=load('rc22_tools_prior',ROOT/'evals/rc19/reproduce.py')
    prior.STAGES=[(name,'evals/rc20/test_applicable_rc19.py',3) if name=='rc19-release' else (name,path,count) for name,path,count in prior.STAGES]
    prior.STAGES += [
        ('rc20-applicable','evals/rc21/test_applicable_rc20.py',4),
        ('rc20-cli','evals/rc20/test_cli.py',4),
        ('rc21-applicable','evals/rc22/test_applicable_rc21.py',4),
        ('rc21-cli','evals/rc21/test_cli.py',4),
        ('go-evidence','evals/rc3/test_evidence.py',33),
        ('go-attribution','evals/rc3/test_failure_attribution.py',3),
        ('process-lifecycle','evals/rc10/probes/test_process_lifecycle.py',9),
        ('process-interrupt','evals/rc10/probes/test_interrupt_edges.py',2),
        ('delivery','evals/rc22/test_delivery_checks.py',21),
        ('stage-shapes','evals/rc22/test_stage_shapes.py',11),
        ('current-release','evals/rc22/test_release.py',8),
        ('one-command-cli','evals/rc22/test_cli.py',4),
    ]
    os.environ.update(RUNNER_PATH=str(ROOT/'evals/rc8/run_integration.py'),
                      RC8_RELEASE_ROOT=str(ROOT),PYTHONDONTWRITEBYTECODE='1')
    original=sys.argv;sys.argv=['rc22-tools','--output',args.output,'--tools-only']
    try:return prior.main()
    finally:sys.argv=original
if __name__=='__main__':raise SystemExit(main())
