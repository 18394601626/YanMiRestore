"""One finite, explicit full-scope verification for the bundled trusted fixtures.

No automatic installs, model calls, production data, or all-language claims.
Full runs all supplied language families plus framework preflights; guide-only
languages remain GUIDE_ONLY. Blocked components keep exit 2. Output must be new.
"""
import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import platform
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
checks=load('rc22_delivery',HERE/'delivery_checks.py')
contracts=load('rc23_stage_contracts',HERE/'stage_contracts.py')

def now(): return datetime.now(timezone.utc).isoformat()
def save(path,value):
    temp=path.with_suffix(path.suffix+'.tmp');temp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    temp.replace(path)

def plan(profile):
    tasks=[('tools','evals/rc22/run_tools.py',[],240,'standard')]
    if profile=='tools':return tasks
    tasks += [
        ('core-languages','evals/rc19/reproduce.py',['--runtime-supplied-by-adapter'],420,'core'),
        ('rc20-boundaries','evals/rc20/run_boundaries.py',[],180,'standard'),
        ('rc21-boundaries','evals/rc21/run_new.py',[],150,'standard'),
        ('new-diagnostics','evals/rc20/collect_unittest.py',[],60,'unittest'),
        ('native','evals/rc14/run_checks.py',['--language','native'],240,'standard'),
        ('native-extra','evals/rc16/run_extra.py',[],180,'standard'),
        ('native-ctest','evals/rc16/run_real_ctest.py',['--root',str(ROOT)],90,'ctest'),
        ('go-resources','evals/rc4/run_checks.py',[],240,'go-resources'),
        ('go-modules','evals/rc5/run_large_repo.py',[],240,'go-modules'),
        ('java-jdk','evals/rc7/run_java_cases.py',[],180,'jdk'),
        ('rust','evals/rc14/run_checks.py',['--language','rust'],150,'standard'),
        ('framework-compile','evals/rc8/run_integration.py',['--run','--phase','compile'],300,'framework-compile'),
        ('framework-integration','evals/rc8/run_integration.py',['--run','--phase','integration','--engine','all'],600,'framework-integration'),
    ]
    return tasks

def normalized(data,exit_code,kind):
    if contracts.shape_issue(data,exit_code,kind) is not None:
        return 'INVALID_EVIDENCE'
    if kind=='core':
        accepted={'PASS','CONTROL_OBSERVATIONS_MATCH','EXPECTED_OBSERVATIONS_REPRODUCED','BLOCKED','PARTIAL_BLOCKED'}
        if any(row['status'] not in accepted for row in data['runtime']):return 'FAIL'
        batch=next(row for row in data['runtime'] if row['id']=='rc17-ten-language-batch')
        if any(run.get('expected_observation') is not True
               for run in batch['details']['runs'] if run['status']!='BLOCKED'):
            return 'FAIL'
    # This older runner records the OS exit code outside summary.json. Validate
    # its explicit shape rather than inventing an exit_code field or dropping it.
    if kind in ('framework-compile','framework-integration'):
        phase=kind.removeprefix('framework-')
        if data.get('kind')!='controlled_integration_fixture_not_agent_ab' or data.get('phase')!=phase:
            return 'INVALID_EVIDENCE'
        state=data.get('status')
        if state=='INTERRUPTED' and exit_code==2:return 'INTERRUPTED'
        if state=='BLOCKED' and exit_code==2:
            rows=data.get('integration_results',[])
            prerequisite=data.get('prerequisites',{})
            if prerequisite.get('status')=='BLOCKED':
                valid=(data.get('candidate_source_compiled') is False and bool(prerequisite.get('issues'))
                       and len(rows)==4 and all(type(x.get('observed_tests')) is int and x['observed_tests']==0 for x in rows))
                return 'BLOCKED' if valid else 'INVALID_EVIDENCE'
            return 'BLOCKED' if any(x.get('status')=='BLOCKED' for x in rows) else 'INVALID_EVIDENCE'
        if phase=='compile' and state=='COMPILED' and exit_code==0:
            return 'PASS' if data.get('candidate_source_compiled') is True and data.get('build_result',{}).get('status')=='COMPILED' else 'INVALID_EVIDENCE'
        if phase=='integration' and state=='EXPECTED_OBSERVATIONS_REPRODUCED' and exit_code==0:
            rows=data.get('integration_results',[])
            expected={(e,f) for e in ('postgres','mysql') for f in ('baseline','fixed')}
            valid=(len(rows)==4 and {(x.get('engine'),x.get('fixture')) for x in rows}==expected
                   and all(x.get('comparison_confirmed') is True and x.get('observed_tests')==13 for x in rows))
            return 'PASS' if valid else 'INVALID_EVIDENCE'
        return 'INVALID_EVIDENCE'
    if kind=='unittest':
        rows=data.get('records',[])
        names=[r.get('test') for r in rows]
        ok=(exit_code==0 and data.get('success') is True and data.get('tests_run')==18
            and len(names)==18 and len(set(names))==18 and all(r.get('status')=='PASS' for r in rows))
        return 'PASS' if ok else 'FAIL'
    if kind=='ctest':
        rows=data.get('observations',[])
        ok=(exit_code==0 and data.get('all_expected') is True and len(rows)==3
            and {r.get('case') for r in rows}=={'matching','borrowed','false-success'} and all(r.get('matches') is True for r in rows))
    elif kind=='go-resources':
        rows=data.get('observations',[])
        ok=(exit_code==0 and data.get('all_expected_observations_reproduced') is True
            and all(row['matches_expected_observation'] is True
                    and row['observed']==row['expected'] for row in rows))
    elif kind=='go-modules':
        flags=data.get('assertions',{})
        ok=exit_code==0 and len(flags)==11 and all(v is True for v in flags.values())
    elif kind=='jdk':
        rows=data.get('cases',[])
        ok=(exit_code==0 and data.get('all_expected') is True and len(rows)==10
            and all(all(r[field] is True for field in contracts.JDK_OUTCOMES) for r in rows))
    else:
        state=data.get('status')
        if data.get('exit_code')!=exit_code:return 'INVALID_EVIDENCE'
        if state=='INTERRUPTED' and exit_code==130:return 'INTERRUPTED'
        if state in ('BLOCKED','PARTIAL_BLOCKED') and exit_code==2:return state
        valid_pass={'PASS','REQUESTED_SCOPE_PASSED','EXPECTED_OBSERVATIONS_REPRODUCED','CONTROL_OBSERVATIONS_MATCH','COMPILED'}
        if kind=='framework':valid_pass.add('EXPECTED_OBSERVATIONS_REPRODUCED')
        return 'PASS' if exit_code==0 and state in valid_pass else 'FAIL'
    if ok:return 'PASS'
    return 'BLOCKED' if exit_code==2 and data.get('status')=='BLOCKED' else 'FAIL'

def collect_observed(rows, requested_stages=None):
    by_id={r['id']:r for r in rows}; observed={}
    primary=by_id.get('core-languages',{})
    core=primary.get('data',{}) if primary.get('status') in ('PASS','PARTIAL_BLOCKED') else {}
    # An INVALID_EVIDENCE payload stays in the raw stage record, never promotion.
    if type(core) is not dict or not contracts.object_rows(core.get('runtime',[])):
        core={}
    for item in core.get('runtime',[]):
        if item.get('id')=='rc17-ten-language-batch':
            for case in item.get('details',{}).get('runs',[]):
                if case.get('variant')=='fixed':
                    observed[case['language']]={'status':case['status'],'executed':case.get('executed',0),'evidence':'core-languages/summary.json','scope':'rc17 fixed fixture; six contracts; one local toolchain'}
        if item.get('id') in ('csharp','dart'):
            observed[item['id']]={'status':item['status'],'executed':item.get('executed',0),'evidence':'core-languages/summary.json','reason':item.get('reason'),'scope':'supplied rc18 source; no framework test'}
        if item.get('id')=='sql-sqlite-fixed':
            observed['sql']={'status':item['status'],'executed':item.get('executed',0),'evidence':'core-languages/summary.json','scope':'SQLite file database only, 12 core tests plus separately listed regression groups'}
    for key,stage,count,scope in [('go','go-modules',11,'11 known multi-module checks, plus resource replay; not 11 independent code generation tasks'),('java','java-jdk',10,'10 JDK-only paired scenarios; not Spring'),('c','native',12,'12 C core tests, plus extra tests in separate configurations'),('cpp','native',10,'10 C++ core tests plus C/C++ linkage and extra tests')]:
        if stage in by_id:
            observed[key]={'status':by_id[stage]['status'],'executed':count if by_id[stage]['status']=='PASS' else 0,'scope':scope,'evidence':stage+'/summary.json'}
    if 'rust' in by_id:
        payload=by_id['rust'].get('data',{})
        languages=payload.get('languages',{}) if type(payload) is dict else {}
        data=languages.get('rust',{}) if type(languages) is dict else {}
        if type(data) is not dict:data={}
        if by_id['rust'].get('status') not in ('PASS','PARTIAL_BLOCKED','BLOCKED'):data={}
        observed['rust']={'status':'PASS' if data.get('status')=='EXPECTED_OBSERVATIONS_REPRODUCED' else ('BLOCKED' if data.get('status')=='BLOCKED' else 'FAIL'), 'executed':data.get('executed_tests',0),'reason':data.get('reason'),'evidence':'rust/summary.json','scope':'supplied rc14 standard-library fixture only'}
    related={
        'sql':('core-languages','rc20-boundaries','rc21-boundaries','new-diagnostics'),
        'python':('core-languages','rc21-boundaries'),
        'javascript':('core-languages','rc21-boundaries'),
        'bash':('core-languages','rc20-boundaries'),
        'kotlin':('core-languages','rc20-boundaries'),
        'swift':('core-languages','rc20-boundaries'),
        'ruby':('core-languages','rc20-boundaries'),
        'c':('native','native-extra','native-ctest'),
        'cpp':('native','native-extra','native-ctest'),
        'go':('go-resources','go-modules'),
    }
    for language,names in related.items():
        bad=[name for name in names if name in by_id and by_id[name]['status'] not in ('PASS','PARTIAL_BLOCKED')]
        # core-languages PARTIAL_BLOCKED may only be due to C#/Dart; its exact
        # per-language records above already distinguish those two inputs.
        if bad and language in observed:
            observed[language]['status']='FAIL'
            observed[language]['scope']+='; related stages did not pass: '+','.join(bad)
    if requested_stages is not None:
        requested=set(requested_stages)
        for language,names in related.items():
            pending=[name for name in names if name in requested
                     and (name not in by_id or by_id[name]['status']=='NOT_RUN')]
            if pending and language in observed and observed[language]['status']=='PASS':
                observed[language]['status']='INCOMPLETE'
                observed[language]['scope']+='; requested stages not completed: '+','.join(pending)
    return observed

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--profile',choices=('full','tools'),default='full')
    parser.add_argument('--plan',action='store_true',help='print explicit scope without executing or creating output')
    args=parser.parse_args()
    registry=json.loads((ROOT/'clean-code-engineering/assets/language-support.json').read_text())
    tasks=plan(args.profile)
    if args.plan:
        print(json.dumps({'profile':args.profile,'stages':[t[0] for t in tasks],'guide_count':len(registry['languages']),
            'guide_only_languages':[k for k,v in registry['languages'].items() if v['status']=='GUIDE_ONLY'],
            'model_ab':'NOT_RUN','book_semantic_audit':'NOT_RUN'},ensure_ascii=False,indent=2));return 0
    if args.output is None:parser.error('--output is required unless --plan')
    out=args.output.resolve()
    if out.exists() or out==ROOT or ROOT in out.parents:parser.error('output must be new and outside package')
    before=checks.check_manifest(ROOT)
    if not before['ok']:
        print(json.dumps({'status':'INVALID_ARCHIVE','integrity':before},ensure_ascii=False,indent=2));return 1
    out.mkdir(parents=True)
    env_before={key:os.environ.get(key) for key in ('PACK_ROOT','RC18_ROOT','RC20_TARGET_ROOT','RC21_TARGET_ROOT','RC22_TARGET_ROOT','PYTHONDONTWRITEBYTECODE')}
    os.environ.update({key:str(ROOT) for key in env_before if key!='PYTHONDONTWRITEBYTECODE'});os.environ['PYTHONDONTWRITEBYTECODE']='1'
    support=load('rc22_process',ROOT/'evals/rc8/run_integration.py')
    summary={'version':(ROOT/'VERSION').read_text().strip(),'profile':args.profile,'started_utc':now(),
        'source_parent_sha256':json.loads((ROOT/'RELEASE.json').read_text())['parent_sha256'],
        'kind':'controlled_package_verification_not_independent_AI_AB','status':'RUNNING','rows':[],
        'requested_stages':[t[0] for t in tasks],'environment':{'python':sys.version,'platform':platform.platform()},
        'integrity_before':before,'model_ab':'NOT_RUN','source_book_audit':'NOT_RUN'}
    save(out/'summary.json',summary)
    try:
        for key,script,extra,timeout,kind in tasks:
            print('START',key,flush=True)
            work=out/key
            if kind=='unittest':
                work.mkdir(); report=work/'report.json'
                cmd=[sys.executable,'-S',str(ROOT/script),str(HERE/'test_diagnostic_resilience.py'),str(report)]
            else:
                report=work/'summary.json'
                if kind=='core':script='evals/rc22/run_core.py';extra=[]
                cmd=[sys.executable,'-S',str(ROOT/script),*extra,'--output',str(work)]
            process=support.execute(cmd,ROOT,out/(key+'.log'),timeout)
            row={'id':key,'status':process['status'],'process':process,'report':str(report.relative_to(out))}
            if process['status']=='FINISHED':
                try:
                    data=json.loads(report.read_text());row['data']=data
                    row['status']=normalized(data,process['exit_code'],kind)
                    if row['status']=='INVALID_EVIDENCE':
                        row['validation_error']=contracts.shape_issue(data,process['exit_code'],kind) or 'report/exit/result contradiction'
                except (OSError,ValueError,TypeError) as error:row.update(status='INVALID_EVIDENCE',error=str(error))
            elif process['status'] not in ('BLOCKED','INTERRUPTED'):row['status']='FAIL'
            summary['rows'].append(row);save(out/'summary.json',summary)
            print('END',key,row['status'],flush=True)
            if row['status']=='INTERRUPTED':break
    except KeyboardInterrupt:
        summary['rows'].append({'id':next((t[0] for t in tasks if t[0] not in {r['id'] for r in summary['rows']}),'interrupt'),'status':'INTERRUPTED'})
    except Exception as error:summary['orchestration_error']=repr(error)
    finally:
        # Inventory is derived output. Failure here must not erase collected stages
        # or prevent environment restoration. Storage failures still propagate.
        try:
            result=checks.rollup(summary['rows'],summary['requested_stages']);summary.update(result)
            after=checks.check_manifest(ROOT);summary['integrity_after']=after
            if not after['ok'] or summary.get('orchestration_error'):
                if summary['exit_code']!=130:summary.update(status='FAIL',exit_code=1)
            try:
                observed=collect_observed(summary['rows'],requested_stages=summary['requested_stages'])
                summary['language_matrix']=checks.inventory(registry,observed)
            except Exception as error:
                summary['inventory_error']=repr(error)
                summary['language_matrix']=[]
                if summary['exit_code']!=130:summary.update(status='FAIL',exit_code=1)
            summary['finished_utc']=now()
            save(out/'summary.json',summary);save(out/'language-matrix.json',summary['language_matrix'])
        finally:
            for key,value in env_before.items():
                if value is None:os.environ.pop(key,None)
                else:os.environ[key]=value
    print(summary['status'],flush=True);return summary['exit_code']
if __name__=='__main__':raise SystemExit(main())
