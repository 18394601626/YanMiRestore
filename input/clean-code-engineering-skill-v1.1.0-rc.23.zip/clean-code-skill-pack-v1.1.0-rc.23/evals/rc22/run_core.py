"""Reuse the frozen language runner without repeating its document checks.
The full verifier runs those applicable checks as a separate required stage."""
import argparse
import importlib.util
import os
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
def load(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args();out=args.output.resolve()
    if out.exists() or out==ROOT or ROOT in out.parents:parser.error('output must be new and outside package')
    out.mkdir(parents=True)
    os.environ.update(PYTHONDONTWRITEBYTECODE='1',PACK_ROOT=str(ROOT),RC18_ROOT=str(ROOT))
    p=load('rc22_core_helpers',ROOT/'evals/rc19/reproduce.py')
    summary={'status':'RUNNING','runtime':[],'not_in_scope':'document checks run in separate tools stage'}
    def save():p.old.save(out,summary)
    save();code=1
    try:
        sub=out/'batch'
        row=p.old.launch(out,'rc17-ten-language-batch',[sys.executable,'-S','evals/rc17/run_batch.py','--languages','batch','--output',str(sub)],300)
        if row['status']=='FINISHED' and (sub/'summary.json').exists():
            import json
            data=json.loads((sub/'summary.json').read_text());row['details']=data
            row['status']=data['status'] if data.get('exit_code')==row['exit_code'] else 'INVALID_EVIDENCE'
        summary['runtime'].append(row);save()
        if row['status']=='INTERRUPTED':raise KeyboardInterrupt
        for action in (lambda:p.previous.typescript(out),lambda:p.previous.sql(out,'baseline'),lambda:p.previous.sql(out,'fixed'),lambda:p.previous.source_attempt(out,'csharp'),lambda:p.previous.source_attempt(out,'dart')):
            row=action();summary['runtime'].append(row);save()
            if row['status']=='INTERRUPTED':raise KeyboardInterrupt
        directory=out/'rc19-new';directory.mkdir()
        row=p.regressions.run_all(directory,ROOT);row['id']='new-42';summary['runtime'].append(row)
        accepted={'PASS','CONTROL_OBSERVATIONS_MATCH','EXPECTED_OBSERVATIONS_REPRODUCED'}
        states=[r['status'] for r in summary['runtime']]
        if any(s not in accepted|{'BLOCKED','PARTIAL_BLOCKED'} for s in states):summary['status']='FAIL';code=1
        elif any(s not in accepted for s in states):summary['status']='PARTIAL_BLOCKED';code=2
        else:summary['status']='PASS';code=0
    except KeyboardInterrupt:summary['status']='INTERRUPTED';code=130
    except Exception as error:summary.update(status='ERROR',reason=repr(error));code=1
    finally:summary['exit_code']=code;save()
    print(summary['status']);return code
if __name__=='__main__':raise SystemExit(main())
