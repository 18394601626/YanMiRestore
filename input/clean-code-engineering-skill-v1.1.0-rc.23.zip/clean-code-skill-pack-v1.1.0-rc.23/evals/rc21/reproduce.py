"""rc21: exact tool checks plus explicit focused/full behavior scopes.

focused (default): old rc20 48 boundaries plus new 31 contracts.
full: also old ten-language/TS/SQLite/rc19 cases and C#/Dart attempts.
--native: full only, adds old C/C++ compiler/sanitizer matrices.
tools: documentation/tool checks only. No scope here covers all 30 languages.
"""
import argparse
from datetime import datetime,timezone
import importlib.util
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--scope',choices=['focused','full','tools'],default='focused')
    parser.add_argument('--native',action='store_true')
    args=parser.parse_args();out=args.output.resolve()
    if args.native and args.scope!='full':parser.error('--native requires --scope full')
    if out.exists() or out==ROOT or ROOT in out.parents:parser.error('output must be new and outside package')
    previous=load('rc21_inherited',ROOT/'evals/rc19/reproduce.py')
    previous.STAGES=[(name,'evals/rc20/test_applicable_rc19.py',3) if name=='rc19-release' else (name,path,count) for name,path,count in previous.STAGES]
    previous.STAGES += [('rc20-applicable','evals/rc21/test_applicable_rc20.py',4),('rc20-cli','evals/rc20/test_cli.py',4),
        ('rc21-release','evals/rc21/test_release.py',6),('rc21-cli','evals/rc21/test_cli.py',4)]
    original_argv=sys.argv[:];sys.argv=[str(ROOT/'evals/rc19/reproduce.py'),'--output',str(out)]
    if args.scope!='full':sys.argv.append('--tools-only')
    if args.native:sys.argv.append('--native')
    try:code=previous.main()
    finally:sys.argv=original_argv
    summary=json.loads((out/'summary.json').read_text())
    summary.update(entry='evals/rc21/reproduce.py',scope=args.scope,
        scope_note='Only listed local fixtures; no model A/B, all-language, framework or production claim.')
    def save():previous.old.save(out,summary)
    if args.scope!='tools' and code!=130:
        for name,path in [('rc20-boundaries-48','evals/rc20/run_boundaries.py'),('rc21-boundaries-31','evals/rc21/run_new.py')]:
            directory=out/name
            summary['requested_runtime'].append(name);summary['status']='RUNNING';save()
            row=previous.old.launch(out,name,[sys.executable,'-S',path,'--output',str(directory)],180)
            if row['status']=='FINISHED' and (directory/'summary.json').is_file():
                details=json.loads((directory/'summary.json').read_text());row['details']=details
                row['status']=details['status'] if details.get('exit_code')==row['exit_code'] else 'INVALID_EVIDENCE'
            summary['runtime'].append(row);save()
            if row['status']=='INTERRUPTED':code=130;break
    accepted={'PASS','CONTROL_OBSERVATIONS_MATCH','EXPECTED_OBSERVATIONS_REPRODUCED'}
    if code==130 or any(row['status']=='INTERRUPTED' for row in summary['runtime']):code=130;summary['status']='INTERRUPTED'
    elif any(row['status']!='PASS' for row in summary['stages']) or any(row['status'] not in accepted|{'BLOCKED','PARTIAL_BLOCKED','SKIPPED'} for row in summary['runtime']):code=1;summary['status']='FAIL'
    elif any(row['status'] in {'BLOCKED','PARTIAL_BLOCKED','SKIPPED'} for row in summary['runtime']):code=2;summary['status']='PARTIAL_BLOCKED'
    else:code=0;summary['status']='REQUESTED_SCOPE_PASSED'
    summary['exit_code']=code;summary['finished_utc']=datetime.now(timezone.utc).isoformat();save()
    print('rc21 final:',summary['status'],'tool_methods='+str(summary['tool_methods']))
    return code
if __name__=='__main__':raise SystemExit(main())
