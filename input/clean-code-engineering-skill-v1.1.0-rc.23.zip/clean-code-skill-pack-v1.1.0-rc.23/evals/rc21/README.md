# rc.21 复测与错误清理

本轮沿用旧执行器、unittest记录器和Node标记解析，不建设新测试格式。测试与候选在同一助手可见上下文产生，不是独立AI对照。

## 新契约31项

- SQL 14项：真实SQLite临时文件。set_authorizer拒绝ROLLBACK/COMMIT，观察原错误、取消对象、连接事务和独立连接数据；正常路径及引擎已回滚也有正控制。
- 诊断回退1项：异常类显式隐藏add_note，在当前Python检查日志路径，不代表实跑旧Python。
- Python 8项：真实临时文件清理；明确的context manager行为替身；生成器取消与快照。
- JavaScript 8项：Node ESM同步迭代器。工作异常/迭代器异常/return异常、正常结束、别名及冻结目标；不测试异步迭代协议。

## 运行

```bash
python -S evals/rc21/run_new.py --output ../rc21-new
python -S evals/rc21/reproduce.py --scope tools --output ../rc21-tools
python -S evals/rc21/reproduce.py --scope focused --output ../rc21-focused
python -S evals/rc21/reproduce.py --scope full --output ../rc21-full
python -S evals/rc21/reproduce.py --scope full --native --output ../rc21-with-native
```

run_new可用`--target-root`指定保留的rc20源码，对同一组测试重现旧失败；输出不允许位于任一输入包内。脚本不下载依赖、不连接业务数据库、不改变全局日志配置，不是不可信代码沙箱。

focused为默认，包含旧48项和新31项，不能代替未请求的全量业务回归。full尝试C#/Dart，缺工具时退出2；Rust不在full行为范围内，旧阻塞不因此解除。Node缺失/旧Python不支持notes或autocommit时记录BLOCKED/SKIPPED，不当成通过。

## 继承规则

原rc20的6项发行检查中，2项只适用于rc20版本与原文件全体身份，已在原rc20及实现修复后版本未变时分别运行；当前复用其他4项，以rc21的6项替换身份/保护，再加4项CLI。原断言源文件不修改。

回滚被拒绝后数据仍可能暂存于原连接：本版保留原异常并追加未完成清理的诊断，**不宣称回滚已成功**。只捕获sqlite3.Error，不吞掉清理阶段出现的其他取消异常。连接归所有者恢复/弃置，不能直接回池。
