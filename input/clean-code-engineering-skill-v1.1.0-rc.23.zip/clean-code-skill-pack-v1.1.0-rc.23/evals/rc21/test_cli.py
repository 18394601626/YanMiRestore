import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
ROOT=Path(__file__).resolve().parents[2]
ENTRY=Path(__file__).with_name('reproduce.py')
class CLIContracts(unittest.TestCase):
    def call(self,*args):
        return subprocess.run([sys.executable,'-S',str(ENTRY),*map(str,args)],capture_output=True,text=True,timeout=15)
    def test_existing_directory_preserved(self):
        with tempfile.TemporaryDirectory() as temp:
            out=Path(temp);sentinel=out/'sentinel';sentinel.write_bytes(b'keep')
            result=self.call('--output',out)
            self.assertEqual(result.returncode,2);self.assertIn('output must be new and outside package',result.stderr)
            self.assertEqual(sentinel.read_bytes(),b'keep');self.assertEqual(len(list(out.iterdir())),1)
    def test_package_internal_output_rejected(self):
        out=ROOT/'_rc21_should_not_exist'
        self.assertFalse(out.exists());result=self.call('--output',out)
        self.assertEqual(result.returncode,2);self.assertIn('output must be new and outside package',result.stderr);self.assertFalse(out.exists())
    def test_unknown_scope_rejected_before_creating_output(self):
        with tempfile.TemporaryDirectory() as temp:
            out=Path(temp)/'new';result=self.call('--output',out,'--scope','all')
            self.assertEqual(result.returncode,2);self.assertIn('invalid choice',result.stderr);self.assertFalse(out.exists())
    def test_native_not_silently_added_to_focused_scope(self):
        with tempfile.TemporaryDirectory() as temp:
            out=Path(temp)/'new';result=self.call('--output',out,'--scope','focused','--native')
            self.assertEqual(result.returncode,2);self.assertIn('--native requires --scope full',result.stderr);self.assertFalse(out.exists())
if __name__=='__main__':unittest.main(verbosity=2)
