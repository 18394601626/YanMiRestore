"""Version and change-set checks, not a semantic audit of the source book."""
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2]
SKILL=ROOT/'clean-code-engineering'
ALLOWED={'VERSION','README.md','VALIDATION.md','CHANGELOG.md','LANGUAGE_MATRIX.md','FIX_SUMMARY.json','SHA256SUMS.txt',
    'clean-code-engineering/VERSION','clean-code-engineering/assets/language-support.json',
    'clean-code-engineering/references/languages/sql.md','evals/rc18/sql/fixed/solution.py'}
class ReleaseContracts(unittest.TestCase):
    def test_identity(self):
        self.assertEqual((ROOT/'VERSION').read_text().strip(),'1.1.0-rc.21')
        self.assertEqual((SKILL/'VERSION').read_text().strip(),'1.1.0-rc.21')
        self.assertEqual(json.loads((SKILL/'assets/language-support.json').read_text())['version'],'1.1.0-rc.21')
    def test_all_prior_files_except_declared_changes_preserved(self):
        baseline=json.loads((ROOT/'provenance/rc21/baseline-manifest.json').read_text())
        for name,digest in baseline.items():
            if name not in ALLOWED:
                with self.subTest(path=name):
                    self.assertTrue((ROOT/name).is_file())
                    self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest)
    def test_new_frozen_behavior_sources_unchanged(self):
        inputs=json.loads((ROOT/'provenance/rc21/frozen-tests.json').read_text())['files']
        self.assertEqual(len(inputs),4)
        for name,digest in inputs.items():self.assertEqual(hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),digest)
    def test_public_signature_unchanged(self):
        spec=importlib.util.spec_from_file_location('release_sql',ROOT/'evals/rc18/sql/fixed/solution.py')
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        self.assertEqual(str(inspect.signature(module.replace_quantities)),'(db, rows)')
    def test_guide_states_cleanup_and_cancellation_limits(self):
        text=(SKILL/'references/languages/sql.md').read_text()
        for word in ('rc.21','KeyboardInterrupt','add_note','回滚失败','NOT_RUN'):
            self.assertIn(word,text)
    def test_guide_registry_scope_not_inflated(self):
        data=json.loads((SKILL/'assets/language-support.json').read_text())
        self.assertEqual(len(data['languages']),30);self.assertFalse(data['independent_agent_AB'])
        self.assertEqual(data['languages']['sql']['rc21_additional_cases']['behavior_cases'],14)
        self.assertEqual(data['languages']['sql']['dialects']['postgresql']['status'],'NOT_RUN')
        for language in ('csharp','dart'):
            self.assertNotEqual(data['languages'][language]['execution']['status'],'PASS')
if __name__=='__main__':unittest.main(verbosity=2)
