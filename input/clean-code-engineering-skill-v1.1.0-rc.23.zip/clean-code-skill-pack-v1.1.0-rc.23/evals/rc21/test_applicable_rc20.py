"""Reuse four unchanged rc20 checks; exact release identity is rc21-specific.
The omitted rc20 identity/protection checks ran on rc20 and again after the
implementation-only fix. rc21 verifies its own complete baseline manifest.
"""
import importlib.util
from pathlib import Path
import unittest
ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('release20',ROOT/'evals/rc20/test_release.py')
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
if __name__=='__main__':
    excluded={'test_identity','test_prior_bytes_except_explicit_edits'}
    suite=unittest.TestSuite(old.ReleaseContracts(name) for name in unittest.defaultTestLoader.getTestCaseNames(old.ReleaseContracts) if name not in excluded)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    raise SystemExit(0 if result.wasSuccessful() else 1)
