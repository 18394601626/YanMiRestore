"""Run exactly 31 local contracts against the supplied, reviewed fixture package.

SQLite14 + diagnostic fallback1 + Python8 + Node.js8. Real sqlite authorizer
failure injection; the fallback is a capability test, not an old-Python run.
This entry neither installs tools nor runs an external model/untrusted code.
"""
import argparse
from datetime import datetime, timezone
import importlib.util
import json
import os
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def save(path,data):
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    temporary.replace(path)

def run(target,out):
    support=load('rc21_process',ROOT/'evals/rc8/run_integration.py')
    marker=load('rc21_markers',ROOT/'evals/rc17/run_batch.py')
    expected=json.loads((HERE/'expected.json').read_text())
    result={'kind':'controlled_contracts_not_AI_AB','target':str(target),'status':'RUNNING',
        'started_utc':datetime.now(timezone.utc).isoformat(),'runs':[],
        'requested_contracts':31,'not_in_scope':['all language features','server databases','IDE/model behavior','production failures']}
    old_env={key:os.environ.get(key) for key in ('RC20_TARGET_ROOT','RC21_TARGET_ROOT','PYTHONDONTWRITEBYTECODE')}
    os.environ.update(RC20_TARGET_ROOT=str(target),RC21_TARGET_ROOT=str(target),PYTHONDONTWRITEBYTECODE='1')
    save(out/'summary.json',result)
    try:
        for name,ids in expected.items():
            directory=out/name;directory.mkdir()
            log=directory/'run.log'
            if name=='javascript':
                cmd=['node',str(HERE/'tests/cases_javascript.mjs')]
            else:
                cmd=[sys.executable,'-S',str(ROOT/'evals/rc20/collect_unittest.py'),str(HERE/'tests'/f'cases_{name}.py'),str(directory/'report.json')]
            record=support.execute(cmd,directory,log,45)
            row={'id':name,'expected_count':len(ids),'executed':0,'process':record,'log':str(log.relative_to(out)),'status':record['status']}
            result['runs'].append(row)
            if record['status']=='FINISHED':
                if name=='javascript':
                    row.update(marker.inspect(log.read_text(errors='replace'),record['exit_code'],ids))
                elif not (directory/'report.json').is_file():row['status']='INVALID_EVIDENCE'
                else:
                    report=json.loads((directory/'report.json').read_text());row['report']=report
                    rows=report['records'];names=[item['test'] for item in rows]
                    row['executed']=report['tests_run']
                    counts={kind:sum(item['status']==kind for item in rows) for kind in ('PASS','FAIL','ERROR','SKIP')}
                    row['observed_counts']=counts
                    exact=(len(names)==len(ids) and sorted(names)==sorted(ids) and report['tests_run']==len(ids))
                    if not exact:row['status']='INVALID_EVIDENCE'
                    elif report['success'] and record['exit_code']==0 and all(item['status']=='PASS' for item in rows):row['status']='PASS'
                    elif report['success'] and report['skipped'] and record['exit_code']==2:row['status']='SKIPPED'
                    elif not report['success'] and record['exit_code']==1:row['status']='TEST_FAIL'
                    else:row['status']='INVALID_EVIDENCE'
            save(out/'summary.json',result)
            if row['status']=='INTERRUPTED':raise KeyboardInterrupt
        states=[r['status'] for r in result['runs']]
        if any(s not in ('PASS','BLOCKED','SKIPPED') for s in states):result['status']='FAIL'
        elif any(s!='PASS' for s in states):result['status']='PARTIAL_BLOCKED'
        else:result['status']='PASS'
    except KeyboardInterrupt:result['status']='INTERRUPTED'
    except Exception as error:result.update(status='ERROR',reason=type(error).__name__+': '+str(error))
    finally:
        for key,value in old_env.items():
            if value is None:os.environ.pop(key,None)
            else:os.environ[key]=value
        result['exit_code']={'PASS':0,'PARTIAL_BLOCKED':2,'INTERRUPTED':130}.get(result['status'],1)
        result['finished_utc']=datetime.now(timezone.utc).isoformat()
        save(out/'summary.json',result)
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--target-root',type=Path,default=ROOT)
    args=parser.parse_args();out=args.output.resolve();target=args.target_root.resolve()
    if not (target/'evals/rc18/sql/fixed/solution.py').is_file():parser.error('target must be the reviewed fixture package')
    if out.exists() or out==ROOT or ROOT in out.parents or out==target or target in out.parents:parser.error('output must be new and outside source packages')
    out.mkdir(parents=True);result=run(target,out)
    for row in result['runs']:print(row['id'],row['status'],row['executed'])
    print(result['status']);raise SystemExit(result['exit_code'])
