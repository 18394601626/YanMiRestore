// Tests the existing synchronous-iterable API; not async iterables/browser APIs.
import assert from 'node:assert/strict';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
const root=process.env.RC21_TARGET_ROOT;
const {runBatch,replaceQuantities}=await import(pathToFileURL(path.join(root,'evals/rc17/fixtures/javascript/fixed/solution.mjs')));
const tests = [
  ['JSCL01',async()=>{let closed=0;const fail=new Error('work');function* items(){try{yield 1;yield 2;}finally{closed++;}}await assert.rejects(runBatch(items(),async()=>{throw fail;}),e=>e===fail);assert.equal(closed,1);} ],
  ['JSCL02',async()=>{let closed=0;const fail=new Error('sync');function* items(){try{yield 1;}finally{closed++;}}await assert.rejects(runBatch(items(),()=>{throw fail;}),e=>e===fail);assert.equal(closed,1);} ],
  ['JSCL03',async()=>{let closed=0;const fail=new Error('iterator');function* items(){try{yield 1;throw fail;}finally{closed++;}}const seen=[];await assert.rejects(runBatch(items(),async x=>{seen.push(x);return x;}),e=>e===fail);assert.equal(closed,1);assert.deepEqual(seen,[1]);} ],
  ['JSCL04',async()=>{const primary=new Error('body'),cleanup=new Error('return');let called=0;const items={[Symbol.iterator](){return this;},next(){return {done:false,value:1};},return(){called++;throw cleanup;}};await assert.rejects(runBatch(items,async()=>{throw primary;}),e=>e===primary);assert.equal(called,1);} ],
  ['JSCL05',async()=>{let closed=0;function* items(){try{yield 1;yield 2;}finally{closed++;}}assert.deepEqual(await runBatch(items(),async x=>x*3),[3,6]);assert.equal(closed,1);} ],
  ['JSCL06',()=>{const target=[7];let closed=0;const fail=new Error('iterator');function* values(){try{yield 1;throw fail;}finally{closed++;}}assert.throws(()=>replaceQuantities(target,values()),e=>e===fail);assert.deepEqual(target,[7]);assert.equal(closed,1);} ],
  ['JSCL07',()=>{const target=[0,Number.MAX_SAFE_INTEGER];assert.equal(replaceQuantities(target,target),target);assert.deepEqual(target,[0,Number.MAX_SAFE_INTEGER]);} ],
  ['JSCL08',()=>{const target=Object.freeze([8,9]);assert.throws(()=>replaceQuantities(target,[1,2]),TypeError);assert.deepEqual(target,[8,9]);} ],
];
let failed=0;
for (const [id,test] of tests){try{await test();console.log(`CASE ${id} PASS`);}catch(error){failed++;console.log(`CASE ${id} FAIL`);console.error(error.stack??error);}}
process.exitCode=failed?1:0;
