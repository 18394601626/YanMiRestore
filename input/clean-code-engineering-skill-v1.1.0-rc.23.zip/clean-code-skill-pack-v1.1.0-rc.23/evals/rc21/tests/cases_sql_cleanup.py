"""Reviewed SQLite cleanup-failure contracts; real disk DB and real authorizer.

New requirement: if cleanup raises sqlite3.Error, keep the original exception
(including cancellation) and report incomplete cleanup, without taking ownership
of the connection. The authorizer intentionally denies ROLLBACK; this is not a
production incident and does not simulate a successful rollback.
"""
import importlib.util
import os
from pathlib import Path
import sqlite3
import tempfile
import unittest

ROOT = Path(os.environ['RC21_TARGET_ROOT'])
spec = importlib.util.spec_from_file_location('rc21_sql_subject', ROOT/'evals/rc18/sql/fixed/solution.py')
subject = importlib.util.module_from_spec(spec)
spec.loader.exec_module(subject)


class CleanupContracts(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(prefix='rc21-sql-')
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name)/'database.sqlite'
        setup = sqlite3.connect(self.path)
        try:
            setup.executescript('CREATE TABLE accounts(id INTEGER PRIMARY KEY, name TEXT, '
                'quantity INTEGER NOT NULL CHECK(quantity>=0), deleted INTEGER NOT NULL DEFAULT 0);'
                "INSERT INTO accounts VALUES(1,'Ada',10,0),(2,'Bo',20,0);")
        finally:
            setup.close()
        self.db = sqlite3.connect(self.path, isolation_level=None, timeout=0.0)
        self.addCleanup(self.db.close)
        self.events = []

    def deny(self, transactions):
        def authorize(action, first, second, db_name, caller):
            if action == sqlite3.SQLITE_TRANSACTION:
                self.events.append(first)
                if first in transactions:
                    return sqlite3.SQLITE_DENY
            return sqlite3.SQLITE_OK
        self.db.set_authorizer(authorize)
        self.addCleanup(self.db.set_authorizer, lambda *args: sqlite3.SQLITE_OK)

    def committed(self):
        other = sqlite3.connect(self.path, timeout=0.0)
        try:
            return other.execute('SELECT id,quantity FROM accounts ORDER BY id').fetchall()
        finally:
            other.close()

    def failed_rows(self, error):
        yield 1, 80
        raise error

    def catch_failure(self, error):
        try:
            subject.replace_quantities(self.db, self.failed_rows(error))
        except BaseException as caught:
            return caught
        self.fail('failure must escape; transaction must not be accepted')

    def assert_cleanup_note(self, error):
        notes = getattr(error, '__notes__', [])
        self.assertTrue(any('rollback' in note.lower() and 'connection' in note.lower()
                            for note in notes), 'incomplete cleanup must be reported on the primary exception')

    @unittest.skipUnless(hasattr(BaseException, 'add_note'), 'note checks require Python 3.11+')
    def test_primary_exception_identity_survives_denied_rollback(self):
        self.deny({'ROLLBACK'})
        original = ValueError('input failed')
        caught = self.catch_failure(original)
        self.assertIs(caught, original)
        self.assert_cleanup_note(caught)
        self.assertEqual(self.events, ['BEGIN', 'ROLLBACK'])

    @unittest.skipUnless(hasattr(BaseException, 'add_note'), 'note checks require Python 3.11+')
    def test_keyboard_interrupt_is_not_replaced_by_database_error(self):
        self.deny({'ROLLBACK'})
        original = KeyboardInterrupt('cancel request')
        self.assertIs(self.catch_failure(original), original)
        self.assert_cleanup_note(original)

    @unittest.skipUnless(hasattr(BaseException, 'add_note'), 'note checks require Python 3.11+')
    def test_system_exit_identity_and_code_are_preserved(self):
        self.deny({'ROLLBACK'})
        original = SystemExit(17)
        caught = self.catch_failure(original)
        self.assertIs(caught, original)
        self.assertEqual(caught.code, 17)
        self.assert_cleanup_note(caught)

    @unittest.skipUnless(hasattr(BaseException, 'add_note'), 'note checks require Python 3.11+')
    def test_existing_cause_and_notes_are_not_overwritten(self):
        self.deny({'ROLLBACK'})
        cause = RuntimeError('previous cause')
        original = ValueError('input failure')
        original.__cause__ = cause
        original.add_note('caller note')
        caught = self.catch_failure(original)
        self.assertIs(caught, original)
        self.assertIs(caught.__cause__, cause)
        self.assertEqual(caught.__notes__[0], 'caller note')
        self.assertGreater(len(caught.__notes__), 1)
        self.assert_cleanup_note(caught)

    @unittest.skipUnless(hasattr(BaseException, 'add_note'), 'note checks require Python 3.11+')
    def test_failed_cleanup_does_not_claim_atomicity_or_close_connection(self):
        self.deny({'ROLLBACK'})
        original = LookupError('rows failed')
        caught = self.catch_failure(original)
        self.assertIs(caught, original)
        self.assert_cleanup_note(caught)
        self.assertTrue(self.db.in_transaction)
        self.assertEqual(self.db.execute('SELECT quantity FROM accounts WHERE id=1').fetchone()[0], 80)
        self.assertEqual(self.committed(), [(1,10),(2,20)])
        # The owner can observe the real failure and explicitly recover; the helper
        # must not secretly remove the authorizer or close a borrowed connection.
        self.db.set_authorizer(lambda *args: sqlite3.SQLITE_OK)
        self.db.execute('ROLLBACK')
        self.assertFalse(self.db.in_transaction)
        subject.replace_quantities(self.db, [(1,30)])
        self.assertEqual(self.committed(), [(1,30),(2,20)])

    @unittest.skipUnless(hasattr(BaseException, 'add_note'), 'note checks require Python 3.11+')
    def test_denied_commit_and_rollback_report_unfinished_cleanup(self):
        self.deny({'COMMIT','ROLLBACK'})
        with self.assertRaises(sqlite3.DatabaseError) as caught:
            subject.replace_quantities(self.db, [(1,90)])
        self.assert_cleanup_note(caught.exception)
        self.assertEqual(self.events, ['BEGIN','COMMIT','ROLLBACK'])
        self.assertTrue(self.db.in_transaction)
        self.assertEqual(self.committed(), [(1,10),(2,20)])

    def test_success_does_not_attempt_rollback_or_change_policy(self):
        self.deny({'ROLLBACK'})
        subject.replace_quantities(self.db, [(1,25)])
        self.assertEqual(self.events, ['BEGIN','COMMIT'])
        self.assertFalse(self.db.in_transaction)
        self.assertEqual(self.committed(), [(1,25),(2,20)])
        with self.assertRaises(sqlite3.DatabaseError):
            self.db.execute('ROLLBACK')

    def test_denied_begin_never_consumes_rows(self):
        self.deny({'BEGIN'})
        used=[]
        def rows():
            used.append(True)
            yield 1, 20
        with self.assertRaises(sqlite3.DatabaseError):
            subject.replace_quantities(self.db, rows())
        self.assertEqual(used, [])
        self.assertEqual(self.events, ['BEGIN'])
        self.assertFalse(self.db.in_transaction)
        self.assertEqual(self.committed(), [(1,10),(2,20)])

    def test_engine_rollback_does_not_trigger_a_second_denied_rollback(self):
        self.db.execute("CREATE TRIGGER guard BEFORE UPDATE ON accounts WHEN new.quantity=99 "
            "BEGIN SELECT RAISE(ROLLBACK,'ENGINE_ABORT'); END")
        self.deny({'ROLLBACK'})
        with self.assertRaises(sqlite3.IntegrityError) as caught:
            subject.replace_quantities(self.db, [(1,80),(2,99)])
        self.assertIn('ENGINE_ABORT', str(caught.exception))
        self.assertEqual(self.events, ['BEGIN'])
        self.assertFalse(self.db.in_transaction)
        self.assertEqual(self.committed(), [(1,10),(2,20)])
        self.assertFalse(getattr(caught.exception,'__notes__', []))

    def test_normal_rollback_keeps_exception_without_cleanup_warning(self):
        original=LookupError('normal rollback')
        caught=self.catch_failure(original)
        self.assertIs(caught,original)
        self.assertFalse(getattr(caught,'__notes__',[]))
        self.assertFalse(self.db.in_transaction)
        self.assertEqual(self.committed(),[(1,10),(2,20)])

    def test_keyboard_interrupt_with_successful_rollback_is_atomic(self):
        original=KeyboardInterrupt('stop')
        self.assertIs(self.catch_failure(original),original)
        self.assertFalse(self.db.in_transaction)
        self.assertEqual(self.committed(),[(1,10),(2,20)])

    def test_empty_batch_commits_without_cleanup_under_restrictive_policy(self):
        self.deny({'ROLLBACK'})
        subject.replace_quantities(self.db, [])
        self.assertEqual(self.events, ['BEGIN','COMMIT'])
        self.assertFalse(self.db.in_transaction)
        self.assertEqual(self.committed(),[(1,10),(2,20)])

    def test_caller_transaction_still_untouched_and_rows_not_consumed(self):
        self.db.execute('BEGIN'); self.db.execute('UPDATE accounts SET quantity=41 WHERE id=1')
        self.deny({'ROLLBACK','COMMIT'})
        used=[]
        def rows():
            used.append(True); yield 2, 60
        with self.assertRaises(RuntimeError): subject.replace_quantities(self.db, rows())
        self.assertEqual(used,[]);self.assertEqual(self.events,[])
        self.assertTrue(self.db.in_transaction)
        self.assertEqual(self.db.execute('SELECT quantity FROM accounts WHERE id=1').fetchone()[0],41)
        self.assertEqual(self.committed(),[(1,10),(2,20)])

    @unittest.skipUnless(hasattr(sqlite3.Connection,'autocommit') and hasattr(BaseException,'add_note'),
                         'autocommit+notes need Python 3.12+')
    def test_autocommit_true_cleanup_error_keeps_original(self):
        # Independent real connection, not a Connection subclass or DB mock.
        self.db.close()
        self.db=sqlite3.connect(self.path, autocommit=True)
        self.addCleanup(self.db.close)
        self.deny({'ROLLBACK'})
        original=ValueError('bad row')
        self.assertIs(self.catch_failure(original),original)
        self.assert_cleanup_note(original)
        self.assertIs(self.db.autocommit, True)
        self.assertTrue(self.db.in_transaction)
        self.assertEqual(self.committed(),[(1,10),(2,20)])

if __name__=='__main__':unittest.main(verbosity=2)
