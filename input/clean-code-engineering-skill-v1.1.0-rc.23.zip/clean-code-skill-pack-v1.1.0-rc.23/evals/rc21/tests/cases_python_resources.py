"""Direct tests of existing Python data and context-manager contracts."""
import importlib.util
import os
from pathlib import Path
import tempfile
import unittest
ROOT=Path(os.environ['RC21_TARGET_ROOT'])
spec=importlib.util.spec_from_file_location('python_subject',ROOT/'evals/rc17/fixtures/python/fixed/solution.py')
subject=importlib.util.module_from_spec(spec);spec.loader.exec_module(subject)

class PythonContracts(unittest.TestCase):
    def test_keyboard_interrupt_closes_real_file_and_preserves_identity(self):
        f=tempfile.TemporaryFile();original=KeyboardInterrupt('stop')
        def work(stream):stream.write(b'abc');raise original
        with self.assertRaises(KeyboardInterrupt) as caught:subject.consume_owned(f,work)
        self.assertIs(caught.exception,original);self.assertTrue(f.closed)

    def test_system_exit_closes_real_file_and_preserves_identity(self):
        f=tempfile.TemporaryFile();original=SystemExit(23)
        def work(stream):raise original
        with self.assertRaises(SystemExit) as caught:subject.consume_owned(f,work)
        self.assertIs(caught.exception,original);self.assertTrue(f.closed)

    def test_iterating_cancellation_does_not_partially_replace(self):
        target=[8,9];original=KeyboardInterrupt('cancel')
        def values():yield 1;raise original
        with self.assertRaises(KeyboardInterrupt) as caught:subject.replace_quantities(target,values())
        self.assertIs(caught.exception,original);self.assertEqual(target,[8,9])

    def test_real_file_context_returns_binary_data_including_nul(self):
        f=tempfile.TemporaryFile();payload=b'a\x00b\xff\n';f.write(payload);f.seek(0)
        self.assertEqual(subject.consume_owned(f,lambda stream:stream.read()),payload)
        self.assertTrue(f.closed)

    def test_failed_context_entry_does_not_call_exit(self):
        failure=RuntimeError('enter failed');events=[]
        class Owned:
            def __enter__(self):events.append('enter');raise failure
            def __exit__(self,*args):events.append('exit')
        with self.assertRaises(RuntimeError) as caught:subject.consume_owned(Owned(),lambda s:events.append('work'))
        self.assertIs(caught.exception,failure);self.assertEqual(events,['enter'])

    def test_context_explicit_suppression_is_respected(self):
        events=[]
        class Suppressor:
            def __enter__(self):return self
            def __exit__(self,kind,error,tb):events.append(type(error));return True
        def work(stream):raise ValueError('explicitly suppressed')
        self.assertIsNone(subject.consume_owned(Suppressor(),work))
        self.assertEqual(events,[ValueError])

    def test_snapshot_preserves_internal_alias_but_not_input_identity(self):
        common=['a'];source={'first':common,'second':common}
        result=subject.snapshot(source)
        self.assertIs(result['first'],result['second']);self.assertIsNot(result['first'],common)
        result['first'].append('b');self.assertEqual(source['first'],['a'])

    def test_nonempty_target_alias_input_remains_supported(self):
        target=[0,10,2**80]
        self.assertIs(subject.replace_quantities(target,target),target)
        self.assertEqual(target,[0,10,2**80])

if __name__=='__main__':unittest.main(verbosity=2)
