"""One explicit capability fallback; NOT a run under an older Python version."""
import importlib.util
import os
from pathlib import Path
import sqlite3
import unittest
ROOT=Path(os.environ['RC21_TARGET_ROOT'])
spec=importlib.util.spec_from_file_location('sql_fallback_subject',ROOT/'evals/rc18/sql/fixed/solution.py')
subject=importlib.util.module_from_spec(spec);spec.loader.exec_module(subject)

class DiagnosticFallback(unittest.TestCase):
    def test_missing_note_method_logs_without_replacing_error(self):
        class ErrorWithoutNote(ValueError):
            add_note=None
        db=sqlite3.connect(':memory:',isolation_level=None)
        self.addCleanup(db.close)
        db.executescript('CREATE TABLE accounts(id INTEGER PRIMARY KEY, quantity INTEGER);INSERT INTO accounts VALUES(1,10);')
        db.set_authorizer(lambda action,first,*args: sqlite3.SQLITE_DENY
            if action==sqlite3.SQLITE_TRANSACTION and first=='ROLLBACK' else sqlite3.SQLITE_OK)
        failure=ErrorWithoutNote('keep me')
        def rows():
            yield 1,20
            raise failure
        with self.assertLogs(subject.__name__,level='ERROR') as logs:
            try: subject.replace_quantities(db,rows())
            except BaseException as caught: self.assertIs(caught,failure)
            else:self.fail('must not return success')
        self.assertTrue(any('rollback' in text.lower() and 'connection' in text.lower() for text in logs.output))
        self.assertTrue(db.in_transaction)

if __name__=='__main__':unittest.main(verbosity=2)
