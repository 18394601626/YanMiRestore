# v1.1.0-rc.23｜阶段证据完整性与汇总收尾修复

日期：2026-10-08（UTC）。以实际 rc.22 完整包为唯一基线，SHA-256：`b5f17596721e0f804da7b726f8ee1d7a1094c14c77f8448df602446d94229267`。不混合此前同名历史版本的数字。

## 结论与范围

先重新执行原rc.22的14阶段，345项工具/资料检查通过；可执行语言样例符合预期，Rust/C#/Dart与真实框架前置仍阻塞。随后追加统一入口的证据与收尾测试，确认计数型占位报告被接受、损坏的嵌套JSON使最终汇总留在RUNNING，以及无效记录仍可能被用于生成语言通过标记等问题。

修正版新增36个工具回归方法全部通过；当前发行入口采用343个原非身份检查、36个新增回归和6个发行检查，共385个方法。原两个绑定rc22精确版本/父包的测试保留且只用于原rc22，本版另验rc23身份。最终ZIP解压后的385项与14阶段复跑结果由外部 `rc23-final-verification.json` 和单独证据包记录，不把归档自身哈希写回归档造成循环。

这是同一助手基于已知报告结构的受控测试，不是模型A/B、独立语义审查、生产事故统计或全语言认证。没有新增语言或改写任何语言样例。

## 1. 本轮确认并修复的三类问题

| 问题 | 旧行为 | 新行为 |
|---|---|---|
| 数量替代具体执行结果 | 10个仅含case名字的JDK项、11个空Go观察仍可判PASS；重复目标可以替代遗漏目标 | 核对固定登记身份、唯一性、必需布尔结果、原预期状态与父子一致性。缺少字段、类型错误、未知身份明确INVALID_EVIDENCE；实际失败保持FAIL |
| 损坏报告破坏最后收尾 | `runtime:[null]`被接收后，语言矩阵再次解析触发AttributeError；最后汇总仍RUNNING，临时环境变量未恢复 | 先检查JSON结构；无效payload保留但不用于通过状态。独立后续阶段继续；矩阵异常记inventory_error、最终FAIL；环境恢复在外层finally中完成 |
| 部分核心通过被显示为完整验证 | 核心结果有PASS时，没有检查本次请求的补充阶段是否实际出现；拒绝的核心报告里仍可能取出TS通过 | 不从INVALID_EVIDENCE取正向结果；已请求补充阶段缺失时标INCOMPLETE，保留确实执行过的子范围数量，不误伤未请求的补充项 |

框架阻塞记录也会核对数据库/候选配对唯一性，避免用重复的postgres/baseline替代遗漏项。这里使用合成的元数据输入，不表示本轮连接过数据库。

变更文件：`evals/rc22/reproduce.py`、`evals/rc22/delivery_checks.py`；新增局部结构契约 `evals/rc22/stage_contracts.py`。所有旧输入正常路径继续支持；不符合原意的错误报告被有意拒绝。根入口仍为verify.py，当前包装层只替换tools阶段的发行检查，14个语言与框架阶段不变。

[实际补丁](provenance/rc23/implementation.diff) · [修复前后直接输出](evidence/rc23/direct-observations/observations.json)

## 2. 测试先行与测试辅助代码的一次纠正

第一轮29项探针先在原rc22运行，暴露多个结构误判；新增7项核心聚合探针又确认了父状态掩盖失败、空/重复批次的缺口，然后才补对应条件。最后冻结的36项在旧版为6个方法通过、21个方法断言失败、9个方法错误；修正版36通过。错误/失败包含同一测试内不同JSON类型，以及旧版不支持新增requested_stages参数，不能解读为30个独立缺陷。

首版三个core流程探针没有考虑入口会重写为run_core.py，实际没有到达注入脚本。这些首次绿灯不能证明null报告已被处理。发现后保存首版、日志和冻结哈希，在临时包正确入口写入同一受控脚本，并加上子进程退出0与报告原字节相同的检查；不是降低断言。最终版本重新在旧实现重现嵌套null导致RUNNING/环境未恢复，在修正版验证最终FAIL与环境恢复。

36项中4项流程测试确实启动本地Python子进程写入受控JSON，但未运行编译器或数据库；其他项使用历史真实报告的标注变体。历史报告只用于格式正控制，不当作本轮语言执行证据。旧语言执行结果另由14阶段实跑生成。

[最终冻结测试](provenance/rc23/frozen-tests.json) · [旧版36项结果](evidence/rc23/final-probes-baseline/summary.json) · [修正版36项结果](evidence/rc23/final-probes-fixed/summary.json) · [辅助定位记录](provenance/rc23/harness-notes.txt)

## 3. 实际执行与分类

| 层次 | 已执行观察 |
|---|---|
| 原rc22完整请求 | 14阶段完成；345方法通过；整体PARTIAL_BLOCKED/2 |
| 初修代码、尚未改版本时 | 原345方法再次通过；旧断言未改 |
| 新证据/流程回归 | 29+7方法通过；包含顺序变化与额外诊断字段、完整阻塞报告、轻量/部分请求的正控制 |
| 当前发行工具 | 第一轮385方法通过；辅助定位纠正后36项重新通过；最终发行另完整复跑385项 |
| 当前14阶段工作树 | 工具、核心语言、rc20/21边界、诊断、C/C++、Go、JDK均完成；Rust与框架为明确阻塞；整体PARTIAL_BLOCKED/2 |
| Rust/C#/Dart | 实际工具尝试失败，各0项运行 |
| Spring编译/服务器数据库 | 实际前置检查BLOCKED，编译与数据库测试0项执行 |

本轮14阶段依次包含：tools、core-languages、rc20-boundaries、rc21-boundaries、new-diagnostics、native、native-extra、native-ctest、go-resources、go-modules、java-jdk、rust、framework-compile、framework-integration。full只指此清单，不指每个历史入口、所有语言版本与框架。

[原版完整运行](evidence/rc23/baseline-full/summary.json) · [工作树完整运行](evidence/rc23/worktree-full-first/summary.json) · [录制进程及退出码](evidence/rc23/driver-records/current-full/command.json)

## 4. 中断记录与环境

实际环境为Linux x86_64、系统Python3.13.5；语言工具版本和命令在各阶段日志中。本轮没有下载工具链、修改DNS、调用模型或接入业务数据库。

首次通过外层有限时长工具启动原版完整验证时被外层超时中断，父摘要RUNNING；该次没有计完整通过。随后另起有总时间边界的录制进程，在同一回合中完成原版14阶段并取得退出2。原版执行产生的两个Python缓存不属于原ZIP清单，不把它们伪称为源码修改。实际执行与第一轮记录均保留。

## 5. 保护与剩余范围

主SKILL.md、01—19参考、全部30项语言指南、原书198卡/274目录/54项待细化、缺页说明、旧模板、语言源码与所有旧测试文件按父包逐字节保持。Skill目录只更新VERSION和语言状态的本版范围说明；只安装轻量包不会替换业务项目中的运行器。

旧报告原文以.txt快照归档，旧测试精确版本断言不改。全体原文件差异白名单和逐文件哈希见 [保护记录](provenance/rc23/preservation.json)。

12项GUIDE_ONLY和3项工具阻塞不因385项工具通过而提升验证级别。没有IDE实际加载、独立模型效果、全书重新审稿、生产性能/安全验证。

## 6. 不保证什么

- 结构自洽不等于报告真实；恶意程序可以伪造完整一致的报告。当前入口只针对已审阅的随包运行器，不是沙箱或权限系统。
- 输出介质可写时，矩阵错误会写出最终失败；未测试磁盘耗尽、SIGKILL、远程进程或其他操作系统，不能承诺这些情形均能落盘/清理。
- 只有已请求但缺失的补充阶段会使原本核心PASS成为INCOMPLETE；未请求的语言保持NOT_RUN，已有GUIDE_ONLY不被改成FAIL。
- 对状态为失败/阻塞且尚未产生完整报告的运行，仍会保留失败/无效证据，不将其强行变成业务通过。

## 7. 复现

```bash
python -S verify.py --plan
python -S verify.py --profile tools --output ../rc23-tools
python -S verify.py --profile full --output ../rc23-full
```

输出必须包外且不存在。本机使用`/usr/bin/python3 -S`，其他Python发行和启动钩子环境未验证。当前full预期退出2是缺工具/框架阻塞，不是全部验证通过。只跑36项新工具回归可使用 `python -S evals/rc23/run_probes.py --output ../rc23-probes`。
