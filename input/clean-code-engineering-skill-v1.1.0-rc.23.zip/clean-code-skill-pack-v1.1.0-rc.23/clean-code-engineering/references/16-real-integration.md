# 真实框架与数据库集成：证据边界

**执行适配，不是原书新增章节。** 01—15 保持原字节。本页是针对 rc.7 明示的“仅 JDK 模拟、未启动框架”缺口设计的验证规则，不宣称已测出新的框架缺陷。

## 1. 什么时候加载

任务涉及 Spring 代理、事务、Mapper/插件、数据库方言、DTO 映射，且要宣称“集成验证通过”时加载。私有改名或纯格式任务仍按原轻量路径处理。

先区分：JDK 自包含样例 → 框架容器测试 → 真实数据库集成 → 真实网络端到端 → 生产负载。上一层通过不能替代下一层。MockMvc 可以运行真实 MVC 映射与 ObjectMapper，但不是已启动真实 HTTP 网络服务。[I04]

## 2. 启动条件与不可替代项

先记录实际 JDK、构建工具、已解析依赖、数据库产品/版本、镜像引用、代理模式、DataSource 和 TransactionManager。依赖不可下载、Maven/Docker 缺失或数据库不可用时返回 **BLOCKED**；未调用编译器就是未编译，不从 XML/源码格式检查推断编译成功。

PostgreSQL 与 MySQL 分别记录结果；本来要验证 MySQL 时不得用 MariaDB/H2 的结果替代。不可用环境不自动降级为内存数据库、JDK 模拟事务或 Mockito，再沿用“真实集成通过”的标题。

只在隔离的一次性实验数据库中执行清表/建表/坏控制，不从用户生产环境变量自动选取连接，不复用已有业务数据库。本包仅提供 Testcontainers 创建的临时数据库入口。首次实际运行可能下载 Maven 依赖、数据库镜像并占用磁盘/端口；运行前说明这些副作用。[I07]

## 3. 事务验证不得被测试托管事务掩盖

Spring 的测试托管事务与应用事务不同，应用可能参加测试已经开启的事务。[I02] 因此，当目标是证明业务入口自己建立了正确边界：

- 通过容器取得并调用被代理的服务，不直接 new 服务冒充集成。
- 验证开始时测试线程没有应用未要求的事务；本包不在测试类/方法上加 `@Transactional`。
- 服务返回或抛出后，在独立获取的连接上查询最终已提交数据，分别验证成功提交、运行时异常及明确要求回滚的受检异常。
- `self-invocation` 只在具体 proxy 配置下判断。内部方法绕过代理不等于调用时必定没有外围事务；不能看到 this 调用就一概判“无事务”。[I01]
- 回滚规则来自项目版本/配置，不强制所有异常都 rollback。对正常默认规则的观察，不能标成框架 bug。[I03]

数据库回滚不证明 HTTP、MQ 或文件副作用被回滚；本套件没有测试这些外部副作用。

## 4. SQL 必须在实际 Mapper 执行路径观察

N+1 检查声明计数边界：本包统计 MyBatis StatementHandler 完成的 query 次数，不是 mock 的 Mapper 调用次数，也不声称统计了连接池内部/所有数据库语句。测量前重置计数，确认本次确实触达数据库；缓存配置、输入规模与查询路径应记录。

区分空 ID 集合、条件被禁用以及全量查询意图。本包约定空 ID 查询不访问数据库、空 ID 更新拒绝执行；其他业务采用自身契约，不把示例当成所有项目的统一规定。

MyBatis-Plus 的 updateStrategy 与显式 NULL 操作是不同问题，不能从 Java 字段为 null 推断 SQL 一定更新 NULL。[I05] 记录实际 SQL 与独立查询结果；默认跳过 null 本身不一定是缺陷，关键是它是否满足本次明确清空要求。

逻辑删除在实际通用/自定义 Mapper 路径分别核对；插件、注解或依赖存在不能替代数据库结果验证。[I06] 本包未覆盖租户插件、分页插件和数据权限插件，不能据其通过宣称这些能力通过。

## 5. JSON 使用真实配置

DTO 通过项目实际 ObjectMapper/MVC 转换器序列化，再检查旧字段、新字段、null/缺失/空集合。不得手写 JSON 字符串或只校验 Map 键来冒充实际 DTO 映射结果。MockMvc 与网络端到端分开报告。[I04]

## 6. 验收记录是多状态，不只有红绿

每种数据库、候选、测试类和方法分开记录：PASS / TEST_FAIL / TEST_ERROR / SKIP / NO_TESTS / INCOMPLETE / INVALID_EVIDENCE / BLOCKED / TIMEOUT。

通过需有本次新生成的 Surefire testcase 记录、目标完整执行、无跳过/错误且命令成功。无报告、旧报告、汇总数字与case不一致不能默认通过。已知坏控制只有在指定行为断言实际失败时才算被检出；依赖解析/容器启动失败不能充作“坏代码已抓住”。

测试、预期与候选均记录版本/哈希。先写测试但因依赖缺失未执行，必须说明没有完成行为 RED→GREEN；文档缺项红绿或 Python 解析器测试不等于框架效果测试。

## 7. 本候选版的实际状态

`evals/rc8/` 已提供真实依赖声明、13 个 JUnit 集成契约和两种受控实现。**在本轮交付环境中，Spring/MyBatis-Plus/Jackson 集成项目未编译，PostgreSQL/MySQL 测试均为 BLOCKED，实际执行 0 项。** 原因是 Maven/Docker 缺失，容器下载依赖又出现 DNS 失败。

Python 运行入口和历史样例可另外验证，但不补足上述证据缺口。此页是待验证执行规范；原先编写的 rc.7 参考仍保留为历史原文。候选实现未被称为已验收正确实现。禁止给出 Skill 的成功率提升或普通 AI 对照胜负。

## 官方依据（2026-09-29查阅）

- [I01] Spring 6.2 事务注解与代理：`https://docs.spring.io/spring/reference/6.2/data-access/transaction/declarative/annotations.html`
- [I02] 测试事务和应用事务：`https://docs.spring.io/spring-framework/reference/6.2/testing/testcontext-framework/tx.html`
- [I03] 默认回滚与可配置规则：`https://docs.spring.io/spring-framework/reference/data-access/transaction/declarative/rolling-back.html`
- [I04] Spring Boot 测试层级：`https://docs.spring.io/spring-boot/3.5/reference/testing/spring-boot-applications.html`
- [I05] MyBatis-Plus updateStrategy：`https://baomidou.com/en/reference/`
- [I06] MyBatis-Plus 逻辑删除：`https://baomidou.com/en/guides/logic-delete/`
- [I07] Testcontainers PostgreSQL：`https://java.testcontainers.org/modules/databases/postgres/`

资料用于规则设计；实际项目仍须按自身版本与配置核对，不能把当前网页描述当成所有历史版本的实现证明。


## rc.9 补充：由实测失败定义的证据检查

**执行适配。** 以下补充针对本包受控验收器，不是原书新章节；不是安全沙箱，也不是来源真实性认证。

- **失败原因归属**：保存同一个 testcase 的终态 failure/error 类型、消息、报告文件与栈；目标名相同不足以确认目标缺陷。坏控制的具体断言使用固定原因标识，只从该 failure 的消息前缀和允许的断言类型核对，不从 stdout、栈、兄弟用例或重试记录借用。标识不能证明测试代码诚实；须冻结可信测试和候选输入。
- **运行身份**：请求的数据库种类、镜像标签、版本系列、候选 baseline/fixed 与实际记录对应；缺失、矛盾、非对象、重复键、损坏身份标为 INVALID_EVIDENCE。保留原始测试状态，在正常可写输出目录先落盘总表，再逐项更新；单项身份损坏不阻止后续候选。不能对断电、磁盘写失败作“汇总永不丢失”的承诺。
- **重试**：保留 flakyFailure/flakyError 及 rerunFailure/rerunError 的失败记录和次数。首次通过与 FLAKY_PASS（重试后通过）分开。默认拒绝把 FLAKY_PASS 当验收完成；明确选择 allow-fixed 后仅允许修正候选以带标记的重试通过，坏控制有重试仍不确认，避免跨次执行归属。
- **XML**：先由解析器识别编码并在 DTD/实体声明事件处拒绝，再读取 testcase；限制单文件大小。UTF-8/UTF-16 同一策略；普通注释和转义日志不当作真正 DTD。未支持/损坏编码明确 INVALID_EVIDENCE，不自行猜解。
- **分阶段**：仅编译使用 Maven test-compile 阶段，不要求 Docker；数据库集成另跑。编译前仍须真实 JDK/Maven/依赖，进程成功还要检查新生成的类文件。仅编译成功不等于测试成功；依赖解析或编译失败统称 BUILD_FAILED 并看 Maven 日志，不靠关键词猜具体阶段。

本轮验收器测试使用合成 XML、身份文件和进程替身；只有进程控制与本地前置探测是真实进程。当前环境没有 Maven、Docker，仍未编译 Java 或运行真实 Spring/数据库。运行身份一致性、原因标识不是密码学认证，不抵御恶意测试伪造整个报告。

实现与复现材料在完整包 evals/rc8、evals/rc9；轻量安装包不包含评估工具。不要求任意业务仓库使用本包固定数据库、镜像、失败码或重试策略。

### 本轮外部依据（2026-10-02 核对）

- Surefire 重试报告：`https://maven.apache.org/surefire/maven-surefire-plugin/examples/rerun-failing-tests.html`
- Python Expat 编码与声明回调：`https://docs.python.org/3/library/pyexpat.html`
- Maven 生命周期及 test-compile：`https://maven.apache.org/guides/introduction/introduction-to-the-lifecycle.html`


## rc.10 补充：超时与中断后的进程所有权

**执行适配。** 本轮实测发现：仅等父进程退出，会漏掉同组中忽略终止信号的子进程。
POSIX 下，本包运行器为命令创建独立会话；发生超时或中断时，向该次命令的进程组发送终止信号，给予有界宽限，再发送强制停止信号并回收直接子进程。只操作自己创建的进程组，不扫描并杀死其他用户进程；避免先回收组长后才做最后一次组信号。

中断记录为 INTERRUPTED；保存当前进程的退出信息、清理动作、耗时与日志摘要，后续尚未开始的候选保留 NOT_RUN，不继续启动新构建或数据库步骤。启动失败同样保存原因、耗时和日志摘要。清理错误单独记录，不把原来的 TIMEOUT/INTERRUPTED 写成 PASS。

**边界：** 发信号并回收直接子进程，并不证明所有外部资源都已释放。脱离原进程组的任务、远程作业及 Docker 容器不在这个清理范围内；真实 Testcontainers 容器清理仍需独立验证。Windows 回退只处理直接子进程，本轮没有在 Windows 运行；不宣称跨平台进程树清理已经完成。测试里的观察窗口不是对任意不可中断系统调用的强制终止保证。

本轮用真实 Python 进程、实际 SIGINT 与受控调度替身验证上述边界，不冒充 Maven/Spring/数据库集成。Maven、Docker 和依赖下载仍不可用，Java 构建与数据库集成仍未执行。既有验收断言、框架版本、业务源码不变。

实现沿用 evals/rc8/run_integration.py；新回归位于 evals/rc10。Python 官方语义依据（2026-10-02 查阅）：
`https://docs.python.org/3.13/library/subprocess.html` 与 `https://docs.python.org/3.13/library/os.html#os.killpg`。
