# Fortran 专项执行适配

**执行适配，不是《代码整洁之道》的新增内容。** 先按项目事实选择相关小节，不将本次样例版本当作项目升级要求。规则不等于编译器、完整语言规范或安全证明。

## 1. 标准、源格式与构建

确认固定/自由源格式、标准版本、kind、预处理、编译器和 BLAS/MPI 等依赖；不把 gfortran 标志强加其他编译器。module、implicit none、intent、显式接口用于表达本次依赖，旧 COMMON/EQUIVALENCE 迁移需行为保护。

## 2. 数值与求值

用项目规定的 kind 或 ISO_FORTRAN_ENV 表达宽度；kind 数字本身不能随意当字节数。[S1] 运算前验证范围；不依靠溢出后的结果再判断是否溢出。逻辑表达式不能用来假定另一个分支必定不求值，保护边界使用明确的顺序分支。[S2]

## 3. 数组、切片与存储

检查形状、上下界、stride、零尺寸和 allocated/associated。调用者的切片可能非连续；临时复制有性能成本。pointer 关联和 allocatable 的赋值不能用同一种所有权解释。按实际任务比较结果、形状和修改隔离。

## 4. 错误与失败原子性

I/O 用 iostat/iomsg 等实际结果，不把读到一部分输入当完整协议有效。list-directed 读取对应用协议可能过于宽松，应先明确词法约束。失败须保留旧 allocatable 数据时，不能先销毁目标；先验证、allocate 临时值、检查 stat，再移交。

## 5. 并行与外部接口

OpenMP、coarray、MPI、C binding 按实际配置分开检查。数组顺序、字符长度、kind 与 ISO_C_BINDING 不能凭两边类型名称推断兼容。本批未验证并行或真实 C binding，不能外推。

## 6. 本轮六项契约

FT01—FT06：加法上溢、最小负值边界、零尺寸分配、非法输入保留旧数组、非连续切片求和、拒绝逗号后尾随数字。gfortran14.2，Fortran2008 与 -fcheck=all；检查标志只覆盖已运行的相应问题，[S3] 不证明所有数值稳定性、溢出或并行正确性。

## 来源与验证边界

2026-10-04 查阅以下官方资料，仅用于语言事实；正文检查建议为本包执行适配。浮动文档不代表已验证其最新所有功能。当前真实运行范围以包根 VALIDATION.md 和运行日志为准，独立代理遵循实验为 NOT_RUN。

- [S1] `https://gcc.gnu.org/onlinedocs/gfortran/ISO_005fFORTRAN_005fENV.html`
- [S2] `https://gcc.gnu.org/onlinedocs/gfortran/Evaluation-of-logical-expressions.html`
- [S3] `https://gcc.gnu.org/onlinedocs/gfortran/Code-Gen-Options.html`
