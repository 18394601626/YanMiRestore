# SQL 方言族 专项执行适配

**执行适配，不是《代码整洁之道》的新增章节。** 本页为语言专项检查指南，不是完整语言规范、编译器或安全证明；先保持项目已有契约。

## 1. 项目与版本识别

触发线索：.sql、迁移目录、数据库驱动和服务端身份。先确认PostgreSQL/MySQL/SQL Server/SQLite等方言、数据库服务版本、驱动、schema、事务隔离和迁移工具。客户端存在不代表连接到预期数据库。测试只使用明确的临时数据库，禁止默认连业务或生产。

## 2. 数据与语言语义

NULL判断、NOT IN子查询含NULL、COUNT列/行和JOIN重复会改变结果；不能只看普通数据。[S1] 参数化值与动态标识符分开处理；输出顺序需要实际ORDER BY，不能依赖当前扫描计划。

## 3. 失败、资源与并发

确认谁拥有事务，成功后由独立连接观察提交结果，失败后检查全体相关行。SQLite同一时刻的写事务限制按其规则验证。[S2] 不把SQLite验证外推到MySQL：后者多种DDL会隐式提交。[S3]

## 4. 兼容性和不过度抽象

迁移分扩展、回填、调用方迁移与删除阶段；新增列也需检查锁、默认值、回填成本和旧消费者，不能宣称必定在线无风险。[S4] 保留列名、类型、约束、NULL、时区和排序语义；执行计划及查询次数单列。

## 5. 具体验证契约

本轮12项SQLite测试在临时磁盘数据库执行，通过Python标准库sqlite3调用真实SQLite引擎，不是字符串模拟。[S5] 覆盖NULL排除、显式清空/缺失、参数值、空ID、批次回滚、提交可见、调用方事务、缺行、顺序与加列兼容。PostgreSQL/MySQL/SQL Server未验证，不用本轮通过替代历史阻塞。

至少将正常、错误、空值/边界、资源结束与旧消费者分开记录；只编译、只启动工具或只有一个正常用例，不等于完整专项验证。缺工具时保留BLOCKED，禁止以其他语言或数据库的结果代替。

## 6. 证据和未验证范围

仅本包指定SQLite路径有本轮执行证据，其余数据库方言为NOT_RUN。SQLite实验不验证Spring/MyBatis、网络服务、生产负载、迁移重入或任意SQL。

指南来源是语言官方资料；自动文档检查仅检查存在性/引用/状态一致，不证明语义穷尽。原书198卡及待补内容不因本页增加而改变。

## rc.19 定点补充：精确整数与隐式转换

SQLite 普通表的 INTEGER 声明和 `CHECK(quantity >= 0)` 不足以证明输入是精确整数；值可能以 REAL/TEXT 保存或被隐式转换。[S6] 修改绑定入口时，按项目协议核对应用类型、数据库存储类与值域，而不靠声明推断。

本批 `replace_quantities` 明确要求 ID 和 quantity 为 Python 的实际 int（不含 bool），且数量落在有符号64位范围。浮点、数字文本、布尔等输入现返回 ValueError；越界整数保持 OverflowError；负整数沿用既有 SQLite CHECK 的 IntegrityError。这是样例的**行为收紧**，不是所有 SQL 应用必须统一使用的异常策略。负数约束、缺行回滚和调用者事务归属没有更改。

本批新增16项真实 SQLite 检查：非法类型批次不部分提交，最大整数保持 INTEGER，迭代器错误保留，延迟外键在 COMMIT 失败后回滚，连接可再次使用。提交阶段不能只由语句失败测试代替。[S7] 不增加对PostgreSQL/MySQL/SQL Server的验证声明。

## 7. 来源

2026-10-04核对；在线资料可能描述比用户项目更新的版本，先按实际项目版本适用。下面支持语言事实，具体测试选择与实施步骤属于本包的工程建议。

- [S1] `https://www.sqlite.org/lang_expr.html`
- [S2] `https://www.sqlite.org/lang_transaction.html`
- [S3] `https://dev.mysql.com/doc/refman/8.4/en/implicit-commit.html`
- [S4] `https://www.postgresql.org/docs/current/ddl-alter.html`
- [S5] `https://docs.python.org/3/library/sqlite3.html`

- [S6] `https://www.sqlite.org/datatype3.html`
- [S7] `https://www.sqlite.org/foreignkeys.html`

## rc.20 定点补充：驱动策略和显式事务必须配对

除数据库方言，还要记录客户端驱动版本、autocommit与isolation_level。CPython 3.12+ sqlite3 的 `autocommit=True` 使连接对象的 `commit()`、`rollback()` 不执行事务控制；这与底层SQL事务是否已打开是两个层次。[S8] 用显式SQL `BEGIN` 开启自有事务时，核对对应的SQL `COMMIT` / `ROLLBACK`，不能混搭后仅凭没有异常宣称已提交。

本例保留调用方已有事务的拒绝策略，不修改连接autocommit配置。失败时先确认事务仍存在：SQLite的 `RAISE(ROLLBACK)` 可能已经回滚，重复执行ROLLBACK会覆盖原始异常。成功用独立连接读已提交结果；失败核对本连接和独立连接、事务关闭、原始异常和连接复用。`autocommit=False` 的调用方事务仍拒绝接管。

本版SQL14个新增检查只验证真实SQLite临时文件和所记录CPython版本；不外推到服务器数据库、不验证任意自定义Connection子类、rollback本身失败、恶意迭代器篡改事务或跨线程复用。旧Python没有autocommit接口时相关用例必须标SKIP，而不是PASS。

- [S8] `https://docs.python.org/3.13/library/sqlite3.html#transaction-control-via-the-autocommit-attribute`（本轮核对，来源不代替本地执行证据）


## rc.21 定点补充：回滚失败不是原始错误，也不是清理完成

错误处理自身也可能失败。优先记录本次失败的原始类型/对象、既有因果链、取消信号，以及回滚是否真正完成；不要让清理时抛出的数据库异常掩盖最初的业务失败或 `KeyboardInterrupt`。不能因为进入过 ROLLBACK 分支就报告已回滚。

本例在回滚或读取事务状态时遇到 `sqlite3.Error`，保留原始异常继续抛出，并用 `add_note` 记录回滚失败与连接状态未验证；已有 cause 与 notes 不覆盖。没有 add_note 能力时记录错误日志，不改全局日志配置。这是样例的新增失败报告契约，不声称所有系统应采用相同错误优先级。[S9]

连接仍归调用方所有：不禁用其授权回调，不偷偷关闭连接，不重试 COMMIT。回滚失败后不能归还连接池当作干净连接，所有者必须显式恢复或丢弃。此次实测使用 SQLite 的 `set_authorizer` 主动拒绝 ROLLBACK：同连接保留了尚未提交的部分写入，新连接仍读到旧值。新实现只保存原异常和诊断，**没有克服授权拒绝、没有完成回滚**。[S10]

本次 SQL 14 项检查使用真实文件数据库，另有1项在实际Python中关闭异常对象的add_note能力以检查日志回退；后者不是旧Python版本运行。`KeyboardInterrupt`/`SystemExit`由受控生成器同步抛出，不是操作系统信号/真实进程退出实验。仅捕获sqlite3.Error，不吞掉新的非数据库取消异常；不验证二次信号、自定义异常方法失效、损坏日志处理器、网络断开、磁盘损坏、跨线程复用或恶意迭代器操纵事务。PostgreSQL/MySQL/SQL Server仍为 NOT_RUN；回滚失败后的任意连接不承诺可直接复用。

- [S9] `https://docs.python.org/3.13/library/exceptions.html#BaseException.add_note`（Python 3.11增加；解释机制，不替代本地测试）
- [S10] `https://www.sqlite.org/c3ref/set_authorizer.html`（SQLITE_DENY拒绝动作；此次用作受控失败注入）


## rc.22 补充：诊断失败不替代原异常

执行适配，来自本包受控测试，不是原书新增内容。回滚失败之后，异常对象的 `add_note` 可能被子类覆盖而再次报错，日志过滤器或自定义 handler 也可能抛出异常。诊断是尽力而为的附加操作，不应把一个普通诊断异常变成调用方最终接收的业务错误。

本例将普通 `Exception` 级别的说明写入失败回退到日志；日志自身也发生普通异常时，不递归记录或重配全局日志，而是保留原异常。诊断阶段出现**新的** `KeyboardInterrupt` / `SystemExit` 仍向外传播，不用笼统捕获 `BaseException` 把新的取消吞掉。

这不能保证日志一定送达、回滚一定成功或连接已经恢复；回滚被拒绝时事务可能仍打开。所有者仍需显式恢复或丢弃连接，不能直接归还连接池。不同语言的异常优先级应遵循既有契约，不照搬此示例。历史 rc.21 的声明保持其当时范围。

官方机制资料（2026-10-05核对）：`https://docs.python.org/3.13/library/logging.html` 与 `https://docs.python.org/3.13/library/sqlite3.html`。测试结果以完整包中的新日志为准，官方文档不是执行证据。
