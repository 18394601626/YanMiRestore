# Scala 专项执行适配

**执行适配，不是《代码整洁之道》的新增章节。** 本页为语言专项检查指南，不是完整语言规范、编译器或安全证明；先保持项目已有契约。

## 1. 项目与版本识别

触发线索：.scala、build.sbt、project/build.properties、Scala CLI配置。记录 Scala 2/3、JDK、sbt/其他构建器、crossScalaVersions、编译选项和目标 JVM/JS/Native。版本线和二进制兼容政策由仓库决定，不自动迁移语法或隐式机制。

## 2. 数据与语言语义

val 固定绑定不证明被引用的对象无可变状态。修改 Option/Either/Try、集合模型或Java互操作null时先定义失败和缺失含义。复制case class前核对内部成员，不把不可重新赋值当深快照。

## 3. 失败、资源与并发

Future 的计算使用实际 ExecutionContext；global 并非专用阻塞I/O池，阻塞工作需要核对调度容量。[S1] 超时等待不自动证明计算已取消。资源释放必须覆盖异步结果完成，不能方法返回就过早关闭。

## 4. 兼容性和不过度抽象

源码重编译通过与旧二进制可链接不同。[S2] 核对返回类型、默认参数、隐式/given、trait、生成方法及Java消费者；跨版本库使用项目选择的兼容工具而不凭表面签名判断。

## 5. 具体验证契约

计划验证：单线程执行环境中的阻塞风险；失败Future保留原因；资源清理；case class内部可变成员隔离；旧源码和预编译消费者。语言检查不替代Akka/Pekko/ZIO等框架验证。

至少将正常、错误、空值/边界、资源结束与旧消费者分开记录；只编译、只启动工具或只有一个正常用例，不等于完整专项验证。缺工具时保留BLOCKED，禁止以其他语言或数据库的结果代替。

## 6. 证据和未验证范围

本轮新增的是指南及具体测试要求；尚无该语言可执行夹具或行为通过证据，状态GUIDE_ONLY。不得把文档存在标成COMPILE_CHECKED/EXECUTED；框架、平台和独立代理遵循均未验证。

指南来源是语言官方资料；自动文档检查仅检查存在性/引用/状态一致，不证明语义穷尽。原书198卡及待补内容不因本页增加而改变。

## 7. 来源

2026-10-04核对；在线资料可能描述比用户项目更新的版本，先按实际项目版本适用。下面支持语言事实，具体测试选择与实施步骤属于本包的工程建议。

- [S1] `https://docs.scala-lang.org/overviews/core/futures.html`
- [S2] `https://docs.scala-lang.org/overviews/core/binary-compatibility-for-library-authors.html`
