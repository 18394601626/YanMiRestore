# Groovy 专项执行适配

**执行适配，不是《代码整洁之道》的新增章节。** 本页为语言专项检查指南，不是完整语言规范、编译器或安全证明；先保持项目已有契约。

## 1. 项目与版本识别

触发线索：.groovy、明确Groovy DSL、build.gradle（不是Kotlin DSL）。确认 Groovy/JDK、动态或@CompileStatic、Gradle/Jenkins等宿主与插件版本。脚本修改可能在配置阶段执行；先限定读取、写入与外部命令权限。

## 2. 数据与语言语义

Groovy truth 会影响0、空集合、空字符串等分支，Elvis回退不等于仅缺失回退。[S1] 区分Map缺键、null和false；不为了缩短判断丢掉有效的0。GString与String的转换及作为键的行为需保留。[S2]

## 3. 失败、资源与并发

闭包捕获的可变状态、delegate/owner解析和脚本binding的作用域先查实际调用。资源异常在finally/withCloseable等项目支持方式中处理；不能因DSL少行就隐藏失败或关闭共享资源。

## 4. 兼容性和不过度抽象

动态调用、property访问、命名Map参数、DSL入口和生成方法属于可能的契约。把def改具体类型或加@CompileStatic可能改变方法选择，必须运行实际宿主而不只groovy语法检查。

## 5. 具体验证契约

计划验证：false/0不被回退覆盖；GString/String键；闭包重复调用无串状态；异常时清理；相同DSL在原宿主仍执行。不得把Jenkins任务成功用本地脚本结果替代。

至少将正常、错误、空值/边界、资源结束与旧消费者分开记录；只编译、只启动工具或只有一个正常用例，不等于完整专项验证。缺工具时保留BLOCKED，禁止以其他语言或数据库的结果代替。

## 6. 证据和未验证范围

本轮新增的是指南及具体测试要求；尚无该语言可执行夹具或行为通过证据，状态GUIDE_ONLY。不得把文档存在标成COMPILE_CHECKED/EXECUTED；框架、平台和独立代理遵循均未验证。

指南来源是语言官方资料；自动文档检查仅检查存在性/引用/状态一致，不证明语义穷尽。原书198卡及待补内容不因本页增加而改变。

## 7. 来源

2026-10-04核对；在线资料可能描述比用户项目更新的版本，先按实际项目版本适用。下面支持语言事实，具体测试选择与实施步骤属于本包的工程建议。

- [S1] `https://docs.groovy-lang.org/latest/html/documentation/core-semantics.html`
- [S2] `https://docs.groovy-lang.org/latest/html/documentation/core-syntax.html`
