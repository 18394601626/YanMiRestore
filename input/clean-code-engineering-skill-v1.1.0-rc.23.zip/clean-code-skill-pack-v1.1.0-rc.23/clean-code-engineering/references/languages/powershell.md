# PowerShell 专项执行适配

**执行适配，不是《代码整洁之道》的新增章节。** 本页为语言专项检查指南，不是完整语言规范、编译器或安全证明；先保持项目已有契约。

## 1. 项目与版本识别

触发线索：.ps1/.psm1/.psd1、pwsh/powershell入口。记录Windows PowerShell 5.1或PowerShell 7.x、模块版本、平台、执行宿主、编码与配置。不是所有原生命令退出码都会自动成为同一种PowerShell错误。

## 2. 数据与语言语义

对象管道不是文本管道。输出对象形状、数组展开和诊断流要分别控制；额外Write-Output可能改变函数返回值，不能把日志随意插入成功输出。原生命令后检查实际LASTEXITCODE，不只读日志。

## 3. 失败、资源与并发

ErrorAction影响非终止性错误的处理；catch不能仅靠默认行为捕获所有非终止性错误。[S1] 根据任务局部使用Stop等策略并恢复调用者偏好，避免全局改$ErrorActionPreference。[S2] Dispose、作业和远程会话独立收尾。

## 4. 兼容性和不过度抽象

函数参数绑定、位置/命名参数、公共别名、模块导出、错误流和JSON深度/编码均是接口。高级函数需要尊重项目ShouldProcess/WhatIf约定，不能以规范化名义执行真实写操作。

## 5. 具体验证契约

计划验证：非终止性错误未被吞；非零原生命令；单对象/多对象返回shape；空/null；异常后偏好与资源恢复；路径含空格及Unicode。平台不同必须分别执行，不用Bash结果代替。

至少将正常、错误、空值/边界、资源结束与旧消费者分开记录；只编译、只启动工具或只有一个正常用例，不等于完整专项验证。缺工具时保留BLOCKED，禁止以其他语言或数据库的结果代替。

## 6. 证据和未验证范围

本轮新增的是指南及具体测试要求；尚无该语言可执行夹具或行为通过证据，状态GUIDE_ONLY。不得把文档存在标成COMPILE_CHECKED/EXECUTED；框架、平台和独立代理遵循均未验证。

指南来源是语言官方资料；自动文档检查仅检查存在性/引用/状态一致，不证明语义穷尽。原书198卡及待补内容不因本页增加而改变。

## 7. 来源

2026-10-04核对；在线资料可能描述比用户项目更新的版本，先按实际项目版本适用。下面支持语言事实，具体测试选择与实施步骤属于本包的工程建议。

- [S1] `https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_commonparameters`
- [S2] `https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_preference_variables`
