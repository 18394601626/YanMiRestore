# TypeScript 专项执行适配

**执行适配，不是《代码整洁之道》的新增内容。** 先按项目事实选择相关小节，不将本次样例版本当作项目升级要求。规则不等于编译器、完整语言规范或安全证明。

## 1. 先读编译与打包契约

读取 tsconfig 及其 extends、target、module、moduleResolution、strict、package exports、项目引用和工具版本；不擅自收紧整个旧仓库。类型检查、发射代码和实际运行分别记录；本例 tsc strict 和 Node 运行不代表项目打包已验证。[S2]

## 2. 静态类型与外部数据分开

as、非空断言和接口不会在运行时验证 JSON。外部数据保留 unknown，经过结构、值域与必要字段检查后再收窄。[S1] 不用 as unknown as 或 any 消掉真正的边界问题；内部已建立前提的断言也不一律禁止。

## 3. 可选字段与只读

先确定缺失、undefined、null 和空值的输入/输出契约，再选择可选字段类型与 exactOptionalPropertyTypes。readonly 不是深层运行时冻结；read-only 视图是否仍指向可变底层对象，要在快照与缓存任务中说明并测试。

## 4. 泛型与公开类型

修改泛型约束、函数返回值、联合类型或重载时检查真实消费方，不只检查定义文件自身。类型可赋值不等于运行时行为相同；检查序列化、d.ts 导出、调用顺序与异常，保留既有 API 兼容策略。

## 5. 异步与错误

继承 JavaScript 的 Promise 与资源问题，不因 tsc 通过就断言异步已等待。用判别联合表达失败还是抛异常服从项目约定；不同分支必须实际测试，默认分支不可静默吞掉新状态。

## 6. 本轮六项契约

TS01—TS06：unknown 正常解析、拒绝伪装的字符串数量、可选/null、readonly 后的嵌套别名、安全整数边界、失败时保持旧数据。编译开启 strict/noEmitOnError，然后执行生成 JS；未验证 React、Vue、构建插件、声明文件发布或所有 tsconfig 选项。

## 来源与验证边界

2026-10-04 查阅以下官方资料，仅用于语言事实；正文检查建议为本包执行适配。浮动文档不代表已验证其最新所有功能。当前真实运行范围以包根 VALIDATION.md 和运行日志为准，独立代理遵循实验为 NOT_RUN。

- [S1] `https://www.typescriptlang.org/docs/handbook/2/everyday-types.html`
- [S2] `https://www.typescriptlang.org/tsconfig/strict.html`

## rc.18 补充：稀疏数组与继承索引

当边界契约要求稠密的外部载荷时，先确认每个数组位置是自身索引，再验证值。map/every等迭代对不存在位置可能不调用回调，不能由“回调没报错”推断所有位置都已验证；继承属性也不是载荷自身字段。原型/稀疏数组在其他业务中可能合法，不将此边界规则强加给所有数组。

批次应先准备和验证，全部成功后再改目标状态。本包追加八项受控测试，在rc.17实现上三项失败，修正后八项通过；不是框架或模型效果对照。来源：`https://tc39.es/ecma262/multipage/indexed-collections.html#sec-array.prototype.map`。
