# Ruby 专项执行适配

**执行适配，不是《代码整洁之道》的新增内容。** 先按项目事实选择相关小节，不将本次样例版本当作项目升级要求。规则不等于编译器、完整语言规范或安全证明。

## 1. 项目、VM与约定

先确认 Ruby 版本、Gemfile.lock、Bundler、MRI/JRuby 等运行环境和真实测试命令。使用项目既有命名、模块和 block 风格，不为简单脚本机械增添类层次；Ruby 版本改变后的参数转发需独立测试。

## 2. 副本与默认值

dup/clone 不是任意对象图的深复制，含数组内可变字符串也要检查共享。[S1] 使用 nil?、Hash#key? 或明确 sentinel 表达不存在，不能用 || 消掉合法 false。冻结外层和业务快照隔离分开验证。

## 3. 输入与批量行为

to_i 风格的宽松转换不能替代完整输入校验；允许空白、符号、不同进制或下划线由接口约定决定。先验证并构造批次，再替换目标；bang 方法是否修改接收者、返回 self/nil 的约定不能顺手改变。

## 4. 异常与清理

通过 block/ensure 把资源所有权变成可见作用域；保留主要异常及必要清理。[S2] 不机械 rescue Exception 后继续，避免吞掉终止或信号；retry 必须有范围、次数和副作用条件。

## 5. 动态入口与兼容

方法查找、模块 prepend、method_missing、回调、反射注册、关键字参数和序列化形成的外部契约不能只靠 grep。Rails/ActiveRecord 另行验证 SQL 次数、回调和事务；本例不验证这些框架。

## 6. 本轮六项契约

RB01—RB06：完整十进制解析、嵌套字符串快照、缺失/nil、StringIO 的 ensure 清理、保留 false、批量失败保持原数组。未验证多线程 VM、Rails、native gem 或最低版本。

## 来源与验证边界

2026-10-04 查阅以下官方资料，仅用于语言事实；正文检查建议为本包执行适配。浮动文档不代表已验证其最新所有功能。当前真实运行范围以包根 VALIDATION.md 和运行日志为准，独立代理遵循实验为 NOT_RUN。

- [S1] `https://docs.ruby-lang.org/en/3.3/Object.html`
- [S2] `https://docs.ruby-lang.org/en/3.3/syntax/exceptions_rdoc.html`
