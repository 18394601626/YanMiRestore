# Swift 专项执行适配

**执行适配，不是《代码整洁之道》的新增内容。** 先按项目事实选择相关小节，不将本次样例版本当作项目升级要求。规则不等于编译器、完整语言规范或安全证明。

## 1. 工具链与部署目标

先读 Package.swift、swift-tools-version、语言模式、Xcode/平台部署目标、模块与依赖锁。Linux Swift 编译成功不等于 Apple SDK 或 SwiftUI/UIKit 通过；Swift 工具版本和 swift-version 模式分别记录。

## 2. 值语义与引用成员

struct 是值类型，但其 class 成员的引用也随结构体复制；容器复制不能自动建立所有可变对象的独立快照。[S1] 按本次模型选择 struct/class/protocol，不为了规整把每种类型都拆出协议或把所有引用强制换值类型。

## 3. 字符串、可选值与数值

String 的字符数与 UTF-8 字节数不同；网络/存储容量按实际编码契约验证。[S2] nil、空字符串、空数组不混同。常规算术、报告溢出和包装算术的失败语义不同，不能用 &+ 掩盖不允许的溢出。

## 4. 清理与错误

通过 defer 明确作用域收尾，抛出类型与 try?/try! 的失败转换必须有依据。[S3] ARC、弱引用和回调生命周期需要真实图；资源释放与业务提交不是一回事，不把 deinit 当可靠的提交接口。

## 5. 并发与兼容

遇到 actor/Sendable/@MainActor/async 时读取当前语言模式与目标运行时的相应文档并独立验证。本版不对这些机制给出验证结论。公共参数标签、协议要求、Codable 键与 C/Objective-C 互操作分别列入影响面。

## 6. 本轮六项契约

SW01—SW06：struct 内引用成员、UTF-8 长度、Int 溢出报告、nil/空、defer 清理、批量解析失败保持状态。Swift6.2.1 编译工具、swift-version 5、Linux；未验证 Swift6 严格并发、Apple平台、Codable 或真实系统资源。

## 来源与验证边界

2026-10-04 查阅以下官方资料，仅用于语言事实；正文检查建议为本包执行适配。浮动文档不代表已验证其最新所有功能。当前真实运行范围以包根 VALIDATION.md 和运行日志为准，独立代理遵循实验为 NOT_RUN。

- [S1] `https://raw.githubusercontent.com/swiftlang/swift-book/main/TSPL.docc/LanguageGuide/ClassesAndStructures.md`
- [S2] `https://raw.githubusercontent.com/swiftlang/swift-book/main/TSPL.docc/LanguageGuide/StringsAndCharacters.md`
- [S3] `https://raw.githubusercontent.com/swiftlang/swift-book/main/TSPL.docc/LanguageGuide/ErrorHandling.md`
