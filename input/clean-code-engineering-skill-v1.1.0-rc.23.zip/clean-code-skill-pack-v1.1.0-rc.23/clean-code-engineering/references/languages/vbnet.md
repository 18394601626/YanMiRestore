# VB.NET 专项执行适配

**执行适配，不是《代码整洁之道》的新增章节。** 本页为语言专项检查指南，不是完整语言规范、编译器或安全证明；先保持项目已有契约。

## 1. 项目与版本识别

触发线索：.vb/.vbproj、Option Strict/Explicit/Infer。识别.NET Framework/.NET、VB版本、Option Strict/Explicit/Infer/Compare、Windows依赖与构建工具。既有COM/WinForms/WPF项目不能因CLI可用就认定跨平台。

## 2. 数据与语言语义

Nothing用于值类型时表示该类型默认值，不能一律理解成空引用。[S1] 保留0、False与Nullable缺失差异；Option Strict影响隐式窄化、晚期绑定等检查，不得为了编译把严格选项关闭。[S2]

## 3. 失败、资源与并发

Using释放范围、Try/Finally失败优先级、事件订阅/解绑和共享对象状态要按所有权核对。Async Sub与可等待返回值不同，先确认事件入口及错误处理者，不机械改掉所有Async Sub。

## 4. 兼容性和不过度抽象

ByRef/ByVal、Optional参数、重载、默认属性、COM/反射和序列化都是消费者契约。参数改为ByVal不保证内部引用对象独立；不要把错误统一转成Nothing返回。

## 5. 具体验证契约

计划验证：Nothing用于值/引用/Nullable的区别；ByRef调用者是否受改动；晚期绑定受选项影响；资源清理；事件解绑；旧命名/可选参数消费者。需真实目标运行时才能标执行通过。

至少将正常、错误、空值/边界、资源结束与旧消费者分开记录；只编译、只启动工具或只有一个正常用例，不等于完整专项验证。缺工具时保留BLOCKED，禁止以其他语言或数据库的结果代替。

## 6. 证据和未验证范围

本轮新增的是指南及具体测试要求；尚无该语言可执行夹具或行为通过证据，状态GUIDE_ONLY。不得把文档存在标成COMPILE_CHECKED/EXECUTED；框架、平台和独立代理遵循均未验证。

指南来源是语言官方资料；自动文档检查仅检查存在性/引用/状态一致，不证明语义穷尽。原书198卡及待补内容不因本页增加而改变。

## 7. 来源

2026-10-04核对；在线资料可能描述比用户项目更新的版本，先按实际项目版本适用。下面支持语言事实，具体测试选择与实施步骤属于本包的工程建议。

- [S1] `https://learn.microsoft.com/en-us/dotnet/visual-basic/language-reference/nothing`
- [S2] `https://learn.microsoft.com/en-us/dotnet/visual-basic/language-reference/statements/option-strict-statement`
