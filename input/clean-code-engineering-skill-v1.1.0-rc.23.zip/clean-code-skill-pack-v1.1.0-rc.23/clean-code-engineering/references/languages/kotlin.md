# Kotlin 专项执行适配

**执行适配，不是《代码整洁之道》的新增内容。** 先按项目事实选择相关小节，不将本次样例版本当作项目升级要求。规则不等于编译器、完整语言规范或安全证明。

## 1. 先区分 JVM/Android/Native/JS

读取 Kotlin 插件、Gradle/Maven、JDK、jvmTarget、source set、协程依赖及平台。build.gradle.kts 通常是构建 DSL，不自动要求把整个 Gradle 工程按 Kotlin 业务模块重写。未运行目标平台就不宣称 Android 或 KMP 支持通过。

## 2. data class 与只读集合

data class 的 copy 是浅复制；MutableList 等引用字段仍可共享。[S1] val 不等于对象不可变，List 视图不等于底层没有其他写入者。快照先定义隔离边界，再复制对应字段，不一律递归复制所有对象。

## 3. 空安全与数值

nullable、空字符串、平台类型和 !! 分开检查；不要为了短代码把原本可恢复失败变成 NPE。[S2] 数字转换和算术结果应按项目值域验证；在 JVM 明确使用溢出检查或预检查，不从 Kotlin 类型安全推断业务计算不会溢出。

## 4. 资源和协程

资源所有权可用 use 表达，主体与 close 双失败的 suppressed 语义应保留。[S3] 协程需要真实 scope、dispatcher、取消传播与子任务等待，禁止把 GlobalScope 当默认生命周期。库和版本未验证时只记录待测，不伪造协程结果。

## 5. Java 互操作与公共 API

默认参数、扩展函数、@JvmName、@JvmOverloads、函数引用、泛型和空注解可能影响旧 Java 调用者。外部 Kotlin 与 Java 消费方分别编译。不要对每个 data class/Service 生成接口。

## 6. 本轮六项契约

KT01—KT06：copy 隔离、Int 加法溢出、完整解析、null 与空、Closeable.use 异常清理、失败不清空旧集合。实际 Kotlin/JVM 1.9、jvmTarget 1.8，在 JDK21 执行；未验证 JDK8 运行、协程库、Android/Native/JS。

## 来源与验证边界

2026-10-04 查阅以下官方资料，仅用于语言事实；正文检查建议为本包执行适配。浮动文档不代表已验证其最新所有功能。当前真实运行范围以包根 VALIDATION.md 和运行日志为准，独立代理遵循实验为 NOT_RUN。

- [S1] `https://kotlinlang.org/docs/data-classes.html`
- [S2] `https://kotlinlang.org/docs/null-safety.html`
- [S3] `https://kotlinlang.org/api/core/kotlin-stdlib/kotlin.io/use.html`
