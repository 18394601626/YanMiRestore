# Dart 专项执行适配

**执行适配，不是《代码整洁之道》的新增章节。** 本页为语言专项检查指南，不是完整语言规范、编译器或安全证明；先保持项目已有契约。

## 1. 项目与版本识别

触发线索：.dart、pubspec.yaml、pubspec.lock。核对 SDK 下限、analyzer 配置、Dart VM/Web/Flutter 平台和锁文件。Dart 单文件可运行不代表 Flutter 插件、Widget 生命周期或 isolate 通信已验证。

## 2. 数据与语言语义

List.unmodifiable 限制列表结构，不自动冻结元素对象。[S1] List/Map 外层复制也不能代替实际模型的快照隔离；nullable 类型不等于能识别字段未提交和显式 null。公共 named parameter 名称属于调用契约。

## 3. 失败、资源与并发

对每个 Future 明确是否等待、谁接收错误，try/finally 包围真正完成的异步工作。[S2] Future.timeout 可提前完成替代 Future，原 Future 仍可能继续完成；测试任务停止不能只检查超时结果。[S3] StreamSubscription/控制器由所有者取消或关闭，并等待必要的清理。

## 4. 兼容性和不过度抽象

保留同步返回与 Future 返回、Stream 的广播/单订阅约定、异常类型、named/required 参数。不能为方便一律转 dynamic、unawaited 或全新 isolate；先确认跨边界的数据模型。

## 5. 具体验证契约

验证：Future 失败仍先清理后返回；共享元素不被误称深复制；缺失/null 清空；批次失败保持状态；旧命名参数消费者仍编译；取消订阅后的监听任务按契约结束。

至少将正常、错误、空值/边界、资源结束与旧消费者分开记录；只编译、只启动工具或只有一个正常用例，不等于完整专项验证。缺工具时保留BLOCKED，禁止以其他语言或数据库的结果代替。

## 6. 证据和未验证范围

本轮提供6项消费者测试与候选源码；工具探测不可用，编译/行为均未验证，状态GUIDE_AND_TEST_SOURCE_BLOCKED。其他版本、平台和框架没有通过证据。

指南来源是语言官方资料；自动文档检查仅检查存在性/引用/状态一致，不证明语义穷尽。原书198卡及待补内容不因本页增加而改变。

## 7. 来源

2026-10-04核对；在线资料可能描述比用户项目更新的版本，先按实际项目版本适用。下面支持语言事实，具体测试选择与实施步骤属于本包的工程建议。

- [S1] `https://api.dart.dev/dart-core/List/List.unmodifiable.html`
- [S2] `https://dart.dev/language/async`
- [S3] `https://api.dart.dev/dart-async/Future/timeout.html`
