# Objective-C 专项执行适配

**执行适配，不是《代码整洁之道》的新增章节。** 本页为语言专项检查指南，不是完整语言规范、编译器或安全证明；先保持项目已有契约。

## 1. 项目与版本识别

触发线索：.m/.mm（须与MATLAB区分）、Xcode项目、明确的ObjC编译命令。先识别 Apple/GNU运行时、SDK、最低系统版本、ARC/MRC、Objective-C++ 混合单元和项目构建配置。Clang 可启动并不能证明 Foundation、Apple SDK 或目标运行时存在。

## 2. 数据与语言语义

对象的 == 比较指针身份，isEqual: 比较相应类型定义的内容。[S1] 明确 mutable 集合及内部对象的复制约定；给 nil 发消息可能让必要工作被静默省略，不用无异常代替成功检查。

## 3. 失败、资源与并发

列出 strong/weak/copy 属性的意图、block 捕获和回调持有关系；对可能的引用环画所有权关系后再调整。不对所有引用机械加 weak。涉及异步队列、autorelease 范围和C句柄时，分别检查释放及回调结束时间。

## 4. 兼容性和不过度抽象

selector 名称、参数数目、protocol、动态注册、KVC/KVO、Swift桥接和序列化都可能是公开入口。静态搜索无调用不证明可删除方法；.mm还需C++异常与资源规则。

## 5. 具体验证契约

计划验证：内容相同但实例不同的对象比较；mutable成员快照；nil接收者导致的未执行；block/owner释放；旧selector消费者；真实目标SDK构建。未安装SDK时只报对应阶段阻塞。

至少将正常、错误、空值/边界、资源结束与旧消费者分开记录；只编译、只启动工具或只有一个正常用例，不等于完整专项验证。缺工具时保留BLOCKED，禁止以其他语言或数据库的结果代替。

## 6. 证据和未验证范围

本轮新增的是指南及具体测试要求；尚无该语言可执行夹具或行为通过证据，状态GUIDE_ONLY。不得把文档存在标成COMPILE_CHECKED/EXECUTED；框架、平台和独立代理遵循均未验证。

指南来源是语言官方资料；自动文档检查仅检查存在性/引用/状态一致，不证明语义穷尽。原书198卡及待补内容不因本页增加而改变。

## 7. 来源

2026-10-04核对；在线资料可能描述比用户项目更新的版本，先按实际项目版本适用。下面支持语言事实，具体测试选择与实施步骤属于本包的工程建议。

- [S1] `https://developer.apple.com/library/archive/documentation/Cocoa/Conceptual/ProgrammingWithObjectiveC/WorkingwithObjects/WorkingwithObjects.html`
