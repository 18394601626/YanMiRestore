# C# 专项执行适配

**执行适配，不是《代码整洁之道》的新增章节。** 本页为语言专项检查指南，不是完整语言规范、编译器或安全证明；先保持项目已有契约。

## 1. 项目与版本识别

触发线索：.cs、.csproj、.sln、global.json。先识别 TargetFramework/TargetFrameworks、LangVersion、Nullable、SDK锁定、NuGet锁和实际测试入口；ASP.NET、Unity与桌面项目分开。文档的新语法不构成升级旧项目的理由。

## 2. 数据与语言语义

record 和 with 不保证内部数组或 List 独立，init 限制也不等于深层不可变。[S1] 先说明返回的是共享身份还是快照，再对实际可变成员做双向修改测试。nullable 编译分析不能替代 JSON/数据库入口校验。

## 3. 失败、资源与并发

using/await using 依据资源接口和项目版本选择，作用域变化会改变释放时间。[S2] CancellationToken 是协作取消；传递 token、观察异常和等待任务结束分别验证，不把调用 Cancel 当作底层工作已停止。[S3]

## 4. 兼容性和不过度抽象

公开委托和方法组、可选参数、泛型约束、程序集调用方、序列化属性名都列入检查。避免为整洁把 IEnumerable 的延迟枚举改成反复执行；不要自动把 DTO 改 record 或每类增加接口。

## 5. 具体验证契约

至少验证：内部可变集合快照独立；取消前不启动工作；失败时释放资源；缺失/null/空串协议；旧委托或命名参数消费者可编译。对数据库查询同时量测次数而不只比较返回值。

至少将正常、错误、空值/边界、资源结束与旧消费者分开记录；只编译、只启动工具或只有一个正常用例，不等于完整专项验证。缺工具时保留BLOCKED，禁止以其他语言或数据库的结果代替。

## 6. 证据和未验证范围

本轮提供6项消费者测试与候选源码；工具探测不可用，编译/行为均未验证，状态GUIDE_AND_TEST_SOURCE_BLOCKED。其他版本、平台和框架没有通过证据。

指南来源是语言官方资料；自动文档检查仅检查存在性/引用/状态一致，不证明语义穷尽。原书198卡及待补内容不因本页增加而改变。

## 7. 来源

2026-10-04核对；在线资料可能描述比用户项目更新的版本，先按实际项目版本适用。下面支持语言事实，具体测试选择与实施步骤属于本包的工程建议。

- [S1] `https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/builtin-types/record`
- [S2] `https://learn.microsoft.com/en-us/dotnet/csharp/language-reference/keywords/using-statement`
- [S3] `https://learn.microsoft.com/en-us/dotnet/standard/parallel-programming/task-cancellation`
