# Rust 专项执行适配

**执行适配，不是原书新增章节，也不是 Rust 编译器或安全证明。** 原书知识仍在01—06与book层。按本次修改读取相关小节；现有公共契约优先，不能机械套用Java异常、Go接口或C++对象层次。

## RS-01 先识别实际项目和验证矩阵

触发：`.rs`、`Cargo.toml`、`Cargo.lock`、`rust-toolchain(.toml)`、`build.rs`或明确Rust任务。先读edition、`rust-version`（MSRV）、锁文件、workspace/default-members、features、target与CI配置。记录真正调用的工具链；不以本例设置替项目升级Rust、切nightly或改resolver。[R1][R2]

默认feature、无默认feature和CI指定组合分别看；`--all-features`不是所有组合的证明，互斥feature不能硬凑成一次构建。跨平台代码、生成绑定和build.rs接入影响面图；不要因默认构建没引用就删除cfg入口。build.rs/过程宏会在构建时运行，外部仓库代码仍须先审阅。[R2]

## RS-02 先确认借用、移动与副本的含义

改参数、返回值和生命周期时，说明调用方是否仍持有所有权、结果是否独立、引用在什么期间有效。借用检查通过不代表业务快照独立；`Arc::clone`共享同一分配，`Clone`的实际语义由类型决定。[R3][R4]

不为消除报错随手增加`clone`、`Arc<Mutex<_>>`、`Box::leak`或`unsafe`。先缩小借用/锁作用域、调整所有权边界；确实要独立副本时，针对实际可变字段做双向修改测试。共享身份本来属于契约时，不能强制深复制。大对象复制需要测量，不能宣称无成本。

## RS-03 可恢复失败与错误契约

业务输入错误按已有`Result`/`Option`契约表达；避免把可恢复失败改为`unwrap`/`expect`导致panic。测试、显然成立的不变量可使用带理由的expect，不机械禁掉所有出现位置。[R5]

检查`?`造成的提前退出、错误分类与`Error::source`是否保留。不要默认把所有错误转字符串或换成某个通用错误crate；公开枚举、trait bounds、返回类型的变化要核对旧调用者。失败前已写入部分状态时，必须说明部分成功或先准备再提交；Rust内存安全不提供业务事务。

## RS-04 资源、锁与退出

明确Drop的所有者及正常返回、`?`、panic路径上的释放时点；显式提交/flush的错误不能寄希望于析构报告。不要承诺abort、进程被强杀或泄漏对象也一定执行Drop。[R6]

Mutex中毒按项目策略处理；`lock().unwrap()`是否允许终止任务要有依据。不要把共享指针的引用计数安全误认为内部数据不需要同步。持锁跨await需核对具体guard/运行时和阻塞风险，不一概用新锁类型修复。[R4][R7]

线程/异步任务分别列出启动、停止、等待完成和资源归属。丢弃标准库JoinHandle会分离线程，不是join；异步运行时的句柄和取消语义必须查该运行时版本，不能从标准线程推断。[R8] 本版未运行Tokio/async或线程调度测试。

## RS-05 unsafe 与 FFI 单独作为高风险边界

`unsafe`不放松未定义行为约束。逐块记录指针对齐、可读写长度、初始化状态、有效生命周期、别名与线程访问前提；安全封装必须在调用处建立前提。`SAFETY`注释解释为何成立，不只写“这里安全”。[R9]

FFI核对调用约定、数据表示、整数宽度、NUL/长度、分配与释放配对、回调存活期，以及panic/异常能否跨该ABI边界。`repr(C)`不是任意Rust类型都能跨语言传递的许可；不把`String`、`Vec`、trait对象直接当C结构使用。需要截获panic时还要核对panic策略，不能以catch_unwind包装推断一切外来异常可捕获。[R10]

## RS-06 公开接口与抽象不过量

先保留函数/方法类型、泛型约束、trait实现、feature可见性和行为，再考虑内部重组。直接调用能编译，不等于函数指针、泛型消费方或匹配错误枚举仍兼容。[R11]

不为每个struct建立trait，不自动把静态分派改为`dyn`，不为了函数短而复制大对象；抽象仍按当前收益与成本判断。生命周期显式与省略两种写法按API可理解性和项目规则处理，不机械追求“更高级”。

## RS-07 测试与工具证据

先使用仓库CI实际命令。适用时核对`cargo fmt --check`、`cargo clippy`、`cargo test --workspace --locked`、文档测试和所需feature/target。`--all-targets`、默认成员或单包结果不能自动代表全workspace与doc-tests。[R12]

Clippy新版本可能改变诊断；不要为绿灯全局allow或擅自把团队警告策略改成硬错误。Miri、sanitizer、fuzz只在工具链支持、任务相关时使用，记录实际命令和覆盖路径；没有这些工具也不能宣称unsafe已经验证。

## RS-08 本版证据边界

随包提供8项Rust行为测试及baseline/fixed两个候选，针对可恢复错误、批处理失败状态、Arc快照隔离和中毒错误。**本轮rustc/cargo未找到，Rust编译与行为执行为BLOCKED、0项运行。** 这些源码是待编译候选，不是通过测试的Rust项目；不以C/C++结果替代。最低版本和feature矩阵也未验证。

当前通用规则与本页可用于指导Rust任务，但尚无独立代理遵循测试。验证状态见完整包VALIDATION与运行器summary，不把“有文档”写成“已完整验证”。

## 外部资料（2026-10-04核对，仅支撑语言事实）

- [R1] Cargo Rust version：`https://doc.rust-lang.org/cargo/reference/rust-version.html`
- [R2] Cargo Features：`https://doc.rust-lang.org/cargo/reference/features.html`
- [R3] Ownership：`https://doc.rust-lang.org/book/ch04-00-understanding-ownership.html`
- [R4] Arc：`https://doc.rust-lang.org/std/sync/struct.Arc.html`
- [R5] Result：`https://doc.rust-lang.org/book/ch09-02-recoverable-errors-with-result.html`
- [R6] Drop：`https://doc.rust-lang.org/std/ops/trait.Drop.html`
- [R7] Mutex：`https://doc.rust-lang.org/std/sync/struct.Mutex.html`
- [R8] JoinHandle：`https://doc.rust-lang.org/std/thread/struct.JoinHandle.html`
- [R9] Unsafe：`https://doc.rust-lang.org/nomicon/what-unsafe-does.html`
- [R10] FFI：`https://doc.rust-lang.org/nomicon/ffi.html`
- [R11] Cargo SemVer：`https://doc.rust-lang.org/cargo/reference/semver.html`
- [R12] cargo test：`https://doc.rust-lang.org/cargo/commands/cargo-test.html`
