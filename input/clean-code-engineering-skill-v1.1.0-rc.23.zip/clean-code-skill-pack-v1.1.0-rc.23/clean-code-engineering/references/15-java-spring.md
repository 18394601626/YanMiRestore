# Java / Spring 企业工程适配

**执行适配，不是《代码整洁之道》的新增章节。** 本页把既有的职责、错误、测试、并发、边界和变更控制原则映射到 Java / Spring 项目。先服从仓库事实和现有契约，不把某个最新 JDK、Spring Boot 或 ORM 版本强加给旧项目。

## 1. 先确认版本与运行方式

涉及 `.java`、`pom.xml`、`build.gradle`、`build.gradle.kts`、Spring 注解或 JVM 并发时，先从仓库确认：JDK/Java language level、Spring Boot/Spring Framework、Maven/Gradle、ORM/SQL 框架、Jackson/序列化配置、测试框架与 CI 命令。存在 toolchain、BOM、parent、插件锁定或企业私服时以仓库为准，**不擅自升级**依赖或语言级别。

不要因为本页举例使用现代 Java 写法，就把 `record`、虚拟线程、新集合 API 或新 Spring 特性引入不支持它们的项目。版本未知时标为 `UNKNOWN` 并先查配置。

## 2. Spring 代理边界：注解存在不等于行为生效

`@Transactional`、`@Async`、`@Cacheable` 等常见能力可能依赖 Spring AOP proxy。默认 proxy 模式下，检查调用是否真正**通过 proxy**；`self-invocation`（同一对象内部 `this.xxx()` 或等价直接调用）不会自动经过代理拦截。AspectJ、类代理、接口代理及项目自定义 AOP 配置可能不同，必须以项目配置为准。

**执行检查：**
- 先画出入口对象、proxy、目标方法和调用方向；不要只看注解是否存在。
- `@Transactional`：核对真正需要事务的入口是否通过代理进入，事务管理是否已启用。
- `@Async`：核对调用是否通过 proxy、实际 executor 是谁，以及异常如何回到调用方。
- `@Cacheable`：核对是否通过代理、key/condition/unless 与缓存管理器，不能用“加了注解”代替行为测试。
- 不默认用 self-injection、`AopContext.currentProxy()` 或拆新 Bean 来“修代理”；先选最小且符合现有架构的事务/异步边界。

## 3. 事务：保护边界、回滚和副作用顺序

事务任务按 deep 处理。先记录**事务边界**、TransactionManager 类型、传播语义、隔离级别/只读意图（若项目依赖）、数据库写入和事务外副作用。

检查 `@Transactional` 的 `propagation`、`rollbackFor`、`noRollbackFor` 与项目默认规则；不要假设所有 checked exception 或所有业务异常都会按同一种方式回滚。catch/convert exception 可能让代理看不到原失败，必须测试实际提交/回滚结果，而不只测试抛出了什么异常。

远程 HTTP、MQ、文件写入等外部副作用放进数据库事务时，核对失败顺序、重试、幂等与补偿；不要仅为“原子”把长耗时外部调用塞进锁或事务。修改传播级别、事务方法可见性或代理入口属于语义变化，写进 Semantic Diff。

## 4. MyBatis / MyBatis-Plus：看生成 SQL 和调用次数

先确认项目使用 MyBatis、MyBatis-Plus、XML、注解 SQL、代码生成器和插件配置；不同版本与插件会改变行为。

- **N+1**：输出正确不代表查询形态正确。循环 `selectById` / mapper 查询时，用 query count 或集成 SQL 日志验证；可批量时再评估批量查询。
- **批量**：批量 API 的提交粒度、主键回填、失败原子性和事务归属必须实测，不用方法名推断。
- **Wrapper**：检查最终条件与生成 SQL。空/缺失条件下的 update/delete 必须有业务保护；不要只相信链式 API 看起来“有限定”。
- **null**：DTO 的 null、数据库 NULL、字段未提交、更新策略可能不是同一语义；保护现有约定。
- **逻辑删除/租户/数据权限**：确认插件是否启用以及对 SELECT/UPDATE/DELETE 的实际影响，不把插件存在当成所有路径都受保护。

## 5. Jackson / DTO / Lombok / record：协议是公开契约

修改字段、getter/setter、构造器、`record` component、Lombok 注解或 Jackson 注解时，先记录实际 JSON Before/After。

重点区分：字段**缺失**、显式 `null`、空字符串、空集合；属性名/别名；默认值；枚举文本；未知字段策略；日期/时区；序列化包含规则。Java 字段名相同不代表 JSON 契约相同，Java 重命名也不代表允许修改外部字段名。

Lombok 会生成方法；`record`、bean getter 和 Jackson 可见性策略会改变属性发现。涉及 OpenAPI/JSON Schema/消息消费者时，把这些节点接入 Change Graph，并使用真实 ObjectMapper/项目配置做契约测试；自写 Map/字符串断言只能算辅助测试。

## 6. Spring Bean 状态与生命周期

Spring singleton Bean 默认会被多个请求/线程共享。把请求用户、当前分页、临时 buffer 等可变请求状态放进实例字段前，必须说明并发所有权；无明确同步/生命周期设计时优先使用局部变量或显式请求上下文。

构造器注入通常有利于显式依赖和测试，但本 Skill 不以“必须构造器注入”作为机械验收条件。初始化、销毁、`@PostConstruct`、事件监听和代理初始化顺序需要按真实容器生命周期验证。

## 7. ThreadLocal：线程池复用意味着上下文会留下来

设置 `ThreadLocal` 时明确谁创建、谁覆盖、谁恢复/清理。在线程池中，线程会复用；请求结束不清理可能把用户、trace、租户等上下文带到下一任务。

拥有该作用域时通常在 `finally` 中恢复之前值或 `remove()`；若存在嵌套上下文，盲目 remove 也可能破坏外层状态，所以先记录 previous value 与所有权。异步执行、调度任务和框架上下文传播不能假设自动继承。

## 8. CompletableFuture / @Async：executor 是契约的一部分

`CompletableFuture.supplyAsync(...)` / `runAsync(...)` 未传 executor 时使用 `ForkJoinPool.commonPool()`；如果项目要求隔离线程池、限流、MDC/安全上下文或可观测性，就不能把省略 executor 当成无害简化。

核对每个 async stage 的 executor、异常包装/传播、timeout、cancel 和任务实际停止能力。`CompletableFuture.cancel`、超时完成或 Spring `@Async` 返回失败，不等价于任意底层阻塞调用被强制终止。

## 9. InterruptedException：不要静默吃掉取消信号

阻塞 API 抛出 `InterruptedException` 时会涉及线程中断状态。若当前层不把该异常继续抛出、且调用方仍需要感知取消，通常应恢复 `Thread.currentThread().interrupt()`；若业务契约明确消费中断，则记录理由和退出语义。不要 catch 后只日志再继续无限重试。

## 10. try-with-resources：Close 异常也会改变公开失败语义

`AutoCloseable`/`try-with-resources` 能简化资源释放，但从手写 `finally` 改成 try-with-resources 仍要保护错误语义。主体和 close 同时失败时，try-with-resources 会保留主体异常并把 close 异常放入 `suppressed`；旧代码若相反，重构会改变调用方看到的异常。

检查资源所有者、关闭顺序、`Throwable.getSuppressed()`、部分成功和提交/flush 型 close。不要为了“更现代”在纯 refactor 中偷偷改变异常优先级。

## 11. Java API 兼容：直接调用能编译还不够

公开方法/类型变化除直接调用外，还检查：**方法引用**、函数式接口赋值、重载解析、泛型边界/擦除、继承/override、接口实现、default method、反射、Spring bean/SpEL/配置绑定入口，以及 Lombok/生成代码形成的 API。

例如把具体返回类型放宽成接口类型，普通 `List x = api()` 可能仍能编译，但原有 `Supplier<ConcreteType> ref = Api::api` 可能失效。此类变化进入兼容性闸门，不因“面向接口更整洁”就默认允许。

新增接口抽象方法会影响现有 implementor；是否使用 default method、适配层、版本化接口或一次性破坏升级由项目兼容策略决定，本 Skill 不替业务选择。

## 12. 最小验证矩阵

| 变化 | 至少验证 |
|---|---|
| `@Transactional` / propagation | 真实代理入口、成功提交、目标异常回滚、catch/转换路径 |
| Mapper/批量 | 结果、SQL/查询次数、事务失败、空条件保护 |
| DTO/JSON | 真实 ObjectMapper 的旧/新 payload、null/缺失/empty、消费者/schema |
| ThreadLocal | 同线程复用、异常路径、嵌套 previous value、清理 |
| CompletableFuture/@Async | 实际 executor、异常、timeout/cancel、上下文 |
| interrupt | 中断前后状态与退出路径 |
| resource | 正常/主体失败/close失败/双失败与 suppressed |
| 公共 API | 直接调用 + 方法引用/实现者/反射或配置入口 |
| singleton state | 并发两请求互不污染 |

轻量私有重命名不要求整套矩阵；由 Rule Router 根据实际风险加载相关小节。

## 13. 常见过度修正

不要机械执行以下做法：每个 Service 都配接口、每个 Mapper 外再包 Repository、所有异常统一 RuntimeException、所有异步都自建线程池、所有 Bean 都拆成无状态类、所有 DTO 改 record、所有旧 API 都立即升级。先证明当前问题和契约，再做最小变更。

## 14. 本轮受控测试与来源边界

`evals/rc7/` 使用 JDK 自包含夹具验证 proxy-like self invocation、回滚契约、ThreadLocal、CompletableFuture、interrupt、方法引用、资源异常、共享状态和 N+1 等行为；它**没有启动真实 Spring / MyBatis / Jackson 运行时**，因此不能把这些夹具冒充框架集成测试。真实项目仍应使用项目依赖和配置运行集成测试。

本页事实核对来源：Spring Framework 官方 transaction / scheduling / cache reference，以及 Oracle JDK 21 `CompletableFuture`、`InterruptedException`、`AutoCloseable`/try-with-resources 文档。项目使用其他版本时以该项目对应版本官方文档为准。
