# C++ / CPP 专项执行适配

**执行适配，不是原书新增章节。** C++不是“C加类”，也不等同Java。使用现有标准库与项目约定，先保护所有权、异常与ABI，再整理表达；不要把所有C头都按C++规则改写。

## CPP-01 识别构建而不是猜版本

从CMake/Makefile、`compile_commands.json`、toolchain、预设与CI确认C++11/14/17/20/23、编译器、标准库、目标平台、异常/RTTI开关和宏。`.cpp/.cc/.cxx/.hpp`只是线索，共享`.h`与大小写后缀看实际编译命令。

不为规整改用新标准的span/expected/ranges，也不自动启用项目禁用的异常。编译、链接与运行分别记录；本机交叉编译成功不是目标平台运行通过。GCC与Clang都用同一个标准库时，不能宣传成覆盖两种标准库。

## CPP-02 RAII、独占与共享的责任

优先由拥有资源的对象管理生命周期；先明确对象、借用指针、文件/锁和自定义deleter的归属。`unique_ptr`表达独占；`shared_ptr`表达共享所有权，并不自动说明业务上应共享。[CPPREF1][CPPREF2]

不要让两个独立智能指针控制块接管同一个raw pointer，也不要混用malloc/free与new/delete。优先Rule of Zero；需要自定义析构、复制或移动时检查其余特殊成员，不机械生成“全套五法则”。RAII不是把所有指针改成shared_ptr。[CPPREF1]

## CPP-03 副本、移动和共享状态

复制`vector<shared_ptr<T>>`仍可共享T。承诺独立快照时核对实际可变子对象并做双向扰动；共享身份与对象图本来属于契约时，不强行深拷贝。[CPPREF2]

`std::move`只是允许后续使用移动语义的转换，不保证资源已经移动；检查真实重载、const、noexcept和移动后对象的允许状态。不在return处机械添加move，也不为消除复制改成可能悬空的返回引用。[CPPREF1]

## CPP-04 借用视图与生命周期

`string_view`和span等视图不拥有所指数据；从临时对象、局部字符串或随后重分配的容器生成视图时，必须记录其有效期。[CPPREF3][CPPREF4]

公开API从`std::string`改成`std::string_view`不仅是性能优化：返回类型、函数指针、存储期和调用者使用方式都可能变化。要保留旧签名或明确授权迁移；不要通过运行一个本来已悬空的引用来“证明安全”。容器扩容/擦除导致迭代器与引用失效，需核对具体容器和操作。[CPPREF5]

## CPP-05 异常安全与提交点

为相关操作说明保证级别：失败时仅保持对象可用，还是保持原值不变，或承诺不抛出。先准备临时结果再swap是一种实现强保证的方式，不是要求所有函数增加复制与事务层。

保持异常类型、传播、清理和外部副作用的顺序。析构期间不让额外异常掩盖原失败；`noexcept`是行为及类型契约，不能为了“更高效”随手添加；异常逃出非抛出函数涉及终止行为。[CPPREF6]

无异常项目按已有错误码/结果类型实现同样清楚的失败语义，不强行打开异常或引入新结果库。失败与成功路径都验证资源在约定时点释放。

## CPP-06 并发、锁与性能

智能指针管理生命周期，不等于内部对象访问已经同步。检查数据、锁、回调、线程退出和外部调用的实际关系。不要把持有锁的guard提到过长作用域；也不能为短函数把锁提早释放。[CPPREF2]

性能声明来自同条件测量。检查复制/移动次数、分配、锁范围和I/O调用次数；加入RAII或视图不自动代表更快。TSan、调度/取消和长期负载与本版单线程样例是不同证据，不混报。

## CPP-07 公开类型、ABI 与C/Rust边界

类布局、虚表、模板实例、重载、cv/ref限定、noexcept、符号可见性和标准库ABI均可能影响调用者。直接调用外，还核对函数指针/成员指针、继承实现者、链接和真实发布组合；普通源码测试不能证明跨版本二进制兼容。

跨C/Rust边界核对语言链接、布局、长度、分配器、错误返回和回调存活期。不要让异常越过不允许展开的边界，不把`extern "C"`当成自动跨语言异常协议。Rust FFI还需读[对应小节](17-rust.md)，共享C头按[C规则](18-c.md)同时验证。

## CPP-08 工具与本版证据范围

遵守项目格式与clang-tidy等静态检查配置，不把全局抑制警告当修复。ASan/UBSan只说明本次启用检查未观察到对应问题；不能据此宣称无所有未定义行为、无竞态或ABI完全兼容。[CPPREF7]

本版实际运行10项C++行为检查：嵌套共享对象隔离、空指针成员、批量解析原子性、RAII异常清理、独占移动和拥有型字符串；另编译旧签名消费方，并让改变返回类型的受控变体编译失败。资源计数器只是逻辑资源替身，不是操作系统句柄测试。示例与实际工具链见VALIDATION；未测MSVC、Windows、C++11/14/23或完整生产仓库。

## 外部资料（2026-10-04核对）

- [CPPREF1] C++ Core Guidelines：`https://isocpp.github.io/CppCoreGuidelines/CppCoreGuidelines`
- [CPPREF2] WG21草案shared_ptr：`https://eel.is/c++draft/util.smartptr.shared`
- [CPPREF3] WG21草案string_view：`https://eel.is/c++draft/string.view`
- [CPPREF4] WG21草案对象生命周期：`https://eel.is/c++draft/basic.life`
- [CPPREF5] WG21草案vector修改与失效：`https://eel.is/c++draft/vector.modifiers`
- [CPPREF6] WG21草案异常规格：`https://eel.is/c++draft/except.spec`
- [CPPREF7] Clang ASan / UBSan：`https://clang.llvm.org/docs/AddressSanitizer.html`、`https://clang.llvm.org/docs/UndefinedBehaviorSanitizer.html`

草案与指南用于解释语言机制，不是本包对全部C++标准的合规证明；项目使用的标准和具体实现仍须单独确认。
