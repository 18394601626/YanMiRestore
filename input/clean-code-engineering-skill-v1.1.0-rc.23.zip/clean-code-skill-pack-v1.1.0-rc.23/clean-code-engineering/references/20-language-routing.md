# 多语言按需路由与验证状态

**执行适配；这是检索指引，不是自动发现插件或完整语言规范。** 根据任务涉及的实际项目证据选择资料；不全量加载所有语言。使用者仍须检查代理是否真正读取和执行。

## 识别顺序

先看用户明确目标、实际编译/运行命令、项目清单和 shebang，再用扩展名缩小范围。混合仓库只选本次变更涉及的语言和边界。`.h` 根据 C/C++ 编译入口决定；`.m` 可能是 Objective-C 或 MATLAB；`.pl` 需排除其他语言；`.ts` 也要结合文件内容。`build.gradle.kts` 是构建 DSL 时，不冒充 Kotlin 业务测试。

## 已有专项资料（30项，不等于全部验证）

| 语言 | 触发线索 | 阅读位置 |
|---|---|---|
| Go | .go / go.mod / go.work | [Go](08-go.md) |
| Java | .java / pom.xml / Spring | [Java/Spring](15-java-spring.md) |
| Rust | .rs / Cargo.toml | [Rust](17-rust.md) |
| C | .c / 确认的 C 编译单元 | [C](18-c.md) |
| C++ | .cpp/.cc/.cxx / 确认的 C++ 单元 | [C++](19-cpp.md) |
| Python | .py / pyproject.toml | [Python](languages/python.md) |
| JavaScript | .js/.mjs/.cjs / package.json | [JavaScript](languages/javascript.md) |
| TypeScript | .ts/.tsx / tsconfig | [TypeScript](languages/typescript.md) |
| PHP | .php / composer.json | [PHP](languages/php.md) |
| Ruby | .rb / Gemfile | [Ruby](languages/ruby.md) |
| Kotlin | .kt / Kotlin source set | [Kotlin](languages/kotlin.md) |
| Swift | .swift / Package.swift / Xcode | [Swift](languages/swift.md) |
| Perl | .pl/.pm + Perl shebang | [Perl](languages/perl.md) |
| Bash | shell shebang / 明确 Bash 命令 | [Bash](languages/bash.md) |
| Fortran | .f/.for/.f90/.f95 + 实际编译命令 | [Fortran](languages/fortran.md) |
| C# | .cs、.csproj、.sln、global.json | [C#](languages/csharp.md) |
| Dart | .dart、pubspec.yaml、pubspec.lock | [Dart](languages/dart.md) |
| Objective-C | .m/.mm（须与MATLAB区分）、Xcode项目、明确的ObjC编译命令 | [Objective-C](languages/objective-c.md) |
| Scala | .scala、build.sbt、project/build.properties、Scala CLI配置 | [Scala](languages/scala.md) |
| Groovy | .groovy、明确Groovy DSL、build.gradle（不是Kotlin DSL） | [Groovy](languages/groovy.md) |
| F# | .fs/.fsx/.fsproj、global.json | [F#](languages/fsharp.md) |
| VB.NET | .vb/.vbproj、Option Strict/Explicit/Infer | [VB.NET](languages/vbnet.md) |
| R | .R/.Rmd、DESCRIPTION、renv.lock | [R](languages/r.md) |
| Julia | .jl、Project.toml、Manifest.toml | [Julia](languages/julia.md) |
| MATLAB | .m/.mlx与MATLAB调用环境（须排除ObjC） | [MATLAB](languages/matlab.md) |
| Lua | .lua、宿主配置、Lua/LuaJIT版本 | [Lua](languages/lua.md) |
| PowerShell | .ps1/.psm1/.psd1、pwsh/powershell入口 | [PowerShell](languages/powershell.md) |
| SQL 方言族 | .sql、迁移目录、数据库驱动和服务端身份 | [SQL 方言族](languages/sql.md) |
| Elixir | .ex/.exs、mix.exs、mix.lock | [Elixir](languages/elixir.md) |
| Erlang | .erl/.hrl、rebar.config、OTP应用配置 | [Erlang](languages/erlang.md) |

## 避免机械跨语言改写

JavaScript 与 TypeScript 有共享运行时，但 TS 类型检查不能充当 JS 运行验证；必要时读两者相关小节。Bash 与 POSIX Shell 分别判断，不把 Bash6或5的能力强加给 sh。Kotlin/JVM 与 Android/Native/JS、Swift/Linux 与 Apple SDK、PHP CLI 与 FPM/常驻服务分别记状态。框架按自己的运行环境和版本另验，不用语言计数替代。

## 指南覆盖与执行状态分开

约定的28个核心项与Elixir/Erlang两项扩展共30项均已提供独立指南。**本次新增15份指南不等于15种运行时都通过**：SQL只验证临时SQLite；C#/Dart有候选源码但编译工具阻塞；其余新指南尚无执行夹具。旧语言执行状态保留历史来源。

没有匹配时明确“仅通用规则、专项未验证”，先确认语言，不默认套用Java。HTML/CSS、JSON/YAML和构建配置单列，不增加语言计数。SQL按数据库方言分别验证；MATLAB不能用Octave替代，Objective-C需要目标运行时，Bash不是所有POSIX Shell。

## 验证状态

[语言清单](../assets/language-support.json)分别记录guide、fixture、execution、framework_validation与agent_behavior_tested。NOT_RUN不等于PASS，工具可启动不等于完整语言支持。没有新的执行证据，不覆盖旧状态；指南存在不代表代理已经读取。当前没有独立模型A/B、IDE自动加载或生产框架证据。

## 工具范围

本批运行器的 `--languages batch` 只等于rc.17新增的Python/JavaScript/TypeScript/PHP/Ruby/Kotlin/Swift/Perl/Bash/Fortran十项；可传明确逗号列表。它不是30项的 all。输出必须列出 requested_languages、实际运行、编译失败/阻塞及未请求范围。历史入口的 all 保持原义，不静默扩大或重命名旧命令。

## 收尾

把相关语言规则用于本次范围、完成适用回归即可停止；不要为“多语言适配”统一语言习惯、升级依赖或修改无关文件。专项指南以官方资料支持语言事实，以实际日志支持运行结论，两者不得混写。

rc.18入口单独列出本次请求：旧十语言回归、TypeScript八项补充、SQLite十二项、C#/Dart各六项候选的编译尝试。其余注册语言明确列为NOT_REQUESTED或GUIDE_ONLY；旧入口含义不变。
